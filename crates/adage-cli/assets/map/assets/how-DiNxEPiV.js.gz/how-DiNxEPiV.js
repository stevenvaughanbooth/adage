import{n as e,r as t,t as n}from"./rolldown-runtime-hePW80VL.js";var r=n((e=>{var t=Symbol.for(`react.transitional.element`),n=Symbol.for(`react.portal`),r=Symbol.for(`react.fragment`),i=Symbol.for(`react.strict_mode`),a=Symbol.for(`react.profiler`),o=Symbol.for(`react.consumer`),s=Symbol.for(`react.context`),c=Symbol.for(`react.forward_ref`),l=Symbol.for(`react.suspense`),u=Symbol.for(`react.memo`),d=Symbol.for(`react.lazy`),f=Symbol.for(`react.activity`),p=Symbol.for(`react.view_transition`),m=Symbol.iterator;function h(e){return typeof e!=`object`||!e?null:(e=m&&e[m]||e[`@@iterator`],typeof e==`function`?e:null)}var g={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},_=Object.assign,v={};function y(e,t,n){this.props=e,this.context=t,this.refs=v,this.updater=n||g}y.prototype.isReactComponent={},y.prototype.setState=function(e,t){if(typeof e!=`object`&&typeof e!=`function`&&e!=null)throw Error(`takes an object of state variables to update or a function which returns an object of state variables.`);this.updater.enqueueSetState(this,e,t,`setState`)},y.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,`forceUpdate`)};function b(){}b.prototype=y.prototype;function x(e,t,n){this.props=e,this.context=t,this.refs=v,this.updater=n||g}var S=x.prototype=new b;S.constructor=x,_(S,y.prototype),S.isPureReactComponent=!0;var C=Array.isArray;function w(){}var T={H:null,A:null,T:null,S:null},E=Object.prototype.hasOwnProperty;function D(e,n,r){var i=r.ref;return{$$typeof:t,type:e,key:n,ref:i===void 0?null:i,props:r}}function O(e,t){return D(e.type,t,e.props)}function k(e){return typeof e==`object`&&!!e&&e.$$typeof===t}function A(e){var t={"=":`=0`,":":`=2`};return`$`+e.replace(/[=:]/g,function(e){return t[e]})}var j=/\/+/g;function M(e,t){return typeof e==`object`&&e&&e.key!=null?A(``+e.key):t.toString(36)}function N(e){switch(e.status){case`fulfilled`:return e.value;case`rejected`:throw e.reason;default:switch(typeof e.status==`string`?e.then(w,w):(e.status=`pending`,e.then(function(t){e.status===`pending`&&(e.status=`fulfilled`,e.value=t)},function(t){e.status===`pending`&&(e.status=`rejected`,e.reason=t)})),e.status){case`fulfilled`:return e.value;case`rejected`:throw e.reason}}throw e}function P(e,r,i,a,o){var s=typeof e;(s===`undefined`||s===`boolean`)&&(e=null);var c=!1;if(e===null)c=!0;else switch(s){case`bigint`:case`string`:case`number`:c=!0;break;case`object`:switch(e.$$typeof){case t:case n:c=!0;break;case d:return c=e._init,P(c(e._payload),r,i,a,o)}}if(c)return o=o(e),c=a===``?`.`+M(e,0):a,C(o)?(i=``,c!=null&&(i=c.replace(j,`$&/`)+`/`),P(o,r,i,``,function(e){return e})):o!=null&&(k(o)&&(o=O(o,i+(o.key==null||e&&e.key===o.key?``:(``+o.key).replace(j,`$&/`)+`/`)+c)),r.push(o)),1;c=0;var l=a===``?`.`:a+`:`;if(C(e))for(var u=0;u<e.length;u++)a=e[u],s=l+M(a,u),c+=P(a,r,i,s,o);else if(u=h(e),typeof u==`function`)for(e=u.call(e),u=0;!(a=e.next()).done;)a=a.value,s=l+M(a,u++),c+=P(a,r,i,s,o);else if(s===`object`){if(typeof e.then==`function`)return P(N(e),r,i,a,o);throw r=String(e),Error(`Objects are not valid as a React child (found: `+(r===`[object Object]`?`object with keys {`+Object.keys(e).join(`, `)+`}`:r)+`). If you meant to render a collection of children, use an array instead.`)}return c}function F(e,t,n){if(e==null)return e;var r=[],i=0;return P(e,r,``,``,function(e){return t.call(n,e,i++)}),r}function I(e){if(e._status===-1){var t=e._result,n=t();n.then(function(t){(e._status===0||e._status===-1)&&(e._status=1,e._result=t,n.status===void 0&&(n.status=`fulfilled`,n.value=t))},function(t){(e._status===0||e._status===-1)&&(e._status=2,e._result=t,n.status===void 0&&(n.status=`rejected`,n.reason=t))}),e._status===-1&&(e._status=0,e._result=n)}if(e._status===1)return e._result.default;throw e._result}var L=typeof reportError==`function`?reportError:function(e){if(typeof window==`object`&&typeof window.ErrorEvent==`function`){var t=new window.ErrorEvent(`error`,{bubbles:!0,cancelable:!0,message:typeof e==`object`&&e&&typeof e.message==`string`?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process==`object`&&typeof process.emit==`function`){process.emit(`uncaughtException`,e);return}console.error(e)};function ee(e){var t=T.T,n={};n.types=t===null?null:t.types,T.T=n;try{var r=e(),i=T.S;i!==null&&i(n,r),typeof r==`object`&&r&&typeof r.then==`function`&&r.then(w,L)}catch(e){L(e)}finally{t!==null&&n.types!==null&&(t.types=n.types),T.T=t}}function te(e){var t=T.T;if(t!==null){var n=t.types;n===null?t.types=[e]:n.indexOf(e)===-1&&n.push(e)}else ee(te.bind(null,e))}var ne={map:F,forEach:function(e,t,n){F(e,function(){t.apply(this,arguments)},n)},count:function(e){var t=0;return F(e,function(){t++}),t},toArray:function(e){return F(e,function(e){return e})||[]},only:function(e){if(!k(e))throw Error(`React.Children.only expected to receive a single React element child.`);return e}};e.Activity=f,e.Children=ne,e.Component=y,e.Fragment=r,e.Profiler=a,e.PureComponent=x,e.StrictMode=i,e.Suspense=l,e.ViewTransition=p,e.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=T,e.__COMPILER_RUNTIME={__proto__:null,c:function(e){return T.H.useMemoCache(e)}},e.addTransitionType=te,e.cache=function(e){return function(){return e.apply(null,arguments)}},e.cacheSignal=function(){return null},e.cloneElement=function(e,t,n){if(e==null)throw Error(`The argument must be a React element, but you passed `+e+`.`);var r=_({},e.props),i=e.key;if(t!=null)for(a in t.key!==void 0&&(i=``+t.key),t)!E.call(t,a)||a===`key`||a===`__self`||a===`__source`||a===`ref`&&t.ref===void 0||(r[a]=t[a]);var a=arguments.length-2;if(a===1)r.children=n;else if(1<a){for(var o=Array(a),s=0;s<a;s++)o[s]=arguments[s+2];r.children=o}return D(e.type,i,r)},e.createContext=function(e){return e={$$typeof:s,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null},e.Provider=e,e.Consumer={$$typeof:o,_context:e},e},e.createElement=function(e,t,n){var r,i={},a=null;if(t!=null)for(r in t.key!==void 0&&(a=``+t.key),t)E.call(t,r)&&r!==`key`&&r!==`__self`&&r!==`__source`&&(i[r]=t[r]);var o=arguments.length-2;if(o===1)i.children=n;else if(1<o){for(var s=Array(o),c=0;c<o;c++)s[c]=arguments[c+2];i.children=s}if(e&&e.defaultProps)for(r in o=e.defaultProps,o)i[r]===void 0&&(i[r]=o[r]);return D(e,a,i)},e.createRef=function(){return{current:null}},e.forwardRef=function(e){return{$$typeof:c,render:e}},e.isValidElement=k,e.lazy=function(e){return{$$typeof:d,_payload:{_status:-1,_result:e},_init:I}},e.memo=function(e,t){return{$$typeof:u,type:e,compare:t===void 0?null:t}},e.startTransition=ee,e.unstable_useCacheRefresh=function(){return T.H.useCacheRefresh()},e.use=function(e){return T.H.use(e)},e.useActionState=function(e,t,n){return T.H.useActionState(e,t,n)},e.useCallback=function(e,t){return T.H.useCallback(e,t)},e.useContext=function(e){return T.H.useContext(e)},e.useDebugValue=function(){},e.useDeferredValue=function(e,t){return T.H.useDeferredValue(e,t)},e.useEffect=function(e,t){return T.H.useEffect(e,t)},e.useEffectEvent=function(e){return T.H.useEffectEvent(e)},e.useId=function(){return T.H.useId()},e.useImperativeHandle=function(e,t,n){return T.H.useImperativeHandle(e,t,n)},e.useInsertionEffect=function(e,t){return T.H.useInsertionEffect(e,t)},e.useLayoutEffect=function(e,t){return T.H.useLayoutEffect(e,t)},e.useMemo=function(e,t){return T.H.useMemo(e,t)},e.useOptimistic=function(e,t){return T.H.useOptimistic(e,t)},e.useReducer=function(e,t,n){return T.H.useReducer(e,t,n)},e.useRef=function(e){return T.H.useRef(e)},e.useState=function(e){return T.H.useState(e)},e.useSyncExternalStore=function(e,t,n){return T.H.useSyncExternalStore(e,t,n)},e.useTransition=function(){return T.H.useTransition()},e.version=`19.3.0`})),i=n(((e,t)=>{t.exports=r()})),a=n((e=>{var t=i();function n(e){var t=`https://react.dev/errors/`+e;if(1<arguments.length){t+=`?args[]=`+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+=`&args[]=`+encodeURIComponent(arguments[n])}return`Minified React error #`+e+`; visit `+t+` for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`}function r(){}var a={d:{f:r,r:function(){throw Error(n(522))},D:r,C:r,L:r,m:r,X:r,S:r,M:r},p:0,findDOMNode:null},o=Symbol.for(`react.portal`),s=Symbol.for(`react.recoverable`),c=Symbol.for(`react.optimistic_key`);function l(e,t,n){var r=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:o,key:r==null?null:r===c?c:``+r,children:e,containerInfo:t,implementation:n}}var u=t.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function d(e,t){if(e===`font`)return``;if(typeof t==`string`)return t===`use-credentials`?t:``}e.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=a,e.browser=function(e){return{$$typeof:s,_reason:e}},e.createPortal=function(e,t){var r=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!t||t.nodeType!==1&&t.nodeType!==9&&t.nodeType!==11)throw Error(n(299));return l(e,t,null,r)},e.flushSync=function(e){var t=u.T,n=a.p;try{if(u.T=null,a.p=2,e)return e()}finally{u.T=t,a.p=n,a.d.f()}},e.preconnect=function(e,t){typeof e==`string`&&(t?(t=t.crossOrigin,t=typeof t==`string`?t===`use-credentials`?t:``:void 0):t=null,a.d.C(e,t))},e.prefetchDNS=function(e){typeof e==`string`&&a.d.D(e)},e.preinit=function(e,t){if(typeof e==`string`&&t&&typeof t.as==`string`){var n=t.as,r=d(n,t.crossOrigin),i=typeof t.integrity==`string`?t.integrity:void 0,o=typeof t.fetchPriority==`string`?t.fetchPriority:void 0;n===`style`?a.d.S(e,typeof t.precedence==`string`?t.precedence:void 0,{crossOrigin:r,integrity:i,fetchPriority:o}):n===`script`&&a.d.X(e,{crossOrigin:r,integrity:i,fetchPriority:o,nonce:typeof t.nonce==`string`?t.nonce:void 0})}},e.preinitModule=function(e,t){if(typeof e==`string`){if(typeof t==`object`&&t){if(t.as==null||t.as===`script`){var n=d(t.as,t.crossOrigin);a.d.M(e,{crossOrigin:n,integrity:typeof t.integrity==`string`?t.integrity:void 0,nonce:typeof t.nonce==`string`?t.nonce:void 0,fetchPriority:typeof t.fetchPriority==`string`?t.fetchPriority:void 0})}}else t??a.d.M(e)}},e.preload=function(e,t){if(typeof e==`string`&&typeof t==`object`&&t&&typeof t.as==`string`){var n=t.as,r=d(n,t.crossOrigin);a.d.L(e,n,{crossOrigin:r,integrity:typeof t.integrity==`string`?t.integrity:void 0,nonce:typeof t.nonce==`string`?t.nonce:void 0,type:typeof t.type==`string`?t.type:void 0,fetchPriority:typeof t.fetchPriority==`string`?t.fetchPriority:void 0,referrerPolicy:typeof t.referrerPolicy==`string`?t.referrerPolicy:void 0,imageSrcSet:typeof t.imageSrcSet==`string`?t.imageSrcSet:void 0,imageSizes:typeof t.imageSizes==`string`?t.imageSizes:void 0,media:typeof t.media==`string`?t.media:void 0})}},e.preloadModule=function(e,t){if(typeof e==`string`){if(t){var n=d(t.as,t.crossOrigin);a.d.m(e,{as:typeof t.as==`string`&&t.as!==`script`?t.as:void 0,crossOrigin:n,integrity:typeof t.integrity==`string`?t.integrity:void 0,nonce:typeof t.nonce==`string`?t.nonce:void 0,fetchPriority:typeof t.fetchPriority==`string`?t.fetchPriority:void 0})}else a.d.m(e)}},e.requestFormReset=function(e){a.d.r(e)},e.unstable_batchedUpdates=function(e,t){return e(t)},e.useFormState=function(e,t,n){return u.H.useFormState(e,t,n)},e.useFormStatus=function(){return u.H.useHostTransitionStatus()},e.version=`19.3.0`})),o=n(((e,t)=>{function n(){if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<`u`&&typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE==`function`)try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n)}catch(e){console.error(e)}}n(),t.exports=a()})),s=t(i(),1),c=t(o(),1),l=e=>JSON.stringify([e.repo,e.session]),u=e=>JSON.stringify([e.repo,e.reference,e.id]);function d(e,t){return e.measurement_history?.find(e=>e.version===t)??e}function f(e,t,n){let r=u(t);return[...e.directives??[],...e.would_have??[],...e.judgements??[]].some(e=>e.route_key===r&&(!n||e.version===n))}function p(e){if(e.trace_sessions)return e.trace_sessions;let t=new Map;for(let n of e.trace_events??e.events){let e=l(n),r=t.get(e);r?(r.events_total++,r.end_ts=Math.max(r.end_ts??0,n.ts)):t.set(e,{session:n.session,repo:n.repo,arm:n.arm,events_total:1,start_ts:n.ts,end_ts:n.ts})}return[...t.values()]}var m=[`fire`,`prime`,`inhibit`],h=[`nascent`,`forming`,`firm`,`dormant`,`extinguished`,`quiet`],g={green:`fire`,yellow:`prime`,red:`inhibit`,fire:`fire`,prime:`prime`,inhibit:`inhibit`};function _(e){return e&&g[e.toLowerCase()]||null}var v={draft:`nascent`,probation:`forming`,active:`firm`,stale:`dormant`,retired:`extinguished`,demoted:`firm`,nascent:`nascent`,forming:`forming`,firm:`firm`,dormant:`dormant`,extinguished:`extinguished`,weakened:`firm`};function y(e){return e&&v[e.toLowerCase()]||`firm`}function b(e){return!!e.instinct}function x(e){return!!e.quiet}function S(e){return e.step?.kind===`card`}var C=.1;function w(e){let t=Math.abs(e)<.005?0:e;return`${t<0?`−`:`+`}${Math.abs(t).toFixed(2)}`}function T(e){let t=e.evidence;return S(e)&&e.step.card?`${e.step.card.passed}/${e.step.card.sessions} passed`:t.basis===`value`&&t.why?`~${t.why.gain.toFixed(2)} calls`:b(e)&&!t.opportunities?`instinct`:`${t.support}/${t.opportunities}`}function E(e){let t=e.evidence;return S(e)&&e.step.card?`from ${ie(e.step.card.sessions,`trace`)} of its family, ${e.step.card.passed} passed`:t.basis===`value`&&t.why?`saves ~${t.why.gain.toFixed(2)} calls when followed (P(saves) ${t.why.conf.toFixed(2)})`:`${t.support}/${t.opportunities} traces took it`}function D(e){switch(e.kind){case`prompt`:return`prompt`;case`after_command`:return`after command`;case`after_failure`:return`after failure`;case`after_edit`:return`after edit`;case`session_start`:return`session start`;case`intent`:return`intent`;case`context`:return`context`;default:return e.kind.replace(/_/g,` `)}}function O(e){switch(e.kind){case`run`:return`run`;case`read_batch`:return`read together`;case`avoid`:return`run instead`;case`advise`:return`advise`;case`sequence`:return`steps in order`;case`card`:return`procedure card`;default:return e.kind.replace(/_/g,` `)}}function k(e){switch(e){case`followed`:return`followed`;case`ignored`:case`derailed`:return`not observed within the window`;case`obligation_met`:return`met`;case`misfired`:case`followed_failed`:return`misfired`;default:return e.replace(/_/g,` `)}}function A(e){return e===`control`||e===`holdout`?`control`:e===`treated`?`with reflexes`:e??`unknown`}function j(e){return b(e)?`Shipped with Adage`:e.imported?`From the pack`:`From conditioning`}function M(e){return b(e)?`Instincts carry no traces of their own: bound from what this repository declares.`:e.imported?`Counted in the traces the pack was conditioned on, not in yours.`:S(e)?`Learned from earlier traces of a family of similar tasks in this repository.`:e.evidence.basis===`value`?`Formed on value: the calls saved when the step is taken, estimated from traces that took it and those that did not.`:`Counted in past traces when Adage conditioned this reflex.`}function N(e){switch(e){case`saved`:return`saved`;case`adds_cost`:return`adds cost`;case`no_difference`:return`no measurable difference yet`;default:return`measuring`}}function P(e){let t=Math.abs(e);return t>=100?`$${t.toFixed(0)}`:t>=1?`$${t.toFixed(2)}`:`$${t.toFixed(3)}`}function F(e,t){if(!e)return``;let n=e.interpreter?` at ${e.interpreter}`:``;if(e.rewrite){let r=e.rewrite===`test`?`test run`:e.rewrite===`repro`?`reproduction run`:`${e.rewrite} run`;return t?`would have pointed this ${r}${n} (control: left as it was)`:`pointed this ${r}${n}, the project's environment`}if(e.advise){let n=e.advise===`pip-install`?`pip install into the system Python`:e.advise===`permissions`?`a command your permission rules would not allow rewritten`:e.advise;return t?`would have advised on ${n} (control)`:`advised on ${n}`}return``}var I=`Live since installed`,L=`Control: traces where Adage withheld the reflex on purpose, so the agent worked unaided: the baseline.`,ee={promote:`strengthen`,demote:`weaken`,reject:`extinguish`,retire:`extinguish`,approve:`approve`,pin:`pin`,dismiss:`dismiss`,strengthen:`strengthen`,weaken:`weaken`,extinguish:`extinguish`};function te(e){return ee[e]??e}var ne={strengthen:`prime → fire, within its ceiling`,weaken:`fire → prime, held across conditioning`,extinguish:`stop delivering it`,approve:`accept it as it is`,pin:`lock it against re-learning`,dismiss:`keep it; silence the proposed change`};function R(e){return ne[te(e)]??``}function re(e,t){return`adage review ${te(e)} ${z(t.reference)} ${z(t.id)}`}function z(e){return/^[A-Za-z0-9@%_+=:,./-]+$/.test(e)?e:`'${e.replace(/'/g,`'\\''`)}'`}function B(e){let t=(e.review?.verbs??[]).map(te),n=y(e.state)===`nascent`?[`approve`,`extinguish`,`strengthen`,`weaken`,`pin`,`dismiss`]:[`strengthen`,`weaken`,`extinguish`,`approve`,`pin`,`dismiss`];return[...new Set(t)].sort((e,t)=>n.indexOf(e)-n.indexOf(t))}function ie(e,t,n=`${t}s`){return`${e} ${e===1?t:n}`}var ae=[[/\broute\(s\)/g,`reflex(es)`],[/\bsession\(s\)/g,`trace(s)`],[/\bgreen\b/g,`fire`],[/\byellow\b/g,`prime`],[/\bred\b/g,`inhibit`],[/\broutes\b/g,`reflexes`],[/\broute\b/g,`reflex`],[/\bsessions\b/g,`traces`],[/\bholdout\b/g,`control`],[/\bretired\b/g,`extinguished`],[/\bdrafted\b/g,`nascent`],[/\bprobation\b/g,`forming`],[/\blearned\b/g,`conditioned`]];function oe(e){let t=e=>e.split(` `).map(e=>e.includes(`/`)||e.includes(`\\`)?e:ae.reduce((e,[t,n])=>e.replace(t,n),e)).join(` `);return e.split("`").map((e,n)=>n%2==1?e:t(e)).join("`")}function se(e){return e.slice(0,8)}var ce=[`nascent`,`quiet`,`dormant`,`extinguished`];function le(e){return x(e)?`quiet`:y(e.state)}function ue(e){return`${e.reference}::${e.id}`}function de(e,t){if(!e||!t)return;let n=e.routes.filter(e=>JSON.stringify([e.repo,e.reference,e.id])===t||ue(e)===t);if(n.length===1)return n[0];let r=e.routes.filter(e=>e.id===t);return r.length===1?r[0]:void 0}function fe(e){return[...new Set(e.routes.map(e=>e.repo).concat(e.events.map(e=>e.repo)).filter(Boolean))].sort()}function pe(e,t){if(!t)return!0;let n=[e.id,e.summary??``,e.trigger.label,e.step.label,e.step.avoid??``,e.track,e.origin.label??``].join(`
`).toLowerCase();return t.toLowerCase().split(/\s+/).filter(Boolean).every(e=>n.includes(e))}function me(e,t){if(t.repo&&e.repo!==t.repo)return!1;let n=le(e);if(ce.includes(n)&&!t.show.has(n)||t.cards===!1&&S(e))return!1;let r=_(e.strength);return r&&!t.strengths.has(r)?!1:pe(e,t.query.trim())}function he(e,t){let n=e.routes.filter(e=>!t||e.repo===t),r=e=>{let t=new Map;for(let r of n){let n=e(r);n&&t.set(n,(t.get(n)??0)+1)}return t},i=n.filter(e=>{let t=y(e.state);return t!==`nascent`&&t!==`extinguished`}),a=new Map;for(let e of i){let t=_(e.strength);t&&a.set(t,(a.get(t)??0)+1)}return{strengths:a,lifecycles:r(le),cards:n.filter(S).length,reflexes:n.filter(e=>!b(e)).length,instincts:n.filter(b).length}}function ge(e){return e.replace(/`/g,``)}function V(e){let t=new Map;for(let n of e)for(let e of[...n.directives??[],...n.arm===`control`?n.would_have??[]:[]]){if(!e.route_key||!e.version)continue;let r=JSON.stringify([e.route_key,e.version]),i=t.get(r);(i===void 0||n.ts<i)&&t.set(r,n.ts)}return t}function _e(e,t){let n=e.routes.filter(e=>me(e,t.filters)),r=t.at==null?null:V(e.events),i=new Map,a=[],o=new Map,s=new Set;for(let e of n){let n=ue(e),c=_(e.strength),d=y(e.state),f=b(e),p=r?.get(JSON.stringify([u(e),e.version])),m=t.at!=null&&!f&&(p===void 0||p>t.at),h=`r:${n}`;i.set(h,{id:h,kind:f?`instinct`:`reflex`,tag:f?`INSTINCT`:x(e)?`REFLEX · QUIET`:S(e)?`REFLEX · CARD`:`REFLEX`,title:e.id,sub:[c??``,f?`instinct`:x(e)?`quiet`:d,T(e)].filter(Boolean).join(` · `),strength:c,lifecycle:d,quiet:x(e),card:S(e),routes:[n],unformed:m});let g=t.mode===`aggregated`,v=g?`s:${e.repo}:${e.trigger.kind}:${e.trigger.label}`:`s:${n}`,C=i.get(v),w=o.get(v)??new Set;for(let t of e.measurement_sessions??[])t.applied.length&&w.add(l(t));o.set(v,w),e.measurement_sessions||s.add(v),C?C.routes.push(n):i.set(v,{id:v,kind:`stimulus`,tag:D(e.trigger).toUpperCase(),title:ge(e.trigger.label),sub:``,routes:[n]});let E=e.step,k=g?`p:${e.repo}:${E.kind}:${E.label}:${E.avoid??``}`:`p:${n}`,A=i.get(k);A?A.routes.push(n):i.set(k,{id:k,kind:`response`,tag:O(E).toUpperCase(),title:ge(E.label),sub:E.kind===`avoid`?ge(E.avoid??``):``,strike:E.kind===`avoid`,routes:[n]}),a.push({id:`e:${v}->${h}`,source:v,target:h,route:n,strength:c}),a.push({id:`e:${h}->${k}`,source:h,target:k,route:n,strength:c})}for(let e of i.values()){if(e.kind===`stimulus`){let t=o.get(e.id)?.size??0,n=e.routes.length;e.sub=[n>1?`starts ${n} reflexes`:``,s.has(e.id)?`trace links unavailable`:t?`in ${t} trace${t===1?``:`s`}`:`not seen live yet`].filter(Boolean).join(` · `)}else if(e.kind===`response`&&!e.strike){let t=e.routes.length;e.sub=t>1?`from ${t} reflexes`:e.tag===`READ TOGETHER`?`files the last result listed`:``}if(e.kind===`stimulus`||e.kind===`response`){let t=e.routes.map(e=>i.get(`r:${e}`));e.unformed=t.length>0&&t.every(e=>e?.unformed)}}return{nodes:[...i.values()],edges:a}}function ve(e,t,n){if(!t||n<=0)return null;let r=new Map;for(let t of e)r.set(t.source,[...r.get(t.source)??[],t.target]),r.set(t.target,[...r.get(t.target)??[],t.source]);let i=new Set([t]),a=[t];for(let e=0;e<n;e++){let e=[];for(let t of a)for(let n of r.get(t)??[])i.has(n)||(i.add(n),e.push(n));a=e}return i}function ye(e,t){return t?{nodes:e.nodes.filter(e=>t.has(e.id)),edges:e.edges.filter(e=>t.has(e.source)&&t.has(e.target))}:e}var H={stimulus:0,reflex:1,instinct:1,response:2};function be(e,t=`RIGHT`){let n=e.nodes.filter(e=>H[e.kind]===1),r=new Map;n.forEach((e,t)=>r.set(e.routes[0]??e.id,t));let i={},a=[0,0,0],o=(e,n)=>{let r=H[e.kind],o=Math.max(n,a[r]??0);a[r]=o+100,i[e.id]=t===`RIGHT`?{x:r*294,y:o}:{x:232/76*o*.9,y:r*146}},s=e=>Math.min(...e.routes.map(e=>r.get(e)??0)),c=[...e.nodes].sort((e,t)=>s(e)-s(t)||H[e.kind]-H[t.kind]);for(let e of c)o(e,s(e)*100);return{positions:i}}function U(e,t){let n=[],r=[`Stimulus`,`Reflex`,`Response`];for(let i=0;i<3;i++){let a=e.nodes.filter(e=>H[e.kind]===i).map(e=>t.positions[e.id]).filter(e=>!!e);a.length&&n.push({label:r[i]??``,x:Math.min(...a.map(e=>e.x)),y:Math.min(...a.map(e=>e.y))})}return n}var W=[`map`,`traces`,`evidence`,`health`,`how`,`setup`],xe=[`24h`,`7d`,`30d`,`all`];function Se(e,t,n){return e===null?new Set(n):new Set(e.split(`,`).filter(e=>t.includes(e)))}function Ce(e){let t=new URLSearchParams(e),n=t.get(`view`),r=t.get(`mode`),i=t.get(`window`),a=Number(t.get(`at`));return{view:W.includes(n)?n:`map`,repo:t.get(`repo`)||null,session:t.get(`session`)||null,traceRepo:t.get(`traceRepo`)||t.get(`repo`)||null,sequence:t.has(`seq`)&&Number.isSafeInteger(Number(t.get(`seq`)))&&Number(t.get(`seq`))>=0?Number(t.get(`seq`)):null,version:t.get(`version`)||null,reflex:t.get(`reflex`)||null,mode:r===`expanded`?`expanded`:`aggregated`,focus:Math.max(0,Math.min(3,Number(t.get(`focus`))||0)),dir:t.get(`dir`)===`down`?`DOWN`:`RIGHT`,q:t.get(`q`)??``,strengths:Se(t.get(`strength`),m,m),show:Se(t.get(`show`),h,[]),cards:t.get(`cards`)!==`hide`,window:xe.includes(i)?i:`all`,at:t.has(`at`)&&Number.isFinite(a)&&a>0?a:null,ch:t.get(`ch`)||null,step:Math.max(0,Math.floor(Number(t.get(`step`))||0))}}function we(e){let t=new URLSearchParams;e.view!==`map`&&t.set(`view`,e.view),e.repo&&t.set(`repo`,e.repo),e.session&&t.set(`session`,e.session),e.traceRepo&&e.session&&t.set(`traceRepo`,e.traceRepo),e.sequence!==null&&e.session&&t.set(`seq`,String(e.sequence)),e.version&&e.reflex&&t.set(`version`,e.version),e.reflex&&t.set(`reflex`,e.reflex),e.mode!==`aggregated`&&t.set(`mode`,e.mode),e.focus&&t.set(`focus`,String(e.focus)),e.dir===`DOWN`&&t.set(`dir`,`down`),e.q&&t.set(`q`,e.q),e.strengths.size!==m.length&&t.set(`strength`,m.filter(t=>e.strengths.has(t)).join(`,`));let n=h.filter(t=>e.show.has(t)&&ce.includes(t));n.length&&t.set(`show`,n.join(`,`)),e.cards||t.set(`cards`,`hide`),e.window!==`all`&&t.set(`window`,e.window),e.at&&t.set(`at`,String(e.at)),e.view===`how`&&e.ch&&t.set(`ch`,e.ch),e.view===`how`&&e.step&&t.set(`step`,String(e.step));let r=t.toString();return r?`?${r}`:``}var Te=new Set,Ee=null,De=null;function Oe(){let e=typeof location>`u`?``:location.search;return(e!==Ee||!De)&&(Ee=e,De=Ce(e)),De}function ke(e){Te.add(e);let t=()=>e();return window.addEventListener(`popstate`,t),()=>{Te.delete(e),window.removeEventListener(`popstate`,t)}}function Ae(e,t=!1){let n={...Oe(),...e},r=`${location.pathname}${we(n)}${location.hash}`;if(r!==`${location.pathname}${location.search}${location.hash}`){t?history.pushState(null,``,r):history.replaceState(null,``,r);for(let e of Te)e()}}function je(){return[(0,s.useSyncExternalStore)(ke,Oe,Oe),(0,s.useCallback)((e,t)=>Ae(e,t),[])]}function Me(e,t){switch(e){case`24h`:return t-864e5;case`7d`:return t-6048e5;case`30d`:return t-2592e6;default:return 0}}var Ne=n((e=>{var t=Symbol.for(`react.transitional.element`),n=Symbol.for(`react.fragment`);function r(e,n,r){var i=null;if(r!==void 0&&(i=``+r),n.key!==void 0&&(i=``+n.key),`key`in n)for(var a in r={},n)a!==`key`&&(r[a]=n[a]);else r=n;return n=r.ref,{$$typeof:t,type:e,key:i,ref:n===void 0?null:n,props:r}}e.Fragment=n,e.jsx=r,e.jsxs=r})),Pe=n(((e,t)=>{t.exports=Ne()})),G=Pe();function Fe({size:e=14}){return(0,G.jsxs)(`svg`,{width:e,height:e,viewBox:`0 0 14 14`,fill:`none`,"aria-hidden":`true`,className:`shrink-0`,children:[(0,G.jsx)(`path`,{d:`M2 12 Q7 -1 12 12`,style:{stroke:`var(--glyph-arc)`},strokeWidth:`1.4`,strokeLinecap:`round`}),(0,G.jsx)(`circle`,{cx:`7`,cy:`5.5`,r:`1.6`,style:{fill:`var(--color-accent-soft)`}}),(0,G.jsx)(`circle`,{cx:`12`,cy:`12`,r:`1.6`,style:{fill:`var(--color-lamp-fire)`}})]})}function Ie({size:e=14}){return(0,G.jsxs)(`svg`,{width:e,height:e,viewBox:`0 0 14 14`,fill:`none`,"aria-hidden":`true`,className:`shrink-0`,children:[(0,G.jsx)(`circle`,{cx:`7`,cy:`7`,r:`5.2`,style:{stroke:`var(--glyph-arc)`},strokeWidth:`1.4`}),(0,G.jsx)(`circle`,{cx:`7`,cy:`7`,r:`2.2`,style:{fill:`var(--color-accent-soft)`}})]})}function Le({size:e=14}){return(0,G.jsxs)(`svg`,{width:e,height:e,viewBox:`0 0 14 14`,fill:`none`,"aria-hidden":`true`,className:`shrink-0`,children:[(0,G.jsx)(`rect`,{x:`1.8`,y:`1.8`,width:`10.4`,height:`10.4`,rx:`1.6`,style:{stroke:`var(--glyph-arc)`},strokeWidth:`1.3`}),(0,G.jsx)(`path`,{d:`M4.3 5h5.4M4.3 7h5.4M4.3 9h3.4`,style:{stroke:`var(--color-accent-soft)`},strokeWidth:`1.2`,strokeLinecap:`round`})]})}function Re({size:e=8}){return(0,G.jsx)(`svg`,{width:e,height:e,viewBox:`0 0 10 10`,fill:`none`,"aria-hidden":`true`,className:`shrink-0`,children:(0,G.jsx)(`circle`,{cx:`5`,cy:`5`,r:`4`,style:{stroke:`var(--color-ink-3)`},strokeWidth:`1.4`,strokeDasharray:`1.6 1.5`})})}function ze({size:e=14}){return(0,G.jsxs)(`svg`,{width:e,height:e,viewBox:`0 0 14 14`,fill:`none`,"aria-hidden":`true`,className:`shrink-0`,children:[(0,G.jsx)(`path`,{d:`M3 3v3.2a2.3 2.3 0 0 0 2.3 2.3H11`,style:{stroke:`currentColor`},strokeWidth:`1.4`,strokeLinecap:`round`}),(0,G.jsx)(`path`,{d:`M8.6 6.1L11 8.5 8.6 10.9`,style:{stroke:`currentColor`},strokeWidth:`1.4`,strokeLinecap:`round`,strokeLinejoin:`round`})]})}function Be({instinct:e,card:t=!1,size:n}){return t?(0,G.jsx)(Le,{size:n}):e?(0,G.jsx)(Ie,{size:n}):(0,G.jsx)(Fe,{size:n})}function Ve({strength:e,hollow:t,quiet:n,glow:r,size:i=8}){return n?(0,G.jsx)(Re,{size:i+1}):(0,G.jsx)(Ue,{strength:e,hollow:t,glow:r,size:i})}var He={fire:`var(--color-lamp-fire)`,prime:`var(--color-lamp-prime)`,inhibit:`var(--color-lamp-inhibit)`};function Ue({strength:e,hollow:t=!1,glow:n=!1,size:r=8}){let i=e?He[e]:`var(--color-ink-3)`,a=t?{width:r,height:r,border:`1.5px solid var(--color-ink-3)`,boxSizing:`border-box`}:{width:r,height:r,background:i,color:i,boxShadow:n?`0 0 8px ${i}`:void 0};return(0,G.jsx)(`span`,{"aria-hidden":`true`,className:`inline-block shrink-0 rounded-full`,style:a})}function We({children:e,size:t=14,label:n}){return(0,G.jsx)(`svg`,{width:t,height:t,viewBox:`0 0 16 16`,fill:`none`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`,strokeLinejoin:`round`,"aria-hidden":!n||void 0,role:n?`img`:void 0,"aria-label":n,className:`shrink-0`,children:e})}var Ge={search:e=>(0,G.jsxs)(We,{...e,children:[(0,G.jsx)(`circle`,{cx:`7`,cy:`7`,r:`4.6`}),(0,G.jsx)(`path`,{d:`M10.6 10.6L14 14`})]}),chevron:e=>(0,G.jsx)(We,{...e,children:(0,G.jsx)(`path`,{d:`M4 6l4 4 4-4`})}),moon:e=>(0,G.jsx)(We,{...e,children:(0,G.jsx)(`path`,{d:`M13.5 9.5A5.5 5.5 0 0 1 6.5 2.5a5.5 5.5 0 1 0 7 7z`})}),sun:e=>(0,G.jsxs)(We,{...e,children:[(0,G.jsx)(`circle`,{cx:`8`,cy:`8`,r:`3`}),(0,G.jsx)(`path`,{d:`M8 1.5v1.6M8 12.9v1.6M1.5 8h1.6M12.9 8h1.6M3.4 3.4l1.1 1.1M11.5 11.5l1.1 1.1M3.4 12.6l1.1-1.1M11.5 4.5l1.1-1.1`})]}),system:e=>(0,G.jsxs)(We,{...e,children:[(0,G.jsx)(`rect`,{x:`2`,y:`2.5`,width:`12`,height:`8.5`,rx:`1.5`}),(0,G.jsx)(`path`,{d:`M5.5 14h5M8 11v3`})]}),copy:e=>(0,G.jsxs)(We,{...e,children:[(0,G.jsx)(`rect`,{x:`5.5`,y:`5.5`,width:`8.5`,height:`8.5`,rx:`1.5`}),(0,G.jsx)(`path`,{d:`M10.5 3.2V3a1 1 0 0 0-1-1H3a1 1 0 0 0-1 1v6.5a1 1 0 0 0 1 1h.3`})]}),check:e=>(0,G.jsx)(We,{...e,children:(0,G.jsx)(`path`,{d:`M3 8.3L6.4 11.5L13 4.5`})}),filter:e=>(0,G.jsx)(We,{...e,children:(0,G.jsx)(`path`,{d:`M2.5 4h11M4.5 8h7M6.5 12h3`})}),cross:e=>(0,G.jsx)(We,{...e,children:(0,G.jsx)(`path`,{d:`M4 4l8 8M12 4l-8 8`})}),warn:e=>(0,G.jsx)(We,{...e,children:(0,G.jsx)(`path`,{d:`M8 3v6M8 12.2v.3`})}),play:e=>(0,G.jsx)(`svg`,{width:e.size??12,height:e.size??12,viewBox:`0 0 12 12`,"aria-hidden":`true`,children:(0,G.jsx)(`path`,{d:`M3 1.8L10 6L3 10.2z`,fill:`currentColor`})}),pause:e=>(0,G.jsxs)(`svg`,{width:e.size??12,height:e.size??12,viewBox:`0 0 12 12`,"aria-hidden":`true`,children:[(0,G.jsx)(`rect`,{x:`2.5`,y:`2`,width:`2.5`,height:`8`,rx:`0.6`,fill:`currentColor`}),(0,G.jsx)(`rect`,{x:`7`,y:`2`,width:`2.5`,height:`8`,rx:`0.6`,fill:`currentColor`})]}),plus:e=>(0,G.jsx)(We,{...e,children:(0,G.jsx)(`path`,{d:`M8 3v10M3 8h10`})}),minus:e=>(0,G.jsx)(We,{...e,children:(0,G.jsx)(`path`,{d:`M3 8h10`})}),fit:e=>(0,G.jsx)(We,{...e,children:(0,G.jsx)(`path`,{d:`M2 6V2h4M10 2h4v4M14 10v4h-4M6 14H2v-4`})}),live:e=>(0,G.jsx)(We,{...e,children:(0,G.jsx)(`path`,{d:`M8 8h.01M5.2 5.2a4 4 0 0 0 0 5.6M10.8 5.2a4 4 0 0 1 0 5.6`})}),keyboard:e=>(0,G.jsxs)(We,{...e,children:[(0,G.jsx)(`rect`,{x:`1.5`,y:`4`,width:`13`,height:`8.5`,rx:`1.5`}),(0,G.jsx)(`path`,{d:`M4.5 7h.01M7 7h.01M9.5 7h.01M12 7h.01M5 10h6`})]})};function Ke(...e){return e.filter(Boolean).join(` `)}var qe={fire:`bg-fire/10 border-fire/35`,prime:`bg-prime/10 border-prime/35`,inhibit:`bg-inhibit/10 border-inhibit/35`};function Je({strength:e,hollow:t=!1}){return e?(0,G.jsxs)(`span`,{className:Ke(`inline-flex h-6 items-center gap-1.5 rounded-full border px-2.5 text-xs text-ink-1`,t?`border-line-strong`:qe[e]),children:[(0,G.jsx)(Ue,{strength:e,hollow:t,glow:!t,size:7}),e]}):null}function Ye({children:e,mono:t=!1,title:n}){return(0,G.jsx)(`span`,{title:n,className:Ke(`inline-flex h-6 max-w-full items-center truncate rounded-full border border-line-strong px-2.5 text-ink-2`,t?`font-mono text-[11px]`:`text-xs`),children:e})}function Xe({lifecycle:e}){return(0,G.jsx)(Ye,{children:e})}function Ze({pressed:e,onClick:t,strength:n,children:r,count:i}){return(0,G.jsxs)(`button`,{type:`button`,"aria-pressed":e,onClick:t,className:Ke(`inline-flex h-[26px] items-center gap-1.5 rounded-full border px-2.5 text-xs transition-colors duration-100`,e&&n?qe[n]+` text-ink-1`:``,e&&!n?`border-accent/45 bg-accent/12 text-ink-1`:``,e?``:`border-line-strong bg-transparent text-ink-2 hover:text-ink-1`),children:[n&&(0,G.jsx)(Ue,{strength:n,hollow:!e,size:7}),r,i!==void 0&&(0,G.jsx)(`span`,{className:e?`text-ink-1`:`text-ink-3`,children:i})]})}function Qe({label:e,value:t,options:n,onChange:r,size:i=`md`}){return(0,G.jsx)(`div`,{role:`group`,"aria-label":e,className:`flex rounded-md border border-line-strong bg-panel p-[3px]`,children:n.map(e=>(0,G.jsx)(`button`,{type:`button`,title:e.title,"aria-pressed":t===e.value,onClick:()=>r(e.value),className:Ke(`rounded-sm px-2.5 transition-colors duration-100`,i===`sm`?`h-6 text-xs`:`h-[26px] text-[12.5px]`,t===e.value?`bg-[var(--sel)] text-ink-1 shadow-[inset_0_0_0_1px_var(--sel-ring)]`:`text-ink-2 hover:text-ink-1`),children:e.label},e.value))})}var $e=``,et=0,tt=new Set;function nt(e){$e=e,et++;for(let e of tt)e()}function rt(){let e=(0,s.useSyncExternalStore)(e=>(tt.add(e),()=>tt.delete(e)),()=>et),[t,n]=(0,s.useState)(!1);return(0,s.useEffect)(()=>{if(!e)return;n(!0);let t=setTimeout(()=>n(!1),2400);return()=>clearTimeout(t)},[e]),(0,G.jsx)(`div`,{role:`status`,"aria-live":`polite`,className:Ke(`pointer-events-none fixed bottom-24 left-1/2 z-50 -translate-x-1/2 rounded-md border border-line-strong bg-raised px-3.5 py-2 font-mono text-xs text-ink-1 shadow-[var(--shadow)] transition-all duration-200`,t?`translate-y-0 opacity-100`:`translate-y-2 opacity-0`),children:t?$e:``})}async function it(e){try{return await navigator.clipboard.writeText(e),!0}catch{let t=document.createElement(`textarea`);t.value=e,t.setAttribute(`readonly`,``),t.className=`sr-only`,document.body.appendChild(t),t.select();let n=!1;try{n=document.execCommand(`copy`)}catch{n=!1}return t.remove(),n}}async function at(e){nt(await it(e)?`Copied · ${e}`:`Copy this: ${e}`)}function ot({command:e,primary:t=!1,why:n}){let[,r]=je(),[i,a]=(0,s.useState)(!1);return(0,s.useEffect)(()=>{if(!i)return;let e=setTimeout(()=>a(!1),1400);return()=>clearTimeout(e)},[i]),(0,G.jsxs)(`div`,{className:`flex flex-col gap-1.5`,children:[(0,G.jsxs)(`button`,{type:`button`,onClick:()=>r({view:`setup`},!0),className:Ke(`rounded-md border px-3 py-2 text-left text-sm`,t?`border-accent/45 bg-[var(--sel)]`:`border-line-strong`),children:[(0,G.jsx)(`span`,{className:`block text-accent-soft`,children:n||`Manage this in the terminal`}),(0,G.jsx)(`span`,{className:`text-xs text-ink-3`,children:`Open terminal action guide →`})]}),(0,G.jsxs)(`details`,{children:[(0,G.jsx)(`summary`,{className:`cursor-pointer text-xs text-ink-3`,children:`CLI alternative`}),(0,G.jsxs)(`button`,{type:`button`,title:n?`${n} · copies the command`:`Copies the command`,onClick:()=>{at(e),a(!0)},className:Ke(`group flex min-h-10 w-full items-center gap-2.5 rounded-md border px-3 py-2 text-left transition-colors duration-100`,t?`border-accent/45 bg-[var(--sel)] text-ink-1 hover:border-accent`:`border-line-strong text-ink-1 hover:border-accent/45 hover:bg-raised`),children:[(0,G.jsx)(`span`,{className:`text-accent-soft`,children:i?(0,G.jsx)(Ge.check,{}):(0,G.jsx)(Ge.copy,{})}),(0,G.jsxs)(`span`,{className:`min-w-0 flex-1`,children:[(0,G.jsx)(`span`,{className:`block truncate font-mono text-xs`,children:e}),n&&(0,G.jsx)(`span`,{className:`block truncate text-[11.5px] text-ink-3`,children:n})]}),(0,G.jsx)(`span`,{className:`sr-only`,children:`Copy`})]})]})]})}var st=`input, button:not([disabled]), a[href], select, textarea, [tabindex]:not([tabindex='-1'])`;function ct({label:e,open:t,onClose:n,children:r,className:i,top:a=64,sheet:o=!1,focusInput:c=!0}){let l=(0,s.useRef)(null),u=(0,s.useRef)(null),d=(0,s.useRef)(c);return d.current=c,(0,s.useEffect)(()=>{if(!t)return;u.current=document.activeElement;let e=l.current;return((d.current?e?.querySelector(`input`):null)??e?.querySelector(st)??e)?.focus(),()=>{u.current?.focus?.()}},[t]),t?(0,G.jsxs)(`div`,{className:`fixed inset-0 z-40`,onKeyDown:e=>{if(e.key===`Escape`){e.stopPropagation(),n();return}if(e.key!==`Tab`||!l.current)return;let t=[...l.current.querySelectorAll(st)].filter(e=>e.offsetParent!==null),r=t[0],i=t[t.length-1];r&&i&&(e.shiftKey&&(document.activeElement===r||document.activeElement===l.current)?(e.preventDefault(),i.focus()):!e.shiftKey&&document.activeElement===i&&(e.preventDefault(),r.focus()))},children:[(0,G.jsx)(`div`,{className:`absolute inset-0 bg-base/60 backdrop-blur-[2px]`,onClick:n,"aria-hidden":`true`}),(0,G.jsx)(`div`,{ref:l,role:`dialog`,"aria-modal":`true`,"aria-label":e,tabIndex:-1,style:o?void 0:{top:a},className:Ke(o?`sheet absolute inset-y-0 left-0 flex w-[min(360px,calc(100vw-40px))] flex-col overflow-hidden border-r border-line-strong bg-panel shadow-[var(--shadow)] outline-none`:`rise absolute left-1/2 flex w-[min(640px,calc(100vw-32px))] -translate-x-1/2 flex-col overflow-hidden rounded-xl border border-line-strong bg-panel shadow-[var(--shadow)] outline-none`,i),children:r})]}):null}function lt({text:e}){return(0,G.jsx)(G.Fragment,{children:oe(e).split("`").map((e,t)=>t%2==1?(0,G.jsx)(`code`,{className:`font-mono text-[0.95em] text-ink-1`,children:e},t):e)})}var ut=[`Jan`,`Feb`,`Mar`,`Apr`,`May`,`Jun`,`Jul`,`Aug`,`Sep`,`Oct`,`Nov`,`Dec`];function dt(e){let t=new Date(e);return`${ut[t.getMonth()]} ${t.getDate()}`}function ft(e){let t=new Date(e),n=e=>String(e).padStart(2,`0`);return`${n(t.getHours())}:${n(t.getMinutes())}:${n(t.getSeconds())}`}var pt=(e,t)=>e.reduce((e,n)=>e+t(n),0);function mt(e){return e.n?e.k/e.n:null}function ht(e){let t=mt(e);return t===null?`—`:`${Math.round(t*100)}%`}function gt(e){let t=e.filter(e=>e.step.kind!==`avoid`),n=e.filter(e=>e.step.kind===`avoid`),r=e.filter(e=>(e.arms.treated?.met??0)+(e.arms.control?.met??0)>0),i=e=>t=>t.arms.treated?e(t.arms.treated):0,a=e=>t=>t.arms.control?e(t.arms.control):0;return[{label:`Took the known path`,treated:{k:pt(t,i(e=>e.followed)),n:pt(t,i(e=>e.applied))},control:{k:pt(t,a(e=>e.followed)),n:pt(t,a(e=>e.applied))},lowerIsBetter:!1,note:`reflex–trace pairs · current versions`},{label:`Ran into a known dead end`,treated:{k:pt(n,i(e=>e.hit_avoided??0)),n:pt(n,i(e=>e.applied))},control:{k:pt(n,a(e=>e.hit_avoided??0)),n:pt(n,a(e=>e.applied))},lowerIsBetter:!0,note:`inhibit reflexes · lower is better`},{label:`Met the finish line`,treated:{k:pt(r,i(e=>e.met)),n:pt(r,i(e=>e.applied))},control:{k:pt(r,a(e=>e.met)),n:pt(r,a(e=>e.applied))},lowerIsBetter:!1,note:`obligations such as regenerating code`}]}function _t(e){let t=new Map;for(let n of e){let e=new Date(n.ts);e.setHours(0,0,0,0);let r=e.getTime(),i=t.get(r)??{t:new Set,c:new Set};(n.arm===`control`?i.c:i.t).add(JSON.stringify([n.repo,n.session])),t.set(r,i)}return[...t.entries()].sort((e,t)=>e[0]-t[0]).map(([e,t])=>({day:e,treated:t.t.size,control:t.c.size}))}function vt(e,t){let n=new Set,r=new Set;for(let e of t)(e.arm===`control`?r:n).add(JSON.stringify([e.repo,e.session]));return{treated:n.size,control:r.size}}var yt=`how-termtip`;function bt(){let[e,t]=(0,s.useState)(null),n=(0,s.useRef)(null);return(0,s.useLayoutEffect)(()=>{let t=n.current;if(!e||!t)return;let r=e.el.getBoundingClientRect(),i=t.offsetWidth,a=t.offsetHeight,o=Math.max(12,Math.min(window.innerWidth-12-i,r.left+r.width/2-i/2)),s=r.top-a-8>=12?r.top-a-8:r.bottom+8;t.style.transform=`translate(${Math.round(o)}px, ${Math.round(s)}px)`},[e]),(0,s.useEffect)(()=>{if(!e)return;let n=()=>t(null),r=e=>e.key===`Escape`&&n();return window.addEventListener(`scroll`,n,!0),window.addEventListener(`keydown`,r),()=>(window.removeEventListener(`scroll`,n,!0),window.removeEventListener(`keydown`,r))},[e]),{setTip:t,node:(0,c.createPortal)((0,G.jsx)(`div`,{ref:n,id:yt,role:`tooltip`,hidden:!e,className:`pointer-events-none fixed top-0 left-0 z-50 max-w-[min(320px,calc(100vw-24px))] rounded-lg border border-line-strong bg-raised px-3 py-2.5 text-[13px] leading-snug text-ink-1 shadow-lg`,children:e?.def}),document.body)}}function xt({parts:e,onTip:t}){return(0,G.jsx)(G.Fragment,{children:e.map((e,n)=>typeof e==`string`?e:(0,G.jsx)(`span`,{tabIndex:0,"aria-describedby":yt,className:`cursor-help rounded-sm underline decoration-accent/70 decoration-dotted decoration-[1.5px] underline-offset-[3px] hover:text-ink-1 focus-visible:outline-2 focus-visible:outline-accent`,onPointerEnter:n=>n.pointerType!==`touch`&&t({def:e.term.def,el:n.currentTarget}),onPointerLeave:e=>e.pointerType!==`touch`&&document.activeElement!==e.currentTarget&&t(null),onFocus:n=>t({def:e.term.def,el:n.currentTarget}),onBlur:()=>t(null),onClick:n=>t({def:e.term.def,el:n.currentTarget}),children:e.text},n))})}var St={P:{label:`prompt · change the registry`,kind:`prompt`,c:[-6.2,2.6,1.2],hue:262},D:{label:`prompt · change dispatch`,kind:`prompt`,c:[-5.6,-2.2,3.4],hue:300},R:{label:`read src/**`,kind:`observe`,c:[-2.2,4,-2.6],hue:205},E:{label:`edit registry/*.csv`,kind:`edit`,c:[1.6,3,3.2],hue:248},S:{label:`edit src/*.ts`,kind:`edit`,c:[1.2,-3.2,4.2],hue:320},G:{label:`make gen`,kind:`regen`,c:[5.4,1.4,-1.8],hue:185},C:{label:`make check`,kind:`verify`,c:[6.6,-2.4,1.2],hue:225},F:{label:`npm test ✗`,kind:`fail`,c:[2.6,-4.2,-3.8],hue:350},W:{label:`git status`,kind:`observe`,c:[-3,-3.4,-2.6],hue:160},h:{label:`curl localhost:8080/health`,kind:`observe`,c:[-.6,.2,-6.2],hue:40,single:!0}},Ct=[[[`P`,`add carrier HX-7`],[`R`,`read src/registry/load.ts`],[`E`,`edit registry/carriers.csv`],[`G`,`make gen`],[`C`,`make check`]],[[`P`,`fix the Oslo port code`],[`R`,`read src/registry/ports.ts`],[`E`,`edit registry/ports.csv`],[`G`,`make gen -B`],[`C`,`make check -j4`]],[[`P`,`lane rate wrong NYC→BOS`],[`R`,`read src/registry/schema.ts`],[`E`,`edit registry/lanes.csv`],[`W`,`git status`],[`G`,`make gen`],[`C`,`make check`]],[[`P`,`add port Gdańsk`],[`E`,`edit registry/ports.csv`],[`G`,`make gen`],[`F`,`npm test`],[`C`,`make check`]],[[`P`,`rename carrier Northwind`],[`R`,`read src/registry/load.ts`],[`E`,`edit registry/carriers.csv`],[`G`,`make gen`],[`C`,`make check`]],[[`P`,`update lane LA→SF`],[`E`,`edit registry/lanes.csv`],[`G`,`make gen`],[`W`,`git status`]],[[`P`,`remove port Tacoma`],[`R`,`read src/registry/ports.ts`],[`E`,`edit registry/ports.csv`],[`G`,`make gen`],[`C`,`make check -j4`]],[[`D`,`dispatch picks the slow lane`],[`R`,`read src/dispatch.ts`],[`S`,`edit src/dispatch.ts`],[`C`,`make check`]],[[`D`,`retry dispatch on 503`],[`S`,`edit src/dispatch.ts`],[`F`,`npm test`],[`C`,`make check`]],[[`D`,`router ignores holidays`],[`R`,`read src/router.ts`],[`W`,`git status`],[`S`,`edit src/router.ts`],[`C`,`make check`]],[[`D`,`log dispatch latency`],[`S`,`edit src/router.ts`],[`h`,`curl localhost:8080/health`],[`C`,`make check`]],[[`P`,`fix carrier contact`],[`R`,`read src/registry/load.ts`],[`E`,`edit registry/carriers.csv`],[`C`,`make check`]]];function wt(e,t,n=0){return e.findIndex((e,r)=>r>=n&&e[0]===t)}var Tt=e=>(e-(Ct.length-1)/2)*1.25,Et=e=>-7.2+e*2.5;function Dt(e=7){let t=e;return()=>(t=t*16807%2147483647)/2147483647*2-1}function Ot(e,t,n=600){let r=[],i=[],a=0;for(let o=1;o<n;o++){let s=o/n,c=Math.exp((e-1)*Math.log(s)+(t-1)*Math.log(1-s));r.push(s),i.push(c),a+=c}let o=0,s=0;for(let e=0;e<i.length;e++)i[e]/=a,o+=i[e],!s&&o>=.05&&(s=r[e]);return{xs:r,ps:i,q05:s,mean:e/(e+t)}}function kt(e,t,n=1.959964){if(!t)return 0;let r=e/t,i=1+n*n/t;return(r+n*n/(2*t)-n*Math.sqrt(r*(1-r)/t+n*n/(4*t*t)))/i}var K=e=>e.toFixed(2),At=5,jt=2,Mt=2,Nt=2,Pt=60,Ft=.3,It=.9,Lt=.8,Rt=.5,zt=8,Bt=4,Vt=256,Ht=2e4,Ut=2e3,Wt=3,Gt=200,Kt=400,qt=.8,Jt=.5,Yt=.5,Xt=3,Zt=.7,Qt={P:`prompt`,D:`prompt`,R:`read`,E:`edit`,S:`edit`,G:`act`,C:`act`,F:`act`,W:`act`,h:`act`},$t={P:[`add carrier HX-7`,`fix the Oslo port code`,`lane rate wrong NYC→BOS`,`rename carrier Northwind`,`remove port Tacoma`,`update lane LA→SF`,`add port Gdańsk`],D:[`dispatch picks the slow lane`,`retry dispatch on 503`,`router ignores holidays`,`log dispatch latency`,`cap dispatch retries`],R:[`read src/registry/load.ts`,`read src/registry/ports.ts`,`read src/dispatch.ts`,`read src/router.ts`],E:[`edit registry/carriers.csv`,`edit registry/ports.csv`,`edit registry/lanes.csv`],S:[`edit src/dispatch.ts`,`edit src/router.ts`],G:[`make gen`,`make gen -B`],C:[`make check`,`make check -j4`],F:[`npm test`],W:[`git status`],h:[`curl localhost:8080/health`]},en=[[`P R E E W G W C W`,4],[`P R E W G R C W`,4],[`P E R G W C`,2],[`P R E G W C W`,2],[`P R E G F W C`,3],[`P R E W G W`,1],[`P R E W C W`,1],[`D R S W F C W`,7],[`D R S W F W C`,2],[`D S F C W`,2],[`D R S W C`,1],[`D R S h C`,1],[`D W S F C`,2]],tn=(()=>{let e=[],t=0;return en.forEach(([n,r],i)=>{for(let a=0;a<r;a++,t++){let r=n.split(` `).map((e,n)=>{let r=$t[e];return{code:e,exact:r[(e===`G`||e===`C`?+(t%9==(e===`G`?4:7)):t*3+n*5+i)%r.length],fail:e===`F`}});e.push({id:`t${t+1}`,task:`task-${String(i).padStart(2,`0`)}-${Math.floor(a/2)}`,day:1+t%6,ev:r})}}),e})(),nn=(e,t={})=>({code:e,...t}),rn=[{key:`seq`,text:`edit registry/*.csv → make gen → make check`,items:[nn(`E`),nn(`G`),nn(`C`)],cut:1},{key:`obl`,text:`last edit of registry/*.csv → make gen`,items:[nn(`E`,{last:!0}),nn(`G`)],cut:1},{key:`ctx`,text:`[edit registry/*.csv, make gen] → make check`,items:[nn(`E`),nn(`G`),nn(`C`)],cut:2},{key:`seq2`,text:`[registry prompt, edit registry/*.csv] → make gen → make check`,items:[nn(`P`),nn(`E`),nn(`G`),nn(`C`)],cut:2},{key:`avoid`,text:`npm test ✗ → make check`,items:[nn(`F`,{fail:!0}),nn(`C`)],cut:1},{key:`npm`,text:`[read src/*.ts, edit src/*.ts] → npm test`,items:[nn(`R`),nn(`S`),nn(`F`)],cut:2},{key:`status`,text:`git status → make check`,items:[nn(`W`),nn(`C`)],cut:1},{key:`curl`,text:`curl localhost:8080/health → make check`,items:[nn(`h`),nn(`C`)],cut:1}];function an(e,t,n){let r=e.ev[t];return r.code!==n.code||n.fail&&!r.fail?!1:!n.last||!e.ev.some((e,r)=>r>t&&e.code===n.code)}function on(e,t,n){let r=e.ev.map((e,t)=>t).filter(r=>an(e,r,t[0])&&(!n||n[r]));for(let i of t.slice(1))r=e.ev.map((e,t)=>t).filter(t=>an(e,t,i)&&(!n||n[t])&&r.some(e=>e<t&&t<=e+zt));return r}var sn=(e,t)=>on(e,t).length>0;function cn(e,t,n,r){if(!n.length)return[];for(let i=t+1;i<=Math.min(t+zt,e.ev.length-1);i++){if(r&&!r[i]||!an(e,i,n[0]))continue;let t=cn(e,i,n.slice(1),r);if(t)return[i,...t]}return null}var ln=e=>e.length?e.slice().sort((e,t)=>e-t)[Math.floor((e.length-1)/2)]:0;function un(e,t,n,r){let i=Math.min(1-1e-6,Math.max(1e-6,n));return[e+r*i,Math.max(0,t-e)+r*(1-i)]}function dn(e,t){let{items:n,cut:r}=t,i=n.slice(0,r),a=n.slice(r),o=Math.max(...e.map(e=>e.day)),s=e.map(e=>.5**((o-e.day)/Pt)),c=s.reduce((e,t)=>e+t,0),l=t=>e.reduce((e,n,r)=>e+(sn(n,t)?s[r]:0),0),u=c>0?l(a)/c:0,d=[0,0];for(let e=0;e<r;e++){let t=i.slice(r-1-e),n=l(t),o=l([...t,...a]);d=[n,o],e+1<r&&(u=(o+Mt*u)/(n+Mt))}let[f,p]=d,[m,h]=un(p,f,u,Mt),g=m/(m+h),_=Ot(m,h).q05,v=i[r-1],y=0,b=0,x=0,S=[],C=new Map,w=[];e.forEach((e,t)=>{let n=on(e,i);n.length&&w.push(t);for(let t of n){y++;let n=cn(e,t,a);n&&(b++,S.push(n[0]-t),n[0]-t<=1&&x++,C.set(e.ev[n[0]].exact,(C.get(e.ev[n[0]].exact)??0)+1))}});let T=0,E=0,D=0,O=0;for(let t of e)t.ev.forEach((e,n)=>{O++;let r=+!!cn(t,n,a);D+=r,Qt[e.code]===Qt[v.code]&&(E++,T+=r)});let k=y?b/y:0,[A,j]=E>y?[T,E]:[D,O],M=j?A/j:0,N=j-y,P=N>0?Math.max(0,A-b)/N:0,F=M>0?k/M:0,I=k-P,L=!!v.fail,ee=y&&!L?x/y:0,te=ln(S),ne=n.filter(e=>e.fail),R=ne.length?Math.min(...ne.map(t=>{let n=e.flatMap(e=>e.ev.filter(e=>e.code===t.code));return n.length?n.filter(e=>e.fail).length/n.length:0})):null,re=g*(1-ee)*te-Nt*(1-g),z=[...C.values()].reduce((e,t)=>e+t,0),B=[...C.entries()].sort((e,t)=>t[1]-e[1]||(e[0]<t[0]?-1:1))[0],ie=B&&z?B[1]/z:0,ae=B&&ie>=Lt?B[0]:null,oe=e.filter(e=>sn(e,n)),se=oe.length,ce=new Set(oe.map(e=>e.day)).size,le=Math.min(jt,Math.max(1,new Set(e.map(e=>e.day)).size)),ue=se<At?`support ${se} < ${At}`:ce<le?`days ${ce} < ${le}`:R===null?I<Ft?`contrast ${K(I)} < ${K(Ft)}`:``:R<It?`consistency ${K(R)} < ${It}`:``,de=L||!!v.last&&Qt[v.code]===`edit`;return!ue&&!de&&re<=0?ue=`value ${K(re)} ≤ 0`:!ue&&de&&_<Rt&&(ue=`guard lower bound ${K(_)} < ${K(Rt)}`),{cand:t,support:se,opp:w.length,days:ce,prior:u,alpha:m,beta:h,conf:g,confLb:_,confCal:g,confLbCal:_,contrast:I,lift:F,consistency:R,pSoon:ee,dturns:te,value:re,variant:ae,variantShare:ie,guard:de,gate:ue,passes:!ue,oppList:w}}function fn(e){let t=[];for(let n of e.filter(e=>e[2]>0))for(t.push([...n]);t.length>=2;){let e=t[t.length-2],n=t[t.length-1];if(e[1]/e[2]<=n[1]/n[2])break;t.pop(),t[t.length-1]=[e[0]+n[0],e[1]+n[1],e[2]+n[2]]}return{points:t.map(e=>[e[0]/e[2],e[1]/e[2]]),bins:e,pairs:e.reduce((e,t)=>e+t[2],0)}}function pn(e,t){let n=e.points;if(!n.length)return t;if(n.length===1||t<=n[0][0])return n[0][1];for(let e=1;e<n.length;e++){let[r,i]=[n[e-1],n[e]];if(t<=i[0]){let e=i[0]>r[0]?(t-r[0])/(i[0]-r[0]):1;return r[1]+e*(i[1]-r[1])}}return n[n.length-1][1]}function mn(e,t){let n=[...new Set(e.map(e=>e.task))].sort();return e.map(e=>n.indexOf(e.task)%t)}function hn(e,t){let n=Object.keys(Qt),r=[];for(let e of n){r.push([nn(e,{fail:e===`F`})]);for(let t of n)r.push([nn(e),nn(t,{fail:t===`F`})])}let i=[];for(let a of r)for(let r of n.filter(e=>Qt[e]===`act`||Qt[e]===`read`)){let n=[...a,nn(r)];e.filter(e=>sn(e,n)).length>=t&&i.push({key:``,text:``,items:n,cut:a.length})}return i}function gn(e){let t=mn(e,Wt),n=Array.from({length:Gt},()=>[0,0,0]);for(let r=0;r<Wt;r++){let i=e.filter((e,n)=>t[n]!==r),a=e.filter((e,n)=>t[n]===r);if(i.length&&a.length)for(let e of hn(i,3)){let t=dn(i,e),r=e.items.slice(0,e.cut);for(let i of a){if(!sn(i,r))continue;let a=Math.min(199,Math.floor(t.conf*Gt));n[a][0]+=t.conf,n[a][1]+=+!!sn(i,e.items),n[a][2]+=1}}}return fn(n)}var _n=e=>e>0?Math.log2(e):0,vn=e=>e>0?e*Math.log2(e):0,yn=(e,t)=>{let n=e+t,r=e=>e>0?-e*_n(e/n):0;return r(e)+r(t)};function bn(e){let t=e.items.slice(0,e.cut),n=e.items.slice(e.cut),r=t[t.length-1];return r.fail?`avoid`:Qt[n[0].code]===`read`?`read-batch`:r.last&&Qt[r.code]===`edit`?`obligation`:n.filter(e=>Qt[e.code]===`act`).length>=2?`sequence`:`run`}var xn=class{traces;freq=new Map;usage=new Map;n=0;uTotal=0;sSum=0;streams=0;model=0;avail;constructor(e){this.traces=e;for(let t of e)for(let e of t.ev)this.n++,this.freq.set(`x:${e.exact}`,(this.freq.get(`x:${e.exact}`)??0)+1),this.freq.set(`c:${e.code}`,(this.freq.get(`c:${e.code}`)??0)+1),this.usage.set(e.exact,(this.usage.get(e.exact)??0)+1);this.uTotal=this.n,this.sSum=[...this.usage.values()].reduce((e,t)=>e+vn(t),0),this.model=[...this.usage.keys()].reduce((e,t)=>e-_n(this.freq.get(`x:${t}`)/this.n),0),this.avail=e.map(e=>e.ev.map(()=>!0))}total(){return vn(this.uTotal)-this.sSum+this.streams+this.model}patternBits(e){return e.reduce((e,t)=>e-_n(this.freq.get(`c:${t.code}`)/this.n)+Bt,0)+_n(6)}tryAdd(e,t){let{items:n,cut:r}=e.cand,i=new Map,a=[],o=new Map,s=0,c=0,l=0;for(let t of e.oppList){let e=this.traces[t],u=this.avail[t].slice(),d=on(e,n.slice(0,r));s+=d.length;let f=!1;for(let t of d){let a=cn(e,t,n.slice(r),u);if(!a)continue;f=!0,c++;let s=t;a.forEach((t,a)=>{u[t]=!1;let c=`${a}:${Math.abs(t-s)}`;i.set(c,(i.get(c)??0)+1),s=t;let d=e.ev[t].exact;o.set(d,(o.get(d)??0)+1),l-=_n(this.freq.get(`x:${d}`)/this.freq.get(`c:${n[r+a].code}`))})}f&&a.push([t,u])}if(c===0)return{gain:0,hits:c,anchors:s};let u=this.total(),d=this.sSum,f=this.model+this.patternBits(n),p=0;for(let[e,t]of o){p+=t;let n=this.usage.get(e);d+=vn(n-t)-vn(n),n-t<=0&&(f-=-_n(this.freq.get(`x:${e}`)/this.n))}let m=this.uTotal-p,h=[...i.values()].reduce((e,t)=>e-t*_n(t/c),0),g=yn(c,s-c)+h+l,_=u-(vn(m)-d+this.streams+g+f);if(_>0&&t){for(let[e,t]of o)this.usage.set(e,this.usage.get(e)-t);this.sSum=d,this.model=f,this.uTotal=m,this.streams+=g;for(let[e,t]of a)this.avail[e]=t}return{gain:_,hits:c,anchors:s}}};function Sn(e,t){let n=t.filter(e=>e.passes).sort((e,t)=>t.value-e.value||t.support-e.support||(e.cand.text<t.cand.text?-1:1)),r=new Map;for(let e of n){let t=bn(e.cand),n=t===`avoid`?St[e.cand.items.slice(0,e.cand.cut).reverse().find(e=>e.fail).code].label:null,i=`${t}|${n??``}`;r.has(i)||r.set(i,{shape:t,runner:n,entries:[]}),r.get(i).entries.push({sc:e,bound:0,gain:0,kept:!1})}for(let t of r.values()){let n=new xn(e);t.entries.forEach(e=>e.bound=n.tryAdd(e.sc,!1).gain);let r=t.entries.map((e,t)=>({g:e.bound,pos:t,e})).filter(e=>e.g>0);for(;r.length;){let e=0;r.forEach((t,n)=>{let i=r[e];(t.g>i.g||t.g===i.g&&t.pos<i.pos)&&(e=n)});let t=r.splice(e,1)[0],i=n.tryAdd(t.e.sc,!1).gain;i<=0||(r.every(e=>i>e.g||i===e.g&&t.pos<e.pos)?(n.tryAdd(t.e.sc,!0),t.e.gain=i,t.e.kept=!0):r.push({...t,g:i}))}}return[...r.values()]}function Cn(){let e=tn,t=rn.map(t=>dn(e,t)),n=gn(e);for(let e of t){let t=Math.min(1-1e-6,Math.max(1e-6,pn(n,e.conf))),r=e.alpha+e.beta;e.confCal=t,e.confLbCal=Ot(t*r,(1-t)*r).q05}let r=Sn(e,t),i=new Map;for(let t of e)for(let e of new Set(t.ev.filter(e=>e.code===`F`).map(e=>e.exact)))i.set(e,(i.get(e)??0)+1);return{traces:e,scored:t,cal:n,tables:r,runners:i,compiled:Tn(t,r,i,e.length),days:new Set(e.map(e=>e.day)).size}}var wn={seq:[`G`,`C`],obl:[`G`],ctx:[`C`],npm:[`F`],avoid:[`C`]};function Tn(e,t,n,r){let i=new Set(t.flatMap(e=>e.entries.filter(e=>e.kept).map(e=>e.sc.cand.key))),a=[];for(let t of e){if(!t.passes)continue;let e=t.cand,o=bn(e),s=e.cut>=2,c={sc:t,shape:s?`${o} · context`:o};if(s&&!i.has(e.key)){a.push({...c,lamp:null,dropped:`a context that saves no bits is not compiled`});continue}if(t.variantShare<Lt){a.push({...c,lamp:null,dropped:`no spelling holds ${Lt} of its runs`});continue}if(o===`avoid`){let i=St[e.items[0].code].label.replace(` ✗`,``),o=(n.get(i)??0)/r,s=o>=Yt,l=s?`inhibit`:t.confLb>=qt?`fire`:t.conf>=Jt?`prime`:null;a.push({...c,lamp:l,dropped:null,atStart:s,share:o});continue}let l=s?t.confLb>=qt?`fire`:t.conf>=Jt?`prime`:null:`prime`;a.push({...c,lamp:l,dropped:l?null:`below the prime rate`})}let o=a.filter(e=>e.shape===`avoid`&&e.lamp).map(e=>e.sc.cand.items[0].code);for(let e of a)e.shape!==`avoid`&&!e.dropped&&(wn[e.sc.cand.key]??[]).some(e=>o.includes(e))&&(e.dropped=`directs ${St.F.label.replace(` ✗`,``)}, which an avoid names`);return a}var En={cards:{target:[-.6,0,0],yaw:-.08,pitch:.1,dist:21},axis:{target:[0,0,0],yaw:0,pitch:.08,dist:21},tables:{target:[0,.4,0],yaw:0,pitch:.12,dist:21},reflexes:{target:[-.6,0,0],yaw:-.06,pitch:.1,dist:21},track:{target:[0,0,0],yaw:0,pitch:.1,dist:22}},Dn={seq:`gen → check after an edit`,obl:`gen after the last edit`,ctx:`[edit, gen] → check`,seq2:`[prompt, edit] → gen → check`,avoid:`npm test ✗ → make check`,npm:`[read, edit src] → npm test`,status:`git status → make check`,curl:`curl → make check`},On={seq:{trigger:`after an edit to registry/*.csv`,step:`make gen, then make check`},obl:{trigger:`the last edit to registry/*.csv`,step:`make gen before finishing`},ctx:{trigger:`after [edit registry/*.csv, make gen]`,step:`make check`},avoid:{trigger:`at session start`,step:`npm test fails here · make check works`},npm:{trigger:`after [read src/*.ts, edit src/*.ts]`,step:`npm test`}},kn={sequence:-6.4,obligation:-2.1,run:2.1,avoid:6.4},An={seq:`edit → gen → check`,obl:`last edit → gen`,ctx:`[edit, gen] → check`,seq2:`[prompt, edit] → gen → check`,avoid:`npm test ✗ → check`,npm:`[read, edit] → npm test`},jn=e=>e.replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`);function Mn(e){let t=Cn(),n=t.scored,r=n.map(e=>e.cand.key),i=new Map(n.map(e=>[e.cand.key,e])),a=new Map(t.compiled.map(e=>[e.sc.cand.key,e])),o=new Map(t.tables.flatMap(e=>e.entries.map(t=>[t.sc.cand.key,{...t,table:e}]))),s=n.filter(e=>e.passes),c=n.filter(e=>!e.passes),l=[...o.values()].filter(e=>e.kept),u=[...o.values()].filter(e=>!e.kept),d=t.compiled.filter(e=>e.lamp&&!e.dropped),f=t.compiled.filter(e=>e.lamp&&e.dropped),p=i.get(`seq`);for(let t of r)e.dot(t,.2),e.dot(`${t}.raw`,.12),e.dot(`${t}.a`,.16),e.dot(`${t}.b`,.26),e.dot(`${t}.c`,.16);e.dot(`why.a`,.2),e.dot(`why.b`,.2);let m=(e,t=r.length,n=4.3)=>n-2*n*e/(t-1),h=e=>[-6.6,m(r.indexOf(e)),0],g=e=>i.get(e).passes?h(e):[-5.8,m(r.indexOf(e))-.4,-1.5],_=e=>-6.5+(e-.5)/.5*10.5,v=e=>m(s.findIndex(t=>t.cand.key===e),s.length,3.2),y=new Map,b=new Map;for(let e of t.tables){let t=kn[e.shape];e.entries.forEach((n,r)=>{y.set(n.sc.cand.key,[t,.2-r*1.5,0]),b.set(n.sc.cand.key,n.kept?[t,2.4-e.entries.filter(e=>e.kept).indexOf(n)*1.5,0]:[t,-3.6,-1])})}let x=t.compiled.filter(e=>e.lamp),S=e=>m(x.findIndex(t=>t.sc.cand.key===e),x.length,3.6),C=[-8.2,-7,-5.8],w=s.map(e=>e.cand.key);e.link(`shift`,w.map(e=>[`${e}.raw`,e]),`ink3`),e.link(`axis`,[[[_(.5),-4.3,0],[_(1),-4.3,0]],...[.5,.6,.7,.8,.9,1].map(e=>[[_(e),-4.3,0],[_(e),-4.5,0]])],`ink3`),e.link(`prime`,[[[_(Jt),-4.3,0],[_(Jt),3.8,0]]],`prime`);let T=(e,t,n)=>{let[r,i]=[e-1.9,e+1.9];return[[[r,t,0],[i,t,0]],[[i,t,0],[i,n,0]],[[i,n,0],[r,n,0]],[[r,n,0],[r,t,0]]]};e.link(`tables`,Object.values(kn).flatMap(e=>T(e,3.4,-2.3)),`ink3`),e.link(`arcs`,x.flatMap(e=>[[`${e.sc.cand.key}.a`,`${e.sc.cand.key}.b`],[`${e.sc.cand.key}.b`,`${e.sc.cand.key}.c`]]),`accent`),e.link(`interlock`,f.map(e=>[`avoid.b`,`${e.sc.cand.key}.b`]),`ink2`);let E=(e,t,n,r)=>[[[e,n,0],[t,n,0]],[[t,n,0],[t,r,0]],[[t,r,0],[e,r,0]],[[e,r,0],[e,n,0]]];e.link(`folders`,[...E(-7.8,-3.2,3.2,-3.4),...E(-2.2,7.4,3.2,-3.4)],`ink3`);for(let t of n){let n=t.cand.key;e.label(`card.${n}`,`${jn(t.cand.text)}<br><span class="how-dim">${t.support} of ${t.opp} traces</span>`,n,{cls:`chip`,dx:14,dy:-17});let r=t.passes?`✓ ${jn(Dn[n])} <span class="how-dim">· ${t.guard?`guard LB ${K(t.confLb)}`:`V ${K(t.value)}`}${t.consistency===null?` · contrast ${K(t.contrast)}`:` · consistency ${K(t.consistency)}`}</span>`:`✗ ${jn(Dn[n])} <span class="how-dim">· ${jn(t.gate)}</span>`;e.label(`gate.${n}`,r,n,{cls:t.passes?`chip`:`note`,dx:14,dy:-9}),e.label(`axis.${n}`,`${jn(Dn[n])} <span class="how-dim">${K(t.conf)} → ${K(t.confCal)}</span>`,n,{dx:12,dy:-18});let i=o.get(n);i&&(e.label(`bits.${n}`,jn(An[n]),n,{dy:12,center:!0}),e.label(`gain.${n}`,i.kept?`−${i.gain.toFixed(1)} bits`:`saves 0 bits · falls away`,n,{cls:`note`,dy:28,center:!0}));let s=a.get(n);if(s?.lamp){let t=On[n];e.label(`rx.${n}`,`<small>${jn(s.shape.toUpperCase())} · ${jn(t.trigger)}</small><span class="how-lamp ${s.lamp}">●</span> ${s.lamp} · ${jn(t.step)}`,`${n}.c`,{cls:`chip big`,dx:16,dy:-20}),s.dropped&&e.label(`drop.${n}`,`dropped · ${jn(s.dropped)}`,`${n}.b`,{cls:`note`,dx:16,dy:20})}}for(let[n,r]of Object.entries(kn)){let i=t.tables.find(e=>e.shape===n),a=n===`avoid`&&i?.runner?`avoid · ${jn(i.runner.replace(` ✗`,``))}`:n;e.label(`col.${n}`,`<small>CODE TABLE</small>${a}`,[r,3.4,0],{cls:`chip`,dy:-44,center:!0})}e.label(`ax.lo`,`0.50`,[_(.5),-4.5,0],{dy:4,center:!0}),e.label(`ax.hi`,`1.00`,[_(1),-4.5,0],{dy:4,center:!0}),e.label(`ax.name`,`posterior mean · raw → calibrated`,[0,-4.5,0],{dy:4,center:!0}),e.label(`ax.prime`,`prime needs 0.50`,[_(Jt),3.8,0],{cls:`note`,dy:-16,center:!0}),e.label(`f.why`,`<small>BESIDE IT · PEOPLE ONLY</small>.why.json`,[-5.5,3.2,0],{cls:`chip`,dy:-44,center:!0}),e.label(`f.track`,`<small>ONE TRACK</small>&lt;repo&gt;/learned`,[2.6,3.2,0],{cls:`chip`,dy:-44,center:!0}),e.label(`report`,`<small>NEXT</small>each is judged again on the traces,<br>then weighed by what telling changes (uplift)`,[2.6,-3.4,0],{cls:`chip`,dy:12,center:!0}),e.label(`why.a`,`pattern · backoff · gain in bits`,`why.a`,{dx:12,dy:-8}),e.label(`why.b`,`lift · confidence · example traces`,`why.b`,{dx:12,dy:-8});for(let t of d)e.label(`sh.${t.sc.cand.key}`,jn(t.shape),`${t.sc.cand.key}.b`,{dy:14,center:!0});function D(e){let t={},r=[];for(let i of n){let n=i.cand.key,s=o.get(n),c=a.get(n);if(e===0)t[n]={pos:h(n),color:`soft`,glow:.35},r.push(`card.${n}`);else if(e===1)t[n]=i.passes?{pos:g(n),color:`soft`,glow:.45}:{pos:g(n),color:`ink3`,alpha:.5,glow:0},r.push(`gate.${n}`);else if(e===2){if(!i.passes)continue;let e=v(n);t[`${n}.raw`]={pos:[_(i.conf),e,0],color:`ink3`,alpha:.8,glow:0},t[n]={pos:[_(i.confCal),e,0],color:`accent`,glow:.6},r.push(`axis.${n}`)}else if(e===3||e===4){if(!s)continue;let i=e===3?y.get(n):b.get(n),a=e===4&&!s.kept;t[n]={pos:i,color:a?`ink3`:`accent`,alpha:a?.45:1,scale:e===4&&s.kept?1.25:1,glow:a?0:.6},r.push(`bits.${n}`),e===4&&r.push(`gain.${n}`)}else if(c?.lamp&&e>=5){let i=S(n),a=e>=6&&c.dropped,o=a?`ink3`:c.lamp;if(e<=6){let s=a?-.35:0;t[`${n}.a`]={pos:[C[0],i+s,0],color:`soft`,alpha:a?.35:.9,glow:.2},t[`${n}.b`]={pos:[C[1],i+s,0],color:o,alpha:a?.5:1,glow:a?0:.9},t[`${n}.c`]={pos:[C[2],i+s,0],color:`soft`,alpha:a?.35:.9,glow:.2},r.push(`rx.${n}`),e===6&&c.dropped&&r.push(`drop.${n}`)}else if(!c.dropped){let e=d.findIndex(e=>e.sc.cand.key===n),r=-1.4+e%2*4.4,i=1.6-Math.floor(e/2)*2.4;t[`${n}.a`]={pos:[r,i,0],color:`soft`,glow:.2},t[`${n}.b`]={pos:[r+.9,i,0],color:c.lamp,glow:.9},t[`${n}.c`]={pos:[r+1.8,i,0],color:`soft`,glow:.2}}}}return e===7&&(t[`why.a`]={pos:[-7.1,1.6,0],color:`ink2`,glow:.3},t[`why.b`]={pos:[-7.1,-.8,0],color:`ink2`,glow:.3},r.push(`why.a`,`why.b`,`f.why`,`f.track`,`report`,...d.map(e=>`sh.${e.sc.cand.key}`))),e===2&&r.push(`ax.lo`,`ax.hi`,`ax.name`,`ax.prime`),(e===3||e===4)&&r.push(...Object.keys(kn).map(e=>`col.${e}`)),{dots:t,labels:r,cam:e<=1?En.cards:e===2?En.axis:e<=4?En.tables:e<=6?En.reflexes:En.track,links:{shift:e===2?.7:0,axis:e===2?.6:0,prime:e===2?.5:0,tables:e===3||e===4?.35:0,arcs:e>=5?.75:0,interlock:e===6?.8:0,folders:e===7?.4:0}}}let O=`10px 'Red Hat Mono', ui-monospace, monospace`,k=[{title:`Candidate habits arrive`,plain:`The pattern finder hands over candidate habits, each with the sessions behind it: here ${n.length} of them, found across ${t.traces.length} sessions.`,body:`Mining hands over closed patterns, each read as a prediction: after this context, this follows. Here are ${n.length} sample candidates over ${t.traces.length} sample traces, among them the registry pattern from the previous chapter. Support counts distinct traces; opportunities are the traces where the context occurs.`,chips:[{text:`${n.length} sample candidates`},{text:`≤ ${Ht.toLocaleString(`en`)} closed patterns scored`},{text:`${t.traces.length} traces over ${t.days} days`}]},{title:`Common is not the same as useful`,plain:`Common is not the same as useful. Each candidate must be seen in enough sessions, really be tied to its trigger, and be likely to hold. ${c.length} of ${n.length} do not make it.`,math:`graph`,key:!0,body:`Confidence is a Beta posterior shrunk toward the parent context (κ ${Mt}), with evidence halved every ${Pt} days, and judged by its 5% quantile. ${p.cand.text.replace(/ → .*/,``)} predicts make gen then make check in ${p.support} of ${p.opp} traces, lower bound ${K(p.confLb)}. ${c.map(e=>`${Dn[e.cand.key]} fails on ${e.gate.split(` `)[0]}`).join(`; `)}.`,chips:[{text:`support ≥ ${At} · days ≥ ${jt}`},{text:`contrast ≥ ${K(Ft)} · or consistency ≥ ${It} after a failure`},{text:`V > 0 · guards LB ≥ ${K(Rt)}`},{text:`${s.length} of ${n.length} pass`,ok:!0}]},{title:`Adage checks its own confidence`,plain:`Adage checks its own confidence: it predicts on some sessions, tests on others it did not see, and corrects itself, so 80% sure means right 80% of the time.`,math:`graph`,body:`On ${Wt} task-grouped inner folds, every candidate's posterior mean is compared with what happened in the fold it did not see. Isotonic regression over ${Gt} bins bends the raw means onto the outcomes. Each candidate keeps both: the calibrated mean and lower bound are recorded beside the raw ones, which the compiler still reads.`,chips:[{text:`${Gt} bins · pool adjacent violators`},{text:`re-mined per fold below ${Kt} traces`},{text:`ECE 0.017 all pairs · 0.116 selected (demo-haiku45)`}],figure:(e,n,r,i)=>{let a=e=>6+e*(n-6-6),o=e=>r-14-e*(r-14-14);e.strokeStyle=i.css(`ink3`),e.globalAlpha=.5,e.setLineDash([3,3]),e.beginPath(),e.moveTo(a(0),o(0)),e.lineTo(a(1),o(1)),e.stroke(),e.setLineDash([]),e.globalAlpha=1;let s=Math.max(...t.cal.bins.map(e=>e[2]));e.fillStyle=i.css(`ink3`);for(let[n,r,i]of t.cal.bins)i&&(e.globalAlpha=.65,e.beginPath(),e.arc(a(n/i),o(r/i),1.2+2.6*Math.sqrt(i/s),0,Math.PI*2),e.fill());e.globalAlpha=1,e.strokeStyle=i.css(`accent`),e.lineWidth=2,e.beginPath(),t.cal.points.forEach(([t,n],r)=>r?e.lineTo(a(t),o(n)):e.moveTo(a(t),o(n))),e.stroke(),e.lineWidth=1,e.font=O,e.textBaseline=`top`,e.fillStyle=i.css(`ink3`),e.textAlign=`left`,e.fillText(`0`,a(0),r-14+2),e.textAlign=`right`,e.fillText(`1`,a(1),r-14+2),e.textAlign=`center`,e.fillText(`predicted → · dots: bins · line: isotonic map`,n/2,r-14+2),e.textAlign=`right`,e.fillText(`${t.cal.pairs.toLocaleString(`en`)} held-out pairs`,a(1),2),e.textAlign=`left`,e.fillText(`observed ↑`,a(0)+2,2)}},{title:`Like competes with like`,plain:`To choose between overlapping habits, Adage asks which ones let it describe the sessions most briefly. Habits that would say different things never compete with each other.`,math:`graph`,body:`Selection is by compression: a reflex earns its place by describing the traces in fewer bits. Candidates that would deliver different directives never compete, so each delivery shape gets its own table, and avoids get one per failing runner. A pattern costs its items' codes plus ${Bt} bits per item and log2 6 for its length.`,chips:[{text:`${t.tables.length} tables`},{text:`${Bt} bits per item + log2 6`},{text:`SQS-style MDL`}]},{title:`Keep what says something new`,plain:`${l.length} candidates make that description shorter, so they stay. One that only repeats what a shorter habit already says is dropped.`,math:`graph`,key:!0,body:`Each table fills best gain first, re-checking a candidate's gain before accepting it. ${l.length} candidates save bits. ${u.map(e=>Dn[e.sc.cand.key]).join(`, `)} would code the same make gen and make check that the shorter sequence already coded, so it saves nothing and falls away.`,chips:[{text:`lazy greedy, best gain first`},{text:`${l.length} kept · ${u.length} saves 0 bits`},{text:`≤ ${Vt} reflexes · ≤ ${Ut.toLocaleString(`en`)} gated extras compile`}],figure:(e,t,n,r)=>{let i=[...o.values()],a=Math.max(...i.map(e=>e.bound)),s=(t-8)/i.length;e.font=O,i.forEach((t,i)=>{let o=4+i*s,c=e=>e/a*(n-14-14);e.strokeStyle=r.css(`ink3`),e.strokeRect(o+6,n-14-c(t.bound),s-12,c(t.bound)),t.kept&&(e.fillStyle=r.css(`accent`),e.fillRect(o+6,n-14-c(t.gain),s-12,c(t.gain))),e.fillStyle=r.css(t.kept?`accent`:`ink3`),e.textAlign=`center`,e.textBaseline=`bottom`,e.fillText(t.kept?t.gain.toFixed(1):`0`,o+s/2,n-14-c(Math.max(t.bound,t.gain))-1),e.textBaseline=`top`,e.fillStyle=r.css(`ink3`),e.font=`9px 'Red Hat Mono', ui-monospace, monospace`,e.fillText(t.table.shape,o+s/2,n-14+2),e.font=O}),e.textAlign=`left`,e.textBaseline=`top`,e.fillStyle=r.css(`ink3`),e.fillText(`bits saved · outline: first estimate`,4,0)}},{title:`Each winner gets a strength`,plain:`Each winner gets a strength. The best-supported one is sure enough to tell the agent; newer ones start as suggestions; and the test command that keeps failing becomes a warning at the start of each session.`,math:`evidence`,body:`Each winner compiles to a delivery shape, and its strength is decided here. The context route's lower bound, ${K(i.get(`ctx`).confLb)}, reaches the ${K(qt)} fire bar. The sequence and the finish line compile provisional: they prime until their evidence is counted again on their own trigger. The dead end is announced at session start, because ${Math.round((a.get(`avoid`).share??0)*t.traces.length)} of ${t.traces.length} traces run npm test.`,chips:[{text:`fire: LB ≥ ${K(qt)} and a fire ceiling`},{text:`prime: mean ≥ ${K(Jt)}`},{text:`avoid at start: ≥ ${Yt} of traces run it`},{text:`instinct prior κ ${Xt} at ${Zt} · never above prime`}]},{title:`Contradictions are dropped`,plain:`One candidate recommends npm test, but another reflex warns that npm test fails here. A contradiction like that is dropped before anything is saved.`,body:`${f.map(e=>Dn[e.sc.cand.key]).join(`, `)} passed every gate and saved bits, but it directs npm test, the runner the avoid says fails here. A run or sequence that directs an avoided runner is dropped before anything is written.`,chips:[{text:`interlock before emission`},{text:`${d.length} reflexes delivered`}]},{title:`Saved, with the reasons why`,plain:`The ${d.length} survivors are saved together, each with a note explaining why it exists, for you to review. The agent never sees those notes.`,body:`The ${d.length} survivors are written to one track, <repo>/learned: the graph engine is the only learner, so there is no track per kind of reflex. Beside it, .why.json records why each exists: the mined pattern, how many context items it conditions on, the bits it saved, its lift and confidence, and example traces. adage review reads it; the agent never sees it, and it never travels in a shared pack. Each reflex is then judged again on the traces, next.`,chips:[{text:`tracks/<repo>/learned`},{text:`.why.json · never rendered to the agent`},{text:`stable ids: review decisions survive re-learning`}]}];return{source:`${n.length} sample candidates · ${t.traces.length} sample traces`,legend:[{label:`candidate`,role:`soft`},{label:`selected`,role:`accent`},{label:`fire`,role:`fire`},{label:`prime`,role:`prime`},{label:`inhibit (avoid)`,role:`inhibit`},{label:`dropped`,role:`ink3`}],steps:k.map((e,t)=>({...e,state:D(t)}))}}var Nn={id:`choose`,title:`Keep the useful ones`,technical:`Choose and compile`,status:`Built · the learner`,kind:`built`,summary:`Not every repeated pattern is worth saying. Adage keeps the reliable ones that add something new, and turns each into a reflex.`,source:`crates/adage-graph/src/{score,select,compile} · crates/adage-tracks/src/why.rs`,usesRepo:!1,build:Mn},Pn=8,Fn=3,In=2,Ln=3,Rn=.1,zn=200,Bn=[{path:`no match`,p50:4,p95:10,measured:1.76},{path:`structured`,p50:6,p95:15,measured:3.18},{path:`intent`,p50:10,p95:25,measured:6.39}];function Vn(e){let t=new Uint32Array([1116352408,1899447441,3049323471,3921009573,961987163,1508970993,2453635748,2870763221,3624381080,310598401,607225278,1426881987,1925078388,2162078206,2614888103,3248222580,3835390401,4022224774,264347078,604807628,770255983,1249150122,1555081692,1996064986,2554220882,2821834349,2952996808,3210313671,3336571891,3584528711,113926993,338241895,666307205,773529912,1294757372,1396182291,1695183700,1986661051,2177026350,2456956037,2730485921,2820302411,3259730800,3345764771,3516065817,3600352804,4094571909,275423344,430227734,506948616,659060556,883997877,958139571,1322822218,1537002063,1747873779,1955562222,2024104815,2227730452,2361852424,2428436474,2756734187,3204031479,3329325298]),n=new TextEncoder().encode(e),r=Math.ceil((n.length+9)/64)*64,i=new Uint8Array(r);i.set(n),i[n.length]=128;let a=n.length*8,o=new DataView(i.buffer);o.setUint32(r-8,Math.floor(a/2**32)),o.setUint32(r-4,a>>>0);let s=new Uint32Array([1779033703,3144134277,1013904242,2773480762,1359893119,2600822924,528734635,1541459225]),c=new Uint32Array(64),l=(e,t)=>e>>>t|e<<32-t;for(let e=0;e<r;e+=64){for(let t=0;t<16;t++)c[t]=o.getUint32(e+t*4);for(let e=16;e<64;e++){let t=c[e-15],n=c[e-2],r=l(t,7)^l(t,18)^t>>>3,i=l(n,17)^l(n,19)^n>>>10;c[e]=c[e-16]+r+c[e-7]+i>>>0}let[n,r,i,a,u,d,f,p]=s;for(let e=0;e<64;e++){let o=l(u,6)^l(u,11)^l(u,25),s=u&d^~u&f,m=p+o+s+t[e]+c[e]>>>0,h=(l(n,2)^l(n,13)^l(n,22))+(n&r^n&i^r&i)>>>0;p=f,f=d,d=u,u=a+m>>>0,a=i,i=r,r=n,n=m+h>>>0}[n,r,i,a,u,d,f,p].forEach((e,t)=>s[t]=s[t]+e>>>0)}let u=new Uint8Array(32),d=new DataView(u.buffer);return s.forEach((e,t)=>d.setUint32(t*4,e)),u}function Hn(e){let t=Vn(`adage-arm:${e}`);return((t[0]|t[1]<<8|t[2]<<16|t[3]<<24)>>>0)/4294967295}function Un(e){return e.length>0&&e.length<=zn&&!e.startsWith(`-`)&&/^[A-Za-z0-9_./:@=+,-]+$/.test(e)}var Wn={id:`finish-line-registry`,glob:`registry/*.csv`,run:`make gen`},Gn={id:`dead-end-npm-test`,avoid:`npm test`,word:`npm`,instead:`make check`},Kn={id:`npm-test-after-edit`,glob:`src/*.ts`,run:`npm test`},qn=[Wn.glob,Kn.glob],Jn=e=>RegExp(`^${e.replace(/[.+^${}()|[\]\\]/g,`\\$&`).replace(/\*/g,`[^/]*`)}$`),Yn=e=>e.includes(Gn.word)||qn.some(t=>t.split(`*`).every(t=>e.includes(t))),Xn=(e,t)=>t===e||t.startsWith(`${e} -`);function Zn(){return Ct.map((e,t)=>{let n=`T${t+1}`,r=Hn(n),i={prompts:0,emitted:new Set,obligations:[],pending:0,stops:0},a=[],o=(e,n,r,i=[],o=[])=>a.push({id:`e${t}.${a.length}`,kind:e,text:n,pass:r,out:i,judged:o});o(`start`,`session start`,!1);for(let[t,n]of e){if(t===`P`||t===`D`){let e=i.prompts===0,t=[];e&&(i.prompts++,i.emitted.add(Gn.id),t.push({route:Gn.id,strength:`inhibit`,what:`${Gn.avoid} fails · use ${Gn.instead}`})),o(`prompt`,n,e,t);continue}if(t===`F`){o(`failure`,`${n} ✗`,Yn(n)||i.pending>0);continue}let e=Yn(n)||i.pending>0||i.obligations.length>0,r=[],a=[];if(e){for(let e of i.obligations.filter(e=>!e.met&&Xn(Wn.run,n)))e.met=!0,a.push(`met`);let e=n.startsWith(`edit `)?n.slice(5):null;if(e&&Jn(Wn.glob).test(e)){let e=i.obligations[0];e?e.met&&Object.assign(e,{met:!1,asked:!1}):i.emitted.has(Wn.id)||(i.emitted.add(Wn.id),i.obligations.push({met:!1,asked:!1}),r.push({route:Wn.id,strength:`fire`,what:`finish line · ${Wn.run}`}))}if(e&&Jn(Kn.glob).test(e)){let e=i.emitted.has(Gn.id);r.push({route:Kn.id,strength:`prime`,what:`run ${Kn.run}`,struck:e}),e||i.emitted.add(Kn.id)}}o(`batch`,n,e,r,a)}let s=i.obligations.find(e=>!e.met&&!e.asked),c=[];return s&&i.stops<In&&(s.asked=!0,i.stops++,c.push({route:Wn.id,strength:`fire`,what:`stop request · ${Wn.run} not run`,stop:!0})),o(`stop`,`stop`,!!s,c),{id:n,name:n,x:r,control:r<Rn,events:a}})}function Qn(e){return/prompt/i.test(e)?`prompt`:/fail/i.test(e)?`failure`:/stop/i.test(e)?`stop`:/start|end/i.test(e)?`start`:`batch`}function $n(e){let t=new Map(e.routes.map(e=>[e.id,_(e.strength)??`prime`])),n=new Map;for(let t of e.events)n.set(t.session,[...n.get(t.session)??[],t]);let r=e=>Math.max(...e.map(e=>e.ts));return[...n.entries()].sort((e,t)=>r(t[1])-r(e[1])).slice(0,12).map(([e,n],r)=>{let i=Hn(e),a=n.some(e=>e.arm===`control`),o=[...n].sort((e,t)=>e.ts-t.ts).slice(-7);return{id:e,name:se(e),x:i,control:a,events:o.map((e,n)=>({id:`e${r}.${n}`,kind:Qn(e.event),text:e.event,pass:!0,out:[...(a?e.would:e.directed).map(e=>({route:e,strength:t.get(e)??`prime`,what:e})),...e.continue?[{route:`stop`,strength:`fire`,what:`stop request`,stop:!0}]:[]],judged:e.judged.map(([e])=>k(e))}))}})}var er={start:40,prompt:262,batch:205,failure:300,stop:160},tr=-1.4,nr=e=>-9+e*.98,rr=e=>.4+e*1.2,ir=e=>-6+12*e,ar=4.4,or={queue:{target:[-1.4,-.6,.4],yaw:-.42,pitch:.72,dist:24},coin:{target:[0,3.8000000000000003,0],yaw:0,pitch:.18,dist:17},lanes:{target:[4.2,.4,.2],yaw:-.1,pitch:.95,dist:20},lock:{target:[3.4,0,0],yaw:-.12,pitch:.62,dist:15},bind:{target:[-1.2,.2,0],yaw:0,pitch:.1,dist:17},follow:{target:[-.6,0,0],yaw:.08,pitch:.16,dist:17}},sr={prompt:`Pick up W-1042…`,contract:`^W-\\d{4}$`,command:`python3 scripts/wi-lookup {id}`,key:`exec python3 scripts/wi-lookup {id}`,values:[`W-1042`,`W-10423`,`--help`,`W-1042;rm`,`$(curl x)`],batches:[`grep -rn W-1042 src`,`python3 scripts/wi-lookup W-1042`,``]};function cr(e,t){let n=t.repo&&t.graph?$n(t.graph):[],r=n.length>0,i=r?n:Zn(),a=i.flatMap(e=>e.events),o=a.filter(e=>e.pass),s=a.length-o.length,c=e=>a.filter(t=>!t.pass&&t.kind===e).length,l=i.filter(e=>!e.control),u=i.filter(e=>e.control),d=i.flatMap(e=>e.events.flatMap(t=>t.out.map(n=>({s:e,e:t,o:n})))),f=d.filter(e=>!e.o.struck),p=d.filter(e=>e.o.struck),m=f.filter(e=>!e.s.control&&!e.o.stop).length,h=f.filter(e=>e.s.control&&!e.o.stop).length,g=f.filter(e=>e.o.stop),_=Math.max(0,...a.map(e=>e.out.filter(e=>!e.struck&&!e.stop).length)),v=Math.max(0,...i.map(e=>e.events.reduce((e,t)=>e+t.out.filter(e=>!e.struck&&!e.stop).length,0))),y=e=>a.flatMap(e=>e.judged).filter(t=>t===e).length,b=y(`met`),x=y(`followed`),S=y(`ignored`),C=i.filter(e=>e.x<Rn===e.control).length,w=[...l,...u],T=e=>i.length===Ct.length?Tt(e):(e-(i.length-1)/2)*1.25,E=e=>-6.4+w.indexOf(e)*1.05+(e.control?.9:0);for(let t of i){e.dot(`coin${t.id}`,.2);for(let n of t.events)e.dot(n.id,.15),n.out.forEach((t,r)=>e.dot(`${n.id}.o${r}`,.2))}let D=new Map;i.forEach((e,t)=>{let n=0,r=0;e.events.forEach((i,a)=>{let o=T(t),s=i.pass?n++:n;D.set(i.id,{queue:[nr(a),0,o],pass:[rr(s),0,o],pile:[-2.3-r*.42,-2.7,o],arm:[rr(s),0,E(e)]}),i.pass||r++})});let O=Math.abs(T(0))+.8;e.link(`gate`,[[[tr,-1.2,-O],[tr,-1.2,O]],[[tr,1.2,-O],[tr,1.2,O]],[[tr,-1.2,-O],[tr,1.2,-O]],[[tr,-1.2,O],[tr,1.2,O]]],`accent`),e.link(`axis`,[[[ir(0),ar,0],[ir(1),ar,0]],...[0,.5,1].map(e=>[[ir(e),4.220000000000001,0],[ir(e),4.58,0]])],`ink3`),e.link(`share`,[[[ir(Rn),3.1000000000000005,0],[ir(Rn),5.800000000000001,0]]],`accent`);let k=[],A=[];for(let e of a)e.out.forEach((t,n)=>(t.struck?A:k).push([e.id,`${e.id}.o${n}`]));e.link(`stems`,k,`ink3`),e.link(`struckStems`,A,`ink3`);let j=[];for(let e of i){let t=e.events.find(e=>e.out.some(e=>e.route===Wn.id&&!e.stop)),n=e.events.find(e=>e.judged.includes(`met`));t&&n&&j.push([`${t.id}.o${t.out.findIndex(e=>e.route===Wn.id)}`,n.id])}e.link(`met`,j,`accent`);let M=e=>-(e.length*6.6+14);i.forEach((t,n)=>e.label(`lane${n}`,t.name,t.events[0].id,{dx:M(t.name),dy:-7})),i.forEach((t,n)=>{let r=t.events.find(e=>e.pass);r&&e.label(`arm${n}`,t.control?`${t.name} <span class="how-dim">control</span>`:t.name,r.id,{cls:t.control?`note`:``,dx:M(t.name)-(t.control?54:0),dy:-7})}),e.label(`gate`,`<small>FAST PATH</small>could this event change anything?`,[tr,1.2,-O],{cls:`chip`,dy:-44,center:!0}),e.label(`pile`,`${s} skipped · no lock, no spool`,[-3,-2.7,T(i.length-1)],{cls:`note`,dy:16,center:!0}),e.label(`passed`,`${o.length} decided`,[rr(3),.6,T(0)],{cls:`note`,dy:-26,center:!0}),e.label(`ax0`,`0`,[ir(0),ar,0],{dx:-12,dy:-7}),e.label(`ax1`,`1`,[ir(1),ar,0],{dx:8,dy:-7}),e.label(`share`,`control if x &lt; ${Rn}`,[ir(Rn),5.800000000000001,0],{cls:`chip`,dy:-30,center:!0}),e.label(`treatedSide`,`treated · ${l.length}`,[ir(.62),2.1000000000000005,0],{cls:`note`,center:!0});let N=[],P={above:[-26,-42,-58].map(e=>({dy:e,right:-1})),below:[14,46].map(e=>({dy:e,right:-1}))};[...i].sort((e,t)=>e.x-t.x).forEach(t=>{let n=i.indexOf(t),r=t.control?`${t.name}<br><span class="how-dim">x ${t.x.toFixed(3)}</span>`:t.name,a=(Math.max(t.name.length,7)*6.6+10)/560,o=(t.control?P.below:P.above).find(e=>t.x-a/2>e.right);o&&(o.right=t.x+a/2,e.label(`coin${n}`,r,`coin${t.id}`,{dy:o.dy,center:!0}),N.push(`coin${n}`))});let F=(e,t=!1)=>f.find(n=>e(n.o)&&n.s.control===t),I=[...f].reverse().find(e=>e.o.strength===`inhibit`&&!e.s.control),L=F(e=>e.route===Wn.id&&!e.stop),ee=g[0],te=[...f].reverse().find(e=>e.s.control),ne=e=>`${e.e.id}.o${e.e.out.indexOf(e.o)}`;I&&e.label(`lInhibit`,`<span class="how-lamp inhibit">●</span> ${I.o.what}`,ne(I),{cls:`chip`,dx:70,dy:14,center:!0}),L&&e.label(`lFinish`,`<span class="how-lamp fire">●</span> ${L.o.what}`,ne(L),{cls:`chip`,dy:-30,center:!0}),ee&&e.label(`lStop`,ee.o.what,ne(ee),{cls:`note`,dy:-26,center:!0}),te&&e.label(`lWould`,`would have · not delivered`,ne(te),{cls:`note`,dx:14,dy:-7});let R=p.find(e=>!e.s.control)??p[0];R&&(e.label(`lStruck`,`<span class="how-lamp prime">●</span> ${R.o.what} · struck`,ne(R),{cls:`chip`,dx:14,dy:-9}),e.label(`lWhy`,`the inhibit announced at the first prompt:<br>${Gn.avoid} fails`,ne(R),{cls:`note`,dx:14,dy:14}));let re=p.flatMap(e=>{let t=e.s.events.flatMap(e=>e.out.map((t,n)=>({e,o:t,k:n}))).find(e=>e.o.strength===`inhibit`);return t?[[`${t.e.id}.o${t.k}`,ne(e)]]:[]});e.link(`lock`,re,`inhibit`),e.dot(`xPrompt`,.3),e.dot(`xTpl`,.36);let z=new RegExp(sr.contract),B=sr.values.map(e=>({v:e,contract:z.test(e),plain:Un(e)}));B.forEach((t,n)=>e.dot(`xv${n}`,.17));let ie=e=>2.4-e*1.2,ae=-.6;e.link(`xIn`,B.map((e,t)=>[`xPrompt`,`xv${t}`]),`ink3`),e.link(`xOk`,B.flatMap((e,t)=>e.contract&&e.plain?[[`xv${t}`,`xTpl`]]:[]),`accent`),e.link(`xGate`,[[[ae,-3.6,0],[ae,3.4,0]]],`accent`),e.label(`xPrompt`,`<small>PROMPT</small>${sr.prompt}`,`xPrompt`,{cls:`chip big`,dy:22,center:!0}),e.label(`xGate`,`<small>SLOT CONTRACT · PLAIN TOKEN</small>${sr.contract}`,[ae,3.4,0],{cls:`chip`,dy:-40,center:!0});let oe=e=>e?`✓`:`<span class="how-dim">✗</span>`;B.forEach((t,n)=>e.label(`xv${n}`,`${t.v.replace(/</g,`&lt;`)}&nbsp; ${oe(t.contract)}<span class="how-dim">contract</span> ${oe(t.plain)}<span class="how-dim">plain</span>`,`xv${n}`,{dx:14,dy:-8}));let se=B.find(e=>e.contract&&e.plain)?.v??``,ce=sr.command.replace(`{id}`,se);e.label(`xTpl`,`<small>FIXED TEMPLATE · PROMPT LOOKUP</small>In this repository, work item details<br>are looked up with:<br>&nbsp;&nbsp;${ce}`,`xTpl`,{cls:`chip big`,dy:22,center:!0}),e.dot(`fDir`,.3),sr.batches.forEach((t,n)=>e.dot(`fB${n}`,.24));let le=e=>-5.6+e*3.6;e.link(`fLine`,[[`fDir`,`fB0`],[`fB0`,`fB1`],[`fB1`,`fB2`]],`ink3`);let ue=sr.batches.findIndex(e=>e&&Xn(sr.command.replace(`{id}`,se),e));e.label(`fDir`,`<small>DIRECTED · PENDING</small>${ce}<br><span class="how-dim">${Ln} batches left</span>`,`fDir`,{cls:`chip big`,dy:24,center:!0}),sr.batches.forEach((t,n)=>{let r=Ln-n-1,i=n<ue?`<small>BATCH ${n+1}</small>${t}<br><span class="how-dim">no match · ${r} left</span>`:n===ue?`<small>BATCH ${n+1}</small>${t}<br>✓ followed`:`<small>BATCH ${n+1}</small><span class="how-dim">not needed. Without a match<br>here, it counts as ignored</span>`;e.label(`fB${n}`,i,`fB${n}`,{cls:n===ue?`chip big`:`chip`,dy:n%2?24:-66,center:!0})}),e.label(`fKey`,`meets ${sr.key}`,`fB${Math.max(0,ue)}`,{cls:`note`,dy:94,center:!0});let de=e=>({hue:er[e.kind]}),fe=new Set(p.map(e=>e.s));function pe(e){let t={};for(let n of i){for(let r of n.events){let i=D.get(r.id),a={pos:i.queue,color:de(r),glow:.2};if(e===1&&(a=r.pass?{pos:i.pass,color:de(r),glow:.3}:{pos:i.pile,color:`ink3`,alpha:.35,glow:0}),e===2&&(a=r.pass?{pos:[ir(n.x),ar,0],color:de(r),alpha:.15,scale:.5,glow:0}:{pos:i.pile,color:`ink3`,alpha:0}),e>=3){if(!r.pass)continue;a={pos:i.arm,color:de(r),alpha:n.control?.4:.9,glow:n.control?.05:.2},e===4&&(a.alpha=(a.alpha??1)*(fe.has(n)?.5:.15))}t[r.id]=a,e>=3&&r.out.forEach((a,o)=>{let[s,,c]=i.arm,l=a.stop?`accent`:a.strength;if(a.struck){e===3&&(t[`${r.id}.o${o}`]={pos:[s,1.2,c],color:l,alpha:n.control?.35:1,glow:.6}),e===4&&(t[`${r.id}.o${o}`]={pos:[s,-1.3,c],color:`ink3`,alpha:.6,scale:.8,glow:0});return}let u=n.control,d=e===4&&!(a.strength===`inhibit`&&re.some(([e])=>e===`${r.id}.o${o}`));t[`${r.id}.o${o}`]={pos:[s,a.stop?1.6:1.2,c],color:l,alpha:e===4&&!fe.has(n)?.1:u?e===7?.45:.3:d?.3:1,scale:u?.85:1,glow:u?e===7?.35:.1:d?0:e===7||e===4?.9:.6}})}e===2&&(t[`coin${n.id}`]={pos:[ir(n.x),ar,0],color:n.control?`ink2`:`accent`,scale:1.1,glow:n.control?.25:.6})}let n=[];return e===0&&n.push(...i.map((e,t)=>`lane${t}`)),e<=1&&n.push(`gate`),e===1&&n.push(...s?[`pile`]:[],`passed`),e===2&&n.push(`ax0`,`ax1`,`share`,`treatedSide`,...N),(e===3||e===7)&&n.push(...i.map((e,t)=>`arm${t}`)),e===3&&n.push(`lInhibit`,`lFinish`,`lStop`),e===4&&n.push(`lStruck`,`lWhy`),e===7&&n.push(`lWould`),{dots:t,labels:n,cam:e<=1?or.queue:e===2?or.coin:e===4&&R?{...or.lock,target:me()}:or.lanes,links:{gate:e<=1?.7:0,axis:e===2?.8:0,share:e===2?.9:0,stems:e===3||e===7?.35:e===4?.08:0,struckStems:e===3?.35:e===4?.3:0,met:e===3?.8:e===7?.5:0,lock:e===4?.75:0}}}function me(){let e=p.map(e=>D.get(e.e.id).arm),t=t=>e.reduce((e,n)=>e+n[t],0)/Math.max(1,e.length);return[t(0),0,t(2)]}function he(e){let t={},n=[];return e===5?(t.xPrompt={pos:[-7.4,0,0],color:{hue:er.prompt},glow:.5},B.forEach((e,r)=>{let i=e.contract&&e.plain;t[`xv${r}`]={pos:[i?.6:-4.6,ie(r),0],color:i?`accent`:`ink3`,alpha:i?1:.55,scale:i?1.3:1,glow:i?.8:0},n.push(`xv${r}`)}),t.xTpl={pos:[3.6,-.6,0],color:`fire`,glow:.9},n.push(`xPrompt`,`xGate`,`xTpl`)):(t.fDir={pos:[le(-1),0,0],color:`fire`,glow:.8},sr.batches.forEach((e,r)=>{t[`fB${r}`]=r===ue?{pos:[le(r),0,0],color:`accent`,scale:1.3,glow:.9}:{pos:[le(r),0,0],color:`ink3`,alpha:r>ue?.35:.8,glow:0},n.push(`fB${r}`)}),n.push(`fDir`,`fKey`)),{dots:t,labels:n,cam:e===5?or.bind:or.follow,links:e===5?{xIn:.35,xOk:.9,xGate:.7}:{fLine:.5}}}let ge=r?`your ${i.length} most recent traces`:`the ${i.length} sample traces`,V=[{title:`Moments to speak up`,plain:`As the agent works, it pauses at set moments: a session starts, a request arrives, a command runs, the agent wants to stop. At each one Adage gets a chance to speak.`,body:r?`Each row is one of ${ge}; each dot is a hook event the map recorded: a prompt, a tool batch, a failure, a stop. For each, the hook reads the payload, translates it through the harness adapter, and asks a pure function, decide(), what to say.`:`Each row is one of ${ge}, replayed as hook events: a session start, a prompt, tool batches, a failure, a stop. For each, the hook reads the payload, translates it through the harness adapter, and asks a pure function, decide(), what to say.`,chips:[{text:`payload → adapter → fast path → lock → arm → decide → spool → print`},{text:`fails open: errors go to fail-open.log`}]},{title:`Skipping what cannot matter`,plain:`Most moments cannot match anything, so Adage skips them in a couple of milliseconds and the agent never waits.`,body:r?`Before the state lock, the hook asks whether an event could change anything. Skipped events leave no spool record, so all ${o.length} of the events shown here are ones that passed; the map never sees the rest.`:`Before the state lock, the hook asks whether an event could change anything. ${s} of ${a.length} events here stop: ${c(`start`)} session starts, ${c(`stop`)} stops with no finish line open, and ${c(`batch`)+c(`failure`)} batches with no trigger word while nothing was pending. The check is on words, not parsed commands, so a read of src/registry/load.ts passes: it contains every piece of the glob src/*.ts.`,chips:[{text:`no match: p95 budget ${Bn[0].p95} ms · measured ${Bn[0].measured} ms`},{text:`never skips an event that would decide something`}],figure:lr},{title:`A fair coin picks the comparison group`,plain:`To prove Adage helps, about 1 in 10 sessions is quietly left alone, like the placebo group in a trial. The choice is random but repeatable: the same session always lands in the same group.`,math:`hook`,body:`The trace id is hashed: x is the first 4 bytes of sha256("adage-arm:" + id), little-endian, divided by u32::MAX. A trace is control if x is below the share, ${Rn} unless ADAGE_CONTROL or runtime.control says otherwise. ${r?`Computed here in your browser for your ${i.length} traces, ${C} of ${i.length} land on the arm the hook recorded; an arm forced with ADAGE_ARM, or drawn with another share, would not.`:`Computed here in your browser: ${u.map(e=>`${e.name} (x ${e.x.toFixed(3)})`).join(` and `)} are control; the other ${l.length} are treated.`}`,chips:[{text:`control share ${Rn}`},{text:`same id → same arm, every event`},{text:`stored with its propensity`}]},{title:`The right word at the right moment`,plain:`At each moment Adage checks what it learned. At the start it warns that npm test fails here; after a registry edit it reminds the agent to run make gen; and it asks the agent not to stop before it has.`,math:`hook`,key:!0,body:r?`Above each event are the reflexes it directed, coloured by strength: ${m} delivered in treated traces, ${h} recorded as would-have in control traces. A prompt runs inhibit announcements first, then prompt reflexes by strength and support, then intent; a batch judges follows and opens finish lines; a failure fires only on its signature; a stop asks at most ${In} times. On Claude Code one more event comes before a shell command runs: the one change Adage makes by default. A Python test run under the system Python is pointed at the project's verified .venv, the person sees each rewrite, and adage delegate rewrites off turns it off.`:`At the first prompt the dead end is announced (inhibit). An edit to registry/*.csv raises the finish line and opens an obligation; make gen meets it in ${b} traces. ${g.length?`${g.map(e=>e.s.name).join(`, `)} tries to stop without it, so the stop hook asks the agent to run it first.`:``} Edits to src/*.ts raise a candidate: run npm test. On Claude Code one more event comes before a shell command runs: the one change Adage makes by default. A Python test run under the system Python is pointed at the project's verified .venv, the person sees each rewrite, and adage delegate rewrites off turns it off.`,chips:[{text:`prompt: inhibit first · then strength, support · intent`},{text:`batch: follows, finish lines`},{text:`failure: signature in output`},{text:`stop: ≤ ${In}, unmet obligations only`},{text:`before a shell command (Claude Code): the .venv rewrite`}]},{title:`Short and consistent`,plain:`Adage keeps it short: at most 3 suggestions at once and 8 per session, and once it has warned about something, it never recommends it.`,math:`hook`,body:p.length?`Two rules prune what decide() found. At most ${Fn} directives per decision and ${Pn} per trace. And once an inhibit has spoken, nothing it avoids is said: the dead end announced at the first prompt says npm test fails, so ${p.length} npm test candidates are struck, with their pending judgements.`:`Two rules prune what decide() found. At most ${Fn} directives per decision and ${Pn} per trace; here the most in one decision is ${_} and in one trace ${v}. And once an inhibit has spoken, nothing it avoids is said. A struck directive leaves no trace in the record, so none shows here.`,chips:[{text:`≤ ${Fn} per decision · most here ${_}`,ok:_<=Fn},{text:`≤ ${Pn} per trace · most here ${v}`,ok:v<=Pn},{text:`approach_lock: inhibit beats run`}]},{title:`Only checked values get through`,plain:`When a suggestion includes something from your request, like a ticket number, the value must look exactly like a real one. Adage never copies free text into the agent's instructions.`,math:`hook`,body:`An example from acme-billing: the prompt "${sr.prompt}" meets the work-item lookup reflex. A value binds only if it matches the slot contract ${sr.contract} and is a plain token: at most ${zn} characters, no leading dash, only letters, digits and _./:@=+,-. It fills a fixed template; the track never supplies prose.`,chips:[{text:`${B.filter(e=>e.contract&&e.plain).length} of ${B.length} values bind`},{text:`template text only`},{text:`sanitised: no backticks, <, >, newlines`}]},{title:`Did the agent take the advice?`,plain:`Adage then watches the agent's next few actions to see whether it took the advice, and records the answer.`,math:`hook`,body:`The directive is pending for ${Ln} tool batches. Each batch's commands are matched on their canonical key: the directed command, or it with options added. Batch ${ue+1} runs the lookup, so the directive is judged followed. Had ${Ln} batches passed without it, it would count as ignored.${r?` In your recorded decisions: ${x} followed, ${S} ignored, ${b} finish lines met.`:``}`,chips:[{text:`follow window ${Ln} batches`},{text:`pattern::meets`},{text:`followed · ignored · misfired`}]},{title:`The comparison group stays silent`,plain:`In the left-alone sessions Adage notes what it would have said, but says nothing. That gives a fair comparison: what agents did with the advice, against what they did without it.`,math:`hook`,key:!0,body:`The same decision runs in both arms. Treated traces received ${m} directive${m===1?``:`s`}; the ${u.length} control trace${u.length===1?``:`s`} logged ${h} would-have directive${h===1?``:`s`} and received none, and no command of theirs was rewritten. That gives the next chapter its comparison: what agents did with a reflex, against what they did without it.`,chips:[{text:`would_have: both arms`},{text:`directives: treated only`},{text:`control ≈ ${Math.round(Rn*100)}% of traces`}]}];return{source:r?`your ${i.length} latest traces`:`${i.length} sample traces`,legend:[{label:`session start`,role:`hue`,hue:er.start},{label:`prompt`,role:`hue`,hue:er.prompt},{label:`tool batch`,role:`hue`,hue:er.batch},{label:`failure`,role:`hue`,hue:er.failure},{label:`stop`,role:`hue`,hue:er.stop},{label:`fire`,role:`fire`},{label:`prime`,role:`prime`},{label:`inhibit`,role:`inhibit`}],steps:V.map((e,t)=>({...e,state:t===5?he(5):t===6?he(6):pe(t)}))}}function lr(e,t,n,r){let i=Math.max(...Bn.map(e=>e.p95)),a=e=>78+e/i*(t-78-54),o=(n-16)/Bn.length;e.font=`10px 'Red Hat Mono', ui-monospace, monospace`,e.textBaseline=`middle`,Bn.forEach((t,n)=>{let i=4+n*o+o/2;e.fillStyle=r.css(`ink2`),e.textAlign=`left`,e.fillText(t.path,0,i),e.fillStyle=r.css(`line`),e.globalAlpha=.25,e.fillRect(a(0),i-5,a(t.p95)-a(0),10),e.globalAlpha=1,e.fillStyle=r.css(`accent`),e.fillRect(a(0),i-3,a(t.measured)-a(0),6),e.strokeStyle=r.css(`ink3`),e.beginPath(),e.moveTo(a(t.p95)+.5,i-7),e.lineTo(a(t.p95)+.5,i+7),e.stroke(),e.fillStyle=r.css(`ink1`),e.fillText(`${t.measured} ms`,a(t.measured)+5,i),e.fillStyle=r.css(`ink3`),e.textAlign=`left`,e.fillText(`≤ ${t.p95} ms`,a(t.p95)+5,i)}),e.fillStyle=r.css(`ink3`),e.textAlign=`left`,e.textBaseline=`bottom`,e.fillText(`p95: measured (bar) against budget (tick)`,78,n)}var ur={id:`hook`,title:`Speak up at the right moment`,technical:`Decide at the hook`,status:`Built`,kind:`built`,summary:`As the agent works, Adage checks each moment against what it learned and, when something matches, hands the agent a one-line suggestion. Otherwise it stays silent.`,source:`crates/adage-hook · crates/adage-runtime/src/{lib,fast,render}.rs`,usesRepo:!0,build:cr},dr={family:.6,overlap:.25,minTraces:2,max:16,threshold:.811,grey:.1,tokens:800},fr=128,pr=16384,mr=10,hr=.6,gr=2,_r=10,vr=.6,yr=.85,br=.8,xr=.15,Sr=5,Cr=.8,wr=.3,Tr=.8,Er=.5,Dr=.5,Or=.99,kr=1e4,Ar=Math.max(Sr,2),jr=/```[\s\S]*?```/g,Mr=[[/https?:\/\/\S+/g,`{url}`],[/\b[A-Z][A-Z0-9]{0,9}-\d{1,7}\b/g,`{ticket}`],[/#\d{1,6}\b/g,`{pr}`],[/\b\w[\w\-./]*\/[\w\-./]+\b/g,`{path}`],[/\b[0-9a-f]{7,40}\b/g,`{sha}`],[/\b\d+\.\d+(?:\.\d+)?\b/g,`{version}`],[/\b[A-Z][A-Z0-9]*(?:_[A-Z0-9]+)+\b/g,`{env_var}`]];function Nr(e){let t=new TextEncoder().encode(e),n=Math.min(t.length,pr);for(;n<t.length&&n>0&&(t[n]&192)==128;)n--;let r=new TextDecoder().decode(t.subarray(0,n)),i=r.includes("```"),a=r.replace(jr,` [code] `),o=0;for(let[e,t]of Mr)o+=a.match(e)?.length??0,a=a.replace(e,t);return{text:a.split(/\s+/).filter(Boolean).slice(0,fr).join(` `),placeholders:o,fence:i}}var Pr=`git status`,Fr=`make test`,Ir=`kubectl logs deploy/dispatch`,Lr=`pnpm outdated`,Rr=`go list -m -u all`,zr=`git log --oneline`,Br=[{raw:`the dispatch tests fail on main since a3f9c21, fix them`,blob:`T`,cmds:[Pr,Fr]},{raw:`make test is red after W-4821 landed`,blob:`T`,cmds:[Pr,Fr]},{raw:`fix the failing test in src/router/holidays.test.ts`,blob:`T`,cmds:[Pr,Fr]},{raw:`lane pricing tests fail, see https://ci.example.dev/run/8812`,blob:`T`,cmds:[Fr]},{raw:`CI fails on #482, the retry test times out`,blob:`T`,cmds:[Pr,Fr]},{raw:`fix the flaky carrier import test`,blob:`T`,cmds:[Pr,Fr,zr]},{raw:"port lookup tests fail with ```AssertionError: expected OSL``` since yesterday",blob:`T`,cmds:[Pr,Fr]},{raw:`unit tests for the quote engine are failing`,blob:`T`,cmds:[Pr,Fr]},{raw:`the ports test suite fails locally, help`,blob:`T`,cmds:[Pr,Fr]},{raw:`fix the broken test after PAY-311`,blob:`T`,cmds:[Pr,Fr]},{raw:`explain how the test fixtures are generated`,blob:`X`,cmds:[Pr]},{raw:`dispatch latency spiked in prod, find out why`,blob:`L`,cmds:[Pr,Ir]},{raw:`customers see 503s from the router`,blob:`L`,cmds:[Pr,Ir,Fr]},{raw:`the nightly sync job crashed, investigate`,blob:`L`,cmds:[Pr,Fr]},{raw:`why is SLA_BREACH_ALERT firing`,blob:`L`,cmds:[Pr]},{raw:`carrier webhooks are timing out`,blob:`L`,cmds:[Fr]},{raw:`bump react to 18.3.1`,blob:`J`,cmds:[Pr,Lr]},{raw:`upgrade vite to the latest major`,blob:`J`,cmds:[Pr,Lr]},{raw:`update the npm dependencies, dependabot flagged #512`,blob:`J`,cmds:[Pr,Lr,Fr]},{raw:`bump typescript to 5.6 in web/map`,blob:`J`,cmds:[Pr,Lr]},{raw:`upgrade @tanstack/query to 5.59.0`,blob:`J`,cmds:[Lr]},{raw:`bump the Go toolchain to 1.23`,blob:`G`,cmds:[Pr,Rr]},{raw:`upgrade golang.org/x/net to the latest patch`,blob:`G`,cmds:[Pr,Rr]},{raw:`update go modules, the grpc one is outdated`,blob:`G`,cmds:[Pr,Rr,Fr]},{raw:`bump pgx in services/ledger`,blob:`G`,cmds:[Pr,Rr]},{raw:`go.mod still pins an old otel, bump it`,blob:`G`,cmds:[Rr]},{raw:`what changed in dispatch since Friday?`,blob:`H1`,cmds:[Pr,zr]},{raw:`who touched the lane pricing last week`,blob:`H1`,cmds:[Pr,zr]},{raw:`what did the last release change in routing`,blob:`H1`,cmds:[Pr,zr]},{raw:`summarise the commits since the 2.3.0 release`,blob:`H1`,cmds:[Pr,zr]},{raw:`what changed in registry/ports.csv recently`,blob:`H1`,cmds:[Pr,zr,Fr]},{raw:`when did the router start ignoring holidays`,blob:`H2`,cmds:[Pr,zr]},{raw:`find the commit that broke carrier import`,blob:`H2`,cmds:[Pr,zr,Fr]},{raw:`which change made quotes slower`,blob:`H2`,cmds:[Pr,zr]},{raw:`bisect the Oslo port regression`,blob:`H2`,cmds:[Pr,zr]},{raw:`when was the retry limit changed to 5`,blob:`H2`,cmds:[Pr,zr]},{raw:`write a haiku about container ships`,blob:`N1`,cmds:[]},{raw:`tidy up the repo description`,blob:`N2`,cmds:[Pr]}],Vr=`ledger tests fail since 9f1c2ab, fix them`,Hr=32;function Ur(e){let t=Math.hypot(...e);return t>0?e.map(e=>e/t):e}var Wr=(e,t)=>e.reduce((e,n,r)=>e+n*t[r],0),Gr=(()=>{let e=(e,t=1)=>Array.from({length:Hr},(n,r)=>r===e?t:0),t=(e,t)=>e.map((e,n)=>e+t[n]);return{T:{base:e(0),noise:.2},X:{base:t(e(0),e(10,1)),noise:.05},L:{base:e(1),noise:.24},J:{base:t(e(2),e(3,.23)),noise:.04},G:{base:t(e(2),e(3,-.23)),noise:.04},H1:{base:t(e(4),e(5,.3)),noise:.716,axis:20},H2:{base:t(e(4),e(5,-.3)),noise:.716,axis:26},N1:{base:e(8),noise:.2},N2:{base:e(9),noise:.2}}})();function Kr(e,t,n){let r=Gr[e];for(let e=0;e<4;e++)n();let i=[],a=[],o=[0,0,0];for(let e=0;e<t;e++){let t,s;e%2?(t=a.map(e=>-e),s=[-o[0],-o[1],-o[2]]):(t=r.axis===void 0?Array.from({length:Hr},()=>n()*r.noise):Array.from({length:Hr},(t,n)=>n===r.axis+e/2?r.noise:0),s=[n(),n(),n()]),a=t,o=s,i.push({vec:Ur(r.base.map((e,n)=>e+t[n])),jitter:s})}return i}function qr(e,t){let n=e.length,r=Math.min(t,n-1);return e.map((t,i)=>{let a=[];for(let r=0;r<n;r++)r!==i&&a.push([r,Wr(t,e[r])]);return a.sort((e,t)=>t[1]-e[1]||e[0]-t[0]),a.slice(0,r)})}function Jr(e,t){let n=e.map(()=>new Map);return e.forEach((e,r)=>{for(let[i,a]of e){if(a<t)break;n[r].set(i,a),n[i].set(r,a)}}),n}function Yr(e,t,n){let r=e.length,i=e.map((e,t)=>[t]),a=e.map(e=>[...e.entries()].sort((e,t)=>e[0]-t[0]));for(let e=0;e<n;e++){let e=a.length,n=a.map(e=>e.reduce((e,t)=>e+t[1],0)),r=n.reduce((e,t)=>e+t,0);if(r===0)break;let o=a.map((e,t)=>t),s=n.slice(),c=!1;for(;;){let i=!1;for(let l=0;l<e;l++){let e=o[l],u=new Map;for(let[e,t]of a[l])e!==l&&u.set(o[e],(u.get(o[e])??0)+t);s[e]-=n[l];let d=e,f=(u.get(e)??0)-t*n[l]*s[e]/r;for(let e of[...u.keys()].sort((e,t)=>e-t)){let i=u.get(e)-t*n[l]*s[e]/r;i>f+1e-12&&(d=e,f=i)}s[d]+=n[l],d!==e&&(o[l]=d,i=c=!0)}if(!i)break}if(!c)break;let l=new Map;for(let e of o)l.has(e)||l.set(e,l.size);let u=Array.from({length:l.size},()=>[]);o.forEach((e,t)=>u[l.get(e)].push(...i[t]));let d=Array.from({length:l.size},()=>new Map);a.forEach((e,t)=>{let n=l.get(o[t]);for(let[t,r]of e){let e=l.get(o[t]);d[n].set(e,(d[n].get(e)??0)+r)}}),a=d.map(e=>[...e.entries()].sort((e,t)=>e[0]-t[0])),i=u}let o=Array(r).fill(0);return i.forEach((e,t)=>e.forEach(e=>o[e]=t)),o}function Xr(e,t){let n=new Map;for(let t of e)t>=0&&n.set(t,(n.get(t)??0)+1);let r=new Map;return e.map(e=>e<0||n.get(e)<t?-1:(r.has(e)||r.set(e,r.size),r.get(e)))}function Zr(e){let t=new Map;return e.forEach((e,n)=>e>=0&&(t.get(e)??t.set(e,[]).get(e)).push(n)),new Map([...t.entries()].sort((e,t)=>e[0]-t[0]))}function Qr(e,t){let n=Array(Hr).fill(0);for(let r of t)e[r].forEach((e,t)=>n[t]=n[t]+e);return Ur(n)}function $r(e,t){let n=new Map;for(let[r,i]of Zr(e)){let e=new Map;for(let n of i)t[n]&&e.set(t[n],(e.get(t[n])??0)+1);let a=null;for(let t of[...e.entries()].sort((e,t)=>e[0]<t[0]?-1:1))(!a||t[1]>a[1])&&(a=t);n.set(r,a?{route:a[0],share:a[1]/i.length,size:i.length}:{route:null,share:0,size:i.length})}return n}function ei(e,t){let n=t.map(t=>{let n=Array(Hr).fill(0);for(let r of t)e[r].forEach((e,t)=>n[t]=n[t]+e);return n}),r=0,i=0;return t.forEach((t,a)=>{for(let o of t){let t=-1,s=-1/0;n.forEach((n,r)=>{let i=n.map((t,n)=>r===a?t-e[o][n]:t),c=Math.hypot(...i);if(c===0)return;let l=Wr(i,e[o])/c;l>s&&(t=r,s=l)}),r+=+(t===a),i++}}),r/Math.max(1,i)}function ti(e,t,n,r){let i=t.slice(),a=Math.max(-1,...t)+1;for(let[o,s]of Zr(t)){let t=new Map;for(let e of s)n[e]&&(t.get(n[e])??t.set(n[e],[]).get(n[e])).push(e);let c=Math.max(Ar,xr*s.length),l=[...t.entries()].sort((e,t)=>e[0]<t[0]?-1:1).filter(([,e])=>e.length>=c);if(l.length<2)continue;let u=l.map(([,e])=>e),d=ei(e,u);if(d<yr)continue;r.push({family:o,sep:d,groups:l.map(([e,t])=>({route:e,size:t.length}))});let f=u.map(t=>Qr(e,t)),p=[o,...u.slice(1).map(()=>a++)];for(let t of s){let n=0;f.forEach((r,i)=>Wr(e[t],r)>Wr(e[t],f[n])&&(n=i)),i[t]=p[n]}}return Xr(i,1)}function ni(e,t,n,r){let i=t.slice();for(;;){let t=$r(i,n),a=Zr(i),o=[...t.entries()].filter(([,e])=>e.route).map(([e])=>e),s=new Map(o.map(t=>[t,Qr(e,a.get(t))])),c=null;if(o.forEach((e,n)=>{for(let r of o.slice(n+1)){if(t.get(e).route!==t.get(r).route)continue;let n=Wr(s.get(e),s.get(r));n>=br&&(!c||n>c.cos)&&(c={a:e,b:r,cos:n,route:t.get(e).route})}}),!c)return Xr(i,1);let{a:l,b:u}=c;r.push(c),i=i.map(e=>e===u?l:e)}}var ri={v:1};function ii(){let e=[...new Set(Br.map(e=>e.blob))],t=new Map(e.map((e,t)=>[e,Kr(e,Br.filter(t=>t.blob===e).length,Dt(ri.v+t*7919))])),n=Br.map((e,n)=>{let r=Nr(e.raw);return{...e,i:n,norm:r.text,placeholders:r.placeholders,...t.get(e.blob).shift()}}).slice().sort((e,t)=>e.norm<t.norm?-1:e.norm>t.norm?1:e.i-t.i),r=n.map(e=>e.vec),i=n.length,a=new Map;for(let e of n)for(let t of new Set(e.cmds))a.set(t,(a.get(t)??0)+1);let o=e=>i>=5&&a.get(e)>Cr*i,s=n.map(e=>e.cmds.find(e=>!o(e))??null),c=[...a.entries()].filter(([e])=>o(e)).map(([e,t])=>({cmd:e,traces:t})),l=qr(r,mr),u=Jr(l,hr),d=[],f=[];l.forEach((e,t)=>e.forEach(([e,n])=>{(t<e||!l[e].some(([e])=>e===t))&&(n>=hr?f:d).push([t,e])}));let p=Yr(u,gr,_r),m=Xr(p,Ar),h=[],g=[],_=ti(r,m,s,h),v=ni(r,_,s,g),y=Zr(v),b=n.map(e=>t=>e.cmds.includes(t)),x=[];for(let[e,t]of $r(v,s)){let n=y.get(e),a=Ur(Qr(r,n).map(e=>Math.max(-1e4,Math.min(kr,Math.round(e*kr)))).map(e=>e/kr)),o=r.map(e=>Wr(e,a)),s=t.route!==null&&t.share>=vr&&t.size>=Ar,c={label:e,members:n,route:t.route??``,share:t.share,kept:s,centroid:a,sims:o,curve:[],t:0,lb:0,support:0,opp:0,rate:0,rateOut:0,reflex:!1,lamp:null};if(x.push(c),!s)continue;let l=t.route,u=e=>Math.floor(e*1e4)/1e4,d=[...new Set(n.map(e=>u(o[e])).filter(e=>e>=Dr))].sort((e,t)=>t-e),f=null;for(let e of d){let t=Math.min(e,Or),n=o.filter(e=>e>=t).length,r=o.filter((e,n)=>e>=t&&b[n](l)).length,i=kt(r,n);c.curve.push({t,lb:i,sup:r,opp:n}),(!f||i>f.lb)&&(f={t,lb:i,sup:r,opp:n})}if(!f)continue;let p=i-f.opp,m=o.filter((e,t)=>e<f.t&&b[t](l)).length;Object.assign(c,{t:f.t,lb:f.lb,support:f.sup,opp:f.opp,rate:f.sup/f.opp,rateOut:p?m/p:0}),c.reflex=c.support>=Sr&&c.rate-c.rateOut>=wr,c.lamp=c.reflex?c.lb>=Tr?`fire`:c.rate>=Er?`prime`:null:null}let S=Kr(`T`,2,Dt(ri.v+113))[0];return{order:n,routes:s,ubiquitous:c,nb:l,edgesAll:d,edgesEps:f,communities:p,clusters:m,splitNotes:h,mergeNotes:g,afterSplit:_,afterMerge:v,families:x,probe:S,match:x.filter(e=>e.reflex&&e.lamp).map(e=>({f:e,s:Wr(S.vec,e.centroid)})).filter(e=>e.s>=e.f.t).sort((e,t)=>t.s-e.s)[0]??null,n:i}}var ai={list:{target:[0,0,0],yaw:0,pitch:.06,dist:21},cloud:{target:[0,-.2,-.4],yaw:.34,pitch:.24,dist:20},family:{target:[-3.6,.9,1.6],yaw:.16,pitch:.18,dist:15}},oi={T:[-4.8,1.2,1.8],X:[-2.6,-.2,2.8],L:[-.4,-4,3.2],J:[4.4,2,-.4],G:[4.2,-.2,-1],H1:[-2.6,3.4,-4.4],H2:[1.6,3,-4.8],N1:[6.4,-3.8,3],N2:[-7,-3.2,-2.2]},si={"make test":200,"git log --oneline":250,"go list -m -u all":165,"pnpm outdated":335,"kubectl logs deploy/dispatch":75},ci=[`the dispatch tests fail on main since a3f9c21, fix them`,`make test is red after W-4821 landed`,`fix the failing test in src/router/holidays.test.ts`,`lane pricing tests fail, see https://ci.example.dev/run/8812`,"port lookup tests fail with ```AssertionError: expected OSL``` since yesterday",`bump typescript to 5.6 in web/map`,`why is SLA_BREACH_ALERT firing`],li=2.3,ui=e=>e.replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`),di=(e,t,n=1)=>[e[0]+t[0]*n,e[1]+t[1]*n,e[2]+t[2]*n],fi=e=>{let t=e.reduce((e,t)=>di(e,t),[0,0,0]);return[t[0]/e.length,t[1]/e.length,t[2]/e.length]},pi=(e,t,n)=>[t[0]+(e[0]-t[0])*n,t[1]+(e[1]-t[1])*n,t[2]+(e[2]-t[2])*n],mi=e=>{let t=Math.hypot(...e);return t>1e-9?[e[0]/t,e[1]/t,e[2]/t]:[.3,.9,.3]},hi=e=>e.replace(/\{(\w+)\}|\[code\]/g,e=>`<b>${e}</b>`);function gi(e){let t=ii(),{order:n,n:r}=t,i=e=>`p${e}`;n.forEach((t,n)=>e.dot(i(n))),e.dot(`probe`,.22);let a=n.map(e=>di(oi[e.blob],e.jitter,1.05)),o=ci.map(e=>n.findIndex(t=>t.raw===e)),s=[],c=0;n.forEach((e,t)=>{let n=o.indexOf(t);n>=0?s[t]=[-8,5-n*1.12,0]:(s[t]=[-8+c%11*1.3,-3.2-Math.floor(c/11)*1.15,0],c++)});let l=e=>{let t=new Map;return e.forEach((e,n)=>e>=0&&(t.get(e)??t.set(e,[]).get(e)).push(n)),t},u=(e,t,r=a)=>{let i=l(e),o=new Map([...i].map(([e,t])=>[e,fi(t.map(e=>r[e]))]));return n.map((n,i)=>e[i]>=0?pi(r[i],o.get(e[i]),t):r[i])},d=u(t.clusters,.6),f=t.clusters[n.findIndex(e=>e.blob===`J`)],p=n.map((e,t)=>t).filter(e=>t.clusters[e]===f),m=t.afterMerge[n.findIndex(e=>e.blob===`H1`)],h=n.map((e,t)=>t).filter(e=>t.afterMerge[e]===m),g=e=>fi(n.flatMap((t,n)=>t.blob===e?[d[n]]:[])),_=mi(di(g(`J`),g(`G`),-1)),v=u(t.afterMerge,.22,d),y=n.map((e,t)=>p.includes(t)?di(d[t],_,e.blob===`J`?1.1:-1.1):h.includes(t)?v[t]:d[t]),b=t.families.find(e=>e.route===`make test`&&e.reflex),x=new Set(b.members),S=n.findIndex(e=>e.blob===`X`),C=fi(b.members.map(e=>y[e])),w=(e,t)=>di(C,mi([t[0],t[1],t[2]*.3]),li*(1-e)/(1-b.t)),T=n.map((e,t)=>t===S?w(b.sims[t],[1,-.3,0]):x.has(t)?w(b.sims[t],e.jitter):y[t]),E=t.match?.s??0,D=w(E,t.probe.jitter),O=[8.5,6,3],k=di(C,[-.6,3.4,0]);e.link(`tag`,[[k,`probe`]],`accent`);let A=n.reduce((e,t)=>e+t.placeholders,0),j=n.filter(e=>e.raw.includes("```")).length,M=t.edgesAll.length+t.edgesEps.length,N=l(t.clusters),P=t.clusters.filter(e=>e<0).length,F=t.ubiquitous[0],I=t.splitNotes[0],L=t.mergeNotes[0],ee=t.families.filter(e=>e.kept),te=t.families.find(e=>!e.kept),ne=t.families.filter(e=>e.reflex&&e.lamp),R=b.curve[b.curve.length-1],re=b.rate-b.rateOut,z=te.members,B=e=>e.toFixed(4).replace(/0+$/,``).replace(/\.$/,``);e.link(`near`,t.edgesAll.map(([e,t])=>[i(e),i(t)]),`ink3`),e.link(`eps`,t.edgesEps.map(([e,t])=>[i(e),i(t)]),`accent`),e.link(`intra`,t.edgesEps.filter(([e,n])=>t.clusters[e]>=0&&t.clusters[e]===t.clusters[n]).map(([e,t])=>[i(e),i(t)]),`soft`),e.link(`fam`,t.edgesEps.filter(([e,n])=>t.afterMerge[e]>=0&&t.afterMerge[e]===t.afterMerge[n]).map(([e,t])=>[i(e),i(t)]),`soft`);let ie=e=>{let t=[];for(let n=0;n<=64;n++){let r=n/64*Math.PI*2,i=Math.cos(r)*li,a=Math.sin(r)*li;t.push(di(C,e===0?[i,a,0]:e===1?[i,0,a]:[0,i,a]))}return t.slice(1).map((e,n)=>[t[n],e])};e.link(`shell`,[...ie(0),...ie(1),...ie(2)],`soft`),o.forEach((t,r)=>{let a=n[t];e.label(`show${r}`,`<span class="how-dim">${ui(a.raw)}</span><br>${hi(ui(a.norm))}`,i(t),{cls:`chip`,dx:14,dy:-17})});let ae=(t,n,r,i={})=>e.label(t,n,r,{cls:`note`,...i}),oe=fi(p.map(e=>d[e])),se=fi(h.map(e=>d[e])),ce=fi(h.map(e=>y[e])),le=fi(z.map(e=>y[e])),ue=fi(n.flatMap((e,t)=>e.blob===`G`?[y[t]]:[])),de=[0,-6.2,0];ae(`embed`,`256 dimensions, drawn here in 3D`,de,{center:!0}),ae(`eps`,`${t.edgesEps.length} links at cosine ≥ ${K(hr)} · ${t.edgesAll.length} weaker ones cut`,de,{center:!0}),ae(`noise`,`noise · a community under ${Ar}`,i(n.findIndex(e=>e.blob===`N1`)),{dy:14,center:!0}),ae(`ubi`,`${ui(F.cmd)} ran in ${F.traces} of ${r} traces · skipped`,de,{center:!0}),ae(`mixed`,`one family · two routes`,oe,{dy:74,center:!0}),ae(`same`,`two families · one route`,se,{dy:-40,center:!0}),ae(`split`,`split · leave-one-out ${K(I.sep)} ≥ ${K(yr)}`,ue,{dy:34,center:!0}),ae(`merge`,`merge · centres ${K(L.cos)} alike ≥ ${K(br)}`,ce,{dy:30,center:!0}),ae(`drop`,`dominant route ${K(te.share)} &lt; ${K(vr)} · not kept`,le,{dy:-64,center:!0}),ae(`t`,`threshold t = ${B(b.t)}`,di(C,[li*.72,li*.72,0]),{dx:10,dy:-14}),ae(`outside`,`the fixtures question<br><span class="how-dim">ran no ${ui(b.route)} · outside</span>`,i(S),{dx:14,dy:-8}),e.label(`probe`,`<span class="how-dim">${ui(Vr)}</span><br>${hi(ui(Nr(Vr).text))}`,k,{cls:`chip`,dy:-40,center:!0}),e.label(`reflex`,`<small>INTENT REFLEX · RUN</small><span class="how-lamp ${b.lamp}">●</span> ${b.lamp} · ${ui(b.route)}<br><span class="how-dim">requests like this one start with it</span>`,di(C,[0,-2.3,0]),{cls:`chip big`,dy:22,center:!0});let fe=e=>{let n=t.routes[e];return n?{hue:si[n]??0}:`ink3`};function pe(e){let r={};n.forEach((n,c)=>{let l=e===0?s[c]:e<=2?a[c]:e<=4?d[c]:e===5?y[c]:T[c],u=e<=2?`ink2`:e===3?t.clusters[c]>=0?`soft`:`ink3`:fe(c),f=1,m=1,g=.18;e===0&&o.includes(c)&&(u=`soft`,g=.4),e>=3&&e<=5&&t.clusters[c]<0&&(f=.4),e===5&&(p.includes(c)||h.includes(c))&&(m=1.3,g=.6),e>=6&&(x.has(c)?(m=1.2,g=b.sims[c]>=b.t?.6:.2):(f=e===6&&z.includes(c)?.5:.18,g=0),c===S&&(u=`ink2`,f=e===6?1:.35)),r[i(c)]={pos:l,color:u,alpha:f,scale:m,glow:g}}),e===6&&(r.probe={pos:O,color:`accent`,alpha:0,glow:0}),e===7&&(r.probe={pos:D,color:`accent`,scale:1.3,glow:1});let c=[];return e===0&&c.push(...ci.map((e,t)=>`show${t}`)),e===1&&c.push(`embed`),e===2&&c.push(`eps`),e===3&&c.push(`noise`),e===4&&c.push(`ubi`,`mixed`,`same`),e===5&&c.push(`split`,`merge`),e===6&&c.push(`drop`,`t`,`outside`),e===7&&c.push(`t`,`probe`,`reflex`),{dots:r,labels:c,cam:e===0?ai.list:e<=5?ai.cloud:ai.family,links:{near:e===2?.16:0,eps:e===2?.55:0,intra:e===3||e===4?.3:0,fam:e===5?.3:e>=6?.1:0,shell:e>=6?.5:0,tag:e===7?.6:0}}}let me=`10px 'Red Hat Mono', ui-monospace, monospace`,he=[{title:`Requests are tidied up`,plain:`Requests are trimmed and their specifics (ticket numbers, file paths, links) swapped for placeholders, so they compare by what they ask, not what they name.`,body:`Each of the ${r} sample prompts is cut to its first ${fr} words, and details become placeholders: tickets, paths, URLs, SHAs, versions, environment variables and PR numbers. Fenced code becomes [code]. Prompts then compare by what they ask, not by what they name.`,chips:[{text:`≤ ${fr} tokens · ≤ 16 KiB read`},{text:`${A} placeholders in ${r} prompts`},{text:`${j} fenced block → [code]`}]},{title:`Requests on a map of meaning`,plain:`A small language model built into Adage places each request on a map of meaning. Requests that mean the same thing land close together, however they are worded.`,math:`intent`,key:!0,body:`A static model embeds the normalised text: WordPiece tokens, the mean of their rows, scaled to unit length. Requests that mean the same thing land near each other. The model ships inside the adage binary, so nothing is downloaded; adage models fetch installs the full-precision table or a code model if you want one. Without a real model (the explicit hashed fallback) there are no intent reflexes, and nothing fails.`,chips:[{text:`potion-base-8M · int8 · bundled (7.7 MB)`},{text:`SHA-256 pinned`},{text:`≤ 512 WordPiece tokens`},{text:`mean · L2 · 256-d`}]},{title:`Similar requests link up`,plain:`Each request connects to the ones most like it, and weak links are cut.`,math:`intent`,body:`Each prompt links to its ${mr} most similar prompts, found exactly, with ties broken by index so every run builds the same graph. Links below cosine ${K(hr)} are cut: ${t.edgesEps.length} of the ${M} remain.`,chips:[{text:`exact kNN, k = ${mr}`},{text:`eps ${K(hr)}`},{text:`${t.edgesEps.length} of ${M} links kept`}],figure:(e,n,r,i)=>{let a=t.nb.flatMap(e=>e.map(([,e])=>e)),o=Math.min(0,...a),s=Array(24).fill(0);for(let e of a)s[Math.min(23,Math.floor((e-o)/(1-o)*24))]++;let c=e=>4+(e-o)/(1-o)*(n-8),l=Math.max(...s),u=(n-8)/24;s.forEach((t,n)=>{let a=o+(1-o)*n/24,s=a>=.599999999;e.fillStyle=i.css(s?`accent`:`ink3`),e.globalAlpha=s?.85:.45;let d=t/l*(r-16-14);e.fillRect(c(a)+1,r-16-d,Math.max(1,u-2),d)}),e.globalAlpha=1,e.font=me,e.fillStyle=i.css(`ink3`),e.textBaseline=`top`;for(let t of[o,hr,1])e.textAlign=t===o?`left`:t===1?`right`:`center`,e.fillText(t===hr?`eps ${K(hr)}`:K(t),c(t),r-16+3);e.setLineDash([3,3]),e.strokeStyle=i.css(`soft`),e.beginPath(),e.moveTo(c(hr),12),e.lineTo(c(hr),r-16),e.stroke(),e.setLineDash([]),e.textAlign=`left`,e.fillText(`cosine to each prompt's ${mr} nearest neighbours`,4,0)}},{title:`Families form`,plain:`Tightly connected requests form families. The few that fit nowhere are left alone.`,math:`intent`,body:`Louvain groups densely linked prompts. It visits them in a fixed order and moves one only on a strictly better gain, so the result never varies. Resolution ${gr.toFixed(1)} keeps communities small and pure. ${N.size} have at least ${Ar} prompts; the ${P} prompts left in smaller ones are noise.`,chips:[{text:`resolution ${gr.toFixed(1)} · ≤ ${_r} levels`},{text:`min size max(min_support, 2) = ${Ar}`},{text:`${N.size} communities · ${P} noise`}]},{title:`Coloured by how each session began`,plain:`Each request is coloured by what its session did first, before editing anything. Something every session does, like git status, says nothing and is ignored.`,body:`Each prompt is labelled with its trace's route: the first check or lookup it ran before editing. ${F.cmd} ran in ${F.traces} of ${r} traces, more than ${Cr} of them, so it says nothing about intent and is skipped. Now the families show what the text alone could not.`,chips:[{text:`first observe or verify step before an edit`},{text:`ubiquitous: > ${Cr} of traces (5 or more)`}]},{title:`Families split and merge`,plain:`When one family's sessions start in two different ways, it splits in two. When two families start the same way and mean nearly the same thing, they merge.`,body:`One family mixes two routes: ${I.groups.map(e=>`${e.size} started with ${e.route}`).join(` and `)}. Each group is large enough and the text tells them apart, so the family splits. Two history families both start with ${L.route}, and their centres are ${K(L.cos)} alike, so they merge.`,chips:[{text:`split: groups ≥ ${Ar} and ≥ ${xr*100}%`},{text:`leave-one-out ${K(I.sep)} ≥ ${K(yr)}`,ok:I.sep>=yr},{text:`merge: same route, cos ${K(L.cos)} ≥ ${K(br)}`,ok:L.cos>=br}]},{title:`Keep the consistent families`,plain:`A family is kept only when most of its sessions start the same way, and each kept family learns how close a new request must be to count as one of its own.`,math:`intent`,body:`A family is kept when at least ${vr} of its traces took its dominant route. The incident family is at ${K(te.share)}, so ${ee.length} of ${t.families.length} are kept. Each kept centre is stored as integers, and its threshold is chosen on this repository's own prompts: the t whose prompts ran ${b.route} with the best Wilson lower bound, ${b.support} of ${b.opp} here. Taking in the fixtures question too would give ${R.sup} of ${R.opp}, a lower bound of ${K(R.lb)}.`,chips:[{text:`bar ${vr} · ${ee.length} kept`},{text:`t = ${B(b.t)} · within [${Dr}, ${Or}]`},{text:`contrast ${K(re)} ≥ ${K(wr)}`,ok:re>=wr},{text:`centroid × 10,000 → i16`}],figure:(e,t,n,r)=>{let i=b.curve,a=Math.min(...i.map(e=>e.t))-.01,o=Math.max(...i.map(e=>e.t))+.01,s=e=>6+(o-e)/(o-a)*(t-12),c=e=>n-16-e*(n-16-14);e.strokeStyle=r.css(`ink3`),e.globalAlpha=.4,e.beginPath(),e.moveTo(4,n-16+.5),e.lineTo(t-4,n-16+.5),e.stroke(),e.globalAlpha=1,e.setLineDash([3,3]),e.strokeStyle=r.css(`fire`),e.beginPath(),e.moveTo(4,c(Tr)),e.lineTo(t-4,c(Tr)),e.stroke(),e.setLineDash([]),e.font=me,e.textBaseline=`bottom`,e.textAlign=`left`,e.fillStyle=r.css(`fire`),e.fillText(`fire bar`,6,c(Tr)-1);for(let t of i){let n=t.t===b.t,i=r.css(n?`accent`:`ink3`);e.strokeStyle=i,e.fillStyle=i,e.lineWidth=n?2:1,e.beginPath(),e.moveTo(s(t.t),c(0)),e.lineTo(s(t.t),c(t.lb)),e.stroke(),e.beginPath(),e.arc(s(t.t),c(t.lb),n?3.5:2.5,0,Math.PI*2),e.fill()}e.lineWidth=1,e.textBaseline=`top`,e.fillStyle=r.css(`ink3`),e.textAlign=`left`,e.fillText(`t ${K(o)}`,4,n-16+3),e.textAlign=`center`,e.fillText(`Wilson lower bound at each candidate t`,t/2,n-16+3),e.textAlign=`right`,e.fillText(K(a),t-4,n-16+3),e.fillStyle=r.css(`accent`),e.textAlign=`right`,e.textBaseline=`top`,e.fillText(`best: ${b.support}/${b.opp} at t ${B(b.t)}, LB ${K(b.lb)}`,t-4,0)}},{title:`A new request arrives`,plain:`When a new request arrives, Adage finds the family it belongs to and suggests the usual first step. The match is close, but the evidence is not yet strong enough to insist.`,math:`intent`,key:!0,body:`At the hook, a new prompt is normalised, embedded and compared with the centre of each of the ${ne.length} intent reflexes. The most similar one whose threshold it clears matches: cosine ${K(E)} against t ${B(b.t)}. Its lower bound, ${K(b.lb)}, is under the ${K(Tr)} fire bar, so the reflex primes rather than fires.`,chips:[{text:`cos ${K(E)} ≥ t ${B(b.t)}`,ok:E>=b.t},{text:`${b.lamp} · lower bound ${K(b.lb)}`},{text:`p95 budget 25 ms with intent`}]},{title:`Repeated tasks get a procedure card`,plain:`A task the repository keeps repeating gets a procedure card: which files to touch, what was added last time, the commands that worked and the check to finish with. It never quotes secrets.`,math:`cards`,key:!0,body:`The same model groups whole tasks. Two traces are one family when their first prompts are at least ${K(dr.family)} alike and the files they edited have the same shapes (Jaccard ≥ ${K(dr.overlap)}). A family of at least ${dr.minTraces} traces, one of them passing, gets a card: the files it touched in order, the lines the latest passing trace added, the commands that worked and those that failed, and the check it finished with, within ${dr.tokens} tokens. A card never quotes .env files, files git ignores, or anything that looks like a secret. A new prompt at cosine ≥ ${dr.threshold} to the family's prompts gets the card once, as prime; up to ${K(dr.grey)} below, it waits for the first edit of one of the card's files.`,chips:[{text:`family: cos ≥ ${K(dr.family)} · files Jaccard ≥ ${K(dr.overlap)}`},{text:`≥ ${dr.minTraces} traces · ≤ ${dr.max} cards per repo`},{text:`deliver at cos ≥ ${dr.threshold} (learn.card_threshold)`},{text:`prime · once per session · never shared`},{text:`adage train cards replays its commands`}]}];return{source:`${r} sample prompts · positions illustrative`,legend:[...Object.entries(si).map(([e,t])=>({label:e,role:`hue`,hue:t})),{label:`no route`,role:`ink3`}],steps:he.map((e,t)=>({...e,state:pe(Math.min(t,7))}))}}var _i={id:`intent`,title:`Recognise similar requests`,technical:`Group prompts by intent`,status:`Built · model bundled`,kind:`built`,summary:`Requests that mean the same thing are grouped, however they are worded, so Adage can suggest how that kind of work usually starts. Tasks a repository keeps repeating get a procedure card.`,source:`crates/adage-graph/src/compile/intent.rs · crates/adage-intent`,usesRepo:!1,build:gi},vi={default:{min_support:5,fire_lower_bound:.8},demo:{min_support:3,fire_lower_bound:.5}},yi=.5,bi=.3,xi=.3,Si=[9,10],Ci=8,wi=16,Ti=2,Ei=.2,Di=.1,Oi=4,ki=11.8,Ai={avoid:{self:.29,follow:.944},"run-after-edit":{self:.32,follow:.881},"read-batch":{self:.93,follow:.986},prompt:{self:.95,follow:.987},obligation:{self:.88,follow:.975},sequence:{self:.88,follow:.975},advise:{self:.5,follow:.99}};function ji(e,t,n=Di){let r=Ai[e]??{self:.5,follow:.958},i=t.control??0,a=Math.min(t.took,t.traces)+Math.min(t.controlTook??0,i),o=t.traces+i,s=t.delivered??0,c=Math.min(t.followed??0,s),l=(r.self*Oi+a)/(Oi+o),u=(r.follow*ki+c)/(ki+s),d=u-l;return{pFollow:u,pSelf:l,mean:d,gated:n>0&&d<n&&o>=3}}var Mi=/[A-Z][A-Z0-9]{0,9}-\d{1,7}/;function Ni(e,t){return e===`observe`||e===`verify`?`fire`:e===`regenerate`?t?`fire`:`prime`:e===`environment`?`prime`:null}function Pi(e,t,n,r,i,a=!1){let o=Ni(e,t);return o?n>=i&&o===`fire`?`fire`:r>=(a?bi:yi)?`prime`:null:null}function Fi(e,t,n=1.959964){if(!t)return 1;let r=e/t,i=1+n*n/t;return(r+n*n/(2*t)+n*Math.sqrt(r*(1-r)/t+n*n/(4*t*t)))/i}function Ii(e,t,n){let r=[],i=[],a=[],o=0;e.forEach((e,s)=>{let c=e.map(e=>e[0]).lastIndexOf(t);if(c<0){e.some(e=>e[1]===n)&&o++;return}r.push(s);let l=e.slice(c+1);l.some(e=>e[1]===n)?i.push(s):l.some(e=>e[0]===`G`)&&a.push(s)});let s=r.length,c=e.length-s,l=s?i.length/s:0,u=c?o/c:0;return{editors:r,support:i,near:a,opp:s,without:c,ranWithout:o,rate:l,rateWithout:u,lb:kt(i.length,s)}}function Li(e){let t=[],n=new Set,r=new Set;e.forEach((e,r)=>e.forEach(([i],a)=>{if(i!==`F`)return;n.add(r);let o=e.slice(a+1,a+1+Ci).findIndex(e=>e[0]===`C`);o>=0&&t.push([r,a,a+1+o])}));let i=n.size,a=i-r.size;return{pairs:t,ran:i,failedIn:a,consistent:i>0&&a*Si[1]>=i*Si[0],support:new Set(t.map(e=>e[0])).size}}var Ri=[{id:`lookup-work-item`,strength:`fire`,effect:`observe`,support:23,opportunities:33,lower_bound:.5266186471733927,what:`python3 scripts/wi-lookup {item}`},{id:`read-linked-files`,strength:`prime`,effect:`observe`,support:15,opportunities:16,lower_bound:.7167126220185179,what:`read the linked files together`},{id:`dead-end-d41b1e`,strength:`inhibit`,effect:`verify`,support:11,opportunities:43,lower_bound:.14929517058883945,what:`avoid pytest / unittest → make test`},{id:`finish-line-e7e809`,strength:`fire`,effect:`regenerate`,support:7,opportunities:7,lower_bound:.6456695613241317,what:`after schema/*.json → make gen`}],zi={lanes:{target:[-.6,-1,.6],yaw:-.2,pitch:.8,dist:25},gauge:{target:[0,.6,0],yaw:-.06,pitch:.1,dist:19},lid:{target:[0,.2,0],yaw:.1,pitch:.14,dist:18.5},board:{target:[0,.8,0],yaw:.08,pitch:.12,dist:21}},Bi={fire:`fire`,prime:`prime`,inhibit:`inhibit`};function Vi(e,t){let n=Ct,r=`make gen`,i=Ii(n,`E`,r),a=i.support.length,o=vi.default.fire_lower_bound,s=Pi(`regenerate`,!0,i.lb,i.rate,o),c=Pi(`regenerate`,!0,i.lb,i.rate,vi.demo.fire_lower_bound),l=ji(`obligation`,{traces:i.opp,took:a}),u=Li(n),d=n.map(e=>e[0][1].match(Mi)?.[0]).filter(Boolean),f=n.some(e=>e.slice(1).some(e=>d.some(t=>e[1].includes(t)))),p=i.editors.map((e,t)=>{let n=i.editors.slice(0,t+1).filter(e=>i.support.includes(e)).length;return{k:n,n:t+1,lb:kt(n,t+1),ub:Fi(n,t+1)}});n.forEach((t,n)=>t.forEach((t,r)=>e.dot(`n${n}.${r}`)));let m=[];n.forEach((e,t)=>e.forEach((e,n)=>n&&m.push([`n${t}.${n-1}`,`n${t}.${n}`]))),e.link(`lane`,m,`ink3`);let h=e=>n[e].map(e=>e[0]).lastIndexOf(`E`),g=e=>n[e].findIndex((t,n)=>n>h(e)&&t[1]===r);e.link(`eg`,i.support.map(e=>[`n${e}.${h(e)}`,`n${e}.${g(e)}`]),`accent`),e.link(`de`,u.pairs.map(([e,t,n])=>[`n${e}.${t}`,`n${e}.${n}`]),`accent`);let v=e=>-5.6+(e-1)*10.8/Math.max(1,p.length-1),y=e=>-3+e*7;p.forEach((t,n)=>{e.dot(`lb${n}`,.16),e.dot(`ub${n}`,.1),e.dot(`rt${n}`,.12)}),e.link(`iv`,p.map((e,t)=>[`lb${t}`,`ub${t}`]),`ink2`),e.link(`fireBar`,[[[-7.4,y(o),0],[7.6,y(o),0]]],`fire`),e.link(`primeLine`,[[[-7.4,y(yi),0],[7.6,y(yi),0]]],`prime`),e.link(`axis`,[[[-7.4,y(0),0],[7.6,y(0),0]]],`ink3`),e.dot(`lamp`,.34);let b=[v(p.length)+.1,y(i.lb),0],x=[{effect:`observe`,byEdit:!1,name:`observe`},{effect:`verify`,byEdit:!1,name:`verify`},{effect:`regenerate`,byEdit:!0,name:`regenerate<br>after an edit`},{effect:`regenerate`,byEdit:!1,name:`regenerate<br>otherwise`},{effect:`environment`,byEdit:!1,name:`environment`},{effect:`author`,byEdit:!1,name:`author`},{effect:`publish`,byEdit:!1,name:`publish`}],S={none:-2.4,prime:0,fire:2.4},C=e=>-6.3+e*12.6/(x.length-1);x.forEach((t,n)=>e.dot(`cap${n}`,.24)),e.link(`lid`,x.map((e,t)=>{let n=S[Ni(e.effect,e.byEdit)??`none`]+.42;return[[C(t)-.7,n,0],[C(t)+.7,n,0]]}),`ink1`),e.link(`floor`,[[[-7.2,S.none-.3,0],[7.2,S.none-.3,0]]],`ink3`);let w=t.repo&&t.graph?t.graph.routes.filter(e=>_(e.strength)):[],T=w.length>0,E=T?t.graph?.bars?.fire_lower_bound??o:vi.demo.fire_lower_bound,D=T?t.graph?.bars?.min_support??vi.default.min_support:vi.demo.min_support,O=T?w.map(e=>({id:e.id,lamp:_(e.strength),lb:e.evidence.lower_bound,rate:e.evidence.rate??(e.evidence.opportunities?e.evidence.support/e.evidence.opportunities:0),support:e.evidence.support,opp:e.evidence.opportunities,what:e.step.label})).sort((e,t)=>t.lb-e.lb).slice(0,24):Ri.map(e=>({id:e.id,lamp:_(e.strength),lb:kt(e.support,e.opportunities),rate:e.support/e.opportunities,support:e.support,opp:e.opportunities,what:e.what})),k=e=>O.length===1?0:-6.6+e*13.2/(O.length-1),A=e=>-3+e*6.4;O.forEach((t,n)=>{e.dot(`bl${n}`,.3),e.dot(`br${n}`,.1)}),e.link(`bstem`,O.map((e,t)=>[`bl${t}`,`br${t}`]),`ink3`),e.link(`bbar`,[[[-7.6,A(E),0],[7.8,A(E),0]]],`fire`),e.link(`baxis`,[[[-7.6,A(0),0],[7.8,A(0),0]]],`ink3`);let j=O.length<=8?O.map((e,t)=>t):O.map((e,t)=>t).filter(e=>e<4||O[e].lamp===`inhibit`).slice(0,6);n.forEach((t,n)=>e.label(`t${n}`,`T${n+1}`,`n${n}.0`,{dx:-34,dy:-7}));let M=i.support[0],N=u.pairs[0],P=n.findIndex(e=>e.some(e=>e[0]===`R`)),F=n.findIndex(e=>e[0][0]===`D`);e.label(`mFinish`,`finish line`,`n${M}.${g(M)}`,{cls:`chip`,dy:-30,center:!0}),e.label(`mDead`,`dead ends`,`n${N[0]}.${N[1]}`,{cls:`chip`,dy:-30,center:!0}),e.label(`mLinked`,`linked files`,`n${P}.${n[P].findIndex(e=>e[0]===`R`)}`,{cls:`chip`,dy:-30,center:!0}),e.label(`mLookup`,`lookup`,`n0.0`,{cls:`chip`,dy:-30,center:!0}),e.label(`mIntent`,`intent`,`n${F}.0`,{cls:`chip`,dy:-30,center:!0});let I=[Et(2),0,Tt(0)-1.4];e.label(`count`,`<small>MAKE GEN AFTER THE LAST registry/*.csv EDIT</small>${a} / ${i.opp} traces`,I,{cls:`chip big`,dy:-44,center:!0});for(let t of i.near)e.label(`near${t}`,`${n[t].find((e,n)=>n>h(t)&&e[0]===`G`)[1]}: another command`,`n${t}.${n[t].findIndex((e,n)=>n>h(t)&&e[0]===`G`)}`,{cls:`note`,dx:12,dy:6});let L=i.editors.filter(e=>!i.support.includes(e)&&!i.near.includes(e));for(let t of L)e.label(`nogen${t}`,`edited, no regenerate step`,`n${t}.${h(t)}`,{cls:`note`,dx:12,dy:6});e.label(`without`,`<small>WITHOUT THE EDIT</small>${r} in ${i.ranWithout} / ${i.without} traces`,[Et(2),0,Tt(n.length-1)+1.2],{cls:`chip big`,dy:8,center:!0}),e.label(`fireBar`,`fire bar ${K(o)}`,[-7.4,y(o),0],{dy:-18}),e.label(`primeLine`,`prime rate ${K(yi)}`,[-7.4,y(yi),0],{dy:-18}),e.label(`n1`,`1 trace`,[v(1),y(0),0],{dy:8,center:!0}),e.label(`nN`,`${p.length} traces`,[v(p.length),y(0),0],{dy:8,center:!0}),e.label(`lbN`,`lower bound ${K(i.lb)}`,`lb${p.length-1}`,{cls:`note`,dx:14,dy:-7}),e.label(`rtN`,`rate ${K(i.rate)}`,`rt${p.length-1}`,{cls:`note`,dx:14,dy:-7}),e.label(`reflex`,`<small>AFTER EDIT registry/*.csv · RUN ${r}</small><span class="how-lamp ${s??``}">●</span> ${s??`no reflex`}`,`lamp`,{cls:`chip big`,dx:-190,dy:28,center:!0}),x.forEach((t,n)=>{let r=Ni(t.effect,t.byEdit),i=t.effect===`environment`?`starts nascent`:r?``:`never`;e.label(`cn${n}`,`${t.name}${i?`<br><span class="how-dim">${i}</span>`:``}`,[C(n),S.none-.3,0],{dy:10,center:!0})}),e.label(`lvFire`,`fire`,[7.2,S.fire,0],{dx:8,dy:-7}),e.label(`lvPrime`,`prime`,[7.2,S.prime,0],{dx:8,dy:-7});let ee=u.pairs.map(([e,t])=>`n${e}.${t}`);e.label(`deNote`,`npm test ✗ → make check within ${Ci} events`,ee[0],{cls:`note`,dx:14,dy:6}),e.label(`deGate`,`<small>DEAD END · WOULD INHIBIT</small>failed in ${u.failedIn} / ${u.ran} traces that ran it · support ${u.support}`,[Et(2),0,Tt(n.length-1)+1.2],{cls:`chip big`,dy:8,center:!0}),O.forEach((t,n)=>{e.label(`bl${n}`,`<span class="how-lamp ${Bi[t.lamp]}">●</span> ${t.id}<br><span class="how-dim">${t.support}/${t.opp} · LB ${K(t.lb)}</span>`,`bl${n}`,{cls:`chip`,dy:n%2?18:-54,center:!0})}),e.label(`bbar`,`fire bar ${K(E)}${T?``:` (demo)`}`,[-7.6,A(E),0],{dy:-18});function te(e){let t={};return n.forEach((n,r)=>n.forEach(([n,a],o)=>{let s=`n${r}.${o}`,c={pos:[Et(o),0,Tt(r)],color:{hue:St[n].hue},alpha:.85,glow:.14},l=c;if(e===0)l=o===g(r)&&i.support.includes(r)||n===`F`||n===`R`||o===0&&(d.some(e=>a.includes(e))||n===`D`)?{...c,scale:1.25,glow:.45}:{...c,alpha:.4,glow:0};else if(e===1||e===2){let t=i.editors.includes(r),a=i.support.includes(r),s=o===h(r),u=a&&o===g(r);l=e===1&&t&&(s||u)?{...c,color:u?`soft`:`accent`,scale:1.45,glow:.8}:e===1&&t&&i.near.includes(r)&&n===`G`?{...c,color:`ink2`,scale:1.2,glow:.3}:e===2&&!t?{...c,color:`ink2`,scale:1.15,glow:.3}:e===2&&(s||u)?{...c,color:u?`soft`:`accent`,alpha:.5,glow:.1}:{...c,alpha:.2,glow:0}}else if(e===6){let e=u.pairs.find(([e,t,n])=>e===r&&(o===t||o===n));l=e?{...c,color:o===e[1]?`ink1`:`soft`,scale:1.5,glow:.8}:{...c,alpha:.2,glow:0}}t[s]=l})),t}function ne(e){let t={},r=[],a={},o=zi.lanes;return e<=2||e===6?(t=te(e),r.push(...n.map((e,t)=>`t${t}`)),a.lane=e===0?.45:.25,e===0&&r.push(`mFinish`,`mDead`,`mLinked`,`mLookup`,`mIntent`),e===1&&r.push(`count`,...i.near.map(e=>`near${e}`),...L.map(e=>`nogen${e}`)),e===2&&r.push(`count`,`without`),(e===1||e===2)&&(a.eg=e===1?.95:.35),e===6&&(r.push(`deNote`,`deGate`),a.de=.95)):e===3||e===4?(p.forEach((n,r)=>{let i=r===p.length-1,a=e===4&&!i,o=a?.3:1;t[`lb${r}`]={pos:[v(r+1),y(n.lb),0],color:`soft`,alpha:o,glow:a?0:.5,scale:i?1.3:1},t[`ub${r}`]={pos:[v(r+1),y(n.ub),0],color:`ink3`,alpha:o,glow:0},t[`rt${r}`]={pos:[v(r+1),y(n.k/n.n),0],color:`ink1`,alpha:o,glow:a?0:.2}}),e===4&&s&&(t.lamp={pos:b,color:s,scale:1,glow:1}),a.iv=e===3?.8:.4,a.fireBar=.9,a.primeLine=.9,a.axis=.5,r.push(`fireBar`,`primeLine`,`n1`,`nN`),e===3&&r.push(`lbN`,`rtN`),e===4&&r.push(`reflex`),o=zi.gauge):e===5?(x.forEach((e,n)=>{let r=Ni(e.effect,e.byEdit);t[`cap${n}`]={pos:[C(n),S[r??`none`],0],color:r??`ink3`,glow:r?.8:.1,alpha:r?1:.6}}),a.lid=.9,a.floor=.5,r.push(...x.map((e,t)=>`cn${t}`),`lvFire`,`lvPrime`),o=zi.lid):(O.forEach((e,n)=>{t[`bl${n}`]={pos:[k(n),A(e.lb),0],color:e.lamp,glow:.9,scale:O.length>12?.7:1},t[`br${n}`]={pos:[k(n),A(e.rate),0],color:`ink3`,glow:0,alpha:.8}}),a.bstem=.6,a.bbar=.9,a.baxis=.5,r.push(...j.map(e=>`bl${e}`),`bbar`),o=zi.board),{dots:t,links:a,labels:r,cam:o}}let R=(e,t,n,r)=>{let i=e=>34+(e-1)/Math.max(1,p.length-1)*(t-34-8),a=e=>n-14-e*(n-14-6);e.font=`10px 'Red Hat Mono', ui-monospace, monospace`,e.beginPath(),p.forEach((t,n)=>n?e.lineTo(i(t.n),a(t.ub)):e.moveTo(i(t.n),a(t.ub))),[...p].reverse().forEach(t=>e.lineTo(i(t.n),a(t.lb))),e.closePath(),e.fillStyle=r.css(`soft`)+`33`,e.fill();let s=(t,n,r)=>{e.beginPath(),t.forEach((t,n)=>n?e.lineTo(i(n+1),a(t)):e.moveTo(i(n+1),a(t))),e.strokeStyle=n,e.lineWidth=r,e.stroke()};s(p.map(e=>e.lb),r.css(`soft`),1.5),s(p.map(e=>e.k/e.n),r.css(`ink2`),1);let c=(n,r,i)=>{e.setLineDash([3,3]),e.strokeStyle=r,e.lineWidth=1,e.beginPath(),e.moveTo(34,a(n)),e.lineTo(t-4,a(n)),e.stroke(),e.setLineDash([]),e.fillStyle=r,e.textAlign=`right`,e.textBaseline=`middle`,e.fillText(i,30,a(n))};c(o,r.css(`fire`),K(o)),c(yi,r.css(`prime`),K(yi)),e.fillStyle=r.css(`ink3`),e.textBaseline=`top`,e.textAlign=`left`,e.fillText(`1 trace`,i(1),n-14+2),e.textAlign=`right`,e.fillText(`${p.length} traces`,i(p.length),n-14+2)},re=(e,t,n,r)=>{let i=[[`told (p_follow)`,l.pFollow,r.css(`fire`)],[`unaided (p_self)`,l.pSelf,r.css(`ink2`)]],a=e=>104+e*(t-104-44),o=(n-16)/i.length;e.font=`10px 'Red Hat Mono', ui-monospace, monospace`,e.textBaseline=`middle`,i.forEach(([t,n,i],s)=>{let c=4+s*o+o/2;e.fillStyle=r.css(`ink2`),e.textAlign=`left`,e.fillText(t,0,c),e.fillStyle=i,e.fillRect(a(0),c-4,a(n)-a(0),8),e.fillStyle=r.css(`ink1`),e.fillText(K(n),a(n)+5,c)}),e.fillStyle=r.css(`ink3`),e.textAlign=`left`,e.textBaseline=`bottom`,e.fillText(`uplift ${l.mean>=0?`+`:``}${K(l.mean)} · bar +${K(Di)}`,104,n)},z=(e,t)=>({text:t,ok:e}),B=[{title:`Every reflex is checked again`,plain:`Before a reflex is kept, its evidence is recounted from scratch, exactly the way it will be used. Sessions where Adage already gave the advice do not count.`,math:`evidence`,body:`Mining and compiling propose; before a reflex is written, its evidence is counted again on the traces, exactly as its own trigger and step read them: a lookup through the value type of the ticket it names, linked files over the traces that ran the lookup, a finish line over the traces that edited its files, a dead end over the traces that ran the failing runner. A trace a directive already steered toward the step is left out. ${d.length?`Only ${d.length} sample prompt names a ticket-shaped token (${d.join(`, `)}), and ${f?`a command uses it`:`no command uses it`}, so no lookup forms here.`:`No sample prompt names a ticket, so no lookup forms here.`}`,chips:[{text:`one learner: the graph engine`},{text:`evidence in distinct traces`},{text:`linked files: reads within ${wi} steps`}]},{title:`Count the sessions`,plain:`Take the rule "after editing registry files, run ${r}". Of the ${i.opp} sessions that edited those files, ${a} ran it.`,math:`evidence`,key:!0,body:`A reflex after an edit asks: after the last edit to registry/*.csv, did the trace run the same regenerate command, and succeed? ${a} of the ${i.opp} traces that edited those files ran ${r}. A different command, even a variant, does not count, and the supporting traces must span at least ${Ti} distinct tasks.`,chips:[{text:`support ${a} ≥ ${vi.default.min_support}`,ok:a>=vi.default.min_support},{text:`opportunities ${i.opp}`},{text:`rate ${K(i.rate)}`},{text:`≥ ${Ti} tasks`}]},{title:`Would it happen anyway?`,plain:`Is the edit really the trigger? In the ${i.without} sessions without it, ${r} ran ${i.ranWithout} times, so yes: the command belongs to the edit.`,math:`evidence`,body:`A finish line must belong to the edit. In the ${i.without} traces without it, ${r} ran ${i.ranWithout} times, so the rate rises by ${K(i.rate-i.rateWithout)} with the edit. It must rise by at least ${K(xi)}.`,chips:[z(i.rate-i.rateWithout>=xi,`contrast ${K(i.rate-i.rateWithout)} ≥ ${K(xi)}`),{text:`${K(i.rate)} with · ${K(i.rateWithout)} without`}]},{title:`Small samples call for caution`,plain:`${a} out of ${i.opp} sounds good, but it is a small sample, like a restaurant with only a few reviews. Adage asks how low the true rate could realistically be: ${K(i.lb)}, short of the ${K(o)} it needs to insist.`,math:`evidence`,key:!0,body:`A rate from few traces is uncertain, so strength is judged by the Wilson lower bound at 95%, not the rate. Each column adds one trace: the interval narrows, but after ${i.opp} traces the lower bound is ${K(i.lb)}, well under the fire bar of ${K(o)}.`,chips:[{text:`Wilson, z = 1.96`},{text:`${a}/${i.opp} → LB ${K(i.lb)}`},{text:`fire bar ${K(o)}`}],figure:R},{title:s===`fire`?`Sure enough to tell`:s===`prime`?`Suggest, but do not insist`:`Not enough evidence yet`,plain:s===`fire`?`Sure enough to tell the agent: the reflex fires.`:s===`prime`?`Not sure enough to insist, but sure enough to suggest: the reflex primes, and grows stronger as evidence comes in.`:`Not enough evidence yet, so no reflex forms.`,math:`evidence`,body:`A reflex fires when its lower bound reaches the fire bar and its effect allows it. Otherwise it primes if its rate reaches ${K(yi)}, or ${K(bi)} for a reflex that already exists, so reflexes do not flicker. A step too few traces took can still prime when the traces that took it succeeded more often than those that did not (the 95% lower bound on the difference at least ${K(Ei)}). Here the lower bound is ${K(i.lb)} and the rate ${K(i.rate)}: ${s??`no reflex`}. With the demo thresholds (fire bar ${K(vi.demo.fire_lower_bound)}), it would ${c??`not form`} too.`,chips:[z(i.lb>=o,`LB ${K(i.lb)} ≥ ${K(o)}`),z(i.rate>=yi,`rate ${K(i.rate)} ≥ ${K(yi)}`),{text:`keep ≥ ${K(bi)}`},{text:`or outcome lift ≥ ${K(Ei)} → prime`}]},{title:`Does telling change anything?`,plain:`Saying what agents already do is just noise. Adage estimates how much more often they take the step when told: ${l.mean>=0?`+`:``}${K(l.mean)} here, ${l.gated?`too little, so it stays quiet`:`enough to be worth saying`}.`,math:`uplift`,key:!0,body:`Agents taking a step is not evidence that telling them helps. Uplift is how much more often agents take the step when told (p_follow) than unaided (p_self), each a Beta posterior that starts from its kind's prior and is updated by this repository's traces: unexposed traces and control-arm traces for p_self, treated judgements for p_follow. A finish line starts at p_self ${K(Ai.obligation.self)}; here ${a} of ${i.opp} editing traces ran ${r} unaided, so p_self is ${K(l.pSelf)} and uplift ${l.mean>=0?`+`:``}${K(l.mean)}: ${l.gated?`under the bar, so it stays quiet`:`above the bar, so it is delivered`}. A reflex under +${K(Di)}, with at least 3 situations of the repository's own evidence, stays quiet: nascent, listed in adage review as quiet, until a person approves it.`,chips:[z(!l.gated,`uplift ${l.mean>=0?`+`:``}${K(l.mean)} ≥ +${K(Di)}`),{text:`p_follow ${K(l.pFollow)} · p_self ${K(l.pSelf)}`},{text:`quiet: nascent until approved`},{text:`demo thresholds and procedure cards: not gated`}],figure:re},{title:`Riskier steps get a gentler voice`,plain:`What a step does limits how hard Adage may push it. Checks and lookups can be insisted on, installs only suggested, and edits and publishing are never directed.`,math:`read`,body:`What a step does limits how strongly Adage may direct it. Reads and checks can fire. A regenerate step fires only after an edit. An install primes at most, and starts nascent until a person reviews it. Edits and publishing are never directed.`,chips:[{text:`observe, verify: fire`},{text:`regenerate: fire after an edit`},{text:`environment: prime`},{text:`author, publish: none`}]},{title:`Spotting a dead end`,plain:`A command that keeps failing, followed by one that works, can become a warning. Here npm test failed every time, but only ${u.support} sessions show it, short of the ${vi.default.min_support} needed, so no warning yet.`,math:`evidence`,body:`A failed check followed within ${Ci} events by a different check that works is a dead-end pair. The runner must fail in at least ${Si[0]} of ${Si[1]} traces that ran it; npm test failed in ${u.failedIn} of ${u.ran}. But only ${u.support} traces show the pair, under the minimum of ${vi.default.min_support}, so no reflex forms. A dead end inhibits: announced at session start when most traces run the failing runner, otherwise said right after the failure.`,chips:[z(u.consistent,`failed ${u.failedIn}/${u.ran} ≥ ${Si[0]}/${Si[1]}`),z(u.support>=vi.default.min_support,`support ${u.support} ≥ ${vi.default.min_support}`)]},T?{title:`Your reflexes against the bar`,plain:`Each column is one of your reflexes. The lamp is how sure Adage can be at worst: above the line it may tell the agent, below it only suggests.`,math:`evidence`,body:`Each column is one of this repository's reflexes: its lower bound (the lamp) below its rate. A lamp above the fire bar of ${K(E)} may fire; the ceiling or the rules explain the rest. Inhibit comes from the dead-end rule, not the bar.`,chips:[{text:`${O.length} reflexes${w.length>O.length?` of ${w.length}`:``}`},{text:`min support ${D}`},{text:`fire bar ${K(E)}`}]}:{title:`The demo's finished reflexes`,plain:`The demo's finished set of reflexes: the lookup is sure enough to tell, the list of files to read is only ever suggested, and the dead end warns.`,math:`evidence`,body:`The demo dataset's recorded index, conditioned with the demo thresholds (fire bar ${K(E)}, min support ${D}). The lookup fires at ${K(O[0].lb)}. Linked files sit higher, at ${K(O[1].lb)}, yet prime: a read is only ever suggested. The dead end inhibits whatever its bound.`,chips:O.map(e=>({text:`${e.lamp} ${e.support}/${e.opp}`}))}],ie=[0,1,2,3,4,4,5,6,7];return{source:T?`${n.length} sample traces · your ${O.length} reflexes`:`${n.length} sample traces · 1 recorded index`,legend:[{label:`fire`,role:`fire`},{label:`prime`,role:`prime`},{label:`inhibit`,role:`inhibit`},{label:`edit`,role:`accent`},{label:`counted step`,role:`soft`}],steps:B.map((e,t)=>({...e,state:ne(ie[t])}))}}var Hi={id:`judge`,title:`Check the evidence`,technical:`Judge the evidence`,status:`Built · default`,kind:`built`,summary:`Every reflex is checked against the record again: how often it held, how sure Adage can be with this many examples, and whether saying it changes anything.`,source:`crates/adage-learn/src/{engine,evidence,value}.rs · crates/adage-tracks/src/model.rs`,usesRepo:!0,build:Vi},Ui=1e4,Wi=2e3,Gi=7,Ki=11,qi=.05,Ji=10,Yi=5,Xi=[[[24,31],[12,14],[1,0],[1,1]],[[28,22],[15,19],[1,1],[1,1]],[[19,25],[18,13],[0,1],[1,0]],[[30,34],[11,16],[0,0],[1,0]],[[21,17],[20,22],[1,1],[1,1]],[[26,29],[14,12],[1,0],[0,1]],[[23,27],[17,25],[1,1],[1,1]],[[33,28],[13,18],[0,1],[1,1]]],Zi=(e,t,n)=>Math.round((.0042*e+.004*((t*3+n*5)%4))*1e3)/1e3,Qi=Xi.map(([e,t,n,r],i)=>({control:e.map((e,t)=>({turns:e,cost:Zi(e,i,t),passed:n[t]})),treated:t.map((e,t)=>({turns:e,cost:Zi(e,i,2+t),passed:r[t]}))})),$i=[{key:`turns`,label:`turns`,agg:`median`},{key:`cost`,label:`cost`,agg:`mean`},{key:`passed`,label:`pass rate`,agg:`mean`}];function ea(e){let t=e>>>0;return()=>{t=t+1831565813>>>0;let e=t;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}}var ta=e=>e.reduce((e,t)=>e+t,0)/e.length;function na(e){let t=[...e].sort((e,t)=>e-t),n=t.length>>1;return t.length%2?t[n]:(t[n-1]+t[n])/2}var ra=e=>e===`median`?na:ta,ia=e=>Qi.map(t=>[t.treated.map(t=>t[e]),t.control.map(t=>t[e])]);function aa(e){return ta(e.map(([e,t])=>ta(e)-ta(t)))}function oa(e,t){for(let n=e.length-1;n>0;n--){let r=Math.floor(t()*(n+1));[e[n],e[r]]=[e[r],e[n]]}}function sa(e,t=Ui,n=Gi){let r=aa(e),i=ea(n),a=e.map(([e,t])=>({k:e.length,vals:[...e,...t]})),o=[],s=0,c=[];for(let e=0;e<t;e++){for(let e of a)oa(e.vals,i);let t=a.map(e=>[e.vals.slice(0,e.k),e.vals.slice(e.k)]);e===0&&(c=t.map(([e,t])=>[[...e],[...t]]));let n=aa(t);o.push(n),Math.abs(n)>=Math.abs(r)-1e-12&&s++}return{p:(s+1)/(t+1),obs:r,null:o,first:c}}function ca(e){let t=e.map(([e,t])=>ta(e)-ta(t)),n=Math.abs(t.reduce((e,t)=>e+t,0))-1e-12,r=0;for(let e=0;e<1<<t.length;e++){let i=t.reduce((t,n,r)=>t+(e>>r&1?-n:n),0);Math.abs(i)>=n&&r++}return r/(1<<t.length)}var la=(e,t)=>{let n=t*(e.length-1),r=Math.floor(n),i=Math.min(r+1,e.length-1);return e[r]+(e[i]-e[r])*(n-r)};function ua(e,t,n=Wi,r=Ki){let i=ea(r),a=[];for(let r=0;r<n;r++){let n=[],r=[];for(let t=0;t<e.length;t++){let[t,a]=e[Math.floor(i()*e.length)];n.push(...t),r.push(...a)}a.push(t(n)-t(r))}let o=[...a].sort((e,t)=>e-t);return{lo:la(o,.025),hi:la(o,.975),draws:a}}function da(e){let t=e.map((e,t)=>[e,t]).sort((e,t)=>e[0]-t[0]),n=Array(e.length),r=0;return t.forEach(([t,i],a)=>{r=Math.max(r,Math.min(1,(e.length-a)*t)),n[i]=r}),n}var fa=[{name:`acme-billing`,sessions:36,learned:!1},{name:`harbor-dispatch`,sessions:48,learned:!0},{name:`py-billing-s11`,sessions:21,learned:!1},{name:`py-clinic-s12`,sessions:27,learned:!0},{name:`py-logistics-s13`,sessions:21,learned:!1},{name:`node-logistics-s21`,sessions:27,learned:!0},{name:`node-billing-s22`,sessions:21,learned:!1},{name:`node-clinic-s23`,sessions:27,learned:!0},{name:`py-billing-hash-s32`,sessions:21,learned:!1},{name:`node-billing-uuid-s42`,sessions:21,learned:!1},{name:`acme-billing`,sessions:42,learned:!0,sonnet:!0},{name:`harbor-dispatch`,sessions:42,learned:!0,sonnet:!0}],pa=[{label:`4 learned · adage − control`,diff:-15.5,lo:-18.5,hi:-9,holm:`0.001`},{label:`all 10 · adage − control`,diff:-8,lo:-13,hi:-1.5,holm:`0.029`},{label:`all 10 · instincts − control`,diff:-1,lo:-4,hi:3,holm:`1.0`}],ma={graph:.6307},ha={control:10,treated:30,resamples:2e3},ga=`For a whole repository, adage savings estimates what a session costs with Adage against the control arm (API-list-equivalent dollars, model turns, turns to the first edit), weighted by each session's recorded arm propensity, with a ${ha.resamples.toLocaleString(`en`)}-resample bootstrap interval. It states dollars only once ${ha.control} control and ${ha.treated} treated sessions have finished; before that it shows counts, and beside it always how often each arm ended asking the person for help.`,_a=e=>-6.2+(e-10)*.46,va=e=>-5.6+e*1.6,ya=.36,ba=e=>e*.55,xa=.5,Sa=200,Ca={rows:{target:[-.2,0,.6],yaw:0,pitch:1.2,dist:20},hist:{target:[-2.2,2,0],yaw:-.12,pitch:.28,dist:20},holm:{target:[0,2.6,0],yaw:0,pitch:.12,dist:16},boot:{target:[-3,.8,0],yaw:0,pitch:.3,dist:16},grid:{target:[0,0,.4],yaw:0,pitch:1.3,dist:21},mine:{target:[-1.5,0,.4],yaw:0,pitch:1.2,dist:19}};function wa(e,t){let n=t.repo&&t.graph?t.graph.routes.filter(e=>e.in_index).slice(0,8):[],r=n.length>0,i=$i.map(e=>{let t=ia(e.key),n=ra(e.agg),r=e=>t.flatMap(t=>t[e]);return{m:e,g:t,diff:n(r(0))-n(r(1)),treated:n(r(0)),control:n(r(1)),perm:sa(t),boot:ua(t,n),flip:ca(t)}}),a=da(i.map(e=>e.perm.p)),o=i[0],s=o.perm.obs,c=o.perm.null,l=2/2**Qi.length,u=e=>e.toFixed(2),d=e=>e<.001?e.toExponential(1):e<.01?e.toFixed(4):e.toFixed(3),f=e=>e>0?`+${e.toFixed(1)}`:e<0?`−${(-e).toFixed(1)}`:`0.0`,p=[];Qi.forEach((t,n)=>[`control`,`treated`].forEach(r=>t[r].forEach((t,i)=>{let a=`r${n}.${r[0]}${i}`;p.push({id:a,t:n,arm:r,r:i,turns:t.turns}),e.dot(a,.19)})));let m=new Map;Qi.forEach((e,t)=>{let[n]=o.perm.first[t],r=[...p.filter(e=>e.t===t)],i=[...n];for(let e of r){let t=i.indexOf(e.turns);t>=0?(m.set(e.id,`treated`),i.splice(t,1)):m.set(e.id,`control`)}});let h=aa(o.perm.first),g=e=>Qi.map((t,n)=>{let r=t=>ta(p.filter(r=>r.t===n&&e(r.id)===t).map(e=>e.turns));return{c:r(`control`),a:r(`treated`)}}),_=g(e=>p.find(t=>t.id===e).arm),v=g(e=>m.get(e));Qi.forEach((t,n)=>{e.dot(`mc${n}`,.12),e.dot(`ma${n}`,.12)}),e.link(`diffs`,Qi.map((e,t)=>[`mc${t}`,`ma${t}`]),`accent`),e.link(`rowlines`,Qi.flatMap((e,t)=>[[[_a(10),0,va(t)-ya],[_a(36),0,va(t)-ya]],[[_a(10),0,va(t)+ya],[_a(36),0,va(t)+ya]]]),`ink3`),Qi.forEach((t,n)=>e.label(`task${n}`,`task ${n+1}`,[_a(10),0,va(n)],{dx:-54,dy:-7})),Qi.forEach((t,n)=>e.label(`d${n}`,f(_[n].a-_[n].c),[_a(36),0,va(n)],{dx:8,dy:-7})),Qi.forEach((t,n)=>e.label(`dp${n}`,f(v[n].a-v[n].c),[_a(36),0,va(n)],{dx:8,dy:-7})),e.label(`armC`,`control`,[_a(10),0,va(0)-ya],{cls:`note`,dx:4,dy:-22}),e.label(`armT`,`treated`,[_a(10),0,va(0)+ya],{cls:`note`,dx:4,dy:6}),e.label(`axisT`,`turns →`,[_a(23),0,va(Qi.length-1)+.8],{dy:4,center:!0}),e.label(`ax10`,`10`,[_a(10),0,va(Qi.length-1)+.8],{dy:4,center:!0}),e.label(`ax36`,`36`,[_a(36),0,va(Qi.length-1)+.8],{dy:4,center:!0}),e.label(`stat`,`<small>MEAN OVER TASKS</small>${f(s)} turns`,[_a(23),0,va(Qi.length-1)+1],{cls:`chip big`,dy:8,center:!0}),e.label(`statP`,`<small>SHUFFLE 1 · MEAN OVER TASKS</small>${f(h)} turns`,[_a(23),0,va(Qi.length-1)+1],{cls:`chip big`,dy:8,center:!0});let y=c.slice(0,Sa),b=new Map,x=y.map(e=>{let t=Math.round(e/xa),n=b.get(t)??0;return b.set(t,n+1),[ba(t*xa),.2+n*.24,0]});y.forEach((t,n)=>e.dot(`h${n}`,.1)),e.dot(`obs`,.26);let S=c.filter(e=>Math.abs(e)>=Math.abs(s)-1e-12).length,C=Math.sqrt(ta(c.map(e=>e*e))-ta(c)**2);e.link(`hAxis`,[[[ba(-16),0,0],[ba(10),0,0]],[[ba(0),-.2,0],[ba(0),.2,0]]],`ink3`),e.link(`obsLine`,[[[ba(s),0,0],[ba(s),3.4,0]]],`accent`),e.label(`obs`,`<small>OBSERVED</small>${f(s)} turns`,[ba(s),3.4,0],{cls:`chip big`,dy:-50,center:!0}),e.label(`nullL`,`${Sa} of ${Ui.toLocaleString(`en`)} shuffles`,[ba(0),0,0],{cls:`note`,dy:10,center:!0}),e.label(`zero`,`0`,[ba(0),0,0],{dy:26,center:!0});let w=e=>Math.min(4.2,-Math.log10(e))*1.25,T=e=>-4.5+e*4.5;i.forEach((t,n)=>{e.dot(`praw${n}`,.16),e.dot(`padj${n}`,.24)}),e.link(`holm`,i.map((e,t)=>[`praw${t}`,`padj${t}`]),`ink3`),e.link(`alpha`,[[[-6.4,w(qi),0],[6.4,w(qi),0]]],`accent`),e.link(`pBase`,[[[-6.4,0,0],[6.4,0,0]]],`ink3`),i.forEach((t,n)=>e.label(`hl${n}`,`<small>${t.m.label.toUpperCase()}</small>p ${d(t.perm.p)} → Holm ${d(a[n])}`,[T(n),0,0],{cls:`chip`,dy:12,center:!0})),e.label(`alphaL`,`α ${qi}`,[-6.4,w(qi),0],{cls:`note`,dx:-46,dy:-7}),e.label(`pAxis`,`−log10 p ↑`,[-6.4,w(1e-4)+.6,0],{dx:-28,dy:-7}),e.link(`pStems`,i.map((e,t)=>[[T(t),0,0],`padj${t}`]),`ink3`);let E=e=>e*.5,D=o.boot.draws.slice(0,120),O=new Map,k=D.map(e=>{let t=Math.round(e*2),n=O.get(t)??0;return O.set(t,n+1),[E(e),.25+n*.2,0]});D.forEach((t,n)=>e.dot(`b${n}`,.09)),e.link(`ci`,[[[E(o.boot.lo),-.3,0],[E(o.boot.hi),-.3,0]],[[E(o.boot.lo),-.55,0],[E(o.boot.lo),-.05,0]],[[E(o.boot.hi),-.55,0],[E(o.boot.hi),-.05,0]]],`accent`),e.link(`zeroB`,[[[0,-.8,0],[0,3,0]]],`ink3`),e.label(`ciL`,`95% CI [${f(o.boot.lo)}, ${f(o.boot.hi)}]`,[E((o.boot.lo+o.boot.hi)/2),-.3,0],{cls:`chip`,dy:10,center:!0}),e.label(`zeroBL`,`no effect`,[0,3,0],{cls:`note`,dy:-18,center:!0});let A=fa.reduce((e,t)=>e+t.sessions,0),j=[];fa.forEach((t,n)=>{let r=-5.7+n%4*3.8,i=-3.9+Math.floor(n/4)*3.9,a=Math.ceil(Math.sqrt(t.sessions));for(let o=0;o<t.sessions;o++){let t=`s${n}.${o}`;j.push({id:t,c:n,pos:[r+(o%a-(a-1)/2)*.34,0,i+(Math.floor(o/a)-(a-1)/2)*.34]}),e.dot(t,.09)}e.label(`sb${n}`,`${t.name}<br><span class="how-dim">${t.sonnet?`Sonnet 5`:`Haiku 4.5`}<br>${t.sessions} traces</span>`,[r,0,i+1.3],{dy:4,center:!0})});let M=fa.filter(e=>e.learned&&!e.sonnet).length,N=fa.filter(e=>!e.sonnet).length,P=n.map(e=>Ea(e));P.forEach((t,n)=>{[`t`,`c`].forEach(r=>{let i=Math.min(24,r===`t`?t.t.n:t.c.n);for(let t=0;t<i;t++)e.dot(`y${n}${r}${t}`,.12)});let r=t.enough?`${ht(t.t)} vs ${ht(t.c)}`:`too few to conclude`;e.label(`y${n}`,`${t.r.id}<br><span class="how-dim">${t.word} · treated ${t.t.k}/${t.t.n} · control ${t.c.k}/${t.c.n} · ${r}</span>`,[-7.4,0,Ta(n,P.length)],{dy:-30})});let F=gt(n)[0];function I(e){let t={},n=[],o={};if(e<=2){for(let n of p){let r=e===2?m.get(n.id):n.arm;t[n.id]={pos:[_a(n.turns),0,va(n.t)+(r===`control`?-.36:ya)],color:r===`control`?`ink2`:`accent`,glow:r===`control`?.12:.4}}return e>=1&&((e===2?v:_).forEach((e,n)=>{t[`mc${n}`]={pos:[_a(e.c),.02,va(n)],color:`ink2`,scale:1.1,glow:0},t[`ma${n}`]={pos:[_a(e.a),.02,va(n)],color:`accent`,scale:1.1,glow:0}}),o.diffs=.9,n.push(...Qi.map((t,n)=>e===2?`dp${n}`:`d${n}`),e===2?`statP`:`stat`)),o.rowlines=.18,n.push(...Qi.map((e,t)=>`task${t}`),`armC`,`armT`),e===0&&n.push(`axisT`,`ax10`,`ax36`),{dots:t,labels:n,links:o,cam:Ca.rows}}if(e===3)return y.forEach((e,n)=>t[`h${n}`]={pos:x[n],color:`ink2`,alpha:.85,glow:.05}),t.obs={pos:[ba(s),.2,0],color:`accent`,scale:1.2,glow:.9},{dots:t,labels:[`obs`,`nullL`,`zero`],links:{hAxis:.6,obsLine:.9},cam:Ca.hist};if(e===4)return i.forEach((e,n)=>{let r=a[n]<qi;t[`praw${n}`]={pos:[T(n),w(e.perm.p),0],color:`ink3`,alpha:.6,glow:0},t[`padj${n}`]={pos:[T(n),w(a[n]),0],color:r?`accent`:`ink2`,glow:r?.8:.1}}),n.push(...i.map((e,t)=>`hl${t}`),`alphaL`,`pAxis`),{dots:t,labels:n,links:{holm:.7,alpha:.8,pBase:.5,pStems:.35},cam:Ca.holm};if(e===5)return D.forEach((e,n)=>t[`b${n}`]={pos:k[n],color:`soft`,alpha:.85,glow:.1}),{dots:t,labels:[`ciL`,`zeroBL`],links:{ci:.95,zeroB:.6},cam:Ca.boot};if(e===6||e===7&&!r){for(let n of j){let r=fa[n.c],i=e===6?r.learned:!r.learned;t[n.id]={pos:n.pos,color:i?e===6?r.sonnet?`soft`:`accent`:`ink1`:`ink3`,alpha:i?1:.28,glow:i?.3:0}}return n.push(...fa.map((e,t)=>`sb${t}`)),{dots:t,labels:n,links:{},cam:Ca.grid}}return P.forEach((e,r)=>{let i=Ta(r,P.length);[`t`,`c`].forEach(n=>{let a=n===`t`?e.t:e.c,o=Math.min(24,a.n),s=a.n>24?Math.round(a.k/a.n*24):a.k;for(let e=0;e<o;e++){let a=e<s;t[`y${r}${n}${e}`]={pos:[-7.2+e*.42,0,i+(n===`t`?-.3:.3)+.5],color:a?n===`t`?`accent`:`ink1`:`ink3`,alpha:a?1:.35,glow:a&&n===`t`?.4:0}}}),n.push(`y${r}`)}),{dots:t,labels:n,links:{},cam:Ca.mine}}let L=[{title:`With and without, task by task`,plain:`The same tasks run both with Adage and without it. Each row is a task and each dot a run, placed by how many turns it took.`,key:!0,body:`Each row is one of ${Qi.length} sample tasks; each dot is a run, placed by its turns. Every task runs in both arms, treated and control, twice each. Runs of one task are not independent, so the task, not the run, is the unit.`,chips:[{text:`${Qi.length} tasks × 2 arms × 2 runs`},{text:`median turns ${o.treated} vs ${o.control}`},{text:`arm order shuffled per (task, repeat)`}]},{title:`Compare within each task`,plain:`Within each task, the runs with Adage are compared with the runs without it. On average the difference is ${f(s)} turns.`,math:`measure`,body:`Within each task, the treated runs' mean is compared with the control runs' mean. The test statistic is the mean of those differences over the ${Qi.length} tasks: ${f(s)} turns.`,chips:[{text:`task mean diff ${f(s)}`},{text:`${o.g.filter(([e,t])=>ta(e)<ta(t)).length} of ${Qi.length} tasks fewer turns`}]},{title:`Could it be luck?`,plain:`If Adage made no difference, swapping which runs had it would change nothing. So the labels are shuffled within each task, and the difference is worked out again.`,math:`measure`,body:`If the arm made no difference, the labels could be swapped within a task and nothing would change. One shuffle, seeded: runs trade arms inside their own row, never across rows, and the statistic becomes ${f(h)}.`,chips:[{text:`labels shuffled within tasks`},{text:`seed ${Gi}`},{text:`shuffle 1: ${f(h)}`}]},{title:`Chance, ten thousand times`,plain:`Shuffled ten thousand times, chance alone almost never matches the real difference, so the result is very unlikely to be luck.`,math:`measure`,key:!0,body:`Repeat the shuffle ${Ui.toLocaleString(`en`)} times and the statistics pile up around zero, with a spread of ±${u(C)}. ${S?`Only ${S}`:`None`} land as far out as the observed ${f(s)}, so p = (${S} + 1) / (${Ui.toLocaleString(`en`)} + 1) = ${d(o.perm.p)}.`,chips:[{text:`${Ui.toLocaleString(`en`)} permutations`},{text:`two-sided`},{text:`p ${d(o.perm.p)}`,ok:o.perm.p<qi}],figure:Oa(c,s)},{title:`Raise the bar for several tests`,plain:`Turns, cost and pass rate are all tested, and testing more things makes a lucky hit more likely, so the bar is raised to match.`,math:`measure`,body:`Turns, cost and pass rate are tested together, so a chance hit somewhere is likelier. Holm's step-down multiplies the smallest p by ${i.length}, the next by ${i.length-1}, and so on, never letting a later p fall below an earlier one. ${i.map((e,t)=>`${e.m.label} ${d(a[t])}`).join(`, `)}.`,chips:i.map((e,t)=>({text:`${e.m.label}: Holm ${d(a[t])}`,ok:a[t]<qi}))},{title:`Would it hold on new tasks?`,plain:`Resampling the tasks gives a likely range for the saving, and a second test asks whether it would carry over to tasks not seen here.`,math:`measure`,body:`Resampling whole tasks ${Wi.toLocaleString(`en`)} times gives a 95% interval for the median difference: [${f(o.boot.lo)}, ${f(o.boot.hi)}] turns${o.boot.hi<0?`, clear of zero`:``}. A sign-flip test over the task differences asks whether it would hold for new tasks; it is exact, and with ${Qi.length} tasks its smallest possible p is 2/2^${Qi.length} = ${d(l)}.`,chips:[{text:`bootstrap ${Wi.toLocaleString(`en`)} · seed ${Ki}`},{text:`sign-flip p ${d(o.flip)}`,ok:o.flip<qi},{text:`${Qi.length} tasks`}],figure:ka([{label:`sample · turns`,diff:o.diff,lo:o.boot.lo,hi:o.boot.hi}],-16,6)},{title:`What 354 real sessions showed`,plain:`Across 354 real agent sessions: where Adage had learned a reflex, agents needed a median of 12.5 turns instead of 28, at about half the cost. The difference in pass rates was too small to call.`,math:`measure`,key:!0,body:`The live corpus: ${A} headless Claude Code sessions over ${fa.length} runs of ${N} sandboxes, confined with bubblewrap, arms control, adage and instincts. With Haiku 4.5, in the ${M} sandboxes where a reflex was learned: median turns 12.5 vs 28 (−15.5, CI [−18.5, −9], Holm p 0.001, sign-flip p 0.0002), cost $0.063 vs $0.120 (−48%). Across all ${N}: 18 vs 26 turns (Holm p 0.029); pass rate 0.62 vs 0.51, Holm p 0.76, not significant.${r?` In ${N-M} of ${N} sandboxes nothing was learned, and instincts alone showed no measurable effect.`:``}`,chips:[{text:`turns −15.5 · Holm 0.001`,ok:!0},{text:`cost −48%`,ok:!0},{text:`pass 0.62 vs 0.51 · not significant`},...r?[{text:`0 false learned reflexes`}]:[]],figure:ka(pa,-20,5)},r?{title:`Your reflexes, with and without`,plain:`Each row is one of your reflexes: with Adage above, without below, so you can see whether it changed what the agent did.`,math:`measure`,body:`Each row is one of your reflexes: a dot per trace where it applied, lit where the agent took its path (or, for an inhibit, hit the dead end). Treated above, control below. A share is stated only with at least ${Ji} treated and ${Yi} control traces; ${P.filter(e=>e.enough).length?`${P.filter(e=>e.enough).length} of ${P.length} have that many.`:`none of your ${P.length} has that many yet, so these numbers are too small to conclude anything.`}${F?` In all: took the known path ${F.treated.k}/${F.treated.n} treated, ${F.control.k}/${F.control.n} control.`:``} ${ga}`,chips:[{text:`≥ ${Ji} treated · ≥ ${Yi} control`},{text:`counts are distinct traces`}]}:{title:`Where nothing was learned, nothing changed`,plain:`Where nothing was learned, nothing changed, and no learned reflex gave wrong advice. Adage also reports its savings on your own work once enough sessions have finished.`,math:`measure`,body:`In ${N-M} of ${N} Haiku sandboxes the agents found the lookup in too few training traces, so no reflex was learned; there, instincts alone showed no measurable effect (turns −1, CI [−4, 3]). No learned reflex was false. Offline, before any agent runs, the L0 bench scores a learner by J = turns saved − 2.0 × false directives + 1.0 × route F1, per session. ${ga}`,chips:[{text:`nothing learned: ${N-M}/${N}`},{text:`0 false learned reflexes`},{text:`L0 J ${ma.graph} · core suite`}]}];return{source:r?`your ${P.length} reflexes · ${Qi.length} sample tasks`:`${Qi.length} sample tasks · the live corpus`,legend:[{label:`control`,role:`ink2`},{label:`treated`,role:`accent`}],steps:L.map((e,t)=>({...e,state:I(t)}))}}var Ta=(e,t)=>(e-(t-1)/2)*Math.min(2.6,16/Math.max(1,t));function Ea(e){let t=e.step.kind===`avoid`,n=e=>({k:e?t?e.hit_avoided??0:e.followed:0,n:e?.hit_avoided===null&&t?0:e?.applied??0}),r=n(e.arms.treated),i=n(e.arms.control);return{r:e,word:t?`hit the dead end`:`took the path`,t:r,c:i,enough:r.n>=Ji&&i.n>=Yi&&mt(r)!==null}}var Da=`10px 'Red Hat Mono', ui-monospace, monospace`;function Oa(e,t){return(n,r,i,a)=>{let o=Math.min(t,...e)-1,s=Math.max(-t,...e)+1,c=Array(48).fill(0);for(let t of e)c[Math.min(47,Math.floor((t-o)/(s-o)*48))]++;let l=e=>4+(e-o)/(s-o)*(r-8),u=Math.max(...c),d=(r-8)/48;n.fillStyle=a.css(`ink3`),c.forEach((e,t)=>{let r=e/u*(i-14-16);n.fillRect(4+t*d+.5,i-14-r,Math.max(1,d-1),r)}),n.font=Da,n.textBaseline=`top`,n.textAlign=`center`,n.fillText(`0`,l(0),i-14+2),n.strokeStyle=a.css(`accent`),n.fillStyle=a.css(`accent`),n.lineWidth=1.5,n.beginPath(),n.moveTo(l(t),12),n.lineTo(l(t),i-14),n.stroke(),n.textAlign=`left`,n.fillText(`observed ${t<0?`−`:``}${Math.abs(t).toFixed(1)}`,l(t)+4,2),n.textAlign=`right`,n.fillStyle=a.css(`ink3`),n.fillText(`${e.length.toLocaleString(`en`)} shuffles`,r-4,2)}}function ka(e,t,n){return(r,i,a,o)=>{let s=e.length>1?176:96,c=e=>s+(e-t)/(n-t)*(i-s-8),l=(a-14-4)/e.length;r.font=Da,r.strokeStyle=o.css(`ink3`),r.globalAlpha=.6,r.setLineDash([3,3]),r.beginPath(),r.moveTo(c(0)+.5,2),r.lineTo(c(0)+.5,a-14),r.stroke(),r.setLineDash([]),r.globalAlpha=1,r.fillStyle=o.css(`ink3`),r.textBaseline=`top`,r.textAlign=`center`;for(let e=Math.ceil(t/5)*5;e<=n;e+=5)r.fillText(e<0?`−${-e}`:String(e),c(e),a-14+2);e.forEach((e,t)=>{let n=4+t*l+l/2,a=e.hi<0||e.lo>0,s=o.css(a?`accent`:`ink2`);if(r.textBaseline=`middle`,r.textAlign=`left`,r.fillStyle=o.css(`ink2`),r.fillText(e.label,0,n),r.strokeStyle=s,r.lineWidth=2,r.beginPath(),r.moveTo(c(e.lo),n),r.lineTo(c(e.hi),n),r.moveTo(c(e.lo),n-4),r.lineTo(c(e.lo),n+4),r.moveTo(c(e.hi),n-4),r.lineTo(c(e.hi),n+4),r.stroke(),r.fillStyle=s,r.beginPath(),r.arc(c(e.diff),n,3.5,0,Math.PI*2),r.fill(),e.holm){r.fillStyle=o.css(`ink3`);let t=`Holm ${e.holm}`,a=c(e.hi)+8+r.measureText(t).width<=i;r.textAlign=a?`left`:`right`,r.fillText(t,a?c(e.hi)+6:c(e.lo)-6,n)}}),r.lineWidth=1}}var Aa={id:`measure`,title:`Prove it helped`,technical:`Measure against control`,status:`Built`,kind:`built`,summary:`A small share of sessions get no help at all, so the two groups can be compared to show whether Adage really saves turns and money.`,source:`crates/adage-eval · evals/live · evals/corpus`,usesRepo:!0,build:wa},ja=[{t:`P`},{t:`X`,m:`6KuNeV`},{t:`U`,m:`6KuNeV`,id:`X7do71`,tool:`Read`},{t:`R`,id:`X7do71`,err:!0},{t:`U`,m:`czdXtv`,id:`EDMWaV`,tool:`Bash`},{t:`R`,id:`EDMWaV`,err:!1},{t:`U`,m:`iwXKBj`,id:`kAxxMv`,tool:`Read`},{t:`R`,id:`kAxxMv`,err:!1},{t:`U`,m:`iwXKBj`,id:`66c8xh`,tool:`Bash`},{t:`R`,id:`66c8xh`,err:!1},{t:`U`,m:`7wJHcz`,id:`N6szRk`,tool:`Read`},{t:`R`,id:`N6szRk`,err:!1},{t:`U`,m:`ZVkzP5`,id:`ue2MHT`,tool:`Bash`},{t:`R`,id:`ue2MHT`,err:!1},{t:`U`,m:`AWAUs6`,id:`UJVezU`,tool:`Bash`},{t:`R`,id:`UJVezU`,err:!0},{t:`U`,m:`CiEQE4`,id:`j2EpG7`,tool:`Bash`},{t:`R`,id:`j2EpG7`,err:!1},{t:`U`,m:`KWVLt9`,id:`Yct3PZ`,tool:`Read`},{t:`R`,id:`Yct3PZ`,err:!1},{t:`U`,m:`aHXhJj`,id:`LnZoTc`,tool:`Bash`},{t:`R`,id:`LnZoTc`,err:!1},{t:`U`,m:`9pcKBA`,id:`yzWUep`,tool:`Read`},{t:`R`,id:`yzWUep`,err:!1},{t:`U`,m:`VErvqR`,id:`FWEUcW`,tool:`Read`},{t:`R`,id:`FWEUcW`,err:!1},{t:`X`,m:`gBGbiY`},{t:`U`,m:`gBGbiY`,id:`YTRPpS`,tool:`Edit`},{t:`R`,id:`YTRPpS`,err:!1},{t:`X`,m:`J6MrX7`},{t:`U`,m:`J6MrX7`,id:`nYWtZq`,tool:`Bash`},{t:`R`,id:`nYWtZq`,err:!0},{t:`U`,m:`RG5Nfm`,id:`b7n5wm`,tool:`Bash`},{t:`R`,id:`b7n5wm`,err:!1},{t:`U`,m:`fZ2Cy9`,id:`H1FERp`,tool:`Bash`},{t:`R`,id:`H1FERp`,err:!1},{t:`U`,m:`JtXXHZ`,id:`WUE3d8`,tool:`Bash`},{t:`R`,id:`WUE3d8`,err:!1},{t:`X`,m:`ruJwfK`},{t:`U`,m:`ruJwfK`,id:`o4AvwH`,tool:`Bash`},{t:`R`,id:`o4AvwH`,err:!1},{t:`X`,m:`G999TY`}],Ma=`Pick up W-1041 and get it done.`,Na=[`observe`,`verify`,`regenerate`,`environment`,`author`,`publish`],Pa={observe:205,verify:140,regenerate:95,environment:40,author:262,publish:320},Fa={X7do71:[[`read {path}`,`observe`,!0]],EDMWaV:[[`list {path}`,`observe`,!1]],kAxxMv:[[`read {path}`,`observe`,!1]],"66c8xh":[[`list {path}`,`observe`,!1]],N6szRk:[[`read {path}`,`observe`,!1]],ue2MHT:[[`search:filename {pattern}`,`observe`,!1]],UJVezU:[[`list {path}`,`observe`,!0]],j2EpG7:[[`search:filename {pattern}`,`observe`,!1]],Yct3PZ:[[`read {path}`,`observe`,!1]],LnZoTc:[[`exec python3 scripts/wi-lookup {id}`,`observe`,!1]],yzWUep:[[`read {path}`,`observe`,!1]],FWEUcW:[[`read {path}`,`observe`,!1]],YTRPpS:[[`edit {path}`,`author`,!1]],nYWtZq:[[`exec python3 -m pytest {path} -v`,`verify`,!0],[`exec python3 -m unittest tests.test_billing -v`,`verify`,!0]],b7n5wm:[[`exec make test`,`verify`,!1]],H1FERp:[[`exec python3`,`environment`,!1]],WUE3d8:[[`exec make ci`,`verify`,!1]],o4AvwH:[[`exec git add {path}`,`author`,!1],[`exec cat`,`observe`,!1],[`exec git commit -m $(cat <<'EOF' …`,`publish`,!1]]},Ia={nYWtZq:`python3 -m pytest tests/test_billing.py -v 2>/dev/null || python3 -m unittest tests.test_billing -v`,o4AvwH:`git add acme/billing.py && git commit -m "$(cat <<'EOF' …"`},La=[[`P`,`add port Bergen`],[`E`,`edit registry/ports.csv`],[`G`,`make gen`],[`C`,`make check`]],Ra=64,za=4,Ba=4096,Va=64,Ha=3,Ua=e=>e.replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`);function Wa(e,t,n,r){return n&&(r||e+1===t)}var Ga={stream:{target:[0,2.4,0],yaw:-.06,pitch:.14,dist:16.5},turns:{target:[0,0,0],yaw:-.08,pitch:.2,dist:17},split:{target:[4.9,-.8,0],yaw:-.04,pitch:.1,dist:12.5},ladder:{target:[-.4,.5,0],yaw:.04,pitch:.1,dist:18.5},lanes:{target:[-.6,-1,.6],yaw:-.2,pitch:.8,dist:25}};function Ka(e){let t=new Map,n=[],r=new Map;ja.forEach((e,i)=>{if(e.t!==`U`)return;t.has(e.m)||t.set(e.m,t.size);let a=t.get(e.m),o=r.get(a)??0;r.set(a,o+1),n.push({id:e.id,rec:i,turn:a,k:o,err:!1,steps:[]})});let i=new Map;ja.forEach((e,t)=>{if(e.t===`R`){i.set(e.id,t);let r=n.find(t=>t.id===e.id);r&&(r.err=e.err)}});let a=0;for(let e of n){let t=Fa[e.id]??[],n=(Ia[e.id]??``).includes(`||`);t.forEach(([r,i,o],s)=>{if(o!==Wa(s,t.length,e.err,n))throw Error(`read: ${e.id} step ${s} breaks the failure rule`);e.steps.push({key:r,effect:i,failed:o,id:`s${a}`,n:a++})})}let o=n.flatMap(e=>e.steps.map(t=>({...t,call:e}))),s=t.size,c=n.filter(e=>e.k===1).map(e=>e.turn)[0],l=n.filter(e=>e.err),u=ja.filter(e=>e.t===`X`).length,d=n.find(e=>(Ia[e.id]??``).includes(`||`)),f=n.find(e=>e.id!==d.id&&Ia[e.id]),p=o.find(e=>e.key.includes(`wi-lookup`)),m=Na.map(e=>o.filter(t=>t.effect===e).length),h=e=>[-7+e*14/(ja.length-1),2.6,0],g=e=>-6.5+e*13/(s-1),_=e=>[g(e.turn),.1+e.k*.62,0],v=e=>[g(e.turn),-.75-e.k*.62,0],y=(e,t)=>[g(e.turn),.1+e.k*.62-(e.steps.length>1?.3+t*.85:0),0],b=e=>-2.6+Na.indexOf(e)*1.05,x=e=>{let t=e.call.steps,n=t.length,r=t.findIndex(t=>t.id===e.id);return[g(e.call.turn)+(n>1?(r-(n-1)/2)*.42:0)+e.call.k*.3,b(e.effect),0]},S=[-7.7,.1,0],C=[-6.6,3.8,0];ja.forEach((t,n)=>e.dot(`r${n}`,.15));for(let t of o)e.dot(t.id,.15);let w=[...Ct,La];w.forEach((t,n)=>t.forEach((t,r)=>e.dot(`n${n}.${r}`))),e.link(`join`,n.map(e=>[`r${e.rec}`,`r${i.get(e.id)}`]),`ink3`),e.link(`seq`,o.slice(1).map((e,t)=>[o[t].id,e.id]),`ink3`),e.link(`rows`,Na.map(e=>[[-7.3,b(e),0],[7,b(e),0]]),`ink3`);let T=[];w.forEach((e,t)=>e.forEach((e,n)=>n&&T.push([`n${t}.${n-1}`,`n${t}.${n}`]))),e.link(`lane`,T,`ink3`),e.link(`steer`,La.slice(1).map((e,t)=>[`n${Ct.length}.${t}`,`n${Ct.length}.${t+1}`]),`accent`);let E=n.find(e=>e.id===p.call.id);e.label(`j0`,`<small>LINE 1 · USER</small>"content": "${Ma}"`,`r0`,{cls:`chip`,dx:-14,dy:22}),e.label(`j1`,`<small>LINE ${E.rec+1} · ASSISTANT</small>"tool_use", "name": "Bash"`,`r${E.rec}`,{cls:`chip`,dy:-58,center:!0}),e.label(`j2`,`<small>LINE ${i.get(E.id)+1} · USER</small>"tool_result", "tool_use_id": "…${E.id}"`,`r${i.get(E.id)}`,{cls:`chip`,dy:20,center:!0}),e.label(`jN`,`${ja.length} lines`,`r${ja.length-1}`,{dy:16,center:!0}),e.label(`prompt`,`<small>PROMPT · STEP 0</small>${Ma}`,`r0`,{cls:`chip`,dx:-12,dy:22}),e.label(`tN`,`turn ${s}`,`r${n[n.length-1].rec}`,{dy:18,center:!0});let D=n.find(e=>e.turn===c&&e.k===1);e.label(`two`,`turn ${c+1}: two calls, one message.id`,`r${D.rec}`,{cls:`note`,dx:10,dy:-40});for(let t of l)e.label(`x${t.id}`,`✗ is_error`,`r${i.get(t.id)}`,{cls:`note`,dy:12,center:!0});e.label(`or`,`<small>ONE CALL · ||</small>${Ua(Ia[d.id]).replace(` || `,`<br>|| `)}`,d.steps[0].id,{cls:`chip`,dx:-130,dy:-76,center:!0}),e.label(`and`,`<small>ONE CALL · &&</small>${Ua(Ia[f.id]).replace(` &amp;&amp; `,`<br>&amp;&amp; `)}`,f.steps[0].id,{cls:`chip`,dx:70,dy:-76,center:!0});let O=e=>Ua(e.replace(/^exec /,``).replace(/ -m \$\(cat.*$/,` -m …`));d.steps.forEach(t=>{let n=`${O(t.key)} ✗`;e.label(`sf${t.id}`,n,t.id,{cls:`note`,dx:-16-n.length*3.3,dy:-7,center:!0})}),f.steps.forEach(t=>e.label(`sk${t.id}`,`${O(t.key)} <span class="how-dim">${t.effect}</span>`,t.id,{cls:`note`,dx:14,dy:-7})),Na.forEach(t=>e.label(`e${t}`,t,[-7.3,b(t),0],{dx:-8-t.length*3.4,dy:-7,center:!0})),e.label(`lk`,`<small>KEY · ${p.effect.toUpperCase()}</small>${p.key}`,p.id,{cls:`chip`,dy:-58,center:!0}),e.label(`pl`,Ma,C,{cls:`note`,dx:12,dy:-7}),w.forEach((t,n)=>e.label(`T${n}`,n<Ct.length?`T${n+1}`:`T+`,`n${n}.0`,{dx:-34,dy:-7})),e.label(`sig`,`<small>STEERED · NAMES make gen</small>&lt;adage-reflex strength="prime" kind="obligation"&gt;`,`n${Ct.length}.${La.length-1}`,{cls:`chip`,dx:16,dy:-24});let k=e=>e.t===`P`?`soft`:e.t===`U`?`accent`:e.t===`R`?`ink2`:`ink3`;function A(e){let t={},r=[],i={},a=Ga.stream;if(e<=2){if(ja.forEach((r,i)=>{let a=`r${i}`,o=h(i),s=r.t===`X`?.55:1,c=r.t===`X`?.7:r.t===`P`?1.5:1,l=r.t===`P`?.6:.18,u=k(r);if(e>=1){if(r.t===`X`)return;if(r.t===`P`&&(o=S),r.t===`U`&&(o=_(n.find(e=>e.id===r.id))),r.t===`R`){let t=n.find(e=>e.id===r.id);e===1?s=.35:(o=v(t),r.err?(u=`ink1`,c=1.5,l=.6):s=.7)}}t[a]={pos:o,color:u,alpha:s,scale:c,glow:l}}),e===2)for(let e of o)t[e.id]={pos:_(e.call),color:`accent`,alpha:0,glow:0};e===0&&r.push(`j0`,`j1`,`j2`,`jN`),e===1&&r.push(`prompt`,`tN`,`two`),e===2&&r.push(`prompt`,...l.map(e=>`x${e.id}`)),i.join=e===2?.7:0,a=e===0?Ga.stream:Ga.turns}else if(e<=4){for(let n of o){let r=n.call,i=r.steps.findIndex(e=>e.id===n.id),a=r.steps.length>1,o=e===3?y(r,i):x(n),s=e===3?n.failed?`ink3`:`accent`:{hue:Pa[n.effect]},c=e!==3||a;t[n.id]={pos:o,color:s,alpha:c?1:e===3?.16:.28,scale:e===3&&a?1.45:n.id===p.id&&e===4?1.5:1,glow:c?e===3?.6:.3:0}}t.r0={pos:e===3?S:C,color:`soft`,scale:1.5,glow:.5,alpha:e===3?.4:1},e===3&&r.push(`or`,`and`,...d.steps.map(e=>`sf${e.id}`),...f.steps.map(e=>`sk${e.id}`)),e===4&&r.push(...Na.map(e=>`e${e}`),`lk`,`pl`),i.seq=e===4?.35:0,i.rows=e===4?.14:0,a=e===3?Ga.split:Ga.ladder}else w.forEach((n,r)=>{let i=r===Ct.length;i&&e!==5||n.forEach(([n],a)=>{t[`n${r}.${a}`]={pos:[Et(a),0,Tt(r)],color:i?`accent`:{hue:St[n].hue},alpha:i?1:e===5?.45:.85,scale:i?1.3:1,glow:i?.8:.14}})}),r.push(...w.map((e,t)=>`T${t}`).filter((t,n)=>e===5||n<Ct.length)),e===5&&r.push(`sig`),i.lane=e===5?.22:.4,i.steer=e===5?.95:0,a=Ga.lanes;return{dots:t,links:i,labels:r,cam:a}}let j=[{title:`Transcript lines stream in`,plain:`Every time a coding agent works, it keeps a diary: what you asked, which files it opened, which commands it ran and what came back. Adage reads that diary, on your machine.`,key:!0,body:`This is a real Claude Code trace from the demo dataset: ${ja.length} JSON lines. Adage reads it line by line and skips sub-agent (sidechain) records. Before that, it recognises the format by content: a Codex rollout, else an OpenCode export, else Claude Code JSONL.`,chips:[{text:`Codex → OpenCode → Claude Code`},{text:`OpenCode: "info" in the first ${Va} bytes`},{text:`isSidechain skipped`}]},{title:`Your request, then the agent's turns`,plain:`First comes your request, here about ticket ${Ma.match(/[A-Z][A-Z0-9]{0,9}-\d{1,7}/)?.[0]??`a ticket`}. Then the agent's actions, grouped into ${s} turns. The agent's chatter in between is not an action, so it is set aside.`,body:`A user string that is not meta or synthetic is a prompt; this one names ${Ma.match(/[A-Z][A-Z0-9]{0,9}-\d{1,7}/)?.[0]??`a ticket`}. Tool calls that share one message.id form one turn: ${n.length} calls make ${s} turns here. The ${u} assistant text blocks are not steps.`,chips:[{text:`prompt ≤ ${Ra} KiB`},{text:`anchored to the step it arrived at`},{text:`${s} turns`}]},{title:`Each action meets its result`,plain:`Each action is matched with its result, so Adage knows what worked: ${l.length} of the ${n.length} actions in this session failed.`,body:`Each tool_result finds its call by tool_use_id, whatever line it sits on. is_error marks the call failed: ${l.length} of the ${n.length} calls failed here, including a read of a directory and a missing tree command.`,chips:[{text:`joined by tool_use_id`},{text:`${l.length} failed`}]},{title:`Two-in-one commands are split`,plain:`A command that does two things at once, like build && test, is split into its parts, and a failure is pinned on the part that failed.`,math:`read`,body:`A shell command is parsed, and a compound one becomes one step per sub-action: ${n.length} calls become ${o.length} steps. A failure is blamed on the last part only, unless the command used ||. Here the test command used ||, so both parts are marked failed.`,chips:[{text:`failure → last part`},{text:`|| → every part`},{text:`${n.length} calls → ${o.length} steps`}]},{title:`Each step gets a name and a risk level`,plain:`Specifics are swapped for placeholders, so looking up W-1041 and W-1042 count as the same step. Each step is also sorted by what it does, from just looking (safe to suggest) to publishing (never suggested).`,math:`read`,key:!0,body:`Each step gets a template key, with the specifics replaced (the ticket becomes {id}), and an effect, ranked from observe to publish. The lookup is ${p.key}, an observe step. Keys are what the learner counts.`,chips:Na.map((e,t)=>({text:`${e} ${m[t]}`})),figure:(e,t,n,r)=>{let i=Math.max(...m,1),a=(t-8)/Na.length;e.font=`10px 'Red Hat Mono', ui-monospace, monospace`,e.textBaseline=`top`,e.textAlign=`center`,Na.forEach((t,o)=>{let s=4+o*a,c=m[o]/i*(n-16-16);e.fillStyle=`#${r.hue(Pa[t]).getHexString()}`,e.fillRect(s+a*.2,n-16-c,a*.6,c),e.fillStyle=r.css(`ink3`),e.fillText(t===`regenerate`?`regen`:t===`environment`?`env`:t,s+a/2,n-16+3),e.fillStyle=r.css(`ink2`),e.textBaseline=`bottom`,e.fillText(String(m[o]),s+a/2,n-16-c-2),e.textBaseline=`top`}),e.strokeStyle=r.css(`ink3`),e.globalAlpha=.4,e.beginPath(),e.moveTo(4,n-16+.5),e.lineTo(t-4,n-16+.5),e.stroke(),e.globalAlpha=1}},{title:`Adage's own advice is set aside`,plain:`When Adage already gave advice in a session, the steps it advised are set aside, so a reflex never learns from its own advice.`,math:`read`,body:`Where Adage already directed the agent, the trace carries an <adage-reflex> tag from the hook; only hook output counts, never text the agent wrote. What that directive named (here, make gen) is exposed from the point it arrived: it is not evidence for any reflex that directs it, so a reflex never learns from its own advice. The rest of the trace still counts.`,chips:[{text:`exposed from the directive on`},{text:`only hook output steers`},{text:`illustrative steered trace`}]},{title:`Read once, kept on your machine`,plain:`Each session is read once and remembered, and nothing leaves your machine. These ${Ct.length} sessions go on to the next chapter.`,body:`Parsed traces are cached by path, size and modification time, and the cache is stamped with the build, so a new build starts it empty. Nothing is redacted here; that happens only when something leaves the machine. These ${Ct.length} traces are what the graph learner reads next.`,chips:[{text:`session format ${Ha}`},{text:`owner-only cache`},{text:`Codex: line ≤ ${za} MiB, ≤ ${Ba.toLocaleString(`en-US`)} calls`}]}];return{source:`1 recorded trace · ${Ct.length} sample traces`,legend:[{label:`prompt`,role:`soft`},{label:`tool call`,role:`accent`},{label:`tool result`,role:`ink2`},{label:`failed result`,role:`ink1`},{label:`assistant text`,role:`ink3`}],steps:j.map((e,t)=>({...e,state:A(t)}))}}var qa={id:`read`,title:`Read what the agent did`,technical:`Read traces`,status:`Built`,kind:`built`,summary:`Coding agents already keep a diary of every session. Adage reads those diaries on your machine and turns each into a simple list of actions.`,source:`crates/adage-learn/src/{lib,import,codex,opencode,cache}.rs`,usesRepo:!1,build:Ka},Ja=[[`Haiku`,.15],[`Sonnet`,.25],[`Opus`,.75],[`other`,.5]],Ya=`Haiku`,Xa=24,Za=1800,Qa=.7,$a=.1,eo=.1,to=[9,10],no=5,ro=.8,io=.5,ao=.3;function oo(e){let t=14695981039346656037n,n=(1n<<64n)-1n;for(let r of e)for(let e of[...new TextEncoder().encode(r),0])t^=BigInt(e),t=t*1099511628211n&n;return(t&16777215n).toString(16).padStart(6,`0`)}var so=e=>e.replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`),co=[{id:`c1`,kind:`verify`,sentence:"Run the tests with `npm test`.",command:`npm test`},{id:`c2`,kind:`regenerate_after`,sentence:"After editing `registry/*.csv`, run `make gen`.",command:`make gen`,glob:`registry/*.csv`},{id:`c3`,kind:`lookup`,sentence:"Look up a carrier with `scripts/carrier HX-7`.",command:`scripts/carrier HX-7`,example:`HX-7`},{id:`c4`,kind:`regenerate_after`,sentence:"After editing `proto/*.proto`, run `make proto`.",command:`make proto`,glob:`proto/*.proto`},{id:`c5`,kind:`environment`,sentence:"Install dependencies with `npm install`.",command:`npm install`,unsafe:`environment: above regenerate`}],lo=[`Makefile`,`package.json`,`registry/carriers.csv`,`registry/lanes.csv`,`registry/ports.csv`,`scripts/carrier`,`src/dispatch.ts`,`src/registry/load.ts`,`src/router.ts`],uo={verify:212,regenerate_after:300,lookup:130,environment:40};function fo(e,t){return RegExp(`^${e.replace(/[.+^${}()|[\]\\]/g,`\\$&`).replace(/\*/g,`[^/]*`)}$`).test(t)}function po(e){return e.unsafe?`unsafe`:e.kind===`environment`?`environment claims are never exercised`:e.glob&&!lo.some(t=>fo(e.glob,t))?`no file matches ${e.glob}`:null}function mo(){let e=co.filter(e=>!po(e)),t=Xa,n=e.length?Math.max(Math.ceil(t/4),1):t,r=t-n,i=Math.floor((r*3+5)/10),a=Array.from({length:r},(e,t)=>t<i),o=Dt(11);for(let e=a.length-1;e>0;e--){let t=Math.floor((o()+1)/2*(e+1))%(e+1);[a[e],a[t]]=[a[t],a[e]]}let s=[];for(let t=0;t<r;t++)s.push({claim:e[t%e.length],explicit:a[t]});for(let e=0;e<n;e++)s.push({claim:null,explicit:!1});return s}function ho(e){let t={},n=0;return e.map(e=>{let r=e.claim?t[e.claim.id]=(t[e.claim.id]??-1)+1:n++,i=lo.filter(e=>e.startsWith(`registry/`))[r%3];if(!e.claim)return r<3?{edits:[`src/router.ts`],runs:[[`npm test`,!1],[`make check`,!0]]}:{edits:r===3?[`src/dispatch.ts`]:[],runs:[[`git status`,!0]]};switch(e.claim.id){case`c1`:return{edits:[],runs:r===5?[[`npm test`,!1]]:[[`npm test`,!1],[`make check`,!0]]};case`c2`:return{edits:[i],runs:r===0?[[`make gen`,!0],[`npm test`,!1],[`make check`,!0]]:[[`make gen`,!0]]};default:return{edits:[],runs:r%2==0?[[`scripts/carrier HX-7`,!0]]:[[`grep HX-7 registry/carriers.csv`,!0]]}}})}var go=[`baseline`,`skill`,`reflex`],_o={c1:{baseline:[[!1,4,.11],[!1,3,.09],[!1,4,.12]],skill:[[!1,3,.09],[!1,3,.1],[!1,3,.09]],reflex:[[!0,2,.07],[!0,2,.06],[!0,2,.07]]},c2:{baseline:[[!0,3,.08],[!1,2,.06],[!1,2,.06]],skill:[[!0,3,.08],[!0,3,.09],[!0,3,.08]],reflex:[[!0,3,.08],[!0,3,.08],[!0,3,.09]]},c3:{baseline:[[!1,4,.1],[!1,3,.09],[!1,4,.1]],skill:[[!0,3,.08],[!0,3,.08],[!1,4,.1]],reflex:[[!1,4,.1],[!1,3,.09],[!1,4,.11]]}},vo=e=>e.reduce((e,t)=>e+t,0)/Math.max(1,e.length),yo={doc:{target:[-3.6,0,0],yaw:.05,pitch:.12,dist:17},grid:{target:[0,.4,0],yaw:-.1,pitch:.2,dist:22},pods:{target:[2.6,1.6,0],yaw:-.28,pitch:.3,dist:20},stage:{target:[.4,-1.8,0],yaw:.06,pitch:.24,dist:22},verdict:{target:[-1.6,0,0],yaw:-.06,pitch:.14,dist:21},held:{target:[-1.4,1.4,0],yaw:-.08,pitch:.16,dist:19}};function bo(e){let t=typeof window<`u`&&window.innerWidth<640,n=mo(),r=ho(n),i=n.filter(e=>!e.claim).length,a=n.length-i,o=a-n.filter(e=>e.explicit).length,s=Ja.find(([e])=>e===Ya)[1],c=s*n.length,l=co.filter(e=>!po(e)),u=(e,t)=>e.runs.filter(([e])=>e===t),d=r.filter(e=>u(e,`npm test`).length>0),f=d.filter(e=>u(e,`npm test`).every(([,e])=>!e)),p=d.length>0&&f.length*to[1]>=d.length*to[0],m=r.filter(e=>{let t=e.runs.findIndex(([e,t])=>e===`npm test`&&!t);return t>=0&&e.runs.some(([e,n],r)=>r>t&&e===`make check`&&n)}).length,h=m>=no&&p,g=`dead-end-${oo([`exec make check`])}`,_=co[1],v=r.filter(e=>e.edits.some(e=>fo(_.glob,e))),y=v.filter(e=>e.runs.some(([e,t])=>e===`make gen`&&t)).length,b=r.filter(e=>!v.includes(e)),x=b.filter(e=>e.runs.some(([e])=>e===`make gen`)).length,S=y/Math.max(1,v.length),C=x/Math.max(1,b.length),w=kt(y,v.length),T=y>=no&&S>=io&&S-C>=ao,E=w>=ro,D=`finish-line-${oo([_.glob,_.command])}`,O=r.filter((e,t)=>n[t].claim?.id===`c3`),k=O.filter(e=>e.runs.some(([e])=>e===`scripts/carrier HX-7`)).length,A=k>=no,j=co.map(e=>{if(e.unsafe)return{kind:`unsafe`,head:`unsafe`,detail:e.unsafe};if(e.id===`c1`&&p&&h)return{kind:`contradicted`,head:`contradicted`,detail:`failed ${f.length}/${d.length} · ${g} → make check`};if(e.id===`c2`&&T)return{kind:`compiled`,head:`compiled`,detail:`→ ${D}`};if(e.id===`c3`&&A)return{kind:`compiled`,head:`compiled`,detail:`→ a lookup reflex`};let t=po(e);return t?{kind:`never`,head:`never exercised`,detail:t}:e.id===`c3`?{kind:`not`,head:`not compiled`,detail:`followed ${k}/${O.length} · support < ${no}`}:{kind:`not`,head:`not compiled`,detail:`below the learning thresholds`}}),M=e=>j.filter(t=>t.kind===e).length,N=[`c1`,`c2`,`c3`].map(e=>{let t=_o[e],n=Object.fromEntries(go.map(e=>{let n=t[e];return[e,{rate:n.filter(([e])=>e).length/n.length,turns:vo(n.map(([,e])=>e)),cost:vo(n.map(([,,e])=>e)),n:n.length}]})),r=n.reflex,i=n.skill,a={follow:r.rate>=Qa,near:r.rate>=i.rate-$a,turns:r.turns<=i.turns*1.1+1e-9,cost:r.cost<=i.cost*1.1+1e-9};return{id:e,st:n,ok:a,accepted:a.follow&&a.near&&a.turns&&a.cost}}),P=N.reduce((e,t)=>e+t.st.skill.n,0),F=[3.6,1.8,0,-1.8,-3.6],I=e=>[-7,F[e],0],L=e=>[1.7+e%6*1.15,2.7-Math.floor(e/6)*1.45,0],ee=[4,5.2,0],te=[1,-4.8,0],ne=[4.3,-4.1,0],R=[4.3,-5.5,0],re=[-3.4,-4.8,0],z=[2.6,F[1],0],B=[2.6,F[0],0],ie=Dt(5),ae=n.map(()=>[te[0]+ie()*.55,te[1]+ie()*.55,ie()*.55]),oe=(e,t)=>-2.6+e*2.5+t*.6;co.forEach(t=>e.dot(t.id,.26)),n.forEach((t,n)=>{e.dot(`t${n}`,.15),e.dot(`tr${n}`,.08)}),e.dot(`repo`,.3),e.dot(`learn`,.34),e.dot(`fl`,.28),e.dot(`de`,.28),e.dot(`idx`,.22);for(let t of N)go.forEach((n,r)=>t.st[n]&&_o[t.id][n].forEach((n,i)=>e.dot(`v${t.id}${r}${i}`,.15)));let se=[];n.forEach((e,t)=>e.claim&&se.push([e.claim.id,`t${t}`])),e.link(`own`,se,`ink3`);let ce=(e,t,n,r)=>{let i=[e-n,t-r,0],a=[e+n,t-r,0],o=[e+n,t+r,0],s=[e-n,t+r,0];return[[i,a],[a,o],[o,s],[s,i]]};e.link(`pods`,n.flatMap((e,t)=>ce(L(t)[0],L(t)[1],.5,.5)),`ink3`),e.link(`clone`,n.map((e,t)=>[`repo`,[L(t)[0],L(t)[1]+.5,0]]),`ink3`),e.link(`flow`,n.map((e,t)=>[[L(t)[0],L(t)[1]-.5,0],`learn`]),`ink3`),e.link(`stagedBox`,ce(6.4,(ne[1]+R[1])/2,2.6,1.3),`accent`),e.link(`idxBox`,ce(re[0],re[1],1.3,.85),`ink3`),e.link(`stageOut`,[[`learn`,`fl`]],`accent`),e.link(`toFl`,[[`c2`,`fl`]],`accent`),e.link(`toDe`,[[`c1`,`de`]],`accent`),co.forEach((t,n)=>{let r=so(t.sentence).replace(/`([^`]+)`/g,`<b>$1</b>`);e.label(`s${n}`,r,t.id,{cls:`chip big`,dx:18,dy:-14});let i=t.kind===`regenerate_after`?`regenerate_after(${so(t.glob)})`:t.kind;e.label(`k${n}`,`<small>${t.id} · ${i}</small>${so(t.command)}${t.unsafe?` <span class="how-dim">· unsafe</span>`:``}`,t.id,{cls:`chip big`,dx:18,dy:-20}),e.label(`q${n}`,`${t.id} <span class="how-dim">${t.kind===`regenerate_after`?`regenerate`:t.kind}</span>`,t.id,{cls:`chip`,dx:16,dy:-10});let a=j[n];e.label(`h${n}`,`${t.id} <span class="how-dim">${a.head}</span>`,t.id,{cls:`chip`,dx:16,dy:-10}),e.label(`v${n}`,`<small>${t.id} · ${a.head}</small>${so(a.detail)}`,t.id,{cls:`chip big`,dx:18,dy:-20})}),e.label(`stale`,`your skill is stale: it says <b>npm test</b>, agents found <b>make check</b>`,`c1`,{cls:`note`,dx:18,dy:25}),e.label(`grid`,`${n.length} tasks · ${a} trigger · ${i} control`,[L(2)[0]+.65,3.9,0],{cls:`chip`,center:!0,dy:-10}),e.label(`ctl`,`controls`,`t${n.length-3}`,{cls:`note`,dy:16,center:!0}),e.label(`repo`,`<small>YOUR REPOSITORY</small>HEAD · working tree untouched`,`repo`,{cls:`chip big`,center:!0,dy:-62}),e.label(`noorigin`,`clones: git clone --local --no-hardlinks · origin removed`,[L(0)[0]-.5,L(18)[1]-.9,0],{cls:`note`,dy:4}),e.label(`learn`,`<small>LEARNER</small>the same graph learner`,`learn`,{cls:`chip big`,center:!0,dy:26}),e.label(`fl`,`<small>PRIME · FORMING</small>${so(D)}`,`fl`,{cls:`chip big`,dx:18,dy:-20}),e.label(`de`,`<small>INHIBIT · FORMING</small>${so(g)}`,`de`,{cls:`chip big`,dx:18,dy:-20}),e.label(`staged`,`staged/tracks · not activated`,[3.8,ne[1]+.7,0],{cls:`note`,dy:-18}),e.label(`idx`,`<small>INDEX.JSON</small>nothing installed`,`idx`,{cls:`chip big`,center:!0,dy:20}),go.forEach((t,n)=>e.label(`arm${n}`,t,[oe(n,1),F[0]+1.1,0],{cls:`chip`,center:!0,dy:-10})),N.forEach((t,n)=>e.label(`acc${n}`,t.accepted?`accepted`:`not accepted`,`v${t.id}22`,{cls:t.accepted?`note`:``,dx:20,dy:-7}));let le=e=>e.unsafe?`ink3`:{hue:uo[e.kind]};function ue(e){let r={},i=[],a={};if(co.forEach((t,n)=>{let i={pos:I(n),color:e===0?`ink2`:le(t),glow:.3};if(e>=2&&e<=5&&(i={...i,alpha:t.unsafe||po(t)?.35:.85,glow:.15}),e===6){let e=j[n].kind;i=e===`compiled`?{pos:I(n),color:`accent`,scale:1.35,glow:.9}:e===`contradicted`?{pos:I(n),color:`ink1`,scale:1.35,glow:.9}:e===`not`?{pos:I(n),color:`ink2`,glow:.2}:{pos:I(n),color:`ink3`,alpha:e===`unsafe`?.35:.6,glow:0}}e===7&&(i={pos:I(n),color:le(t),alpha:n<3?1:.2,glow:n<3?.3:0}),(e!==3&&e!==4||!po(t))&&(e===7&&n>=3||(r[t.id]=i))}),e<=2&&i.push(...co.map((n,r)=>t?`q${r}`:e===0?`s${r}`:`k${r}`)),e===6&&i.push(...co.map((e,n)=>t?`h${n}`:`v${n}`),...t?[]:[`stale`]),e===7&&i.push(`q0`,`q1`,`q2`),e>=2&&e<=5&&(n.forEach((t,n)=>{let i=t.claim,a=e===5;r[`t${n}`]={pos:L(n),color:i?{hue:uo[i.kind]}:`ink3`,scale:t.explicit?1.35:1,alpha:a?.25:i?1:.7,glow:a?0:e===3?.5:.25}}),e<5&&i.push(`grid`),e===2&&i.push(`ctl`)),e===2&&(a.own=.28),e>=3&&e<=4&&(a.pods=.5),e===5&&(a.pods=.15),e===3&&(r.repo={pos:ee,color:`ink1`,glow:.5},a.clone=.25,i.push(`repo`,`noorigin`)),e===3&&n.forEach((e,t)=>r[`tr${t}`]={pos:L(t),color:`ink2`,alpha:0}),(e===4||e===5)&&(n.forEach((t,n)=>{r[`tr${n}`]={pos:ae[n],color:t.claim?{hue:uo[t.claim.kind]}:`ink3`,alpha:e===5?.35:.9,glow:.2}}),r.learn={pos:te,color:`soft`,glow:e===4?.9:.5,scale:1},a.flow=e===4?.22:.05,i.push(`learn`)),e===5||e===6){let t=.5,n=e===6;T&&(r.fl={pos:n?z:ne,color:E?`fire`:`prime`,alpha:t,glow:.35}),h&&(r.de={pos:n?B:R,color:`inhibit`,alpha:t,glow:.35}),n||(a.stagedBox=.5,i.push(`fl`,`de`,`staged`)),e===5&&(r.idx={pos:re,color:`ink3`,alpha:.4,glow:0},a.idxBox=.4,a.stageOut=.5,i.push(`idx`)),e===6&&(T&&(a.toFl=.55),h&&(a.toDe=.55))}return e===7&&(N.forEach((e,t)=>go.forEach((n,i)=>_o[e.id][n].forEach(([n],a)=>{r[`v${e.id}${i}${a}`]={pos:[oe(i,a),F[t],0],color:n?`accent`:`ink3`,alpha:n?1:.55,scale:n?1.3:1,glow:n?.6:0}}))),i.push(`arm0`,`arm1`,`arm2`,...N.map((e,t)=>`acc${t}`))),{dots:r,links:a,labels:i,cam:e===0||e===1?yo.doc:e===2?yo.grid:e===3||e===4?yo.pods:e===5?yo.stage:e===6?yo.verdict:yo.held}}let de=e=>`${Math.round(e*100)}%`,fe=e=>`$${e.toFixed(2)}`,pe=[{title:`A guide is a set of claims`,plain:`A skill is a written guide to how work is done in a repository. Adage turns its instructions into reflexes for free, and treats each one as a claim to test, not a fact.`,math:`train`,key:!0,body:`A skill file says what an agent should do here. adage train <SKILL.md> compiles its procedure into one pack of reflexes, for free: no model and no agent session. Every compiled command is replayed on a clean checkout of HEAD in adage-exec's sandbox (network off, your working tree untouched); one that fails there is dropped as stale, and nothing is installed until adage train accept. Sessions are optional evidence, and the rest of this chapter follows them: this sample SKILL.md for the registry service makes ${co.length} instructions, and each one is a hypothesis to test, not a fact.`,chips:[{text:`compile + sandbox replay: free`},{text:`sessions: adage train plan, then --plan … --execute`},{text:`SKILL.md · CONTRIBUTING.md · Makefile · package.json · CI · runbook`},{text:`no model reads it: rules only`}]},{title:`Each instruction is sorted`,plain:`Each instruction is sorted by what it does. One that installs packages is too risky to run on its own, so it is marked unsafe.`,body:`Commands come from code spans in imperative sentences, and each is classed by effect. ${co.filter(e=>e.unsafe).length} claim installs packages, which is above regenerate, so it is marked unsafe and never run.`,chips:[{text:`verify · regenerate_after(glob) · lookup · avoid(x→y) · environment`},{text:`unsafe: above regenerate, or not one plain command`}]},{title:`Practice tasks test the claims`,plain:`To test the claims, Adage writes ${n.length} practice tasks, including control tasks that touch none of them. Most never mention the guide, so they test what an agent does unprompted.`,body:`The plan makes ${n.length} tasks for ${l.length} claims: ${a} give a claim its chance, and ${i} are controls that touch nothing a claim covers. ${o} of the ${a} never name the skill or the command. No file matches proto/*.proto, so that claim gets no tasks.`,chips:[{text:`${de(o/a)} implicit (about 70%)`},{text:`${i}/${n.length} controls ≥ 25%`,ok:i*4>=n.length},{text:`3 templates × 2 verbosities`},{text:`estimate ${n.length} × ${fe(s)} = ${fe(c)}`}],figure:(e,t,r,i)=>{let a=Ja.map(([e,t])=>[e,t*n.length]),o=Math.max(...a.map(([,e])=>e)),s=(r-4)/a.length;e.font=`10px 'Red Hat Mono', ui-monospace, monospace`,e.textBaseline=`middle`,a.forEach(([n,r],a)=>{let c=2+a*s+s/2;e.fillStyle=i.css(`ink3`),e.textAlign=`left`,e.fillText(n,0,c);let l=(t-56-60)*r/o;e.fillStyle=i.css(`cost`),e.globalAlpha=n===Ya?1:.45,e.fillRect(56,c-s*.3,l,s*.6),e.globalAlpha=1,e.fillStyle=n===Ya?i.css(`ink1`):i.css(`ink3`),e.fillText(`${fe(r)}${n===Ya?` · default`:``}`,56+l+6,c)})}},{title:`Practice runs in a sealed copy`,plain:`Your own agent works each task in a throwaway copy of the repository that cannot push anywhere. Your working files are never touched.`,body:`With --execute, your own agent runs each task headlessly. Every session gets a fresh local clone with its origin removed, its own home and config directory, and a short tool list. Nothing can be pushed, and your working tree is never touched.`,chips:[{text:`tools: Bash Read Edit Write Glob Grep`},{text:`--permission-mode dontAsk · sandbox on`},{text:`environment allowlist`},{text:`timeout ${Za.toLocaleString(`en`)} s · budget cap`}]},{title:`Same learning as real work`,plain:`The practice sessions then go through the same learning as your real ones.`,body:`Exploration runs with the skill in the system prompt and Adage switched off, so no reflex steers it. The ${r.length} traces then go through the same learner as your own traces.`,chips:[{text:`ADAGE_DISABLE=1`},{text:`synthetic:skill:<sha256>@<run>`},{text:`min support ${no}`}]},{title:`Held for your review`,plain:`What it learns is set aside for review and kept at suggestion strength. Nothing reaches your agent until you accept it.`,math:`train`,body:`The learner found ${[T,h].filter(Boolean).length} reflexes. They are written to staged/tracks, capped at prime and forming, and never reach the index your hooks read. The finish line ${E?`would fire, but is capped`:`primes`}: ${y} of ${v.length} sessions regenerated after the edit, a lower bound of ${K(w)}.`,chips:[{text:`never fire · never firm`},{text:`a dead end stays inhibit`},{text:`finish line ${y}/${v.length} · LB ${K(w)}`},{text:`dead end ${m} traces`}]},{title:`Each claim gets a verdict`,plain:`Each claim gets a verdict. The guide says to run npm test, but it failed every time and agents found make check instead, so the claim is marked out of date.`,math:`train`,key:!0,body:`The skill says npm test. It failed in ${f.length} of the ${d.length} sessions that ran it, and the agents found make check instead, so a dead end was learned: the claim is contradicted. The regenerate claim compiled. The lookup was followed only ${k} times, too few to learn.`,chips:[{text:`stale: failed ≥ ${to[0]}/${to[1]} + a dead end`,ok:p&&h},{text:`${M(`compiled`)} compiled · ${M(`contradicted`)} contradicted · ${M(`never`)} never exercised · ${M(`not`)} not compiled · ${M(`unsafe`)} unsafe`},{text:`unsafe > contradicted > compiled > never exercised > not compiled`}]},{title:`A fair test on fresh tasks`,plain:`Fresh tasks compare three set-ups: no guide, the guide in the prompt, and the learned reflexes. A reflex is accepted when it works about as well as the guide, at no extra cost.`,math:`train`,body:`${P} new tasks run in three arms: no skill, the skill in the prompt, and the staged reflexes through Adage's hooks with no control arm. A reflex is accepted when its arm follows it in at least 70% of sessions, within 10 points of the skill arm, and costs no more than 10% extra in turns or dollars.`,chips:[...N.map(e=>({text:`${e.id} reflex ${de(e.st.reflex.rate)} · skill ${de(e.st.skill.rate)}`,ok:e.accepted})),{text:`follow ≥ ${K(Qa)} · within ${K($a)} · ≤ +${de(eo)}`},{text:`reflex arm: ADAGE_CONTROL=0`}],figure:(e,t,n,r)=>{let i=e=>n-14-e*(n-14-18),a=(t-8)/N.length,o=Math.min(22,a/5),s=[`ink3`,`ink2`,`accent`];e.font=`10px 'Red Hat Mono', ui-monospace, monospace`,N.forEach((t,c)=>{let l=4+c*a+a/2-(o*3+8)/2;go.forEach((n,a)=>{let c=t.st[n].rate;e.fillStyle=r.css(s[a]),e.fillRect(l+a*(o+4),i(c),o,Math.max(1,i(0)-i(c)))}),e.fillStyle=r.css(`ink3`),e.textAlign=`center`,e.textBaseline=`top`,e.fillText(t.id,l+(o*3+8)/2,n-14+3)}),e.setLineDash([3,3]),e.strokeStyle=r.css(`soft`),e.beginPath(),e.moveTo(4,i(Qa)),e.lineTo(t-4,i(Qa)),e.stroke(),e.setLineDash([]),e.fillStyle=r.css(`soft`),e.textAlign=`right`,e.textBaseline=`bottom`,e.fillText(`follow ${K(Qa)}`,t-4,i(Qa)-2),e.textAlign=`left`,e.textBaseline=`top`;let c=4;go.forEach((t,n)=>{e.fillStyle=r.css(s[n]),e.fillRect(c,2,8,8),e.fillStyle=r.css(`ink2`),e.fillText(t,c+12,1),c+=12+e.measureText(t).width+12})}}];return{source:`a sample SKILL.md · ${n.length} sample sessions`,legend:[{label:`verify`,role:`hue`,hue:uo.verify},{label:`regenerate_after`,role:`hue`,hue:uo.regenerate_after},{label:`lookup`,role:`hue`,hue:uo.lookup},{label:`unsafe / control`,role:`ink3`},{label:`compiled · followed`,role:`accent`}],steps:pe.map((e,t)=>({...e,state:ue(t)}))}}var xo={id:`train`,title:`Learn from a written guide`,technical:`Train on a skill`,status:`Built · sessions optional`,kind:`built`,summary:`A written guide to how work is done here can become reflexes too. Each of its instructions is tested, not trusted.`,source:`crates/adage-train · docs/training.md`,usesRepo:!1,build:bo},So=16,Co=19,wo=8,To=`instinct:core@0.1.0`,Eo=3,Do=5,Oo=.5,ko=.1,Ao=.8,jo=e=>e.replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`);function Mo(e){let t=new Uint32Array([1116352408,1899447441,3049323471,3921009573,961987163,1508970993,2453635748,2870763221,3624381080,310598401,607225278,1426881987,1925078388,2162078206,2614888103,3248222580,3835390401,4022224774,264347078,604807628,770255983,1249150122,1555081692,1996064986,2554220882,2821834349,2952996808,3210313671,3336571891,3584528711,113926993,338241895,666307205,773529912,1294757372,1396182291,1695183700,1986661051,2177026350,2456956037,2730485921,2820302411,3259730800,3345764771,3516065817,3600352804,4094571909,275423344,430227734,506948616,659060556,883997877,958139571,1322822218,1537002063,1747873779,1955562222,2024104815,2227730452,2361852424,2428436474,2756734187,3204031479,3329325298]),n=new TextEncoder().encode(e),r=n.length,i=new Uint8Array(r+9+63>>6<<6);i.set(n),i[r]=128;let a=r*8,o=new DataView(i.buffer);o.setUint32(i.length-8,Math.floor(a/2**32)),o.setUint32(i.length-4,a>>>0);let s=new Uint32Array([1779033703,3144134277,1013904242,2773480762,1359893119,2600822924,528734635,1541459225]),c=new Uint32Array(64),l=(e,t)=>e>>>t|e<<32-t;for(let e=0;e<i.length;e+=64){for(let t=0;t<16;t++)c[t]=o.getUint32(e+t*4);for(let e=16;e<64;e++){let t=c[e-15],n=c[e-2],r=l(t,7)^l(t,18)^t>>>3,i=l(n,17)^l(n,19)^n>>>10;c[e]=c[e-16]+r+c[e-7]+i>>>0}let[n,r,i,a,u,d,f,p]=[s[0],s[1],s[2],s[3],s[4],s[5],s[6],s[7]];for(let e=0;e<64;e++){let o=l(u,6)^l(u,11)^l(u,25),s=u&d^~u&f,m=p+o+s+t[e]+c[e]>>>0,h=(l(n,2)^l(n,13)^l(n,22))+(n&r^n&i^r&i)>>>0;p=f,f=d,d=u,u=a+m>>>0,a=i,i=r,r=n,n=m+h>>>0}s[0]=s[0]+n>>>0,s[1]=s[1]+r>>>0,s[2]=s[2]+i>>>0,s[3]=s[3]+a>>>0,s[4]=s[4]+u>>>0,s[5]=s[5]+d>>>0,s[6]=s[6]+f>>>0,s[7]=s[7]+p>>>0}return[...s].map(e=>e.toString(16).padStart(8,`0`)).join(``)}var No=`registry-svc`,Po=`finish-line-${oo([`registry/*.csv`,`make gen`])}`,Fo=`dead-end-${oo([`exec make check`])}`,Io=[{key:`A1`,id:Po,source:`first-hand`,track:`${No}/learned`,version:`1.0.0`,trigger:{kind:`after_edit`,on:`registry/*.csv`},step:{kind:`run`,command:`make gen`},strength:`fire`,state:`firm`,support:26,opportunities:27},{key:`A2`,id:`finish-line-${oo([`registry/**`,`make registry`])}`,source:`first-hand`,track:`${No}/learned`,version:`1.0.0`,trigger:{kind:`after_edit`,on:`registry/**`},step:{kind:`run`,command:`make registry`},strength:`fire`,state:`firm`,support:20,opportunities:20},{key:`A3`,id:Fo,source:`first-hand`,track:`${No}/learned`,version:`1.0.0`,trigger:{kind:`after_failure`,on:`npm test`},step:{kind:`avoid`,command:`npm test`,instead:`make check`},strength:`inhibit`,state:`firm`,support:9,opportunities:9},{key:`A4`,id:`lookup-carrier`,source:`first-hand`,track:`${No}/learned`,version:`1.0.0`,trigger:{kind:`prompt`,on:`a carrier id`},step:{kind:`run`,command:`scripts/carrier {id}`},strength:`prime`,state:`forming`,support:7,opportunities:11},{key:`B1`,id:Fo,source:`imported`,track:`ops-team/registry`,version:`0.3.0`,trigger:{kind:`after_failure`,on:`npm test`},step:{kind:`avoid`,command:`npm test`,instead:`make check`},strength:`inhibit`,state:`forming`,support:14,opportunities:15},{key:`B2`,id:`finish-line-${oo([`src/*.ts`,`npm test`])}`,source:`imported`,track:`ops-team/registry`,version:`0.3.0`,trigger:{kind:`after_edit`,on:`src/*.ts`},step:{kind:`run`,command:`npm test`},strength:`prime`,state:`forming`,support:12,opportunities:16},{key:`B3`,id:`read-linked-${oo([`registry/*.csv`])}`,source:`imported`,track:`ops-team/registry`,version:`0.3.0`,trigger:{kind:`after_edit`,on:`registry/*.csv`},step:{kind:`read`,command:`src/registry/schema.ts`},strength:`prime`,state:`forming`,support:10,opportunities:14},{key:`I1`,id:Po,source:`instinct`,track:`${No}/instincts`,version:`0.1.0`,trigger:{kind:`after_edit`,on:`registry/*.csv`},step:{kind:`run`,command:`make gen`},strength:`prime`,state:`forming`,support:0,opportunities:0},{key:`I2`,id:`instinct-u4-${oo([`gen/**`])}`,source:`instinct`,track:`${No}/instincts`,version:`0.1.0`,trigger:{kind:`after_edit`,on:`gen/**`},step:{kind:`advise`,command:`don't hand-edit generated files`},strength:`prime`,state:`forming`,support:0,opportunities:0}],Lo={"first-hand":0,imported:1,instinct:2};function Ro(e,t){let n=e=>RegExp(`^${e.replace(/[.+^${}()|[\]\\]/g,`\\$&`).replace(/\*\*/g,`\0`).replace(/\*/g,`[^/]*`).replace(/\u0000/g,`.*`)}$`);return e===t||n(e).test(t)||n(t).test(e)}var zo=(e,t)=>e.trigger.kind===t.trigger.kind&&(e.trigger.kind===`after_edit`?Ro(e.trigger.on,t.trigger.on):e.trigger.on===t.trigger.on);function Bo(e=Io){let t=[...e].sort((e,t)=>e.id<t.id?-1:e.id>t.id?1:Lo[e.source]-Lo[t.source]),n=[],r=[];for(let e of t){let t=n.find(t=>t.id===e.id);t?r.push({lost:e,to:t}):n.push(e)}n.sort((e,t)=>e.track+`\0`+e.id<t.track+`\0`+t.id?-1:1);let i=[];for(let e of n)for(let t of n)e!==t&&e.step.kind===`avoid`&&t.step.kind===`run`&&t.step.command===e.step.command&&i.push({by:e,route:t});let a=n.map(e=>({...e})),o=a.filter(e=>e.strength===`fire`&&e.step.kind===`run`).sort((e,t)=>(e.source===`first-hand`?0:1)-(t.source===`first-hand`?0:1)||t.support-e.support||(e.id<t.id?-1:1)),s=[],c=[];for(let e of o){let t=s.find(t=>zo(t,e)&&t.step.command!==e.step.command);t?(c.push({winner:t,loser:{...e}}),e.strength=`prime`):s.push(e)}let l=JSON.stringify(a.map(e=>({repo:No,track:e.track,version:e.version,route:{id:e.id,trigger:e.trigger,step:e.step,strength:e.strength,state:e.state,support:e.support,opportunities:e.opportunities}}))),u=Mo(l);return{out:a,dropped:r,locked:i,demoted:c,body:l,hash:u,generation:u.slice(0,So)}}var Vo={tracks:{target:[0,0,0],yaw:-.08,pitch:.14,dist:22},merge:{target:[0,.2,0],yaw:.1,pitch:.16,dist:19},seal:{target:[0,0,0],yaw:-.18,pitch:.3,dist:19}},Ho=(e,t,n,r)=>{let i=[e-n,t-r,0],a=[e+n,t-r,0],o=[e+n,t+r,0],s=[e-n,t+r,0];return[[i,a],[a,o],[o,s],[s,i]]},Uo=(e,t,n=3.4)=>{let r=-Math.PI/2+e/Math.max(1,t)*Math.PI*2;return[Math.cos(r)*n,-Math.sin(r)*n,0]},Wo=e=>e.step.kind===`avoid`?`avoid ${e.step.command} → ${e.step.instead}`:e.step.kind===`read`?`read ${e.step.command}`:e.step.kind===`advise`?`advise`:e.step.command;function Go(e){let t=typeof window<`u`&&window.innerWidth<640,n=Bo(),r=new Map(Io.map(e=>[e.key,e])),i=[`first-hand`,`imported`,`instinct`],a={"first-hand":-6,imported:0,instinct:6},o=e=>Io.filter(t=>t.source===e),s=e=>{let t=o(e.source).indexOf(e);return[a[e.source]-1.9,1.8-t*1.25,0]},c=e=>[-3.4,3.6-n.out.findIndex(t=>t.key===e.key)*1.2,0],l=e=>e,u=new Map(n.out.map(e=>[e.key,e])),d=n.locked[0],f=n.demoted[0];for(let t of Io)e.dot(t.key,.22);e.dot(`seal`,.4),i.forEach(t=>e.link(`folder-${t}`,Ho(a[t],-.1,2.6,3.1),`ink3`)),e.link(`ringBox`,Ho(0,0,4.4,4.4),`accent`),e.link(`toSeal`,n.out.map(e=>[e.key,`seal`]),`accent`),d&&e.link(`lock`,[[d.by.key,d.route.key]],`inhibit`),f&&e.link(`pair`,[[f.winner.key,f.loser.key]],`ink2`);let p=n.dropped.map(e=>[e.lost.key,e.to.key]);e.link(`dup`,p,`ink2`);let m={"first-hand":`<small>FIRST-HAND · LEARNED HERE</small>tracks/${No}/…`,imported:`<small>IMPORTED PACK · FORMING</small>@imported/ops-team/registry`,instinct:`<small>INSTINCTS</small>${To}`};i.forEach(n=>e.label(`h-${n}`,t?n:m[n],[a[n],3,0],{cls:`chip big`,center:!0,dy:-52}));for(let n of Io){let r=n.trigger.kind===`after_edit`?`edit ${n.trigger.on}`:n.trigger.kind===`after_failure`?`${n.trigger.on} fails`:n.trigger.on,i=n.step.kind===`avoid`?`avoid ${n.step.command}`:n.step.kind===`read`?`read ${n.step.command.split(`/`).pop()}`:Wo(n);e.label(`l-${n.key}`,`${jo(i)}<br><span class="how-dim">${jo(r)}</span>`,n.key,{dx:14,dy:-13}),e.label(`m-${n.key}`,t?jo(n.id):`${jo(n.id)} <span class="how-dim">· ${n.source} · ${jo(Wo(n))}</span>`,n.key,{dx:16,dy:-15})}let h=r.get(`A1`);e.label(`ver`,`<small>${jo(h.track)} · track.toml + routes/&lt;id&gt;.yaml</small>0.1.0 created → 0.1.1 evidence → 0.2.0 route added → 1.0.0 route changed`,[a[`first-hand`],-3.2,0],{cls:`chip big`,dx:-120,dy:16}),e.label(`pack`,`pack.toml<br>routes/*.yaml<br>scripts/sha256-&lt;hex&gt;<br>evidence.json<br>CLOSURE<br>pack.sig <span class="how-dim">· sshsig</span>`,[a.imported,-3.2,0],{cls:`chip`,center:!0,dy:14}),e.label(`inst`,`${wo} of ${Co} enabled · prime at most`,[a.instinct,-3.2,0],{cls:`chip`,center:!0,dy:14});for(let t of n.dropped)e.label(`drop-${t.lost.key}`,`${t.lost.source} copy dropped: ${t.to.source} wins`,t.to.key,{cls:`note`,dx:16,dy:3});d&&e.label(`lockNote`,`locked: never beside or after the inhibit`,d.route.key,{cls:`note`,dx:16,dy:10}),f&&e.label(`demNote`,`fewer traces (${f.loser.support} vs ${f.winner.support}): compiled as prime`,f.loser.key,{cls:`note`,dx:16,dy:10}),e.label(`gen`,`<small>INDEX.JSON · GENERATION</small>${n.generation}`,[0,-4.4,0],{cls:`chip big`,center:!0,dy:12});function g(e){let r={},a=[],o={};if(e<=3){let n=e===1?`first-hand`:e===2?`imported`:e===3?`instinct`:null;for(let i of Io){let o=!n||i.source===n;r[i.key]={pos:s(i),color:l(i.strength),alpha:o?i.state===`forming`?.8:1:.2,scale:e===1&&i.key===`A1`?1.35:1,glow:o?.5:0},o&&!t&&a.push(`l-${i.key}`)}i.forEach(e=>{o[`folder-${e}`]=!n||n===e?.45:.12,(!n||n===e)&&a.push(`h-${e}`)}),e===1&&!t&&a.push(`ver`),e===2&&a.push(`pack`),e===3&&a.push(`inst`)}else if(e<=6){for(let t of Io){let i=u.get(t.key),o=n.dropped.find(e=>e.lost.key===t.key);if(o){if(e===4){let e=c(o.to);r[t.key]={pos:[e[0]-1.1,e[1],e[2]],color:l(t.strength),alpha:.3,scale:.8,glow:0}}continue}let s=c(t),p=l(i.strength),m=1,h=1,g=.4;e===6&&f&&t.key!==f.winner.key&&t.key!==f.loser.key&&(m=.2),e===5&&d&&t.key!==d.by.key&&t.key!==d.route.key&&(m=.2),e===5&&d&&t.key===d.route.key&&(s=[s[0]+2.2,s[1],s[2]],m=.6,h=1.2),e===5&&d&&t.key===d.by.key&&(h=1.35,g=.9),e===6&&f&&(t.key===f.winner.key||t.key===f.loser.key)&&(h=1.3,g=.8,t.key===f.loser.key&&(s=[s[0]+2.2,s[1],s[2]])),e<6&&f&&t.key===f.loser.key&&(p=l(f.loser.strength)),r[t.key]={pos:s,color:p,alpha:m,scale:h,glow:g},(e===4||e===5&&d&&(t.key===d.by.key||t.key===d.route.key)||e===6&&f&&(t.key===f.winner.key||t.key===f.loser.key))&&a.push(`m-${t.key}`)}e===4&&(o.dup=.5,t||a.push(...n.dropped.map(e=>`drop-${e.lost.key}`))),e===5&&d&&(o.lock=.95,t||a.push(`lockNote`)),e===6&&f&&(o.pair=.5,t||a.push(`demNote`))}else n.out.forEach((e,t)=>r[e.key]={pos:Uo(t,n.out.length),color:l(e.strength),glow:.5}),r.seal={pos:[0,.2,0],color:`accent`,scale:1,glow:1},o.toSeal=.35,o.ringBox=.5,a.push(`gen`);return{dots:r,labels:a,links:o,cam:e<=3?Vo.tracks:e<=6?Vo.merge:Vo.seal}}let _=[{title:`One folder per repository`,plain:`Everything Adage learns in a repository is kept in one folder, with a note on why each reflex exists. Only you can read it.`,math:`seal`,body:`Everything Adage conditions in a repository goes into one track directory, <repo>/learned: a track.toml, one routes/<id>.yaml per reflex, and a .why.json beside them that says why each exists (read by people, never sent to the agent). Instincts get their own track. Tracks and the index are readable by their owner only. This sample repository has ${Io.filter(e=>e.source===`first-hand`).length} reflexes learned here, ${Io.filter(e=>e.source===`imported`).length} from an imported pack, and ${Io.filter(e=>e.source===`instinct`).length} instincts.`,chips:[{text:`tracks/<repo>/learned/track.toml`},{text:`routes/<id>.yaml · .why.json`},{text:`mode 0600`},{text:`${Io.length} sample reflexes`}]},{title:`Versions say what changed`,plain:`Each folder has a version number that shows whether only the evidence moved, a reflex was added, or one was changed or removed.`,math:`seal`,body:`A new track starts at 0.1.0. When only the evidence moves, the patch number goes up. An added reflex bumps the minor number; a changed or removed reflex bumps the major number, so anything that reads the track can tell.`,chips:[{text:`new: 0.1.0`},{text:`evidence only: patch`},{text:`added: minor`},{text:`changed or removed: major`}]},{title:`Teammates' reflexes start humble`,plain:`Teammates can share what they learned as a signed pack. Their reflexes only suggest until your own sessions confirm them.`,math:`seal`,body:`A pack is a signed, self-contained track from a teammate: its reflexes, any scripts named by their own hash, its evidence and a closure listing. Imported reflexes start forming and never fire until your own traces confirm them.`,chips:[{text:`adage-pack/1`},{text:`sshsig · namespace adage-pack`},{text:`imports never fire`},{text:`material change: lower bound moves ≥ ${K(ko)}`}]},{title:`Instincts ship with Adage`,plain:`Instincts work from day one, set up from files your repository already has, like a Makefile. They only ever suggest, and one that keeps being wrong switches itself off.`,math:`seal`,key:!0,body:`Instincts are bound on day one from files the repository declares, like its Makefile, package.json, CI and lockfiles. They are delivered as prime at most, only react to events, and never block the agent from stopping. One, U11, points a Python test run at the project's verified .venv before it runs. An instinct that keeps misfiring extinguishes itself.`,chips:[{text:`${wo} of ${Co} enabled`},{text:To},{text:`extinguish: ${Eo} misfires`},{text:`or ≥ ${Do} judgements, ignored LB ≥ ${K(Oo)}`}]},{title:`Duplicates are merged`,plain:`Everything is merged into one list. When two sources learned the same thing, your own evidence wins over a teammate's, and both win over an instinct.`,math:`seal`,body:`All installed tracks compile into one list. The same behaviour gets the same id wherever it was found, so ids collide: ${n.dropped.length} copies are dropped. Your own evidence beats a teammate's pack, and both beat an instinct. ${n.out.length} reflexes remain.`,chips:[{text:`key: (repo, id)`},{text:`first-hand > imported > instinct`},...n.dropped.map(e=>({text:`${e.lost.key} → ${e.to.key}`}))]},{title:`Warnings beat recommendations`,plain:`When a warning and a recommendation disagree, the warning wins: if npm test fails here, nothing will recommend it.`,math:`seal`,body:d?`The dead end says npm test fails here; the imported reflex says to run it. Inhibit wins, whatever the source. Because the dead end speaks after a failure, not at the first prompt, the other reflex stays in the index but is locked: it is never delivered beside or after the warning.`:`No reflex here runs a command a dead end avoids.`,chips:[{text:`suppressed if the inhibit speaks at session start`},{text:`otherwise locked at runtime`}]},{title:`One strong voice at a time`,plain:`Only one reflex may insist at any moment. When two would, the one learned here with more sessions behind it keeps the strong voice, and the other becomes a suggestion.`,math:`seal`,body:f?`Two first-hand reflexes fire after an edit to overlapping paths, with different commands. One keeps fire: learned beats imported, then the one with more supporting traces (${f.winner.support} against ${f.loser.support}). The other is compiled as prime.`:`No two fires share a decision point here.`,chips:f?[{text:`${f.winner.support}/${f.winner.opportunities} · LB ${K(kt(f.winner.support,f.winner.opportunities))}`,ok:kt(f.winner.support,f.winner.opportunities)>=Ao},{text:`${f.loser.support}/${f.loser.opportunities} · LB ${K(kt(f.loser.support,f.loser.opportunities))} → prime`},{text:`instincts last`}]:[{text:`instincts last`}]},{title:`Sealed into one file`,plain:`The final list is sealed into one file with a fingerprint. Any change gives a new fingerprint, and this file is all Adage reads while the agent works.`,math:`seal`,key:!0,body:`The ${n.out.length} survivors are serialised in order and hashed. The first ${So} hex digits of the SHA-256 are the generation, ${n.generation}. Any change to any reflex gives a new generation, and the hook reads only this one file.`,chips:[{text:`generation = sha256[..${So}]`},{text:`trigger words derived, not hashed`},{text:`written atomically`}]}];return{source:`${Io.length} sample reflexes`,legend:[{label:`fire`,role:`fire`},{label:`prime`,role:`prime`},{label:`inhibit`,role:`inhibit`}],steps:_.map((e,t)=>({...e,state:g(t)}))}}var Ko=e=>e.instinct?`instinct`:e.imported?`imported`:`first-hand`;function qo(e,t,n){let r=new Map;for(let e of t)r.set(e.track,[...r.get(e.track)??[],e]);let i=[...r.keys()].sort((e,t)=>Lo[Ko(r.get(e)[0])]-Lo[Ko(r.get(t)[0])]||(e<t?-1:1)),a=i.slice(0,6),o=i.length-a.length,s=e=>Math.ceil(r.get(e).length/8),c=a.map(e=>s(e)*.9+3.8),l=c.reduce((e,t)=>e+t,0),u=[],d=-l/2;for(let e of c)u.push(d+.4),d+=e;let f=new Map,p=[];a.forEach((t,n)=>r.get(t).forEach((t,r)=>{let i=`r${p.length}`;p.push(i),f.set(i,[u[n]+Math.floor(r/8)*.9,2.6-r%8*.85,0]),e.dot(i,.2)}));let m=a.flatMap(e=>r.get(e)),h=m.map(e=>e.in_index),g=t.filter(e=>e.in_index).length;e.dot(`seal`,.4);let v=p.filter((e,t)=>h[t]);e.link(`toSeal`,v.map(e=>[e,`seal`]),`accent`),e.link(`ringBox`,Ho(0,0,4.4,4.4),`accent`);let y=e=>Math.min(8,r.get(e).length);a.forEach((t,n)=>e.link(`folder${n}`,Ho(u[n]-.4+c[n]/2-.2,2.6-(y(t)-1)*.85/2,c[n]/2-.3,(y(t)-1)*.425+.7),`ink3`));let b={target:[0,.625,0],yaw:-.06,pitch:.12,dist:Math.max(14,Math.min(24,8+l*1.1))};a.forEach((t,n)=>{let i=r.get(t)[0];e.label(`t${n}`,`<small>${Ko(i).toUpperCase()}</small>${jo(t)} <span class="how-dim">${jo(i.version)}</span>`,[u[n],2.6,0],{cls:`chip big`,dy:-58})}),m.forEach((t,n)=>e.label(`l${n}`,jo(t.id),p[n],{dx:12,dy:-7})),e.label(`gen`,`<small>YOUR INDEX · GENERATION</small>${jo(n||`none yet`)}`,[0,-4.4,0],{cls:`chip big`,center:!0,dy:12});let x=e=>t.filter(t=>Ko(t)===e).length,S={fire:0,prime:0,inhibit:0};for(let e of t)e.in_index&&S[_(e.strength)??`prime`]++;let C=e=>m.length<=12?m.map((e,t)=>`l${t}`).slice(0,e):[];function w(e){let t={},n=a.map((e,t)=>`t${t}`);p.forEach((n,r)=>{let i=m[r],a=_(i.strength)??`prime`,o=f.get(n);e<=1?t[n]={pos:o,color:e===0?`ink2`:a,glow:.4}:e===2?t[n]={pos:i.in_index?o:[o[0],o[1]-.35,o[2]],color:a,alpha:i.in_index?1:.2,glow:i.in_index?.5:0}:i.in_index&&(t[n]={pos:Uo(v.indexOf(n),v.length),color:a,glow:.5})}),e<3?n.push(...C(99)):(n.length=0,n.push(`gen`),t.seal={pos:[0,.2,0],color:`accent`,glow:1});let r=e===3?{toSeal:.35,ringBox:.5}:{};return e<3&&a.forEach((e,t)=>r[`folder${t}`]=.4),{dots:t,labels:n,links:r,cam:e<3?b:Vo.seal}}let T=[{title:`Your reflexes, by source`,plain:`Your repository's reflexes, grouped by where they came from.`,math:`seal`,key:!0,body:`This repository's map has ${t.length} reflexes in ${i.length} track${i.length===1?``:`s`}${o?`; the ${a.length} largest sources are shown`:``}. Each track is a directory with a track.toml and one file per reflex.`,chips:[{text:`${x(`first-hand`)} first-hand`},{text:`${x(`imported`)} imported`},{text:`${x(`instinct`)} instinct`}]},{title:`Each has a strength`,plain:`Colour shows each reflex's strength: tell, suggest or warn.`,math:`seal`,body:`Colour is strength as compiled: fire, prime or inhibit. Of the reflexes in your index, ${S.fire} fire, ${S.prime} prime and ${S.inhibit} inhibit.`,chips:[{text:`${S.fire} fire`},{text:`${S.prime} prime`},{text:`${S.inhibit} inhibit`}]},{title:`What is active`,plain:`Not every reflex is active: some wait for your approval, some were switched off, and some lost to a better copy or a warning.`,math:`seal`,body:`${g} of ${t.length} are in the index. A reflex is left out when it is nascent or extinguished, when a first-hand copy of it exists, or when the interlock suppressed it.`,chips:[{text:`${g} in the index`},{text:`${t.length-g} left out`},{text:`first-hand > imported > instinct`}]},{title:`Your sealed file`,plain:`Your active reflexes, sealed into the one file Adage reads while your agent works.`,math:`seal`,key:!0,body:`adage compiled these ${g} reflexes into index.json. Its generation, ${n||`not yet written`}, is your real one, read from the map: the page does not recompute it, because adage serialises the full routes, which the map does not carry.`,chips:[{text:`generation = sha256[..${So}]`},{text:`trigger words not hashed`}]}];return{source:`your ${t.length} reflexes`,legend:[{label:`fire`,role:`fire`},{label:`prime`,role:`prime`},{label:`inhibit`,role:`inhibit`}],steps:T.map((e,t)=>({...e,state:w(t)}))}}var Jo={id:`index`,title:`Package what was learned`,technical:`Seal the index`,status:`Built`,kind:`built`,summary:`Reflexes from your work, your teammates and Adage's built-in instincts are merged, conflicts are settled, and the result is sealed into one file.`,source:`crates/adage-tracks/src/{index,interlock}.rs · adage-instincts · adage-pack`,usesRepo:!0,build(e,t){let n=t.graph?.routes??[];return t.repo&&n.length?qo(e,n,t.graph?.generation??``):Go(e)}},Yo={lanes:{target:[-.6,-1,.6],yaw:-.2,pitch:.8,dist:25},cloud:{target:[.4,0,0],yaw:.42,pitch:.22,dist:18},compile:{target:[0,1.8,1],yaw:-.12,pitch:.46,dist:24}},Xo=2,Zo=.8;function Qo(e){let t=Ct,n=Dt(7),r=[];t.forEach((t,i)=>t.forEach(([t,a],o)=>{let s=St[t],c=s.single?0:.85,l=a.length%3,u=[s.c[0]+n()*c+l*.25,s.c[1]+n()*c,s.c[2]+n()*c],d=s.single?u:[s.c[0]+(u[0]-s.c[0])*.14,s.c[1]+(u[1]-s.c[1])*.14,s.c[2]+(u[2]-s.c[2])*.14],f=`n${i}.${o}`;r.push({id:f,i,j:o,code:t,exact:a,lane:[Et(o),0,Tt(i)],cloud:u,proto:d}),e.dot(f)}));let i=t.map((e,t)=>r.filter(e=>e.i===t)),a=e=>{let t=wt(e,`E`),n=t>=0?wt(e,`G`,t):-1;return t>=0&&n>t&&n-t<=8},o=t.filter(e=>wt(e,`E`)>=0).length,s=t.filter(a).length,c=t.filter(e=>wt(e,`E`)<0),l=c.filter(e=>wt(e,`G`)>=0).length,u=t.filter(e=>wt(e,`E`)>=0||wt(e,`S`)>=0),d=u.filter(e=>wt(e,`G`)>=0).length,f=t.filter(e=>a(e)&&wt(e,`C`,wt(e,`G`))>wt(e,`G`)).length,p=d/u.length,m=Ot(s+Xo*p,o-s+Xo*(1-p)),h=Ot(d+1,u.length-d+1),g=s/o-l/Math.max(1,c.length),_={G:new Set,E:new Set,C:new Set,miss:new Set},v=[],y=[];t.forEach((e,t)=>{let n=wt(e,`E`);if(n<0)return;let r=i[t];if(!a(e)){_.miss.add(r[n].id);return}let o=wt(e,`G`,n);_.E.add(r[n].id),_.G.add(r[o].id),v.push([r[n].id,r[o].id]);let s=wt(e,`C`,o);s>o&&(_.C.add(r[s].id),y.push([r[o].id,r[s].id]))});let b=[];i.forEach(e=>e.forEach((t,n)=>n&&b.push([e[n-1].id,t.id]))),e.link(`lane`,b,`ink3`);let x=[],S=[],C=(e,t)=>Math.hypot(e[0]-t[0],e[1]-t[1],e[2]-t[2]);for(let e of r){let t=r.filter(t=>t!==e&&t.code===e.code).sort((t,n)=>C(t.cloud,e.cloud)-C(n.cloud,e.cloud)).slice(0,3);for(let n of t)(e.exact!==n.exact&&(e.code===`C`||e.code===`G`)&&/-j4|-B/.test(e.exact+n.exact)?S:x).push([e.id,n.id])}e.link(`knn`,x,`ink3`),e.link(`must`,S,`accent`),e.link(`eg`,v,`accent`),e.link(`gc`,y,`accent`);let w=[[-5.6,5.2,1],[0,5.2,1],[5.6,5.2,1]];e.dot(`rx0`,.3),e.dot(`rx1`,.42),e.dot(`rx2`,.3),e.link(`rx`,[[`rx0`,`rx1`],[`rx1`,`rx2`]],`accent`),i.forEach((t,n)=>{e.label(`t${n}`,`T${n+1}`,t[0].id,{dx:-34,dy:-7}),e.label(`s${n}`,t.map(e=>e.code).join(` `),t[t.length-1].id,{dx:16,dy:-7})});for(let[t,n]of Object.entries(St)){let r=n.single?`${n.label}<br><span class="how-dim">singleton · keeps its exact label</span>`:n.label;e.label(`p${t}`,r,n.c,{cls:`chip`,dy:-30,center:!0})}let T=r.find(e=>e.exact===`make check -j4`);e.label(`must`,`must-link: make check ≈ make check -j4`,T.id,{cls:`note`,dx:12,dy:10}),e.label(`miss`,`edited, no make gen`,[..._.miss][0],{cls:`note`,dx:12,dy:6});let E=r.find(e=>e.code===`S`);e.label(`coarse`,`coarser: any edit → make gen · same ${s} traces · dropped`,E.id,{cls:`note`,dx:12,dy:6}),e.label(`rx0`,`<small>AFTER EDIT</small>registry/*.csv`,w[0],{cls:`chip big`,dy:-52,center:!0}),e.label(`rx1`,`<small>REFLEX · SEQUENCE</small><span class="how-lamp prime">●</span> prime · provisional`,w[1],{cls:`chip big`,dy:-64,center:!0}),e.label(`rx2`,`<small>RUN</small>make gen → make check`,w[2],{cls:`chip big`,dy:-52,center:!0});let D=i.map((e,t)=>`t${t}`);function O(e){let t={};for(let n of r){let r=St[n.code],i=e>=3?{hue:r.hue}:{prompt:`soft`,observe:`ink2`,edit:`accent`,regen:`ink1`,verify:`ink1`,fail:`ink3`}[r.kind],a=n.lane,o=1,s=1,c=.18;if(e>=1&&e<=3&&(a=e===3?n.proto:n.cloud),e===3&&r.single&&(c=.5,s=1.3),e>=5){let t=_.G.has(n.id)||e>=6&&_.E.has(n.id)||e>=7&&_.C.has(n.id);t?(i=`soft`,s=1.5,c=.9):e>=6&&_.miss.has(n.id)?(i=`ink2`,s=1.25,c=.4):e===8&&n.code===`S`?(i=`ink2`,s=1.25,c=.35):(o=.3,c=0),e===10&&(o*=t?.55:.4,c*=.3)}t[n.id]={pos:a,color:i,alpha:o,scale:s,glow:c}}e===10&&(t.rx0={pos:w[0],color:`soft`,glow:.4},t.rx1={pos:w[1],color:`prime`,glow:.9},t.rx2={pos:w[2],color:`soft`,glow:.4});let n=[];return(e===0||e>=4&&e<=9)&&n.push(...D),e===4&&n.push(...i.map((e,t)=>`s${t}`)),e===3&&n.push(...Object.keys(St).map(e=>`p${e}`)),e===2&&n.push(`must`),e>=6&&e<=9&&n.push(`miss`),e===8&&n.push(`coarse`),e===10&&n.push(`rx0`,`rx1`,`rx2`),{dots:t,labels:n,cam:e>=1&&e<=3?Yo.cloud:e===10?Yo.compile:Yo.lanes,links:{lane:e===0?.55:e>=4&&e<=9?.3:e===10?.08:0,knn:e===2?.5:e===3?.18:0,must:e===2?.95:e===3?.4:0,eg:e>=6&&e<=9?.9:e===10?.25:0,gc:e>=7&&e<=9?.9:e===10?.25:0,rx:e===10?.9:0}}}let k=[{title:`Past sessions, side by side`,plain:`Here are ${t.length} past sessions, one per row. Each dot is one thing the agent did: read a file, made an edit, ran a command. Adage looks for what keeps repeating.`,key:!0,body:`Each row is one of ${t.length} sample agent traces; each dot is an event: a prompt, a file read, an edit, a command. Order is kept, and so is which events came in the same tool batch. This is how Adage conditions: the graph engine is its only learner, with no list of reflex kinds written by hand.`,chips:[{text:`≤ 2,000 events per trace`},{text:`edges: follows · reads · writes · binds`}]},{title:`Similar actions land close together`,plain:`Each action is placed on a map of meaning, so similar commands and files land close together even when they are not written exactly the same.`,math:`graph`,body:`Events leave their rows and take positions in embedding space, so similar commands and files land near each other. A command's vector mixes a hash of its exact form with the meaning of its words.`,chips:[{text:`act 384-d = 256 hashed + 128 potion`},{text:`weights 0.75 / 0.25`},{text:`quantised to i16`}]},{title:`Look-alikes link up`,plain:`Each action connects to the ones most like it. A check is never lumped in with an edit, and commands that differ only in their options count as the same.`,math:`graph`,body:`Each event links to its nearest neighbours, but only inside its own effect class and program, so a check never merges with an edit. Commands that differ only by options are tied together.`,chips:[{text:`exact kNN, k = 15`},{text:`τ act 0.90 · art 0.85 · prompt 0.80`},{text:`must-link: options only`}]},{title:`Each group gets one name`,plain:`Each tight group of similar actions gets one shared name. A one-off action keeps its own name instead of being forced into a group.`,math:`graph`,body:`Louvain turns each dense group into one label. An event with no close group, like the one-off curl, keeps its exact text instead of being forced into a neighbour.`,chips:[{text:`Louvain, resolution 1.0`},{text:`ambiguity margin δ 0.02`},{text:`τ calibrated on 0.80–0.95`}]},{title:`Sessions read like sentences`,plain:`Now each session reads like a sentence made of those names, and finding habits becomes finding phrases that keep repeating.`,math:`graph`,body:`With every event relabelled, each trace reads as a string. Events in one batch are sorted by label, so the same work always spells the same string, and finding repeated subgraphs becomes finding repeated strings.`,chips:[{text:`no graph isomorphism test`},{text:`labels: exact ⊂ proto ⊂ coarse ⊂ head ⊂ kind`}]},{title:`Start from a step worth suggesting`,plain:`Adage starts from a step worth recommending, here make gen, which ${s} of the ${t.length} sessions ran, and asks what usually comes right before it.`,body:`Mining starts from a step worth delivering and asks what predicts it. Here the target is make gen, which appears in ${s} of the ${t.length} traces.`,chips:[{text:`targets: deliverable steps`},{text:`make gen · ${s} traces`}]},{title:`What comes just before it?`,plain:`Whenever the last edit touched a file in registry/, make gen followed in ${s} of ${o} sessions. Without that edit it ran ${l} times. That edit is the trigger.`,key:!0,body:`The pattern grows backward one item at a time. When the last edit touched registry/*.csv, make gen followed in ${s} of ${o} traces. In the ${c.length} traces without that edit it ran ${l} times.`,chips:[{text:`≤ 3 context items`},{text:`within 8 events of one prompt`},{text:`${s}/${o} with · ${l}/${c.length} without`}]},{title:`What comes just after?`,plain:`Then it looks at what comes after: make check followed make gen in ${f} of those ${s} sessions. The habit is now edit, make gen, make check.`,body:`Then forward, up to two items: after make gen, make check followed in ${f} of those ${s} traces. The pattern is now edit, make gen, make check.`,chips:[{text:`2–6 items in all`},{text:`beam 8 · budget 2,000,000 nodes`},{text:`${f} traces`}]},{title:`The specific habit wins`,plain:`A vaguer version, any edit followed by make gen, covers the same sessions but says less, so the more specific habit wins.`,body:`A coarser version, any edit followed by make gen, matches the same ${s} traces. It says less and explains nothing more, so it is dropped and the specific one stays.`,chips:[{text:`BIDE-style closure`},{text:`same traces + same context size → drop`}]},{title:`Score it cautiously`,plain:`${s} out of ${o} is promising, but it is a small sample, so Adage scores it cautiously: ${K(m.q05)}. Enough to keep, not yet enough to insist.`,math:`graph`,body:`Confidence is ${s}/${o} = ${K(s/o)}. With so few traces it is shrunk toward its parent (any edit → make gen, ${d}/${u.length}) by a Beta posterior, and judged by its 5% quantile: ${K(m.q05)}.`,chips:[{text:`support ${s} ≥ 5`,ok:s>=5},{text:`contrast ${K(g)} ≥ 0.30`,ok:g>=.3},{text:`lower bound ${K(m.q05)} ≥ 0.50`,ok:m.q05>=.5},{text:`κ ${Xo}, parent m ${K(p)}`}],figure:(e,t,n,r)=>{let i=e=>4+e*(t-8),a=Math.max(...m.ps,...h.ps),o=e=>n-16-e/a*(n-16-8);e.strokeStyle=r.css(`ink3`),e.globalAlpha=.4,e.beginPath(),e.moveTo(4,n-16+.5),e.lineTo(t-4,n-16+.5),e.stroke(),e.globalAlpha=1,e.font=`10px 'Red Hat Mono', ui-monospace, monospace`,e.fillStyle=r.css(`ink3`),e.textBaseline=`top`;for(let t of[0,.5,1])e.textAlign=t===0?`left`:t===1?`right`:`center`,e.fillText(String(t),i(t),n-16+3);let s=(t,n,r)=>{e.beginPath(),e.moveTo(i(t.xs[0]),o(0)),t.xs.forEach((n,r)=>e.lineTo(i(n),o(t.ps[r]))),e.lineTo(i(1),o(0)),r&&(e.fillStyle=n+`33`,e.fill()),e.strokeStyle=n,e.lineWidth=1.5,e.stroke()};s(h,r.css(`ink3`),!1),s(m,r.css(`accent`),!0);let c=(t,r,a,o)=>{e.setLineDash([3,3]),e.strokeStyle=r,e.beginPath(),e.moveTo(i(t),6),e.lineTo(i(t),n-16),e.stroke(),e.setLineDash([]),e.fillStyle=r,e.textAlign=o,e.fillText(a,i(t)+(o===`left`?4:-4),4)};c(m.q05,r.css(`soft`),`5% · ${K(m.q05)}`,`right`),c(Zo,r.css(`fire`),`fire bar`,`left`)}},{title:`The habit becomes a reflex`,plain:`The habit becomes a reflex: after editing registry files, run make gen, then make check. It starts as a gentle suggestion until more evidence comes in.`,math:`graph`,key:!0,body:`The pattern compiles to a sequence reflex: after an edit to registry/*.csv, run make gen, then make check. A sequence starts provisional, so it primes until its evidence is counted again on its own trigger; to fire, a reflex needs its lower bound at the 0.80 fire bar. This is the reflex the Map tab then shows.`,chips:[{text:`shape: sequence`},{text:`shapes: run · avoid · read-batch · obligation · sequence · advise · card`},{text:`then MDL selection, ≤ 256 reflexes`}]}];return{source:`${t.length} sample traces`,legend:[{label:`prompt`,role:`soft`},{label:`read / status`,role:`ink2`},{label:`edit`,role:`accent`},{label:`make gen / check`,role:`ink1`},{label:`failed`,role:`ink3`}],steps:k.map((e,t)=>({...e,state:O(t)}))}}var $o=[qa,{id:`subgraphs`,title:`Spot the patterns`,technical:`Find repeated subgraphs`,status:`Built · the learner`,kind:`built`,summary:`Adage lines up past sessions and looks for runs of actions that keep repeating, like an edit that is always followed by the same command.`,source:`crates/adage-graph/src/{events,embed,proto,mine} · crates/adage-learn/src/bridge.rs`,usesRepo:!1,build:Qo},Nn,Hi,_i,xo,Jo,ur,Aa],es={miners:`judge`};function ts(e){let t=e?es[e]??e:null;return Math.max(0,$o.findIndex(e=>e.id===t))}function ns(e){return e.ok===!1?e.text.replace(` ≥ `,` < `):e.text}function rs(e){return e.ok===!0?`✓`:e.ok===!1?`✗`:null}var is=[{id:`trace`,forms:[`trace`,`traces`,`transcript`,`transcripts`],def:`The record of one agent session: what was asked, then every file read, edit and command, in order. Coding agents already write these as they work.`},{id:`reflex`,forms:[`reflex`,`reflexes`],def:`A small learned rule: in this situation, suggest this next step. Each one carries the evidence it was learned from.`},{id:`instinct`,forms:[`instinct`,`instincts`],def:`A rule that ships with Adage and works from day one, set up from files your repository already has, like its Makefile or package.json.`},{id:`hook`,forms:[`hook`,`hooks`,`hook event`,`hook events`],def:`A moment when the coding agent lets an outside tool speak: a session starts, a prompt arrives, a command runs, the agent stops. Adage listens there.`},{id:`directive`,forms:[`directive`,`directives`],def:`The one-line message Adage hands the agent, such as "after editing these files, run make gen".`},{id:`fire-bar`,forms:[`fire bar`],def:`How sure Adage must be before it tells the agent to take a step rather than suggesting it: a lower bound of 0.80.`},{id:`fire`,forms:[`fire`,`fires`],def:`The strongest level: Adage tells the agent to take the step.`},{id:`prime`,forms:[`prime`,`primes`],def:`A gentler level: Adage suggests the step and leaves the choice to the agent.`},{id:`inhibit`,forms:[`inhibit`,`inhibits`],def:`A warning: this step is a dead end here, and here is what works instead.`},{id:`dead-end`,forms:[`dead end`,`dead ends`],def:`A command that keeps failing in this repository, followed by a different one that works.`},{id:`finish-line`,forms:[`finish line`,`finish lines`],def:`A step that has to follow a certain edit, like regenerating code after changing a schema.`},{id:`control`,forms:[`control arm`,`control session`,`control sessions`,`control traces`,`control trace`,`control runs`,`control group`],def:`About 1 in 10 sessions where Adage stays silent and only records what it would have said, so the others can be compared with them, like the placebo group in a trial.`},{id:`uplift`,forms:[`uplift`],def:`How much more often agents take a step when told than on their own. A step they would take anyway is not worth saying.`},{id:`lower-bound`,forms:[`wilson lower bound`,`lower bound`,`lower bounds`],def:`A cautious estimate of a success rate: the lowest the true rate is likely to be, given how few examples there are. 6 out of 8 is 0.75, but its lower bound is only 0.41.`},{id:`beta`,forms:[`beta posterior`,`beta posteriors`],def:`A way to estimate a rate that starts from a sensible guess and moves toward what the data says as examples pile up.`},{id:`embedding`,forms:[`embedding`,`embeddings`,`embedding space`],def:`A list of numbers that places a piece of text on a map of meaning, so things that mean similar things sit close together.`},{id:`cosine`,forms:[`cosine`],def:`How alike two embeddings are: 1 means the same meaning, 0 means unrelated.`},{id:`louvain`,forms:[`louvain`],def:`A standard way to find groups in a network: things that link to each other more than to the rest become one group.`},{id:`knn`,forms:[`knn`,`nearest neighbours`],def:`Each item links to the handful of items most similar to it.`},{id:`mdl`,forms:[`compression`,`minimum description length`,`mdl`],def:`Keep the rules that let you describe the traces most briefly. A rule that saves no space explains nothing new.`},{id:`calibration`,forms:[`calibrated`,`calibration`,`isotonic regression`],def:`Checking predicted confidence against what actually happened on data held back, then correcting it, so that 80% sure means right 80% of the time.`},{id:`subgraph`,forms:[`subgraph`,`subgraphs`],def:`A small piece of the web of events that keeps repeating, like "edit this file, then run that command".`},{id:`card`,forms:[`procedure card`,`procedure cards`],def:`A short note for a task the repository keeps repeating: the files to touch, the commands that worked and the check to finish with.`},{id:`track`,forms:[`track`,`tracks`],def:`A folder of reflexes with their evidence: one per repository, one for the instincts, one per imported pack.`},{id:`pack`,forms:[`pack`,`packs`],def:`A signed bundle of reflexes that a teammate shares.`},{id:`index`,forms:[`index`],def:`One sealed file that holds every active reflex. It is the only thing the hook reads.`},{id:`sandbox`,forms:[`sandbox`],def:`A walled-off space where a command runs without touching your files or the network.`},{id:`p-value`,forms:[`p-value`,`p-values`],def:`How often chance alone would give a result at least this big. The smaller it is, the less likely the result is luck.`},{id:`holm`,forms:[`holm's step-down`,`holm`],def:`A correction for testing several things at once, so one lucky result does not count as a win.`},{id:`bootstrap`,forms:[`bootstrap`],def:`Resampling the data many times to see how much a result could wobble. It gives a range the true value likely sits in.`},{id:`sign-flip`,forms:[`sign-flip test`,`sign-flip`],def:`A test of whether an effect would hold on new tasks: flip each task's result between better and worse, and see how often chance matches what was seen.`},{id:`propensity`,forms:[`propensity`],def:`The chance a session had of landing in its group. Results are weighed by it so the comparison stays fair.`},{id:`skill`,forms:[`skill file`,`skill.md`,`skill`],def:`A written guide that tells an agent how work is done in a repository.`},{id:`nascent`,forms:[`nascent`],def:`Learned, but held back until a person approves it.`},{id:`forming`,forms:[`forming`,`provisional`],def:`Not yet confirmed by enough of your own traces: it can suggest, never insist.`},{id:`obligation`,forms:[`obligation`],def:`Something the agent should still do before it stops, like running the check after an edit.`},{id:`interlock`,forms:[`interlock`,`interlocks`],def:`A safety rule that drops any reflex that would recommend a command a dead end says fails.`},{id:`effect`,forms:[`effect class`,`effects`],def:`What a step does: observe, verify, regenerate, environment, author or publish. It caps how strongly Adage may ever suggest the step.`},{id:`support`,forms:[`support`],def:`How many separate traces back a pattern.`},{id:`contrast`,forms:[`contrast`],def:`How much more often the step follows its trigger than it happens without it.`},{id:`template-key`,forms:[`template key`],def:`A step with the specifics swapped for placeholders, so "look up W-1041" and "look up W-1042" count as the same step.`},{id:`sidechain`,forms:[`sidechain`],def:`Records a sub-agent wrote inside the main transcript.`}],as=new Map;for(let e of is)for(let t of e.forms)as.set(t.toLowerCase(),e);var os=e=>e.replace(/[.*+?^${}()|[\]\\]/g,`\\$&`),ss=RegExp(`(?<![\\w-])(${[...as.keys()].sort((e,t)=>t.length-e.length).map(os).join(`|`)})(?![\\w-])`,`gi`);function cs(e,t=new Set){let n=[],r=0;for(let i of e.matchAll(ss)){let a=as.get(i[0].toLowerCase());t.has(a.id)||(t.add(a.id),i.index>r&&n.push(e.slice(r,i.index)),n.push({text:i[0],term:a}),r=i.index+i[0].length)}return r<e.length&&n.push(e.slice(r)),n}var ls=1e3,us=1001,ds=1002,fs=1003,ps=1004,ms=1005,hs=1006,gs=1007,_s=1008,vs=1009,ys=1010,bs=1011,xs=1012,Ss=1013,Cs=1014,ws=1015,Ts=1016,Es=1017,Ds=1018,Os=1020,ks=35902,As=35899,js=1021,Ms=1022,Ns=1023,Ps=1026,Fs=1027,Is=1028,Ls=1029,Rs=1030,zs=1031,Bs=1033,Vs=33776,Hs=33777,Us=33778,Ws=33779,Gs=35840,Ks=35841,qs=35842,Js=35843,Ys=36196,Xs=37492,Zs=37496,Qs=37488,$s=37489,ec=37490,tc=37491,nc=37808,rc=37809,ic=37810,ac=37811,oc=37812,sc=37813,cc=37814,lc=37815,uc=37816,dc=37817,fc=37818,pc=37819,mc=37820,hc=37821,gc=36492,_c=36494,vc=36495,yc=36283,bc=36284,xc=36285,Sc=36286,Cc=2300,wc=2301,Tc=2302,Ec=2303,Dc=2400,Oc=2401,kc=2402,Ac=3200,jc=`srgb`,Mc=`srgb-linear`,Nc=`linear`,Pc=`srgb`,Fc=7680,Ic=35044,Lc=2e3;function Rc(e){for(let t=e.length-1;t>=0;--t)if(e[t]>=65535)return!0;return!1}function zc(e){return ArrayBuffer.isView(e)&&!(e instanceof DataView)}function Bc(e){return document.createElementNS(`http://www.w3.org/1999/xhtml`,e)}function Vc(){let e=Bc(`canvas`);return e.style.display=`block`,e}var Hc={};function Uc(...e){let t=`THREE.`+e.shift();console.log(t,...e)}function Wc(e){let t=e[0];if(typeof t==`string`&&t.startsWith(`TSL:`)){let t=e[1];t&&t.isStackTrace?e[0]+=` `+t.getLocation():e[1]=`Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.`}return e}function q(...e){e=Wc(e);let t=`THREE.`+e.shift();{let n=e[0];n&&n.isStackTrace?console.warn(n.getError(t)):console.warn(t,...e)}}function J(...e){e=Wc(e);let t=`THREE.`+e.shift();{let n=e[0];n&&n.isStackTrace?console.error(n.getError(t)):console.error(t,...e)}}function Gc(...e){let t=e.join(` `);t in Hc||(Hc[t]=!0,q(...e))}function Kc(e,t,n){return new Promise(function(r,i){function a(){switch(e.clientWaitSync(t,e.SYNC_FLUSH_COMMANDS_BIT,0)){case e.WAIT_FAILED:i();break;case e.TIMEOUT_EXPIRED:setTimeout(a,n);break;default:r()}}setTimeout(a,n)})}var qc={0:1,2:6,4:7,3:5,1:0,6:2,7:4,5:3},Jc=class{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});let n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){let n=this._listeners;return n!==void 0&&n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){let n=this._listeners;if(n===void 0)return;let r=n[e];if(r!==void 0){let e=r.indexOf(t);e!==-1&&r.splice(e,1)}}dispatchEvent(e){let t=this._listeners;if(t===void 0)return;let n=t[e.type];if(n!==void 0){e.target=this;let t=n.slice(0);for(let n=0,r=t.length;n<r;n++)t[n].call(this,e);e.target=null}}},Yc=`00.01.02.03.04.05.06.07.08.09.0a.0b.0c.0d.0e.0f.10.11.12.13.14.15.16.17.18.19.1a.1b.1c.1d.1e.1f.20.21.22.23.24.25.26.27.28.29.2a.2b.2c.2d.2e.2f.30.31.32.33.34.35.36.37.38.39.3a.3b.3c.3d.3e.3f.40.41.42.43.44.45.46.47.48.49.4a.4b.4c.4d.4e.4f.50.51.52.53.54.55.56.57.58.59.5a.5b.5c.5d.5e.5f.60.61.62.63.64.65.66.67.68.69.6a.6b.6c.6d.6e.6f.70.71.72.73.74.75.76.77.78.79.7a.7b.7c.7d.7e.7f.80.81.82.83.84.85.86.87.88.89.8a.8b.8c.8d.8e.8f.90.91.92.93.94.95.96.97.98.99.9a.9b.9c.9d.9e.9f.a0.a1.a2.a3.a4.a5.a6.a7.a8.a9.aa.ab.ac.ad.ae.af.b0.b1.b2.b3.b4.b5.b6.b7.b8.b9.ba.bb.bc.bd.be.bf.c0.c1.c2.c3.c4.c5.c6.c7.c8.c9.ca.cb.cc.cd.ce.cf.d0.d1.d2.d3.d4.d5.d6.d7.d8.d9.da.db.dc.dd.de.df.e0.e1.e2.e3.e4.e5.e6.e7.e8.e9.ea.eb.ec.ed.ee.ef.f0.f1.f2.f3.f4.f5.f6.f7.f8.f9.fa.fb.fc.fd.fe.ff`.split(`.`),Xc=Math.PI/180,Zc=180/Math.PI;function Qc(){let e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0,r=Math.random()*4294967295|0;return(Yc[e&255]+Yc[e>>8&255]+Yc[e>>16&255]+Yc[e>>24&255]+`-`+Yc[t&255]+Yc[t>>8&255]+`-`+Yc[t>>16&15|64]+Yc[t>>24&255]+`-`+Yc[n&63|128]+Yc[n>>8&255]+`-`+Yc[n>>16&255]+Yc[n>>24&255]+Yc[r&255]+Yc[r>>8&255]+Yc[r>>16&255]+Yc[r>>24&255]).toLowerCase()}function $c(e,t,n){return Math.max(t,Math.min(n,e))}function el(e,t){return(e%t+t)%t}function tl(e,t,n){return(1-n)*e+n*t}function nl(e,t){switch(t.constructor){case Float32Array:return e;case Uint32Array:return e/4294967295;case Uint16Array:return e/65535;case Uint8Array:case Uint8ClampedArray:return e/255;case Int32Array:return Math.max(e/2147483647,-1);case Int16Array:return Math.max(e/32767,-1);case Int8Array:return Math.max(e/127,-1);default:throw Error(`THREE.MathUtils: Invalid component type.`)}}function rl(e,t){switch(t.constructor){case Float32Array:return e;case Uint32Array:return Math.round(e*4294967295);case Uint16Array:return Math.round(e*65535);case Uint8Array:case Uint8ClampedArray:return Math.round(e*255);case Int32Array:return Math.round(e*2147483647);case Int16Array:return Math.round(e*32767);case Int8Array:return Math.round(e*127);default:throw Error(`THREE.MathUtils: Invalid component type.`)}}var Y=class e{static{e.prototype.isVector2=!0}constructor(e=0,t=0){this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw Error(`THREE.Vector2: index is out of range: `+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw Error(`THREE.Vector2: index is out of range: `+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){let t=this.x,n=this.y,r=e.elements;return this.x=r[0]*t+r[3]*n+r[6],this.y=r[1]*t+r[4]*n+r[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=$c(this.x,e.x,t.x),this.y=$c(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=$c(this.x,e,t),this.y=$c(this.y,e,t),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar($c(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let n=this.dot(e)/t;return Math.acos($c(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){let n=Math.cos(t),r=Math.sin(t),i=this.x-e.x,a=this.y-e.y;return this.x=i*n-a*r+e.x,this.y=i*r+a*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},il=class{constructor(e=0,t=0,n=0,r=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=r}static slerpFlat(e,t,n,r,i,a,o){let s=n[r+0],c=n[r+1],l=n[r+2],u=n[r+3],d=i[a+0],f=i[a+1],p=i[a+2],m=i[a+3];if(u!==m||s!==d||c!==f||l!==p){let e=s*d+c*f+l*p+u*m;e<0&&(d=-d,f=-f,p=-p,m=-m,e=-e);let t=1-o;if(e<.9995){let n=Math.acos(e),r=Math.sin(n);t=Math.sin(t*n)/r,o=Math.sin(o*n)/r,s=s*t+d*o,c=c*t+f*o,l=l*t+p*o,u=u*t+m*o}else{s=s*t+d*o,c=c*t+f*o,l=l*t+p*o,u=u*t+m*o;let e=1/Math.sqrt(s*s+c*c+l*l+u*u);s*=e,c*=e,l*=e,u*=e}}e[t]=s,e[t+1]=c,e[t+2]=l,e[t+3]=u}static multiplyQuaternionsFlat(e,t,n,r,i,a){let o=n[r],s=n[r+1],c=n[r+2],l=n[r+3],u=i[a],d=i[a+1],f=i[a+2],p=i[a+3];return e[t]=o*p+l*u+s*f-c*d,e[t+1]=s*p+l*d+c*u-o*f,e[t+2]=c*p+l*f+o*d-s*u,e[t+3]=l*p-o*u-s*d-c*f,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,r){return this._x=e,this._y=t,this._z=n,this._w=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){let n=e._x,r=e._y,i=e._z,a=e._order,o=Math.cos,s=Math.sin,c=o(n/2),l=o(r/2),u=o(i/2),d=s(n/2),f=s(r/2),p=s(i/2);switch(a){case`XYZ`:this._x=d*l*u+c*f*p,this._y=c*f*u-d*l*p,this._z=c*l*p+d*f*u,this._w=c*l*u-d*f*p;break;case`YXZ`:this._x=d*l*u+c*f*p,this._y=c*f*u-d*l*p,this._z=c*l*p-d*f*u,this._w=c*l*u+d*f*p;break;case`ZXY`:this._x=d*l*u-c*f*p,this._y=c*f*u+d*l*p,this._z=c*l*p+d*f*u,this._w=c*l*u-d*f*p;break;case`ZYX`:this._x=d*l*u-c*f*p,this._y=c*f*u+d*l*p,this._z=c*l*p-d*f*u,this._w=c*l*u+d*f*p;break;case`YZX`:this._x=d*l*u+c*f*p,this._y=c*f*u+d*l*p,this._z=c*l*p-d*f*u,this._w=c*l*u-d*f*p;break;case`XZY`:this._x=d*l*u-c*f*p,this._y=c*f*u-d*l*p,this._z=c*l*p+d*f*u,this._w=c*l*u+d*f*p;break;default:q(`Quaternion: .setFromEuler() encountered an unknown order: `+a)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){let n=t/2,r=Math.sin(n);return this._x=e.x*r,this._y=e.y*r,this._z=e.z*r,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){let t=e.elements,n=t[0],r=t[4],i=t[8],a=t[1],o=t[5],s=t[9],c=t[2],l=t[6],u=t[10],d=n+o+u;if(d>0){let e=.5/Math.sqrt(d+1);this._w=.25/e,this._x=(l-s)*e,this._y=(i-c)*e,this._z=(a-r)*e}else if(n>o&&n>u){let e=2*Math.sqrt(1+n-o-u);this._w=(l-s)/e,this._x=.25*e,this._y=(r+a)/e,this._z=(i+c)/e}else if(o>u){let e=2*Math.sqrt(1+o-n-u);this._w=(i-c)/e,this._x=(r+a)/e,this._y=.25*e,this._z=(s+l)/e}else{let e=2*Math.sqrt(1+u-n-o);this._w=(a-r)/e,this._x=(i+c)/e,this._y=(s+l)/e,this._z=.25*e}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<1e-8?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs($c(this.dot(e),-1,1)))}rotateTowards(e,t){let n=this.angleTo(e);if(n===0)return this;let r=Math.min(1,t/n);return this.slerp(e,r),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x*=e,this._y*=e,this._z*=e,this._w*=e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){let n=e._x,r=e._y,i=e._z,a=e._w,o=t._x,s=t._y,c=t._z,l=t._w;return this._x=n*l+a*o+r*c-i*s,this._y=r*l+a*s+i*o-n*c,this._z=i*l+a*c+n*s-r*o,this._w=a*l-n*o-r*s-i*c,this._onChangeCallback(),this}slerp(e,t){let n=e._x,r=e._y,i=e._z,a=e._w,o=this.dot(e);o<0&&(n=-n,r=-r,i=-i,a=-a,o=-o);let s=1-t;if(o<.9995){let e=Math.acos(o),c=Math.sin(e);s=Math.sin(s*e)/c,t=Math.sin(t*e)/c,this._x=this._x*s+n*t,this._y=this._y*s+r*t,this._z=this._z*s+i*t,this._w=this._w*s+a*t,this._onChangeCallback()}else this._x=this._x*s+n*t,this._y=this._y*s+r*t,this._z=this._z*s+i*t,this._w=this._w*s+a*t,this.normalize();return this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){let e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),r=Math.sqrt(1-n),i=Math.sqrt(n);return this.set(r*Math.sin(e),r*Math.cos(e),i*Math.sin(t),i*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},X=class e{static{e.prototype.isVector3=!0}constructor(e=0,t=0,n=0){this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw Error(`THREE.Vector3: index is out of range: `+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw Error(`THREE.Vector3: index is out of range: `+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(ol.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(ol.setFromAxisAngle(e,t))}applyMatrix3(e){let t=this.x,n=this.y,r=this.z,i=e.elements;return this.x=i[0]*t+i[3]*n+i[6]*r,this.y=i[1]*t+i[4]*n+i[7]*r,this.z=i[2]*t+i[5]*n+i[8]*r,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){let t=this.x,n=this.y,r=this.z,i=e.elements,a=1/(i[3]*t+i[7]*n+i[11]*r+i[15]);return this.x=(i[0]*t+i[4]*n+i[8]*r+i[12])*a,this.y=(i[1]*t+i[5]*n+i[9]*r+i[13])*a,this.z=(i[2]*t+i[6]*n+i[10]*r+i[14])*a,this}applyQuaternion(e){let t=this.x,n=this.y,r=this.z,i=e.x,a=e.y,o=e.z,s=e.w,c=2*(a*r-o*n),l=2*(o*t-i*r),u=2*(i*n-a*t);return this.x=t+s*c+a*u-o*l,this.y=n+s*l+o*c-i*u,this.z=r+s*u+i*l-a*c,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){let t=this.x,n=this.y,r=this.z,i=e.elements;return this.x=i[0]*t+i[4]*n+i[8]*r,this.y=i[1]*t+i[5]*n+i[9]*r,this.z=i[2]*t+i[6]*n+i[10]*r,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=$c(this.x,e.x,t.x),this.y=$c(this.y,e.y,t.y),this.z=$c(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=$c(this.x,e,t),this.y=$c(this.y,e,t),this.z=$c(this.z,e,t),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar($c(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){let n=e.x,r=e.y,i=e.z,a=t.x,o=t.y,s=t.z;return this.x=r*s-i*o,this.y=i*a-n*s,this.z=n*o-r*a,this}projectOnVector(e){let t=e.lengthSq();if(t===0)return this.set(0,0,0);let n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return al.copy(this).projectOnVector(e),this.sub(al)}reflect(e){return this.sub(al.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let n=this.dot(e)/t;return Math.acos($c(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y,r=this.z-e.z;return t*t+n*n+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){let r=Math.sin(t)*e;return this.x=r*Math.sin(n),this.y=Math.cos(t)*e,this.z=r*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){let t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),r=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=r,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},al=new X,ol=new il,Z=class e{static{e.prototype.isMatrix3=!0}constructor(e,t,n,r,i,a,o,s,c){this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,n,r,i,a,o,s,c)}set(e,t,n,r,i,a,o,s,c){let l=this.elements;return l[0]=e,l[1]=r,l[2]=o,l[3]=t,l[4]=i,l[5]=s,l[6]=n,l[7]=a,l[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){let t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,r=t.elements,i=this.elements,a=n[0],o=n[3],s=n[6],c=n[1],l=n[4],u=n[7],d=n[2],f=n[5],p=n[8],m=r[0],h=r[3],g=r[6],_=r[1],v=r[4],y=r[7],b=r[2],x=r[5],S=r[8];return i[0]=a*m+o*_+s*b,i[3]=a*h+o*v+s*x,i[6]=a*g+o*y+s*S,i[1]=c*m+l*_+u*b,i[4]=c*h+l*v+u*x,i[7]=c*g+l*y+u*S,i[2]=d*m+f*_+p*b,i[5]=d*h+f*v+p*x,i[8]=d*g+f*y+p*S,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[1],r=e[2],i=e[3],a=e[4],o=e[5],s=e[6],c=e[7],l=e[8];return t*a*l-t*o*c-n*i*l+n*o*s+r*i*c-r*a*s}invert(){let e=this.elements,t=e[0],n=e[1],r=e[2],i=e[3],a=e[4],o=e[5],s=e[6],c=e[7],l=e[8],u=l*a-o*c,d=o*s-l*i,f=c*i-a*s,p=t*u+n*d+r*f;if(p===0)return this.set(0,0,0,0,0,0,0,0,0);let m=1/p;return e[0]=u*m,e[1]=(r*c-l*n)*m,e[2]=(o*n-r*a)*m,e[3]=d*m,e[4]=(l*t-r*s)*m,e[5]=(r*i-o*t)*m,e[6]=f*m,e[7]=(n*s-c*t)*m,e[8]=(a*t-n*i)*m,this}transpose(){let e,t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){let t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,r,i,a,o){let s=Math.cos(i),c=Math.sin(i);return this.set(n*s,n*c,-n*(s*a+c*o)+a+e,-r*c,r*s,-r*(-c*a+s*o)+o+t,0,0,1),this}scale(e,t){return Gc(`Matrix3: .scale() is deprecated. Use .makeScale() instead.`),this.premultiply(sl.makeScale(e,t)),this}rotate(e){return Gc(`Matrix3: .rotate() is deprecated. Use .makeRotation() instead.`),this.premultiply(sl.makeRotation(-e)),this}translate(e,t){return Gc(`Matrix3: .translate() is deprecated. Use .makeTranslation() instead.`),this.premultiply(sl.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){let t=this.elements,n=e.elements;for(let e=0;e<9;e++)if(t[e]!==n[e])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}},sl=new Z,cl=new Z().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),ll=new Z().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function ul(){let e={enabled:!0,workingColorSpace:Mc,spaces:{},convert:function(e,t,n){return this.enabled===!1||t===n||!t||!n?e:(this.spaces[t].transfer===`srgb`&&(e.r=fl(e.r),e.g=fl(e.g),e.b=fl(e.b)),this.spaces[t].primaries!==this.spaces[n].primaries&&(e.applyMatrix3(this.spaces[t].toXYZ),e.applyMatrix3(this.spaces[n].fromXYZ)),this.spaces[n].transfer===`srgb`&&(e.r=pl(e.r),e.g=pl(e.g),e.b=pl(e.b)),e)},workingToColorSpace:function(e,t){return this.convert(e,this.workingColorSpace,t)},colorSpaceToWorking:function(e,t){return this.convert(e,t,this.workingColorSpace)},getPrimaries:function(e){return this.spaces[e].primaries},getTransfer:function(e){return e===``?Nc:this.spaces[e].transfer},getToneMappingMode:function(e){return this.spaces[e].outputColorSpaceConfig.toneMappingMode||`standard`},getLuminanceCoefficients:function(e,t=this.workingColorSpace){return e.fromArray(this.spaces[t].luminanceCoefficients)},define:function(e){Object.assign(this.spaces,e)},_getMatrix:function(e,t,n){return e.copy(this.spaces[t].toXYZ).multiply(this.spaces[n].fromXYZ)},_getDrawingBufferColorSpace:function(e){return this.spaces[e].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(e=this.workingColorSpace){return this.spaces[e].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(t,n){return Gc(`ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace().`),e.workingToColorSpace(t,n)},toWorkingColorSpace:function(t,n){return Gc(`ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking().`),e.colorSpaceToWorking(t,n)}},t=[.64,.33,.3,.6,.15,.06],n=[.2126,.7152,.0722],r=[.3127,.329];return e.define({[Mc]:{primaries:t,whitePoint:r,transfer:Nc,toXYZ:cl,fromXYZ:ll,luminanceCoefficients:n,workingColorSpaceConfig:{unpackColorSpace:jc},outputColorSpaceConfig:{drawingBufferColorSpace:jc}},[jc]:{primaries:t,whitePoint:r,transfer:Pc,toXYZ:cl,fromXYZ:ll,luminanceCoefficients:n,outputColorSpaceConfig:{drawingBufferColorSpace:jc}}}),e}var dl=ul();function fl(e){return e<.04045?e*.0773993808:(e*.9478672986+.0521327014)**2.4}function pl(e){return e<.0031308?e*12.92:1.055*e**.41666-.055}var ml,hl=class{static getDataURL(e,t=`image/png`){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>`u`)return e.src;let n;if(e instanceof HTMLCanvasElement)n=e;else{ml===void 0&&(ml=Bc(`canvas`)),ml.width=e.width,ml.height=e.height;let t=ml.getContext(`2d`);e instanceof ImageData?t.putImageData(e,0,0):t.drawImage(e,0,0,e.width,e.height),n=ml}return n.toDataURL(t)}static sRGBToLinear(e){if(typeof HTMLImageElement<`u`&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<`u`&&e instanceof HTMLCanvasElement||typeof ImageBitmap<`u`&&e instanceof ImageBitmap){let t=Bc(`canvas`);t.width=e.width,t.height=e.height;let n=t.getContext(`2d`);n.drawImage(e,0,0,e.width,e.height);let r=n.getImageData(0,0,e.width,e.height),i=r.data;for(let e=0;e<i.length;e++)i[e]=fl(i[e]/255)*255;return n.putImageData(r,0,0),t}if(e.data){let t=e.data.slice(0);for(let e=0;e<t.length;e++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[e]=Math.floor(fl(t[e]/255)*255):t[e]=fl(t[e]);return{data:t,width:e.width,height:e.height}}return q(`ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied.`),e}},gl=0,_l=class{constructor(e=null){this.isTextureSource=!0,Object.defineProperty(this,"id",{value:gl++}),this.uuid=Qc(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){let t=this.data;return typeof HTMLVideoElement<`u`&&t instanceof HTMLVideoElement?e.set(t.videoWidth,t.videoHeight,0):typeof VideoFrame<`u`&&t instanceof VideoFrame?e.set(t.displayWidth,t.displayHeight,0):t===null?e.set(0,0,0):e.set(t.width,t.height,t.depth||0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){let t=e===void 0||typeof e==`string`;if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];let n={uuid:this.uuid,url:``},r=this.data;if(r!==null){let e;if(Array.isArray(r)){e=[];for(let t=0,n=r.length;t<n;t++)r[t].isDataTexture?e.push(vl(r[t].image)):e.push(vl(r[t]))}else e=vl(r);n.url=e}return t||(e.images[this.uuid]=n),n}};function vl(e){return typeof HTMLImageElement<`u`&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<`u`&&e instanceof HTMLCanvasElement||typeof ImageBitmap<`u`&&e instanceof ImageBitmap?hl.getDataURL(e):e.data?{data:Array.from(e.data),width:e.width,height:e.height,type:e.data.constructor.name}:(q(`Texture: Unable to serialize Texture.`),{})}var yl=0,bl=new X,xl=class e extends Jc{constructor(t=e.DEFAULT_IMAGE,n=e.DEFAULT_MAPPING,r=us,i=us,a=hs,o=_s,s=Ns,c=vs,l=e.DEFAULT_ANISOTROPY,u=``){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:yl++}),this.uuid=Qc(),this.name=``,this.source=new _l(t),this.mipmaps=[],this.mapping=n,this.channel=0,this.wrapS=r,this.wrapT=i,this.magFilter=a,this.minFilter=o,this.anisotropy=l,this.format=s,this.internalFormat=null,this.type=c,this.offset=new Y(0,0),this.repeat=new Y(1,1),this.center=new Y(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Z,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=u,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(t&&t.depth&&t.depth>1),this.pmremVersion=0,this.normalized=!1}get width(){return this.source.getSize(bl).x}get height(){return this.source.getSize(bl).y}get depth(){return this.source.getSize(bl).z}get image(){return this.source.data}set image(e){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.normalized=e.normalized,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(let t in e){let n=e[t];if(n===void 0){q(`Texture.setValues(): parameter '${t}' has value of undefined.`);continue}let r=this[t];if(r===void 0){q(`Texture.setValues(): property '${t}' does not exist.`);continue}r&&n&&r.isVector2&&n.isVector2||r&&n&&r.isVector3&&n.isVector3||r&&n&&r.isMatrix3&&n.isMatrix3?r.copy(n):this[t]=n}}toJSON(e){let t=e===void 0||typeof e==`string`;if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];let n={metadata:{version:4.7,type:`Texture`,generator:`Texture.toJSON`},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:`dispose`})}transformUv(e){if(this.mapping!==300)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case ls:e.x-=Math.floor(e.x);break;case us:e.x=e.x<0?0:1;break;case ds:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x-=Math.floor(e.x)}if(e.y<0||e.y>1)switch(this.wrapT){case ls:e.y-=Math.floor(e.y);break;case us:e.y=e.y<0?0:1;break;case ds:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y-=Math.floor(e.y)}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}};xl.DEFAULT_IMAGE=null,xl.DEFAULT_MAPPING=300,xl.DEFAULT_ANISOTROPY=1;var Sl=class e{static{e.prototype.isVector4=!0}constructor(e=0,t=0,n=0,r=1){this.x=e,this.y=t,this.z=n,this.w=r}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,r){return this.x=e,this.y=t,this.z=n,this.w=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw Error(`THREE.Vector4: index is out of range: `+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw Error(`THREE.Vector4: index is out of range: `+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w===void 0?1:e.w,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){let t=this.x,n=this.y,r=this.z,i=this.w,a=e.elements;return this.x=a[0]*t+a[4]*n+a[8]*r+a[12]*i,this.y=a[1]*t+a[5]*n+a[9]*r+a[13]*i,this.z=a[2]*t+a[6]*n+a[10]*r+a[14]*i,this.w=a[3]*t+a[7]*n+a[11]*r+a[15]*i,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);let t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,r,i,a=.01,o=.1,s=e.elements,c=s[0],l=s[4],u=s[8],d=s[1],f=s[5],p=s[9],m=s[2],h=s[6],g=s[10];if(Math.abs(l-d)<a&&Math.abs(u-m)<a&&Math.abs(p-h)<a){if(Math.abs(l+d)<o&&Math.abs(u+m)<o&&Math.abs(p+h)<o&&Math.abs(c+f+g-3)<o)return this.set(1,0,0,0),this;t=Math.PI;let e=(c+1)/2,s=(f+1)/2,_=(g+1)/2,v=(l+d)/4,y=(u+m)/4,b=(p+h)/4;return e>s&&e>_?e<a?(n=0,r=.707106781,i=.707106781):(n=Math.sqrt(e),r=v/n,i=y/n):s>_?s<a?(n=.707106781,r=0,i=.707106781):(r=Math.sqrt(s),n=v/r,i=b/r):_<a?(n=.707106781,r=.707106781,i=0):(i=Math.sqrt(_),n=y/i,r=b/i),this.set(n,r,i,t),this}let _=Math.sqrt((h-p)*(h-p)+(u-m)*(u-m)+(d-l)*(d-l));return Math.abs(_)<.001&&(_=1),this.x=(h-p)/_,this.y=(u-m)/_,this.z=(d-l)/_,this.w=Math.acos((c+f+g-1)/2),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=$c(this.x,e.x,t.x),this.y=$c(this.y,e.y,t.y),this.z=$c(this.z,e.z,t.z),this.w=$c(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=$c(this.x,e,t),this.y=$c(this.y,e,t),this.z=$c(this.z,e,t),this.w=$c(this.w,e,t),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar($c(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},Cl=class extends Jc{constructor(e=1,t=1,n={}){super(),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:hs,depthBuffer:!0,stencilBuffer:!1,resolveColorBuffer:!0,resolveDepthBuffer:!0,resolveStencilBuffer:!0,storeMultisampledColorBuffer:!0,storeMultisampledDepthBuffer:!0,storeMultisampledStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1,useArrayDepthTexture:!1},n),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=n.depth,this.scissor=new Sl(0,0,e,t),this.scissorTest=!1,this.viewport=new Sl(0,0,e,t),this.textures=[];let r=new xl({width:e,height:t,depth:n.depth}),i=n.count;for(let e=0;e<i;e++)this.textures[e]=r.clone(),this.textures[e].isRenderTargetTexture=!0,this.textures[e].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveColorBuffer=n.resolveColorBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this.storeMultisampledColorBuffer=n.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=n.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=n.storeMultisampledStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview,this.useArrayDepthTexture=n.useArrayDepthTexture}_setTextureOptions(e={}){let t={minFilter:hs,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(t.mapping=e.mapping),e.wrapS!==void 0&&(t.wrapS=e.wrapS),e.wrapT!==void 0&&(t.wrapT=e.wrapT),e.wrapR!==void 0&&(t.wrapR=e.wrapR),e.magFilter!==void 0&&(t.magFilter=e.magFilter),e.minFilter!==void 0&&(t.minFilter=e.minFilter),e.format!==void 0&&(t.format=e.format),e.type!==void 0&&(t.type=e.type),e.anisotropy!==void 0&&(t.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(t.colorSpace=e.colorSpace),e.flipY!==void 0&&(t.flipY=e.flipY),e.generateMipmaps!==void 0&&(t.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(t.internalFormat=e.internalFormat);for(let e=0;e<this.textures.length;e++)this.textures[e].setValues(t)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&this._depthTexture.renderTarget===this&&(this._depthTexture.renderTarget=null),e!==null&&e.renderTarget===null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,n=1){if(this.width!==e||this.height!==t||this.depth!==n){this.width=e,this.height=t,this.depth=n;for(let r=0,i=this.textures.length;r<i;r++)this.textures[r].image.width=e,this.textures[r].image.height=t,this.textures[r].image.depth=n,this.textures[r].isData3DTexture!==!0&&(this.textures[r].isArrayTexture=this.textures[r].image.depth>1);this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,n=e.textures.length;t<n;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;let n=Object.assign({},e.textures[t].image);this.textures[t].source=new _l(n)}if(this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveColorBuffer=e.resolveColorBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,this.storeMultisampledColorBuffer=e.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=e.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=e.storeMultisampledStencilBuffer,e.depthTexture!==null){if(e.depthTexture.renderTarget===e){let t=e.depthTexture.clone();t.renderTarget=null,this.depthTexture=t}else this.depthTexture=e.depthTexture}return this.samples=e.samples,this.multiview=e.multiview,this.useArrayDepthTexture=e.useArrayDepthTexture,this}dispose(){this.dispatchEvent({type:`dispose`})}},wl=class extends Cl{constructor(e=1,t=1,n={}){super(e,t,n),this.isWebGLRenderTarget=!0}},Tl=class extends xl{constructor(e=null,t=1,n=1,r=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:n,depth:r},this.magFilter=fs,this.minFilter=fs,this.wrapR=us,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}},El=class extends xl{constructor(e=null,t=1,n=1,r=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:n,depth:r},this.magFilter=fs,this.minFilter=fs,this.wrapR=us,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}},Dl=class e{static{e.prototype.isMatrix4=!0}constructor(e,t,n,r,i,a,o,s,c,l,u,d,f,p,m,h){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,n,r,i,a,o,s,c,l,u,d,f,p,m,h)}set(e,t,n,r,i,a,o,s,c,l,u,d,f,p,m,h){let g=this.elements;return g[0]=e,g[4]=t,g[8]=n,g[12]=r,g[1]=i,g[5]=a,g[9]=o,g[13]=s,g[2]=c,g[6]=l,g[10]=u,g[14]=d,g[3]=f,g[7]=p,g[11]=m,g[15]=h,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new e().fromArray(this.elements)}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){let t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){let t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return this.determinantAffine()===0?(e.set(1,0,0),t.set(0,1,0),n.set(0,0,1),this):(e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this)}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){if(e.determinantAffine()===0)return this.identity();let t=this.elements,n=e.elements,r=1/Ol.setFromMatrixColumn(e,0).length(),i=1/Ol.setFromMatrixColumn(e,1).length(),a=1/Ol.setFromMatrixColumn(e,2).length();return t[0]=n[0]*r,t[1]=n[1]*r,t[2]=n[2]*r,t[3]=0,t[4]=n[4]*i,t[5]=n[5]*i,t[6]=n[6]*i,t[7]=0,t[8]=n[8]*a,t[9]=n[9]*a,t[10]=n[10]*a,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){let t=this.elements,n=e.x,r=e.y,i=e.z,a=Math.cos(n),o=Math.sin(n),s=Math.cos(r),c=Math.sin(r),l=Math.cos(i),u=Math.sin(i);if(e.order===`XYZ`){let e=a*l,n=a*u,r=o*l,i=o*u;t[0]=s*l,t[4]=-s*u,t[8]=c,t[1]=n+r*c,t[5]=e-i*c,t[9]=-o*s,t[2]=i-e*c,t[6]=r+n*c,t[10]=a*s}else if(e.order===`YXZ`){let e=s*l,n=s*u,r=c*l,i=c*u;t[0]=e+i*o,t[4]=r*o-n,t[8]=a*c,t[1]=a*u,t[5]=a*l,t[9]=-o,t[2]=n*o-r,t[6]=i+e*o,t[10]=a*s}else if(e.order===`ZXY`){let e=s*l,n=s*u,r=c*l,i=c*u;t[0]=e-i*o,t[4]=-a*u,t[8]=r+n*o,t[1]=n+r*o,t[5]=a*l,t[9]=i-e*o,t[2]=-a*c,t[6]=o,t[10]=a*s}else if(e.order===`ZYX`){let e=a*l,n=a*u,r=o*l,i=o*u;t[0]=s*l,t[4]=r*c-n,t[8]=e*c+i,t[1]=s*u,t[5]=i*c+e,t[9]=n*c-r,t[2]=-c,t[6]=o*s,t[10]=a*s}else if(e.order===`YZX`){let e=a*s,n=a*c,r=o*s,i=o*c;t[0]=s*l,t[4]=i-e*u,t[8]=r*u+n,t[1]=u,t[5]=a*l,t[9]=-o*l,t[2]=-c*l,t[6]=n*u+r,t[10]=e-i*u}else if(e.order===`XZY`){let e=a*s,n=a*c,r=o*s,i=o*c;t[0]=s*l,t[4]=-u,t[8]=c*l,t[1]=e*u+i,t[5]=a*l,t[9]=n*u-r,t[2]=r*u-n,t[6]=o*l,t[10]=i*u+e}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(Al,e,jl)}lookAt(e,t,n){let r=this.elements;return Pl.subVectors(e,t),Pl.lengthSq()===0&&(Pl.z=1),Pl.normalize(),Ml.crossVectors(n,Pl),Ml.lengthSq()===0&&(Math.abs(n.z)===1?Pl.x+=1e-4:Pl.z+=1e-4,Pl.normalize(),Ml.crossVectors(n,Pl)),Ml.normalize(),Nl.crossVectors(Pl,Ml),r[0]=Ml.x,r[4]=Nl.x,r[8]=Pl.x,r[1]=Ml.y,r[5]=Nl.y,r[9]=Pl.y,r[2]=Ml.z,r[6]=Nl.z,r[10]=Pl.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,r=t.elements,i=this.elements,a=n[0],o=n[4],s=n[8],c=n[12],l=n[1],u=n[5],d=n[9],f=n[13],p=n[2],m=n[6],h=n[10],g=n[14],_=n[3],v=n[7],y=n[11],b=n[15],x=r[0],S=r[4],C=r[8],w=r[12],T=r[1],E=r[5],D=r[9],O=r[13],k=r[2],A=r[6],j=r[10],M=r[14],N=r[3],P=r[7],F=r[11],I=r[15];return i[0]=a*x+o*T+s*k+c*N,i[4]=a*S+o*E+s*A+c*P,i[8]=a*C+o*D+s*j+c*F,i[12]=a*w+o*O+s*M+c*I,i[1]=l*x+u*T+d*k+f*N,i[5]=l*S+u*E+d*A+f*P,i[9]=l*C+u*D+d*j+f*F,i[13]=l*w+u*O+d*M+f*I,i[2]=p*x+m*T+h*k+g*N,i[6]=p*S+m*E+h*A+g*P,i[10]=p*C+m*D+h*j+g*F,i[14]=p*w+m*O+h*M+g*I,i[3]=_*x+v*T+y*k+b*N,i[7]=_*S+v*E+y*A+b*P,i[11]=_*C+v*D+y*j+b*F,i[15]=_*w+v*O+y*M+b*I,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[4],r=e[8],i=e[12],a=e[1],o=e[5],s=e[9],c=e[13],l=e[2],u=e[6],d=e[10],f=e[14],p=e[3],m=e[7],h=e[11],g=e[15],_=s*f-c*d,v=o*f-c*u,y=o*d-s*u,b=a*f-c*l,x=a*d-s*l,S=a*u-o*l;return t*(m*_-h*v+g*y)-n*(p*_-h*b+g*x)+r*(p*v-m*b+g*S)-i*(p*y-m*x+h*S)}determinantAffine(){let e=this.elements,t=e[0],n=e[4],r=e[8],i=e[1],a=e[5],o=e[9],s=e[2],c=e[6],l=e[10];return t*(a*l-o*c)-n*(i*l-o*s)+r*(i*c-a*s)}transpose(){let e=this.elements,t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){let r=this.elements;return e.isVector3?(r[12]=e.x,r[13]=e.y,r[14]=e.z):(r[12]=e,r[13]=t,r[14]=n),this}invert(){let e=this.elements,t=e[0],n=e[1],r=e[2],i=e[3],a=e[4],o=e[5],s=e[6],c=e[7],l=e[8],u=e[9],d=e[10],f=e[11],p=e[12],m=e[13],h=e[14],g=e[15],_=t*o-n*a,v=t*s-r*a,y=t*c-i*a,b=n*s-r*o,x=n*c-i*o,S=r*c-i*s,C=l*m-u*p,w=l*h-d*p,T=l*g-f*p,E=u*h-d*m,D=u*g-f*m,O=d*g-f*h,k=_*O-v*D+y*E+b*T-x*w+S*C;if(k===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let A=1/k;return e[0]=(o*O-s*D+c*E)*A,e[1]=(r*D-n*O-i*E)*A,e[2]=(m*S-h*x+g*b)*A,e[3]=(d*x-u*S-f*b)*A,e[4]=(s*T-a*O-c*w)*A,e[5]=(t*O-r*T+i*w)*A,e[6]=(h*y-p*S-g*v)*A,e[7]=(l*S-d*y+f*v)*A,e[8]=(a*D-o*T+c*C)*A,e[9]=(n*T-t*D-i*C)*A,e[10]=(p*x-m*y+g*_)*A,e[11]=(u*y-l*x-f*_)*A,e[12]=(o*w-a*E-s*C)*A,e[13]=(t*E-n*w+r*C)*A,e[14]=(m*v-p*b-h*_)*A,e[15]=(l*b-u*v+d*_)*A,this}scale(e){let t=this.elements,n=e.x,r=e.y,i=e.z;return t[0]*=n,t[4]*=r,t[8]*=i,t[1]*=n,t[5]*=r,t[9]*=i,t[2]*=n,t[6]*=r,t[10]*=i,t[3]*=n,t[7]*=r,t[11]*=i,this}getMaxScaleOnAxis(){let e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],r=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,r))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){let t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){let n=Math.cos(t),r=Math.sin(t),i=1-n,a=e.x,o=e.y,s=e.z,c=i*a,l=i*o;return this.set(c*a+n,c*o-r*s,c*s+r*o,0,c*o+r*s,l*o+n,l*s-r*a,0,c*s-r*o,l*s+r*a,i*s*s+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,r,i,a){return this.set(1,n,i,0,e,1,a,0,t,r,1,0,0,0,0,1),this}compose(e,t,n){let r=this.elements,i=t._x,a=t._y,o=t._z,s=t._w,c=i+i,l=a+a,u=o+o,d=i*c,f=i*l,p=i*u,m=a*l,h=a*u,g=o*u,_=s*c,v=s*l,y=s*u,b=n.x,x=n.y,S=n.z;return r[0]=(1-(m+g))*b,r[1]=(f+y)*b,r[2]=(p-v)*b,r[3]=0,r[4]=(f-y)*x,r[5]=(1-(d+g))*x,r[6]=(h+_)*x,r[7]=0,r[8]=(p+v)*S,r[9]=(h-_)*S,r[10]=(1-(d+m))*S,r[11]=0,r[12]=e.x,r[13]=e.y,r[14]=e.z,r[15]=1,this}decompose(e,t,n){let r=this.elements;e.x=r[12],e.y=r[13],e.z=r[14];let i=this.determinantAffine();if(i===0)return n.set(1,1,1),t.identity(),this;let a=Ol.set(r[0],r[1],r[2]).length(),o=Ol.set(r[4],r[5],r[6]).length(),s=Ol.set(r[8],r[9],r[10]).length();i<0&&(a=-a),kl.copy(this);let c=1/a,l=1/o,u=1/s;return kl.elements[0]*=c,kl.elements[1]*=c,kl.elements[2]*=c,kl.elements[4]*=l,kl.elements[5]*=l,kl.elements[6]*=l,kl.elements[8]*=u,kl.elements[9]*=u,kl.elements[10]*=u,t.setFromRotationMatrix(kl),n.x=a,n.y=o,n.z=s,this}makePerspective(e,t,n,r,i,a,o=Lc,s=!1){let c=this.elements,l=2*i/(t-e),u=2*i/(n-r),d=(t+e)/(t-e),f=(n+r)/(n-r),p,m;if(s)p=i/(a-i),m=a*i/(a-i);else if(o===2e3)p=-(a+i)/(a-i),m=-2*a*i/(a-i);else if(o===2001)p=-a/(a-i),m=-a*i/(a-i);else throw Error(`THREE.Matrix4.makePerspective(): Invalid coordinate system: `+o);return c[0]=l,c[4]=0,c[8]=d,c[12]=0,c[1]=0,c[5]=u,c[9]=f,c[13]=0,c[2]=0,c[6]=0,c[10]=p,c[14]=m,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(e,t,n,r,i,a,o=Lc,s=!1){let c=this.elements,l=2/(t-e),u=2/(n-r),d=-(t+e)/(t-e),f=-(n+r)/(n-r),p,m;if(s)p=1/(a-i),m=a/(a-i);else if(o===2e3)p=-2/(a-i),m=-(a+i)/(a-i);else if(o===2001)p=-1/(a-i),m=-i/(a-i);else throw Error(`THREE.Matrix4.makeOrthographic(): Invalid coordinate system: `+o);return c[0]=l,c[4]=0,c[8]=0,c[12]=d,c[1]=0,c[5]=u,c[9]=0,c[13]=f,c[2]=0,c[6]=0,c[10]=p,c[14]=m,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(e){let t=this.elements,n=e.elements;for(let e=0;e<16;e++)if(t[e]!==n[e])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}},Ol=new X,kl=new Dl,Al=new X(0,0,0),jl=new X(1,1,1),Ml=new X,Nl=new X,Pl=new X,Fl=new Dl,Il=new il,Ll=class e{constructor(t=0,n=0,r=0,i=e.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=n,this._z=r,this._order=i}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,r=this._order){return this._x=e,this._y=t,this._z=n,this._order=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){let r=e.elements,i=r[0],a=r[4],o=r[8],s=r[1],c=r[5],l=r[9],u=r[2],d=r[6],f=r[10];switch(t){case`XYZ`:this._y=Math.asin($c(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-l,f),this._z=Math.atan2(-a,i)):(this._x=Math.atan2(d,c),this._z=0);break;case`YXZ`:this._x=Math.asin(-$c(l,-1,1)),Math.abs(l)<.9999999?(this._y=Math.atan2(o,f),this._z=Math.atan2(s,c)):(this._y=Math.atan2(-u,i),this._z=0);break;case`ZXY`:this._x=Math.asin($c(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-u,f),this._z=Math.atan2(-a,c)):(this._y=0,this._z=Math.atan2(s,i));break;case`ZYX`:this._y=Math.asin(-$c(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(d,f),this._z=Math.atan2(s,i)):(this._x=0,this._z=Math.atan2(-a,c));break;case`YZX`:this._z=Math.asin($c(s,-1,1)),Math.abs(s)<.9999999?(this._x=Math.atan2(-l,c),this._y=Math.atan2(-u,i)):(this._x=0,this._y=Math.atan2(o,f));break;case`XZY`:this._z=Math.asin(-$c(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(d,c),this._y=Math.atan2(o,i)):(this._x=Math.atan2(-l,f),this._y=0);break;default:q(`Euler: .setFromRotationMatrix() encountered an unknown order: `+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return Fl.makeRotationFromQuaternion(e),this.setFromRotationMatrix(Fl,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return Il.setFromEuler(this),this.setFromQuaternion(Il,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};Ll.DEFAULT_ORDER=`XYZ`;var Rl=class{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return!!(this.mask&(1<<e|0))}},zl=0,Bl=new X,Vl=new il,Hl=new Dl,Ul=new X,Wl=new X,Gl=new X,Kl=new il,ql=new X(1,0,0),Jl=new X(0,1,0),Yl=new X(0,0,1),Xl={type:`added`},Zl={type:`removed`},Ql={type:`childadded`,child:null},$l={type:`childremoved`,child:null},eu=class e extends Jc{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:zl++}),this.uuid=Qc(),this.name=``,this.type=`Object3D`,this.parent=null,this.children=[],this.up=e.DEFAULT_UP.clone();let t=new X,n=new Ll,r=new il,i=new X(1,1,1);function a(){r.setFromEuler(n,!1)}function o(){n.setFromQuaternion(r,void 0,!1)}n._onChange(a),r._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:n},quaternion:{configurable:!0,enumerable:!0,value:r},scale:{configurable:!0,enumerable:!0,value:i},modelViewMatrix:{value:new Dl},normalMatrix:{value:new Z}}),this.matrix=new Dl,this.matrixWorld=new Dl,this.matrixAutoUpdate=e.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=e.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Rl,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return Vl.setFromAxisAngle(e,t),this.quaternion.multiply(Vl),this}rotateOnWorldAxis(e,t){return Vl.setFromAxisAngle(e,t),this.quaternion.premultiply(Vl),this}rotateX(e){return this.rotateOnAxis(ql,e)}rotateY(e){return this.rotateOnAxis(Jl,e)}rotateZ(e){return this.rotateOnAxis(Yl,e)}translateOnAxis(e,t){return Bl.copy(e).applyQuaternion(this.quaternion),this.position.add(Bl.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(ql,e)}translateY(e){return this.translateOnAxis(Jl,e)}translateZ(e){return this.translateOnAxis(Yl,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(Hl.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?Ul.copy(e):Ul.set(e,t,n);let r=this.parent;this.updateWorldMatrix(!0,!1),Wl.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Hl.lookAt(Wl,Ul,this.up):Hl.lookAt(Ul,Wl,this.up),this.quaternion.setFromRotationMatrix(Hl),r&&(Hl.extractRotation(r.matrixWorld),Vl.setFromRotationMatrix(Hl),this.quaternion.premultiply(Vl.invert()))}add(e){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return e===this?(J(`Object3D.add: object can't be added as a child of itself.`,e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(Xl),Ql.child=e,this.dispatchEvent(Ql),Ql.child=null):J(`Object3D.add: object not an instance of THREE.Object3D.`,e),this)}remove(e){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.remove(arguments[e]);return this}let t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(Zl),$l.child=e,this.dispatchEvent($l),$l.child=null),this}removeFromParent(){let e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),Hl.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),Hl.multiply(e.parent.matrixWorld)),e.applyMatrix4(Hl),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(Xl),Ql.child=e,this.dispatchEvent(Ql),Ql.child=null,this}getObjectById(e){return this.getObjectByProperty(`id`,e)}getObjectByName(e){return this.getObjectByProperty(`name`,e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,r=this.children.length;n<r;n++){let r=this.children[n].getObjectByProperty(e,t);if(r!==void 0)return r}}getObjectsByProperty(e,t,n=[]){this[e]===t&&n.push(this);let r=this.children;for(let i=0,a=r.length;i<a;i++)r[i].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Wl,e,Gl),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Wl,Kl,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);let t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}intersectsFrustum(){}traverse(e){e(this);let t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);let t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].traverseVisible(e)}traverseAncestors(e){let t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);let e=this.pivot;if(e!==null){let t=e.x,n=e.y,r=e.z,i=this.matrix.elements;i[12]+=t-i[0]*t-i[4]*n-i[8]*r,i[13]+=n-i[1]*t-i[5]*n-i[9]*r,i[14]+=r-i[2]*t-i[6]*n-i[10]*r}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);let t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].updateMatrixWorld(e)}updateWorldMatrix(e,t,n=!1){let r=this.parent;if(e===!0&&r!==null&&r.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||n)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,n=!0),t===!0){let e=this.children;for(let t=0,r=e.length;t<r;t++)e[t].updateWorldMatrix(!1,!0,n)}}toJSON(e){let t=e===void 0||typeof e==`string`,n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:`Object`,generator:`Object3D.toJSON`});let r={};r.uuid=this.uuid,r.type=this.type,r.name=this.name,r.castShadow=this.castShadow,r.receiveShadow=this.receiveShadow,r.visible=this.visible,r.frustumCulled=this.frustumCulled,r.renderOrder=this.renderOrder,r.static=this.static,r.matrixAutoUpdate=this.matrixAutoUpdate,Object.keys(this.userData).length>0&&(r.userData=this.userData),r.layers=this.layers.mask,r.matrix=this.matrix.toArray(),r.up=this.up.toArray(),this.pivot!==null&&(r.pivot=this.pivot.toArray()),this.morphTargetDictionary!==void 0&&(r.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(r.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(r.type=`InstancedMesh`,r.count=this.count,r.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(r.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(r.type=`BatchedMesh`,r.perObjectFrustumCulled=this.perObjectFrustumCulled,r.sortObjects=this.sortObjects,r.drawRanges=this._drawRanges,r.reservedRanges=this._reservedRanges,r.geometryInfo=this._geometryInfo.map(e=>({...e,boundingBox:e.boundingBox?e.boundingBox.toJSON():void 0,boundingSphere:e.boundingSphere?e.boundingSphere.toJSON():void 0})),r.instanceInfo=this._instanceInfo.map(e=>({...e})),r.availableInstanceIds=this._availableInstanceIds.slice(),r.availableGeometryIds=this._availableGeometryIds.slice(),r.nextIndexStart=this._nextIndexStart,r.nextVertexStart=this._nextVertexStart,r.geometryCount=this._geometryCount,r.maxInstanceCount=this._maxInstanceCount,r.maxVertexCount=this._maxVertexCount,r.maxIndexCount=this._maxIndexCount,r.geometryInitialized=this._geometryInitialized,r.matricesTexture=this._matricesTexture.toJSON(e),r.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(r.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(r.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(r.boundingBox=this.boundingBox.toJSON()));function i(t,n){return t[n.uuid]===void 0&&(t[n.uuid]=n.toJSON(e)),n.uuid}if(this.isScene)this.background&&(this.background.isColor?r.background=this.background.toJSON():this.background.isTexture&&(r.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(r.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){r.geometry=i(e.geometries,this.geometry);let t=this.geometry.parameters;if(t!==void 0&&t.shapes!==void 0){let n=t.shapes;if(Array.isArray(n))for(let t=0,r=n.length;t<r;t++){let r=n[t];i(e.shapes,r)}else i(e.shapes,n)}}if(this.isSkinnedMesh&&(r.bindMode=this.bindMode,r.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(i(e.skeletons,this.skeleton),r.skeleton=this.skeleton.uuid)),this.material!==void 0){if(Array.isArray(this.material)){let t=[];for(let n=0,r=this.material.length;n<r;n++)t.push(i(e.materials,this.material[n]));r.material=t}else r.material=i(e.materials,this.material)}if(this.children.length>0){r.children=[];for(let t=0;t<this.children.length;t++)r.children.push(this.children[t].toJSON(e).object)}if(this.animations.length>0){r.animations=[];for(let t=0;t<this.animations.length;t++){let n=this.animations[t];r.animations.push(i(e.animations,n))}}if(t){let t=a(e.geometries),r=a(e.materials),i=a(e.textures),o=a(e.images),s=a(e.shapes),c=a(e.skeletons),l=a(e.animations),u=a(e.nodes);t.length>0&&(n.geometries=t),r.length>0&&(n.materials=r),i.length>0&&(n.textures=i),o.length>0&&(n.images=o),s.length>0&&(n.shapes=s),c.length>0&&(n.skeletons=c),l.length>0&&(n.animations=l),u.length>0&&(n.nodes=u)}return n.object=r,n;function a(e){let t=[];for(let n in e){let r=e[n];delete r.metadata,t.push(r)}return t}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.pivot=e.pivot===null?null:e.pivot.clone(),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.static=e.static,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let t=0;t<e.children.length;t++){let n=e.children[t];this.add(n.clone())}return this}dispose(){this.dispatchEvent({type:`dispose`})}};eu.DEFAULT_UP=new X(0,1,0),eu.DEFAULT_MATRIX_AUTO_UPDATE=!0,eu.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var tu=class extends eu{constructor(){super(),this.isGroup=!0,this.type=`Group`}},nu={type:`move`},ru=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new tu,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new tu,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new X,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new X),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new tu,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new X,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new X,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){let t=this._hand;if(t)for(let n of e.hand.values())this._getHandJoint(t,n)}return this.dispatchEvent({type:`connected`,data:e}),this}disconnect(e){return this.dispatchEvent({type:`disconnected`,data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,n){let r=null,i=null,a=null,o=this._targetRay,s=this._grip,c=this._hand;if(e&&t.session.visibilityState!==`visible-blurred`){if(c&&e.hand){a=!0;for(let r of e.hand.values()){let e=t.getJointPose(r,n),i=this._getHandJoint(c,r);e!==null&&(i.matrix.fromArray(e.transform.matrix),i.matrix.decompose(i.position,i.rotation,i.scale),i.matrixWorldNeedsUpdate=!0,i.jointRadius=e.radius),i.visible=e!==null}let r=c.joints[`index-finger-tip`],i=c.joints[`thumb-tip`],o=r.position.distanceTo(i.position);c.inputState.pinching&&o>.025?(c.inputState.pinching=!1,this.dispatchEvent({type:`pinchend`,handedness:e.handedness,target:this})):!c.inputState.pinching&&o<=.015&&(c.inputState.pinching=!0,this.dispatchEvent({type:`pinchstart`,handedness:e.handedness,target:this}))}else s!==null&&e.gripSpace&&(i=t.getPose(e.gripSpace,n),i!==null&&(s.matrix.fromArray(i.transform.matrix),s.matrix.decompose(s.position,s.rotation,s.scale),s.matrixWorldNeedsUpdate=!0,i.linearVelocity?(s.hasLinearVelocity=!0,s.linearVelocity.copy(i.linearVelocity)):s.hasLinearVelocity=!1,i.angularVelocity?(s.hasAngularVelocity=!0,s.angularVelocity.copy(i.angularVelocity)):s.hasAngularVelocity=!1,s.eventsEnabled&&s.dispatchEvent({type:`gripUpdated`,data:e,target:this})));o!==null&&(r=t.getPose(e.targetRaySpace,n),r===null&&i!==null&&(r=i),r!==null&&(o.matrix.fromArray(r.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,r.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(r.linearVelocity)):o.hasLinearVelocity=!1,r.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(r.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(nu)))}return o!==null&&(o.visible=r!==null),s!==null&&(s.visible=i!==null),c!==null&&(c.visible=a!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){let n=new tu;n.matrixAutoUpdate=!1,n.visible=!1,e.joints[t.jointName]=n,e.add(n)}return e.joints[t.jointName]}},iu={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},au={h:0,s:0,l:0},ou={h:0,s:0,l:0};function su(e,t,n){return n<0&&(n+=1),n>1&&--n,n<1/6?e+(t-e)*6*n:n<1/2?t:n<2/3?e+(t-e)*6*(2/3-n):e}var cu=class{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){let t=e;t&&t.isColor?this.copy(t):typeof t==`number`?this.setHex(t):typeof t==`string`&&this.setStyle(t)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=jc){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,dl.colorSpaceToWorking(this,t),this}setRGB(e,t,n,r=dl.workingColorSpace){return this.r=e,this.g=t,this.b=n,dl.colorSpaceToWorking(this,r),this}setHSL(e,t,n,r=dl.workingColorSpace){if(e=el(e,1),t=$c(t,0,1),n=$c(n,0,1),t===0)this.r=this.g=this.b=n;else{let r=n<=.5?n*(1+t):n+t-n*t,i=2*n-r;this.r=su(i,r,e+1/3),this.g=su(i,r,e),this.b=su(i,r,e-1/3)}return dl.colorSpaceToWorking(this,r),this}setStyle(e,t=jc){function n(t){t!==void 0&&parseFloat(t)<1&&q(`Color: Alpha component of `+e+` will be ignored.`)}let r;if(r=/^(\w+)\(([^\)]*)\)/.exec(e)){let i,a=r[1],o=r[2];switch(a){case`rgb`:case`rgba`:if(i=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(i[4]),this.setRGB(Math.min(255,parseInt(i[1],10))/255,Math.min(255,parseInt(i[2],10))/255,Math.min(255,parseInt(i[3],10))/255,t);if(i=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(i[4]),this.setRGB(Math.min(100,parseInt(i[1],10))/100,Math.min(100,parseInt(i[2],10))/100,Math.min(100,parseInt(i[3],10))/100,t);break;case`hsl`:case`hsla`:if(i=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(i[4]),this.setHSL(parseFloat(i[1])/360,parseFloat(i[2])/100,parseFloat(i[3])/100,t);break;default:q(`Color: Unknown color model `+e)}}else if(r=/^\#([A-Fa-f\d]+)$/.exec(e)){let n=r[1],i=n.length;if(i===3)return this.setRGB(parseInt(n.charAt(0),16)/15,parseInt(n.charAt(1),16)/15,parseInt(n.charAt(2),16)/15,t);if(i===6)return this.setHex(parseInt(n,16),t);q(`Color: Invalid hex color `+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=jc){let n=iu[e.toLowerCase()];return n===void 0?q(`Color: Unknown color `+e):this.setHex(n,t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=fl(e.r),this.g=fl(e.g),this.b=fl(e.b),this}copyLinearToSRGB(e){return this.r=pl(e.r),this.g=pl(e.g),this.b=pl(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=jc){return dl.workingToColorSpace(lu.copy(this),e),Math.round($c(lu.r*255,0,255))*65536+Math.round($c(lu.g*255,0,255))*256+Math.round($c(lu.b*255,0,255))}getHexString(e=jc){return(`000000`+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=dl.workingColorSpace){dl.workingToColorSpace(lu.copy(this),t);let n=lu.r,r=lu.g,i=lu.b,a=Math.max(n,r,i),o=Math.min(n,r,i),s,c,l=(o+a)/2;if(o===a)s=0,c=0;else{let e=a-o;switch(c=l<=.5?e/(a+o):e/(2-a-o),a){case n:s=(r-i)/e+(r<i?6:0);break;case r:s=(i-n)/e+2;break;case i:s=(n-r)/e+4}s/=6}return e.h=s,e.s=c,e.l=l,e}getRGB(e,t=dl.workingColorSpace){return dl.workingToColorSpace(lu.copy(this),t),e.r=lu.r,e.g=lu.g,e.b=lu.b,e}getStyle(e=jc){dl.workingToColorSpace(lu.copy(this),e);let t=lu.r,n=lu.g,r=lu.b;return e===`srgb`?`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(r*255)})`:`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${r.toFixed(3)})`}offsetHSL(e,t,n){return this.getHSL(au),this.setHSL(au.h+e,au.s+t,au.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(au),e.getHSL(ou);let n=tl(au.h,ou.h,t),r=tl(au.s,ou.s,t),i=tl(au.l,ou.l,t);return this.setHSL(n,r,i),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){let t=this.r,n=this.g,r=this.b,i=e.elements;return this.r=i[0]*t+i[3]*n+i[6]*r,this.g=i[1]*t+i[4]*n+i[7]*r,this.b=i[2]*t+i[5]*n+i[8]*r,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},lu=new cu;cu.NAMES=iu;var uu=class extends eu{constructor(){super(),this.isScene=!0,this.type=`Scene`,this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Ll,this.environmentIntensity=1,this.environmentRotation=new Ll,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<`u`&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent(`observe`,{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){let t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),t.object.backgroundBlurriness=this.backgroundBlurriness,t.object.backgroundIntensity=this.backgroundIntensity,t.object.backgroundRotation=this.backgroundRotation.toArray(),t.object.environmentIntensity=this.environmentIntensity,t.object.environmentRotation=this.environmentRotation.toArray(),t}},du=new X,fu=new X,pu=new X,mu=new X,hu=new X,gu=new X,_u=new X,vu=new X,yu=new X,bu=new X,xu=new Sl,Su=new Sl,Cu=new Sl,wu=class e{constructor(e=new X,t=new X,n=new X){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,r){r.subVectors(n,t),du.subVectors(e,t),r.cross(du);let i=r.lengthSq();return i>0?r.multiplyScalar(1/Math.sqrt(i)):r.set(0,0,0)}static getBarycoord(e,t,n,r,i){du.subVectors(r,t),fu.subVectors(n,t),pu.subVectors(e,t);let a=du.dot(du),o=du.dot(fu),s=du.dot(pu),c=fu.dot(fu),l=fu.dot(pu),u=a*c-o*o;if(u===0)return i.set(0,0,0),null;let d=1/u,f=(c*s-o*l)*d,p=(a*l-o*s)*d;return i.set(1-f-p,p,f)}static containsPoint(e,t,n,r){return this.getBarycoord(e,t,n,r,mu)!==null&&mu.x>=0&&mu.y>=0&&mu.x+mu.y<=1}static getInterpolation(e,t,n,r,i,a,o,s){return this.getBarycoord(e,t,n,r,mu)===null?(s.x=0,s.y=0,`z`in s&&(s.z=0),`w`in s&&(s.w=0),null):(s.setScalar(0),s.addScaledVector(i,mu.x),s.addScaledVector(a,mu.y),s.addScaledVector(o,mu.z),s)}static getInterpolatedAttribute(e,t,n,r,i,a){return xu.setScalar(0),Su.setScalar(0),Cu.setScalar(0),xu.fromBufferAttribute(e,t),Su.fromBufferAttribute(e,n),Cu.fromBufferAttribute(e,r),a.setScalar(0),a.addScaledVector(xu,i.x),a.addScaledVector(Su,i.y),a.addScaledVector(Cu,i.z),a}static isFrontFacing(e,t,n,r){return du.subVectors(n,t),fu.subVectors(e,t),du.cross(fu).dot(r)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,r){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[r]),this}setFromAttributeAndIndices(e,t,n,r){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,r),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return du.subVectors(this.c,this.b),fu.subVectors(this.a,this.b),du.cross(fu).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return e.getNormal(this.a,this.b,this.c,t)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,n){return e.getBarycoord(t,this.a,this.b,this.c,n)}getInterpolation(t,n,r,i,a){return e.getInterpolation(t,this.a,this.b,this.c,n,r,i,a)}containsPoint(t){return e.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return e.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){let n=this.a,r=this.b,i=this.c,a,o;hu.subVectors(r,n),gu.subVectors(i,n),vu.subVectors(e,n);let s=hu.dot(vu),c=gu.dot(vu);if(s<=0&&c<=0)return t.copy(n);yu.subVectors(e,r);let l=hu.dot(yu),u=gu.dot(yu);if(l>=0&&u<=l)return t.copy(r);let d=s*u-l*c;if(d<=0&&s>=0&&l<=0)return a=s/(s-l),t.copy(n).addScaledVector(hu,a);bu.subVectors(e,i);let f=hu.dot(bu),p=gu.dot(bu);if(p>=0&&f<=p)return t.copy(i);let m=f*c-s*p;if(m<=0&&c>=0&&p<=0)return o=c/(c-p),t.copy(n).addScaledVector(gu,o);let h=l*p-f*u;if(h<=0&&u-l>=0&&f-p>=0)return _u.subVectors(i,r),o=(u-l)/(u-l+(f-p)),t.copy(r).addScaledVector(_u,o);let g=1/(h+m+d);return a=m*g,o=d*g,t.copy(n).addScaledVector(hu,a).addScaledVector(gu,o)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}},Tu=class{constructor(e=new X(1/0,1/0,1/0),t=new X(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint(Du.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint(Du.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){let n=Du.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);let n=e.geometry;if(n!==void 0){let r=n.getAttribute(`position`);if(t===!0&&r!==void 0&&e.isInstancedMesh!==!0)for(let t=0,n=r.count;t<n;t++)e.isMesh===!0?e.getVertexPosition(t,Du):Du.fromBufferAttribute(r,t),Du.applyMatrix4(e.matrixWorld),this.expandByPoint(Du);else e.boundingBox===void 0?(n.boundingBox===null&&n.computeBoundingBox(),Ou.copy(n.boundingBox)):(e.boundingBox===null&&e.computeBoundingBox(),Ou.copy(e.boundingBox)),Ou.applyMatrix4(e.matrixWorld),this.union(Ou)}let r=e.children;for(let e=0,n=r.length;e<n;e++)this.expandByObject(r[e],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,Du),Du.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(Fu),Iu.subVectors(this.max,Fu),ku.subVectors(e.a,Fu),Au.subVectors(e.b,Fu),ju.subVectors(e.c,Fu),Mu.subVectors(Au,ku),Nu.subVectors(ju,Au),Pu.subVectors(ku,ju);let t=[0,-Mu.z,Mu.y,0,-Nu.z,Nu.y,0,-Pu.z,Pu.y,Mu.z,0,-Mu.x,Nu.z,0,-Nu.x,Pu.z,0,-Pu.x,-Mu.y,Mu.x,0,-Nu.y,Nu.x,0,-Pu.y,Pu.x,0];return!zu(t,ku,Au,ju,Iu)||(t=[1,0,0,0,1,0,0,0,1],!zu(t,ku,Au,ju,Iu))?!1:(Lu.crossVectors(Mu,Nu),t=[Lu.x,Lu.y,Lu.z],zu(t,ku,Au,ju,Iu))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Du).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(Du).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(Eu[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),Eu[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),Eu[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),Eu[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),Eu[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),Eu[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),Eu[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),Eu[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(Eu),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}},Eu=[new X,new X,new X,new X,new X,new X,new X,new X],Du=new X,Ou=new Tu,ku=new X,Au=new X,ju=new X,Mu=new X,Nu=new X,Pu=new X,Fu=new X,Iu=new X,Lu=new X,Ru=new X;function zu(e,t,n,r,i){for(let a=0,o=e.length-3;a<=o;a+=3){Ru.fromArray(e,a);let o=i.x*Math.abs(Ru.x)+i.y*Math.abs(Ru.y)+i.z*Math.abs(Ru.z),s=t.dot(Ru),c=n.dot(Ru),l=r.dot(Ru);if(Math.max(-Math.max(s,c,l),Math.min(s,c,l))>o)return!1}return!0}var Bu=new X,Vu=new Y,Hu=0,Uu=class extends Jc{constructor(e,t,n=!1){if(super(),Array.isArray(e))throw TypeError(`THREE.BufferAttribute: array should be a Typed Array.`);this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:Hu++}),this.name=``,this.array=e,this.itemSize=t,this.count=e===void 0?0:e.length/t,this.normalized=n,this.usage=Ic,this.updateRanges=[],this.gpuType=ws,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let r=0,i=this.itemSize;r<i;r++)this.array[e+r]=t.array[n+r];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)Vu.fromBufferAttribute(this,t),Vu.applyMatrix3(e),this.setXY(t,Vu.x,Vu.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)Bu.fromBufferAttribute(this,t),Bu.applyMatrix3(e),this.setXYZ(t,Bu.x,Bu.y,Bu.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)Bu.fromBufferAttribute(this,t),Bu.applyMatrix4(e),this.setXYZ(t,Bu.x,Bu.y,Bu.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)Bu.fromBufferAttribute(this,t),Bu.applyNormalMatrix(e),this.setXYZ(t,Bu.x,Bu.y,Bu.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)Bu.fromBufferAttribute(this,t),Bu.transformDirection(e),this.setXYZ(t,Bu.x,Bu.y,Bu.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];return this.normalized&&(n=nl(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=rl(n,this.array)),this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=nl(t,this.array)),t}setX(e,t){return this.normalized&&(t=rl(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=nl(t,this.array)),t}setY(e,t){return this.normalized&&(t=rl(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=nl(t,this.array)),t}setZ(e,t){return this.normalized&&(t=rl(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=nl(t,this.array)),t}setW(e,t){return this.normalized&&(t=rl(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=rl(t,this.array),n=rl(n,this.array)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,r){return e*=this.itemSize,this.normalized&&(t=rl(t,this.array),n=rl(n,this.array),r=rl(r,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=r,this}setXYZW(e,t,n,r,i){return e*=this.itemSize,this.normalized&&(t=rl(t,this.array),n=rl(n,this.array),r=rl(r,this.array),i=rl(i,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=r,this.array[e+3]=i,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return e.name=this.name,e.usage=this.usage,e.gpuType=this.gpuType,e}dispose(){this.dispatchEvent({type:`dispose`})}},Wu=class extends Uu{constructor(e,t,n){super(new Uint16Array(e),t,n)}},Gu=class extends Uu{constructor(e,t,n){super(new Uint32Array(e),t,n)}},Ku=class extends Uu{constructor(e,t,n){super(new Float32Array(e),t,n)}},qu=new Tu,Ju=new X,Yu=new X,Xu=class{constructor(e=new X,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){let n=this.center;t===void 0?qu.setFromPoints(e).getCenter(n):n.copy(t);let r=0;for(let t=0,i=e.length;t<i;t++)r=Math.max(r,n.distanceToSquared(e[t]));return this.radius=Math.sqrt(r),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){let t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){let n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius*=e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;Ju.subVectors(e,this.center);let t=Ju.lengthSq();if(t>this.radius*this.radius){let e=Math.sqrt(t),n=(e-this.radius)*.5;this.center.addScaledVector(Ju,n/e),this.radius+=n}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Yu.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(Ju.copy(e.center).add(Yu)),this.expandByPoint(Ju.copy(e.center).sub(Yu))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}},Zu=0,Qu=new Dl,$u=new eu,ed=new X,td=new Tu,nd=new Tu,rd=new X,id=class e extends Jc{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:Zu++}),this.uuid=Qc(),this.name=``,this.type=`BufferGeometry`,this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(e){return this.index=Array.isArray(e)?new(Rc(e)?Gu:Wu)(e,1):e,this}setIndirect(e,t=0){return this.indirect=e,this.indirectOffset=t,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){let t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);let n=this.attributes.normal;if(n!==void 0){let t=new Z().getNormalMatrix(e);n.applyNormalMatrix(t),n.needsUpdate=!0}let r=this.attributes.tangent;return r!==void 0&&(r.transformDirection(e),r.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(e){return Qu.makeRotationFromQuaternion(e),this.applyMatrix4(Qu),this}rotateX(e){return Qu.makeRotationX(e),this.applyMatrix4(Qu),this}rotateY(e){return Qu.makeRotationY(e),this.applyMatrix4(Qu),this}rotateZ(e){return Qu.makeRotationZ(e),this.applyMatrix4(Qu),this}translate(e,t,n){return Qu.makeTranslation(e,t,n),this.applyMatrix4(Qu),this}scale(e,t,n){return Qu.makeScale(e,t,n),this.applyMatrix4(Qu),this}lookAt(e){return $u.lookAt(e),$u.updateMatrix(),this.applyMatrix4($u.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(ed).negate(),this.translate(ed.x,ed.y,ed.z),this}setFromPoints(e){let t=this.getAttribute(`position`);if(t===void 0){let t=[];for(let n=0,r=e.length;n<r;n++){let r=e[n];t.push(r.x,r.y,r.z||0)}this.setAttribute(`position`,new Ku(t,3))}else{let n=Math.min(e.length,t.count);for(let r=0;r<n;r++){let n=e[r];t.setXYZ(r,n.x,n.y,n.z||0)}e.length>t.count&&q(`BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry.`),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Tu);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){J(`BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.`,this),this.boundingBox.set(new X(-1/0,-1/0,-1/0),new X(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let e=0,n=t.length;e<n;e++){let n=t[e];td.setFromBufferAttribute(n),this.morphTargetsRelative?(rd.addVectors(this.boundingBox.min,td.min),this.boundingBox.expandByPoint(rd),rd.addVectors(this.boundingBox.max,td.max),this.boundingBox.expandByPoint(rd)):(this.boundingBox.expandByPoint(td.min),this.boundingBox.expandByPoint(td.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&J(`BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.`,this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Xu);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){J(`BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.`,this),this.boundingSphere.set(new X,1/0);return}if(e){let n=this.boundingSphere.center;if(td.setFromBufferAttribute(e),t)for(let e=0,n=t.length;e<n;e++){let n=t[e];nd.setFromBufferAttribute(n),this.morphTargetsRelative?(rd.addVectors(td.min,nd.min),td.expandByPoint(rd),rd.addVectors(td.max,nd.max),td.expandByPoint(rd)):(td.expandByPoint(nd.min),td.expandByPoint(nd.max))}td.getCenter(n);let r=0;for(let t=0,i=e.count;t<i;t++)rd.fromBufferAttribute(e,t),r=Math.max(r,n.distanceToSquared(rd));if(t)for(let i=0,a=t.length;i<a;i++){let a=t[i],o=this.morphTargetsRelative;for(let t=0,i=a.count;t<i;t++)rd.fromBufferAttribute(a,t),o&&(ed.fromBufferAttribute(e,t),rd.add(ed)),r=Math.max(r,n.distanceToSquared(rd))}this.boundingSphere.radius=Math.sqrt(r),isNaN(this.boundingSphere.radius)&&J(`BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.`,this)}}computeTangents(){let e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){J(`BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)`);return}let n=t.position,r=t.normal,i=t.uv,a=this.getAttribute(`tangent`);(a===void 0||a.count!==n.count)&&(a=new Uu(new Float32Array(4*n.count),4),this.setAttribute(`tangent`,a));let o=[],s=[];for(let e=0;e<n.count;e++)o[e]=new X,s[e]=new X;let c=new X,l=new X,u=new X,d=new Y,f=new Y,p=new Y,m=new X,h=new X;function g(e,t,r){c.fromBufferAttribute(n,e),l.fromBufferAttribute(n,t),u.fromBufferAttribute(n,r),d.fromBufferAttribute(i,e),f.fromBufferAttribute(i,t),p.fromBufferAttribute(i,r),l.sub(c),u.sub(c),f.sub(d),p.sub(d);let a=1/(f.x*p.y-p.x*f.y);isFinite(a)&&(m.copy(l).multiplyScalar(p.y).addScaledVector(u,-f.y).multiplyScalar(a),h.copy(u).multiplyScalar(f.x).addScaledVector(l,-p.x).multiplyScalar(a),o[e].add(m),o[t].add(m),o[r].add(m),s[e].add(h),s[t].add(h),s[r].add(h))}let _=this.groups;_.length===0&&(_=[{start:0,count:e.count}]);for(let t=0,n=_.length;t<n;++t){let n=_[t],r=n.start,i=n.count;for(let t=r,n=r+i;t<n;t+=3)g(e.getX(t+0),e.getX(t+1),e.getX(t+2))}let v=new X,y=new X,b=new X,x=new X;function S(e){b.fromBufferAttribute(r,e),x.copy(b);let t=o[e];v.copy(t),v.sub(b.multiplyScalar(b.dot(t))).normalize(),y.crossVectors(x,t);let n=y.dot(s[e])<0?-1:1;a.setXYZW(e,v.x,v.y,v.z,n)}for(let t=0,n=_.length;t<n;++t){let n=_[t],r=n.start,i=n.count;for(let t=r,n=r+i;t<n;t+=3)S(e.getX(t+0)),S(e.getX(t+1)),S(e.getX(t+2))}this._transformed=!0}computeVertexNormals(){let e=this.index,t=this.getAttribute(`position`);if(t!==void 0){let n=this.getAttribute(`normal`);if(n===void 0||n.count!==t.count)n=new Uu(new Float32Array(t.count*3),3),this.setAttribute(`normal`,n);else for(let e=0,t=n.count;e<t;e++)n.setXYZ(e,0,0,0);let r=new X,i=new X,a=new X,o=new X,s=new X,c=new X,l=new X,u=new X;if(e)for(let d=0,f=e.count;d<f;d+=3){let f=e.getX(d+0),p=e.getX(d+1),m=e.getX(d+2);r.fromBufferAttribute(t,f),i.fromBufferAttribute(t,p),a.fromBufferAttribute(t,m),l.subVectors(a,i),u.subVectors(r,i),l.cross(u),o.fromBufferAttribute(n,f),s.fromBufferAttribute(n,p),c.fromBufferAttribute(n,m),o.add(l),s.add(l),c.add(l),n.setXYZ(f,o.x,o.y,o.z),n.setXYZ(p,s.x,s.y,s.z),n.setXYZ(m,c.x,c.y,c.z)}else for(let e=0,o=t.count;e<o;e+=3)r.fromBufferAttribute(t,e+0),i.fromBufferAttribute(t,e+1),a.fromBufferAttribute(t,e+2),l.subVectors(a,i),u.subVectors(r,i),l.cross(u),n.setXYZ(e+0,l.x,l.y,l.z),n.setXYZ(e+1,l.x,l.y,l.z),n.setXYZ(e+2,l.x,l.y,l.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){let e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)rd.fromBufferAttribute(e,t),rd.normalize(),e.setXYZ(t,rd.x,rd.y,rd.z)}toNonIndexed(){function t(e,t){let n=e.array,r=e.itemSize,i=e.normalized,a=new n.constructor(t.length*r),o=0,s=0;for(let i=0,c=t.length;i<c;i++){o=e.isInterleavedBufferAttribute?t[i]*e.data.stride+e.offset:t[i]*r;for(let e=0;e<r;e++)a[s++]=n[o++]}return new Uu(a,r,i)}if(this.index===null)return q(`BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed.`),this;let n=new e,r=this.index.array,i=this.attributes;for(let e in i){let a=i[e],o=t(a,r);n.setAttribute(e,o)}let a=this.morphAttributes;for(let e in a){let i=[],o=a[e];for(let e=0,n=o.length;e<n;e++){let n=o[e],a=t(n,r);i.push(a)}n.morphAttributes[e]=i}n.morphTargetsRelative=this.morphTargetsRelative;let o=this.groups;for(let e=0,t=o.length;e<t;e++){let t=o[e];n.addGroup(t.start,t.count,t.materialIndex)}return n}toJSON(){let e={metadata:{version:4.7,type:`BufferGeometry`,generator:`BufferGeometry.toJSON`}};if(e.uuid=this.uuid,e.type=this.parameters!==void 0&&this._transformed===!0?`BufferGeometry`:this.type,e.name=this.name,Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){let t=this.parameters;for(let n in t)t[n]!==void 0&&(e[n]=t[n]);return e}e.data={attributes:{}};let t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});let n=this.attributes;for(let t in n){let r=n[t];e.data.attributes[t]=r.toJSON(e.data)}let r={},i=!1;for(let t in this.morphAttributes){let n=this.morphAttributes[t],a=[];for(let t=0,r=n.length;t<r;t++){let r=n[t];a.push(r.toJSON(e.data))}a.length>0&&(r[t]=a,i=!0)}i&&(e.data.morphAttributes=r,e.data.morphTargetsRelative=this.morphTargetsRelative);let a=this.groups;a.length>0&&(e.data.groups=JSON.parse(JSON.stringify(a)));let o=this.boundingSphere;return o!==null&&(e.data.boundingSphere=o.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let t={};this.name=e.name;let n=e.index;n!==null&&this.setIndex(n.clone());let r=e.attributes;for(let e in r){let n=r[e];this.setAttribute(e,n.clone(t))}let i=e.morphAttributes;for(let e in i){let n=[],r=i[e];for(let e=0,i=r.length;e<i;e++)n.push(r[e].clone(t));this.morphAttributes[e]=n}this.morphTargetsRelative=e.morphTargetsRelative;let a=e.groups;for(let e=0,t=a.length;e<t;e++){let t=a[e];this.addGroup(t.start,t.count,t.materialIndex)}let o=e.boundingBox;o!==null&&(this.boundingBox=o.clone());let s=e.boundingSphere;return s!==null&&(this.boundingSphere=s.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this._transformed=e._transformed,this}dispose(){this.dispatchEvent({type:`dispose`})}},ad=class{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e===void 0?0:e.length/t,this.usage=Ic,this.updateRanges=[],this.version=0,this.uuid=Qc()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,n){e*=this.stride,n*=t.stride;for(let r=0,i=this.stride;r<i;r++)this.array[e+r]=t.array[n+r];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Qc()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);let t=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(t,this.stride);return n.setUsage(this.usage),n}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Qc()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer)));let t={uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride};return t.usage=this.usage,t}},od=new X,sd=class e{constructor(e,t,n,r=!1){this.isInterleavedBufferAttribute=!0,this.name=``,this.data=e,this.itemSize=t,this.offset=n,this.normalized=r}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,n=this.data.count;t<n;t++)od.fromBufferAttribute(this,t),od.applyMatrix4(e),this.setXYZ(t,od.x,od.y,od.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)od.fromBufferAttribute(this,t),od.applyNormalMatrix(e),this.setXYZ(t,od.x,od.y,od.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)od.fromBufferAttribute(this,t),od.transformDirection(e),this.setXYZ(t,od.x,od.y,od.z);return this}getComponent(e,t){let n=this.array[e*this.data.stride+this.offset+t];return this.normalized&&(n=nl(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=rl(n,this.array)),this.data.array[e*this.data.stride+this.offset+t]=n,this}setX(e,t){return this.normalized&&(t=rl(t,this.array)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=rl(t,this.array)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=rl(t,this.array)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=rl(t,this.array)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=nl(t,this.array)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=nl(t,this.array)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=nl(t,this.array)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=nl(t,this.array)),t}setXY(e,t,n){return e=e*this.data.stride+this.offset,this.normalized&&(t=rl(t,this.array),n=rl(n,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this}setXYZ(e,t,n,r){return e=e*this.data.stride+this.offset,this.normalized&&(t=rl(t,this.array),n=rl(n,this.array),r=rl(r,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=r,this}setXYZW(e,t,n,r,i){return e=e*this.data.stride+this.offset,this.normalized&&(t=rl(t,this.array),n=rl(n,this.array),r=rl(r,this.array),i=rl(i,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=r,this.data.array[e+3]=i,this}clone(t){if(t===void 0){Uc(`InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.`);let e=[];for(let t=0;t<this.count;t++){let n=t*this.data.stride+this.offset;for(let t=0;t<this.itemSize;t++)e.push(this.data.array[n+t])}return new Uu(new this.array.constructor(e),this.itemSize,this.normalized)}return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.clone(t)),new e(t.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){Uc(`InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.`);let e=[];for(let t=0;t<this.count;t++){let n=t*this.data.stride+this.offset;for(let t=0;t<this.itemSize;t++)e.push(this.data.array[n+t])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:e,normalized:this.normalized}}return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}},cd=new X,ld=new X,ud=new Z,dd=class{constructor(e=new X(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,r){return this.normal.set(e,t,n),this.constant=r,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){let r=cd.subVectors(n,t).cross(ld.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(r,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){let e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t,n=!0){let r=e.delta(cd),i=this.normal.dot(r);if(i===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;let a=-(e.start.dot(this.normal)+this.constant)/i;return n===!0&&(a<0||a>1)?null:t.copy(e.start).addScaledVector(r,a)}intersectsLine(e){let t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){let n=t||ud.getNormalMatrix(e),r=this.coplanarPoint(cd).applyMatrix4(e),i=this.normal.applyMatrix3(n).normalize();return this.constant=-r.dot(i),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}toJSON(){return{normal:this.normal.toArray(),constant:this.constant}}fromJSON(e){return this.normal.fromArray(e.normal),this.constant=e.constant,this}},fd=0,pd=class extends Jc{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:fd++}),this.uuid=Qc(),this.name=``,this.type=`Material`,this.blending=1,this.side=0,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=204,this.blendDst=205,this.blendEquation=100,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new cu(0,0,0),this.blendAlpha=0,this.depthFunc=3,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=519,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Fc,this.stencilZFail=Fc,this.stencilZPass=Fc,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(let t in e){let n=e[t];if(n===void 0){q(`Material: parameter '${t}' has value of undefined.`);continue}let r=this[t];if(r===void 0){q(`Material: '${t}' is not a property of THREE.${this.type}.`);continue}r&&r.isColor?r.set(n):r&&r.isVector2&&n&&n.isVector2||r&&r.isEuler&&n&&n.isEuler||r&&r.isVector3&&n&&n.isVector3?r.copy(n):this[t]=n}}toJSON(e){let t=e===void 0||typeof e==`string`;t&&(e={textures:{},images:{}});let n={metadata:{version:4.7,type:`Material`,generator:`Material.toJSON`}};n.uuid=this.uuid,n.type=this.type,n.blending=this.blending,n.side=this.side,n.shadowSide=this.shadowSide,n.vertexColors=this.vertexColors,n.opacity=this.opacity,n.transparent=this.transparent,n.blendSrc=this.blendSrc,n.blendDst=this.blendDst,n.blendEquation=this.blendEquation,n.blendSrcAlpha=this.blendSrcAlpha,n.blendDstAlpha=this.blendDstAlpha,n.blendEquationAlpha=this.blendEquationAlpha,n.blendColor=this.blendColor.getHex(),n.blendAlpha=this.blendAlpha,n.depthFunc=this.depthFunc,n.depthTest=this.depthTest,n.depthWrite=this.depthWrite,n.colorWrite=this.colorWrite,n.clipIntersection=this.clipIntersection,n.clipShadows=this.clipShadows,n.stencilWriteMask=this.stencilWriteMask,n.stencilFunc=this.stencilFunc,n.stencilRef=this.stencilRef,n.stencilFuncMask=this.stencilFuncMask,n.stencilFail=this.stencilFail,n.stencilZFail=this.stencilZFail,n.stencilZPass=this.stencilZPass,n.stencilWrite=this.stencilWrite,n.polygonOffset=this.polygonOffset,n.polygonOffsetFactor=this.polygonOffsetFactor,n.polygonOffsetUnits=this.polygonOffsetUnits,n.dithering=this.dithering,n.alphaTest=this.alphaTest,n.alphaHash=this.alphaHash,n.alphaToCoverage=this.alphaToCoverage,n.premultipliedAlpha=this.premultipliedAlpha,n.forceSinglePass=this.forceSinglePass,n.allowOverride=this.allowOverride,n.visible=this.visible,n.toneMapped=this.toneMapped,n.name=this.name,this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(n.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.retroreflectivity!==void 0&&(n.retroreflectivity=this.retroreflectivity),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),Array.isArray(this.clippingPlanes)&&this.clippingPlanes.length>0&&(n.clippingPlanes=this.clippingPlanes.map(e=>e.toJSON())),this.rotation!==void 0&&(n.rotation=this.rotation),this.depthPacking!==void 0&&(n.depthPacking=this.depthPacking),this.linewidth!==void 0&&(n.linewidth=this.linewidth),this.linecap!==void 0&&(n.linecap=this.linecap),this.linejoin!==void 0&&(n.linejoin=this.linejoin),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.wireframe!==void 0&&(n.wireframe=this.wireframe),this.wireframeLinewidth!==void 0&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!==void 0&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!==void 0&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading!==void 0&&(n.flatShading=this.flatShading),this.fog!==void 0&&(n.fog=this.fog),Object.keys(this.userData).length>0&&(n.userData=this.userData);function r(e){let t=[];for(let n in e){let r=e[n];delete r.metadata,t.push(r)}return t}if(t){let t=r(e.textures),i=r(e.images);t.length>0&&(n.textures=t),i.length>0&&(n.images=i)}return n}fromJSON(e,t){if(e.uuid!==void 0&&(this.uuid=e.uuid),e.name!==void 0&&(this.name=e.name),e.color!==void 0&&this.color!==void 0&&this.color.setHex(e.color),e.roughness!==void 0&&(this.roughness=e.roughness),e.metalness!==void 0&&(this.metalness=e.metalness),e.sheen!==void 0&&(this.sheen=e.sheen),e.sheenColor!==void 0&&(this.sheenColor=new cu().setHex(e.sheenColor)),e.sheenRoughness!==void 0&&(this.sheenRoughness=e.sheenRoughness),e.emissive!==void 0&&this.emissive!==void 0&&this.emissive.setHex(e.emissive),e.specular!==void 0&&this.specular!==void 0&&this.specular.setHex(e.specular),e.specularIntensity!==void 0&&(this.specularIntensity=e.specularIntensity),e.specularColor!==void 0&&this.specularColor!==void 0&&this.specularColor.setHex(e.specularColor),e.shininess!==void 0&&(this.shininess=e.shininess),e.clearcoat!==void 0&&(this.clearcoat=e.clearcoat),e.clearcoatRoughness!==void 0&&(this.clearcoatRoughness=e.clearcoatRoughness),e.dispersion!==void 0&&(this.dispersion=e.dispersion),e.retroreflectivity!==void 0&&(this.retroreflectivity=e.retroreflectivity),e.iridescence!==void 0&&(this.iridescence=e.iridescence),e.iridescenceIOR!==void 0&&(this.iridescenceIOR=e.iridescenceIOR),e.iridescenceThicknessRange!==void 0&&(this.iridescenceThicknessRange=e.iridescenceThicknessRange),e.transmission!==void 0&&(this.transmission=e.transmission),e.thickness!==void 0&&(this.thickness=e.thickness),e.attenuationDistance!==void 0&&(this.attenuationDistance=e.attenuationDistance),e.attenuationColor!==void 0&&this.attenuationColor!==void 0&&this.attenuationColor.setHex(e.attenuationColor),e.anisotropy!==void 0&&(this.anisotropy=e.anisotropy),e.anisotropyRotation!==void 0&&(this.anisotropyRotation=e.anisotropyRotation),e.fog!==void 0&&(this.fog=e.fog),e.flatShading!==void 0&&(this.flatShading=e.flatShading),e.blending!==void 0&&(this.blending=e.blending),e.combine!==void 0&&(this.combine=e.combine),e.side!==void 0&&(this.side=e.side),e.shadowSide!==void 0&&(this.shadowSide=e.shadowSide),e.opacity!==void 0&&(this.opacity=e.opacity),e.transparent!==void 0&&(this.transparent=e.transparent),e.alphaTest!==void 0&&(this.alphaTest=e.alphaTest),e.alphaHash!==void 0&&(this.alphaHash=e.alphaHash),e.depthFunc!==void 0&&(this.depthFunc=e.depthFunc),e.depthTest!==void 0&&(this.depthTest=e.depthTest),e.depthWrite!==void 0&&(this.depthWrite=e.depthWrite),e.colorWrite!==void 0&&(this.colorWrite=e.colorWrite),e.clippingPlanes!==void 0&&(this.clippingPlanes=e.clippingPlanes.map(e=>new dd().fromJSON(e))),e.clipIntersection!==void 0&&(this.clipIntersection=e.clipIntersection),e.clipShadows!==void 0&&(this.clipShadows=e.clipShadows),e.depthPacking!==void 0&&(this.depthPacking=e.depthPacking),e.blendSrc!==void 0&&(this.blendSrc=e.blendSrc),e.blendDst!==void 0&&(this.blendDst=e.blendDst),e.blendEquation!==void 0&&(this.blendEquation=e.blendEquation),e.blendSrcAlpha!==void 0&&(this.blendSrcAlpha=e.blendSrcAlpha),e.blendDstAlpha!==void 0&&(this.blendDstAlpha=e.blendDstAlpha),e.blendEquationAlpha!==void 0&&(this.blendEquationAlpha=e.blendEquationAlpha),e.blendColor!==void 0&&this.blendColor!==void 0&&this.blendColor.setHex(e.blendColor),e.blendAlpha!==void 0&&(this.blendAlpha=e.blendAlpha),e.stencilWriteMask!==void 0&&(this.stencilWriteMask=e.stencilWriteMask),e.stencilFunc!==void 0&&(this.stencilFunc=e.stencilFunc),e.stencilRef!==void 0&&(this.stencilRef=e.stencilRef),e.stencilFuncMask!==void 0&&(this.stencilFuncMask=e.stencilFuncMask),e.stencilFail!==void 0&&(this.stencilFail=e.stencilFail),e.stencilZFail!==void 0&&(this.stencilZFail=e.stencilZFail),e.stencilZPass!==void 0&&(this.stencilZPass=e.stencilZPass),e.stencilWrite!==void 0&&(this.stencilWrite=e.stencilWrite),e.wireframe!==void 0&&(this.wireframe=e.wireframe),e.wireframeLinewidth!==void 0&&(this.wireframeLinewidth=e.wireframeLinewidth),e.wireframeLinecap!==void 0&&(this.wireframeLinecap=e.wireframeLinecap),e.wireframeLinejoin!==void 0&&(this.wireframeLinejoin=e.wireframeLinejoin),e.rotation!==void 0&&(this.rotation=e.rotation),e.linewidth!==void 0&&(this.linewidth=e.linewidth),e.linecap!==void 0&&(this.linecap=e.linecap),e.linejoin!==void 0&&(this.linejoin=e.linejoin),e.dashSize!==void 0&&(this.dashSize=e.dashSize),e.gapSize!==void 0&&(this.gapSize=e.gapSize),e.scale!==void 0&&(this.scale=e.scale),e.polygonOffset!==void 0&&(this.polygonOffset=e.polygonOffset),e.polygonOffsetFactor!==void 0&&(this.polygonOffsetFactor=e.polygonOffsetFactor),e.polygonOffsetUnits!==void 0&&(this.polygonOffsetUnits=e.polygonOffsetUnits),e.dithering!==void 0&&(this.dithering=e.dithering),e.alphaToCoverage!==void 0&&(this.alphaToCoverage=e.alphaToCoverage),e.premultipliedAlpha!==void 0&&(this.premultipliedAlpha=e.premultipliedAlpha),e.forceSinglePass!==void 0&&(this.forceSinglePass=e.forceSinglePass),e.allowOverride!==void 0&&(this.allowOverride=e.allowOverride),e.visible!==void 0&&(this.visible=e.visible),e.toneMapped!==void 0&&(this.toneMapped=e.toneMapped),e.userData!==void 0&&(this.userData=e.userData),e.vertexColors!==void 0&&(this.vertexColors=typeof e.vertexColors==`number`?e.vertexColors>0:e.vertexColors),e.size!==void 0&&(this.size=e.size),e.sizeAttenuation!==void 0&&(this.sizeAttenuation=e.sizeAttenuation),e.map!==void 0&&(this.map=t[e.map]||null),e.matcap!==void 0&&(this.matcap=t[e.matcap]||null),e.alphaMap!==void 0&&(this.alphaMap=t[e.alphaMap]||null),e.bumpMap!==void 0&&(this.bumpMap=t[e.bumpMap]||null),e.bumpScale!==void 0&&(this.bumpScale=e.bumpScale),e.normalMap!==void 0&&(this.normalMap=t[e.normalMap]||null),e.normalMapType!==void 0&&(this.normalMapType=e.normalMapType),e.normalScale!==void 0){let t=e.normalScale;Array.isArray(t)===!1&&(t=[t,t]),this.normalScale=new Y().fromArray(t)}return e.displacementMap!==void 0&&(this.displacementMap=t[e.displacementMap]||null),e.displacementScale!==void 0&&(this.displacementScale=e.displacementScale),e.displacementBias!==void 0&&(this.displacementBias=e.displacementBias),e.roughnessMap!==void 0&&(this.roughnessMap=t[e.roughnessMap]||null),e.metalnessMap!==void 0&&(this.metalnessMap=t[e.metalnessMap]||null),e.emissiveMap!==void 0&&(this.emissiveMap=t[e.emissiveMap]||null),e.emissiveIntensity!==void 0&&(this.emissiveIntensity=e.emissiveIntensity),e.specularMap!==void 0&&(this.specularMap=t[e.specularMap]||null),e.specularIntensityMap!==void 0&&(this.specularIntensityMap=t[e.specularIntensityMap]||null),e.specularColorMap!==void 0&&(this.specularColorMap=t[e.specularColorMap]||null),e.envMap!==void 0&&(this.envMap=t[e.envMap]||null),e.envMapRotation!==void 0&&this.envMapRotation.fromArray(e.envMapRotation),e.envMapIntensity!==void 0&&(this.envMapIntensity=e.envMapIntensity),e.reflectivity!==void 0&&(this.reflectivity=e.reflectivity),e.refractionRatio!==void 0&&(this.refractionRatio=e.refractionRatio),e.lightMap!==void 0&&(this.lightMap=t[e.lightMap]||null),e.lightMapIntensity!==void 0&&(this.lightMapIntensity=e.lightMapIntensity),e.aoMap!==void 0&&(this.aoMap=t[e.aoMap]||null),e.aoMapIntensity!==void 0&&(this.aoMapIntensity=e.aoMapIntensity),e.gradientMap!==void 0&&(this.gradientMap=t[e.gradientMap]||null),e.clearcoatMap!==void 0&&(this.clearcoatMap=t[e.clearcoatMap]||null),e.clearcoatRoughnessMap!==void 0&&(this.clearcoatRoughnessMap=t[e.clearcoatRoughnessMap]||null),e.clearcoatNormalMap!==void 0&&(this.clearcoatNormalMap=t[e.clearcoatNormalMap]||null),e.clearcoatNormalScale!==void 0&&(this.clearcoatNormalScale=new Y().fromArray(e.clearcoatNormalScale)),e.iridescenceMap!==void 0&&(this.iridescenceMap=t[e.iridescenceMap]||null),e.iridescenceThicknessMap!==void 0&&(this.iridescenceThicknessMap=t[e.iridescenceThicknessMap]||null),e.transmissionMap!==void 0&&(this.transmissionMap=t[e.transmissionMap]||null),e.thicknessMap!==void 0&&(this.thicknessMap=t[e.thicknessMap]||null),e.anisotropyMap!==void 0&&(this.anisotropyMap=t[e.anisotropyMap]||null),e.sheenColorMap!==void 0&&(this.sheenColorMap=t[e.sheenColorMap]||null),e.sheenRoughnessMap!==void 0&&(this.sheenRoughnessMap=t[e.sheenRoughnessMap]||null),this}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;let t=e.clippingPlanes,n=null;if(t!==null){let e=t.length;n=Array(e);for(let r=0;r!==e;++r)n[r]=t[r].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.allowOverride=e.allowOverride,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:`dispose`})}set needsUpdate(e){e===!0&&this.version++}},md=class extends pd{constructor(e){super(),this.isSpriteMaterial=!0,this.type=`SpriteMaterial`,this.color=new cu(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.rotation=e.rotation,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}},hd,gd=new X,_d=new X,vd=new X,yd=new Y,bd=new Y,xd=new Dl,Sd=new X,Cd=new X,wd=new X,Td=new Y,Ed=new Y,Dd=new Y,Od=class extends eu{constructor(e=new md){if(super(),this.isSprite=!0,this.type=`Sprite`,hd===void 0){hd=new id;let e=new ad(new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),5);hd.setIndex([0,1,2,0,2,3]),hd.setAttribute(`position`,new sd(e,3,0,!1)),hd.setAttribute(`uv`,new sd(e,2,3,!1))}this.geometry=hd,this.material=e,this.center=new Y(.5,.5),this.count=1}intersectsFrustum(e){return e.intersectsSprite(this)}raycast(e,t){e.camera===null&&J(`Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.`),_d.setFromMatrixScale(this.matrixWorld),xd.copy(e.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(e.camera.matrixWorldInverse,this.matrixWorld),vd.setFromMatrixPosition(this.modelViewMatrix),e.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&_d.multiplyScalar(-vd.z);let n=this.material.rotation,r,i;n!==0&&(i=Math.cos(n),r=Math.sin(n));let a=this.center;kd(Sd.set(-.5,-.5,0),vd,a,_d,r,i),kd(Cd.set(.5,-.5,0),vd,a,_d,r,i),kd(wd.set(.5,.5,0),vd,a,_d,r,i),Td.set(0,0),Ed.set(1,0),Dd.set(1,1);let o=e.ray.intersectTriangle(Sd,Cd,wd,!1,gd);if(o===null&&(kd(Cd.set(-.5,.5,0),vd,a,_d,r,i),Ed.set(0,1),o=e.ray.intersectTriangle(Sd,wd,Cd,!1,gd),o===null))return;let s=e.ray.origin.distanceTo(gd);s<e.near||s>e.far||t.push({distance:s,point:gd.clone(),uv:wu.getInterpolation(gd,Sd,Cd,wd,Td,Ed,Dd,new Y),face:null,object:this})}copy(e,t){return super.copy(e,t),e.center!==void 0&&this.center.copy(e.center),this.material=e.material,this}};function kd(e,t,n,r,i,a){yd.subVectors(e,n).addScalar(.5).multiply(r),i===void 0?bd.copy(yd):(bd.x=a*yd.x-i*yd.y,bd.y=i*yd.x+a*yd.y),e.copy(t),e.x+=bd.x,e.y+=bd.y,e.applyMatrix4(xd)}var Ad=new X,jd=new X,Md=new X,Nd=new X,Pd=class{constructor(e=new X,t=new X(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,Ad)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);let n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){let t=Ad.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(Ad.copy(this.origin).addScaledVector(this.direction,t),Ad.distanceToSquared(e))}distanceSqToSegment(e,t,n,r){jd.copy(e).add(t).multiplyScalar(.5),Md.copy(t).sub(e).normalize(),Nd.copy(this.origin).sub(jd);let i=e.distanceTo(t)*.5,a=-this.direction.dot(Md),o=Nd.dot(this.direction),s=-Nd.dot(Md),c=Nd.lengthSq(),l=Math.abs(1-a*a),u,d,f,p;if(l>0){if(u=a*s-o,d=a*o-s,p=i*l,u>=0){if(d>=-p){if(d<=p){let e=1/l;u*=e,d*=e,f=u*(u+a*d+2*o)+d*(a*u+d+2*s)+c}else d=i,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*s)+c}else d=-i,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*s)+c}else d<=-p?(u=Math.max(0,-(-a*i+o)),d=u>0?-i:Math.min(Math.max(-i,-s),i),f=-u*u+d*(d+2*s)+c):d<=p?(u=0,d=Math.min(Math.max(-i,-s),i),f=d*(d+2*s)+c):(u=Math.max(0,-(a*i+o)),d=u>0?i:Math.min(Math.max(-i,-s),i),f=-u*u+d*(d+2*s)+c)}else d=a>0?-i:i,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*s)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,u),r&&r.copy(jd).addScaledVector(Md,d),f}intersectSphere(e,t){if(e.radius<0)return null;Ad.subVectors(e.center,this.origin);let n=Ad.dot(this.direction),r=Ad.dot(Ad)-n*n,i=e.radius*e.radius;if(r>i)return null;let a=Math.sqrt(i-r),o=n-a,s=n+a;return s<0?null:o<0?this.at(s,t):this.at(o,t)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){let t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;let n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){let n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){let t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,r,i,a,o,s,c=1/this.direction.x,l=1/this.direction.y,u=1/this.direction.z,d=this.origin;return c>=0?(n=(e.min.x-d.x)*c,r=(e.max.x-d.x)*c):(n=(e.max.x-d.x)*c,r=(e.min.x-d.x)*c),l>=0?(i=(e.min.y-d.y)*l,a=(e.max.y-d.y)*l):(i=(e.max.y-d.y)*l,a=(e.min.y-d.y)*l),n>a||i>r||((i>n||isNaN(n))&&(n=i),(a<r||isNaN(r))&&(r=a),u>=0?(o=(e.min.z-d.z)*u,s=(e.max.z-d.z)*u):(o=(e.max.z-d.z)*u,s=(e.min.z-d.z)*u),n>s||o>r)||((o>n||n!==n)&&(n=o),(s<r||r!==r)&&(r=s),r<0)?null:this.at(n>=0?n:r,t)}intersectsBox(e){return this.intersectBox(e,Ad)!==null}intersectTriangle(e,t,n,r,i){let a=this.origin,o=this.direction,s=o.x,c=o.y,l=o.z,u=e.x-a.x,d=e.y-a.y,f=e.z-a.z,p=t.x-a.x,m=t.y-a.y,h=t.z-a.z,g=n.x-a.x,_=n.y-a.y,v=n.z-a.z,y=Math.abs(s),b=Math.abs(c),x=Math.abs(l),S,C,w,T,E,D,O,k,A,j,M,N;if(y>=b&&y>=x?(w=s,D=u,A=p,N=g,s>=0?(S=c,C=l,T=d,E=f,O=m,k=h,j=_,M=v):(S=l,C=c,T=f,E=d,O=h,k=m,j=v,M=_)):b>=x?(w=c,D=d,A=m,N=_,c>=0?(S=l,C=s,T=f,E=u,O=h,k=p,j=v,M=g):(S=s,C=l,T=u,E=f,O=p,k=h,j=g,M=v)):(w=l,D=f,A=h,N=v,l>=0?(S=s,C=c,T=u,E=d,O=p,k=m,j=g,M=_):(S=c,C=s,T=d,E=u,O=m,k=p,j=_,M=g)),w===0)return null;let P=S/w,F=C/w,I=1/w,L=T-P*D,ee=E-F*D,te=O-P*A,ne=k-F*A,R=j-P*N,re=M-F*N,z=R*ne-re*te,B=L*re-ee*R,ie=te*ee-ne*L;if(r){if(z<0||B<0||ie<0)return null}else if((z<0||B<0||ie<0)&&(z>0||B>0||ie>0))return null;let ae=z+B+ie;if(ae===0)return null;let oe=I*(z*D+B*A+ie*N);return(ae>0?oe<0:oe>0)?null:this.at(oe/ae,i)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},Fd=class extends pd{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type=`MeshBasicMaterial`,this.color=new cu(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Ll,this.combine=0,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap=`round`,this.wireframeLinejoin=`round`,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}},Id=new Dl,Ld=new Pd,Rd=new Xu,zd=new X,Bd=new X,Vd=new X,Hd=new X,Ud=new X,Wd=new X,Gd=new X,Kd=new X,qd=class extends eu{constructor(e=new id,t=new Fd){super(),this.isMesh=!0,this.type=`Mesh`,this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let n=e[t[0]];if(n!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let e=0,t=n.length;e<t;e++){let t=n[e].name||String(e);this.morphTargetInfluences.push(0),this.morphTargetDictionary[t]=e}}}}getVertexPosition(e,t){let n=this.geometry,r=n.attributes.position,i=n.morphAttributes.position,a=n.morphTargetsRelative;t.fromBufferAttribute(r,e);let o=this.morphTargetInfluences;if(i&&o){Wd.set(0,0,0);for(let n=0,r=i.length;n<r;n++){let r=o[n],s=i[n];r!==0&&(Ud.fromBufferAttribute(s,e),a?Wd.addScaledVector(Ud,r):Wd.addScaledVector(Ud.sub(t),r))}t.add(Wd)}return t}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){let n=this.geometry,r=this.material,i=this.matrixWorld;r!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),Rd.copy(n.boundingSphere),Rd.applyMatrix4(i),Ld.copy(e.ray).recast(e.near),!(Rd.containsPoint(Ld.origin)===!1&&(Ld.intersectSphere(Rd,zd)===null||Ld.origin.distanceToSquared(zd)>(e.far-e.near)**2))&&(Id.copy(i).invert(),Ld.copy(e.ray).applyMatrix4(Id),(n.boundingBox===null||Ld.intersectsBox(n.boundingBox)!==!1)&&this._computeIntersections(e,t,Ld)))}_computeIntersections(e,t,n){let r,i=this.geometry,a=this.material,o=i.index,s=i.attributes.position,c=i.attributes.uv,l=i.attributes.uv1,u=i.attributes.normal,d=i.groups,f=i.drawRange;if(o!==null){if(Array.isArray(a))for(let i=0,s=d.length;i<s;i++){let s=d[i],p=a[s.materialIndex],m=Math.max(s.start,f.start),h=Math.min(o.count,Math.min(s.start+s.count,f.start+f.count));for(let i=m,a=h;i<a;i+=3){let a=o.getX(i),d=o.getX(i+1),f=o.getX(i+2);r=Yd(this,p,e,n,c,l,u,a,d,f),r&&(r.faceIndex=Math.floor(i/3),r.face.materialIndex=s.materialIndex,t.push(r))}}else{let i=Math.max(0,f.start),s=Math.min(o.count,f.start+f.count);for(let d=i,f=s;d<f;d+=3){let i=o.getX(d),s=o.getX(d+1),f=o.getX(d+2);r=Yd(this,a,e,n,c,l,u,i,s,f),r&&(r.faceIndex=Math.floor(d/3),t.push(r))}}}else if(s!==void 0){if(Array.isArray(a))for(let i=0,o=d.length;i<o;i++){let o=d[i],p=a[o.materialIndex],m=Math.max(o.start,f.start),h=Math.min(s.count,Math.min(o.start+o.count,f.start+f.count));for(let i=m,a=h;i<a;i+=3){let a=i,s=i+1,d=i+2;r=Yd(this,p,e,n,c,l,u,a,s,d),r&&(r.faceIndex=Math.floor(i/3),r.face.materialIndex=o.materialIndex,t.push(r))}}else{let i=Math.max(0,f.start),o=Math.min(s.count,f.start+f.count);for(let s=i,d=o;s<d;s+=3){let i=s,o=s+1,d=s+2;r=Yd(this,a,e,n,c,l,u,i,o,d),r&&(r.faceIndex=Math.floor(s/3),t.push(r))}}}}};function Jd(e,t,n,r,i,a,o,s){let c;if(c=t.side===1?r.intersectTriangle(o,a,i,!0,s):r.intersectTriangle(i,a,o,t.side===0,s),c===null)return null;Kd.copy(s),Kd.applyMatrix4(e.matrixWorld);let l=n.ray.origin.distanceTo(Kd);return l<n.near||l>n.far?null:{distance:l,point:Kd.clone(),object:e}}function Yd(e,t,n,r,i,a,o,s,c,l){e.getVertexPosition(s,Bd),e.getVertexPosition(c,Vd),e.getVertexPosition(l,Hd);let u=Jd(e,t,n,r,Bd,Vd,Hd,Gd);if(u){let e=new X;wu.getBarycoord(Gd,Bd,Vd,Hd,e),i&&(u.uv=wu.getInterpolatedAttribute(i,s,c,l,e,new Y)),a&&(u.uv1=wu.getInterpolatedAttribute(a,s,c,l,e,new Y)),o&&(u.normal=wu.getInterpolatedAttribute(o,s,c,l,e,new X),u.normal.dot(r.direction)>0&&u.normal.multiplyScalar(-1));let t={a:s,b:c,c:l,normal:new X,materialIndex:0};wu.getNormal(Bd,Vd,Hd,t.normal),u.face=t,u.barycoord=e}return u}var Xd=class extends xl{constructor(e=null,t=1,n=1,r,i,a,o,s,c=fs,l=fs,u,d){super(null,a,o,s,c,l,r,i,u,d),this.isDataTexture=!0,this.image={data:e,width:t,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}},Zd=new Xu,Qd=new Y(.5,.5),$d=new X,ef=class{constructor(e=new dd,t=new dd,n=new dd,r=new dd,i=new dd,a=new dd){this.planes=[e,t,n,r,i,a]}set(e,t,n,r,i,a){let o=this.planes;return o[0].copy(e),o[1].copy(t),o[2].copy(n),o[3].copy(r),o[4].copy(i),o[5].copy(a),this}copy(e){let t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=Lc,n=!1){let r=this.planes,i=e.elements,a=i[0],o=i[1],s=i[2],c=i[3],l=i[4],u=i[5],d=i[6],f=i[7],p=i[8],m=i[9],h=i[10],g=i[11],_=i[12],v=i[13],y=i[14],b=i[15];if(r[0].setComponents(c-a,f-l,g-p,b-_).normalize(),r[1].setComponents(c+a,f+l,g+p,b+_).normalize(),r[2].setComponents(c+o,f+u,g+m,b+v).normalize(),r[3].setComponents(c-o,f-u,g-m,b-v).normalize(),n)r[4].setComponents(s,d,h,y).normalize(),r[5].setComponents(c-s,f-d,g-h,b-y).normalize();else if(r[4].setComponents(c-s,f-d,g-h,b-y).normalize(),t===2e3)r[5].setComponents(c+s,f+d,g+h,b+y).normalize();else if(t===2001)r[5].setComponents(s,d,h,y).normalize();else throw Error(`THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: `+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),Zd.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{let t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),Zd.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(Zd)}intersectsSprite(e){return Zd.center.set(0,0,0),Zd.radius=.7071067811865476+Qd.distanceTo(e.center),Zd.applyMatrix4(e.matrixWorld),this.intersectsSphere(Zd)}intersectsSphere(e){let t=this.planes,n=e.center,r=-e.radius;for(let e=0;e<6;e++)if(t[e].distanceToPoint(n)<r)return!1;return!0}intersectsBox(e){let t=this.planes;for(let n=0;n<6;n++){let r=t[n];if($d.x=r.normal.x>0?e.max.x:e.min.x,$d.y=r.normal.y>0?e.max.y:e.min.y,$d.z=r.normal.z>0?e.max.z:e.min.z,r.distanceToPoint($d)<0)return!1}return!0}containsPoint(e){let t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}},tf=class extends pd{constructor(e){super(),this.isLineBasicMaterial=!0,this.type=`LineBasicMaterial`,this.color=new cu(16777215),this.map=null,this.linewidth=1,this.linecap=`round`,this.linejoin=`round`,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}},nf=new X,rf=new X,af=new Dl,of=new Pd,sf=new Xu,cf=new X,lf=new X,uf=class extends eu{constructor(e=new id,t=new tf){super(),this.isLine=!0,this.type=`Line`,this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,n=[0];for(let e=1,r=t.count;e<r;e++)nf.fromBufferAttribute(t,e-1),rf.fromBufferAttribute(t,e),n[e]=n[e-1],n[e]+=nf.distanceTo(rf);e.setAttribute(`lineDistance`,new Ku(n,1))}else q(`Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.`);return this}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){let n=this.geometry,r=this.matrixWorld,i=e.params.Line.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),sf.copy(n.boundingSphere),sf.applyMatrix4(r),sf.radius+=i,e.ray.intersectsSphere(sf)===!1)return;af.copy(r).invert(),of.copy(e.ray).applyMatrix4(af);let o=i/((this.scale.x+this.scale.y+this.scale.z)/3),s=o*o,c=this.isLineSegments?2:1,l=n.index,u=n.attributes.position;if(l!==null){let n=Math.max(0,a.start),r=Math.min(l.count,a.start+a.count);for(let i=n,a=r-1;i<a;i+=c){let n=l.getX(i),r=l.getX(i+1),a=df(this,e,of,s,n,r,i);a&&t.push(a)}if(this.isLineLoop){let i=l.getX(r-1),a=l.getX(n),o=df(this,e,of,s,i,a,r-1);o&&t.push(o)}}else{let n=Math.max(0,a.start),r=Math.min(u.count,a.start+a.count);for(let i=n,a=r-1;i<a;i+=c){let n=df(this,e,of,s,i,i+1,i);n&&t.push(n)}if(this.isLineLoop){let i=df(this,e,of,s,r-1,n,r-1);i&&t.push(i)}}}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let n=e[t[0]];if(n!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let e=0,t=n.length;e<t;e++){let t=n[e].name||String(e);this.morphTargetInfluences.push(0),this.morphTargetDictionary[t]=e}}}}};function df(e,t,n,r,i,a,o){let s=e.geometry.attributes.position;if(nf.fromBufferAttribute(s,i),rf.fromBufferAttribute(s,a),n.distanceSqToSegment(nf,rf,cf,lf)>r)return;cf.applyMatrix4(e.matrixWorld);let c=t.ray.origin.distanceTo(cf);if(!(c<t.near||c>t.far))return{distance:c,point:lf.clone().applyMatrix4(e.matrixWorld),index:o,face:null,faceIndex:null,barycoord:null,object:e}}var ff=new X,pf=new X,mf=class extends uf{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type=`LineSegments`}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,n=[];for(let e=0,r=t.count;e<r;e+=2)ff.fromBufferAttribute(t,e),pf.fromBufferAttribute(t,e+1),n[e]=e===0?0:n[e-1],n[e+1]=n[e]+ff.distanceTo(pf);e.setAttribute(`lineDistance`,new Ku(n,1))}else q(`LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.`);return this}},hf=class extends xl{constructor(e=[],t=301,n,r,i,a,o,s,c,l){super(e,t,n,r,i,a,o,s,c,l),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}},gf=class extends xl{constructor(e,t,n,r,i,a,o,s,c){super(e,t,n,r,i,a,o,s,c),this.isCanvasTexture=!0,this.needsUpdate=!0}},_f=class extends xl{constructor(e,t,n=Cs,r,i,a,o=fs,s=fs,c,l=Ps,u=1){if(l!==1026&&l!==1027)throw Error(`THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat`);super({width:e,height:t,depth:u},r,i,a,o,s,l,n,c),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new _l(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){let t=super.toJSON(e);return t.compareFunction=this.compareFunction,t}},vf=class extends _f{constructor(e,t=Cs,n=301,r,i,a=fs,o=fs,s,c=Ps){let l={width:e,height:e,depth:1},u=[l,l,l,l,l,l];super(e,e,t,n,r,i,a,o,s,c),this.image=u,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(e){this.image=e}},yf=class extends xl{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}},bf=class e extends id{constructor(e=1,t=1,n=1,r=1,i=1,a=1){super(),this.type=`BoxGeometry`,this.parameters={width:e,height:t,depth:n,widthSegments:r,heightSegments:i,depthSegments:a};let o=this;r=Math.floor(r),i=Math.floor(i),a=Math.floor(a);let s=[],c=[],l=[],u=[],d=0,f=0;p(`z`,`y`,`x`,-1,-1,n,t,e,a,i,0),p(`z`,`y`,`x`,1,-1,n,t,-e,a,i,1),p(`x`,`z`,`y`,1,1,e,n,t,r,a,2),p(`x`,`z`,`y`,1,-1,e,n,-t,r,a,3),p(`x`,`y`,`z`,1,-1,e,t,n,r,i,4),p(`x`,`y`,`z`,-1,-1,e,t,-n,r,i,5),this.setIndex(s),this.setAttribute(`position`,new Ku(c,3)),this.setAttribute(`normal`,new Ku(l,3)),this.setAttribute(`uv`,new Ku(u,2));function p(e,t,n,r,i,a,p,m,h,g,_){let v=a/h,y=p/g,b=a/2,x=p/2,S=m/2,C=h+1,w=g+1,T=0,E=0,D=new X;for(let a=0;a<w;a++){let o=a*y-x;for(let s=0;s<C;s++)D[e]=(s*v-b)*r,D[t]=o*i,D[n]=S,c.push(D.x,D.y,D.z),D[e]=0,D[t]=0,D[n]=m>0?1:-1,l.push(D.x,D.y,D.z),u.push(s/h),u.push(1-a/g),T+=1}for(let e=0;e<g;e++)for(let t=0;t<h;t++){let n=d+t+C*e,r=d+t+C*(e+1),i=d+(t+1)+C*(e+1),a=d+(t+1)+C*e;s.push(n,r,a),s.push(r,i,a),E+=6}o.addGroup(f,E,_),f+=E,d+=T}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}},xf=class e extends id{constructor(e=1,t=1,n=1,r=1){super(),this.type=`PlaneGeometry`,this.parameters={width:e,height:t,widthSegments:n,heightSegments:r};let i=e/2,a=t/2,o=Math.floor(n),s=Math.floor(r),c=o+1,l=s+1,u=e/o,d=t/s,f=[],p=[],m=[],h=[];for(let e=0;e<l;e++){let t=e*d-a;for(let n=0;n<c;n++){let r=n*u-i;p.push(r,-t,0),m.push(0,0,1),h.push(n/o),h.push(1-e/s)}}for(let e=0;e<s;e++)for(let t=0;t<o;t++){let n=t+c*e,r=t+c*(e+1),i=t+1+c*(e+1),a=t+1+c*e;f.push(n,r,a),f.push(r,i,a)}this.setIndex(f),this.setAttribute(`position`,new Ku(p,3)),this.setAttribute(`normal`,new Ku(m,3)),this.setAttribute(`uv`,new Ku(h,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.width,t.height,t.widthSegments,t.heightSegments)}},Sf=class e extends id{constructor(e=1,t=32,n=16,r=0,i=Math.PI*2,a=0,o=Math.PI){super(),this.type=`SphereGeometry`,this.parameters={radius:e,widthSegments:t,heightSegments:n,phiStart:r,phiLength:i,thetaStart:a,thetaLength:o},t=Math.max(3,Math.floor(t)),n=Math.max(2,Math.floor(n));let s=Math.min(a+o,Math.PI),c=0,l=[],u=new X,d=new X,f=[],p=[],m=[],h=[];for(let f=0;f<=n;f++){let g=[],_=f/n,v=a+_*o,y=e*Math.cos(v),b=Math.sqrt(e*e-y*y),x=0;f===0&&a===0?x=.5/t:f===n&&s===Math.PI&&(x=-.5/t);for(let e=0;e<=t;e++){let n=e/t,a=r+n*i;u.x=-b*Math.cos(a),u.y=y,u.z=b*Math.sin(a),p.push(u.x,u.y,u.z),d.copy(u).normalize(),m.push(d.x,d.y,d.z),h.push(n+x,1-_),g.push(c++)}l.push(g)}for(let e=0;e<n;e++)for(let r=0;r<t;r++){let t=l[e][r+1],i=l[e][r],o=l[e+1][r],c=l[e+1][r+1];(e!==0||a>0)&&f.push(t,i,c),(e!==n-1||s<Math.PI)&&f.push(i,o,c)}this.setIndex(f),this.setAttribute(`position`,new Ku(p,3)),this.setAttribute(`normal`,new Ku(m,3)),this.setAttribute(`uv`,new Ku(h,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}};function Cf(e){let t={};for(let n in e){t[n]={};for(let r in e[n]){let i=e[n][r];if(Tf(i))i.isRenderTargetTexture?(q(`UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms().`),t[n][r]=null):t[n][r]=i.clone();else if(Array.isArray(i)){if(Tf(i[0])){let e=[];for(let t=0,n=i.length;t<n;t++)e[t]=i[t].clone();t[n][r]=e}else t[n][r]=i.slice()}else t[n][r]=i}}return t}function wf(e){let t={};for(let n=0;n<e.length;n++){let r=Cf(e[n]);for(let e in r)t[e]=r[e]}return t}function Tf(e){return e&&(e.isColor||e.isMatrix3||e.isMatrix4||e.isVector2||e.isVector3||e.isVector4||e.isTexture||e.isQuaternion)}function Ef(e){let t=[];for(let n=0;n<e.length;n++)t.push(e[n].clone());return t}function Df(e){let t=e.getRenderTarget();return t===null?e.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:dl.workingColorSpace}var Of={clone:Cf,merge:wf},kf=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Af=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,jf=class extends pd{constructor(e){super(),this.isShaderMaterial=!0,this.type=`ShaderMaterial`,this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=kf,this.fragmentShader=Af,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Cf(e.uniforms),this.uniformsGroups=Ef(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this.defaultAttributeValues=Object.assign({},e.defaultAttributeValues),this.index0AttributeName=e.index0AttributeName,this.uniformsNeedUpdate=e.uniformsNeedUpdate,this}toJSON(e){let t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(let n in this.uniforms){let r=this.uniforms[n].value;r&&r.isTexture?t.uniforms[n]={type:`t`,value:r.toJSON(e).uuid}:r&&r.isColor?t.uniforms[n]={type:`c`,value:r.getHex()}:r&&r.isVector2?t.uniforms[n]={type:`v2`,value:r.toArray()}:r&&r.isVector3?t.uniforms[n]={type:`v3`,value:r.toArray()}:r&&r.isVector4?t.uniforms[n]={type:`v4`,value:r.toArray()}:r&&r.isMatrix3?t.uniforms[n]={type:`m3`,value:r.toArray()}:r&&r.isMatrix4?t.uniforms[n]={type:`m4`,value:r.toArray()}:t.uniforms[n]={value:r}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;let n={};for(let e in this.extensions)this.extensions[e]===!0&&(n[e]=!0);return Object.keys(n).length>0&&(t.extensions=n),t}fromJSON(e,t){if(super.fromJSON(e,t),e.uniforms!==void 0)for(let n in e.uniforms){let r=e.uniforms[n];switch(this.uniforms[n]={},r.type){case`t`:this.uniforms[n].value=t[r.value]||null;break;case`c`:this.uniforms[n].value=new cu().setHex(r.value);break;case`v2`:this.uniforms[n].value=new Y().fromArray(r.value);break;case`v3`:this.uniforms[n].value=new X().fromArray(r.value);break;case`v4`:this.uniforms[n].value=new Sl().fromArray(r.value);break;case`m3`:this.uniforms[n].value=new Z().fromArray(r.value);break;case`m4`:this.uniforms[n].value=new Dl().fromArray(r.value);break;default:this.uniforms[n].value=r.value}}if(e.defines!==void 0&&(this.defines=e.defines),e.vertexShader!==void 0&&(this.vertexShader=e.vertexShader),e.fragmentShader!==void 0&&(this.fragmentShader=e.fragmentShader),e.glslVersion!==void 0&&(this.glslVersion=e.glslVersion),e.extensions!==void 0)for(let t in e.extensions)this.extensions[t]=e.extensions[t];return e.lights!==void 0&&(this.lights=e.lights),e.clipping!==void 0&&(this.clipping=e.clipping),this}},Mf=class extends jf{constructor(e){super(e),this.isRawShaderMaterial=!0,this.type=`RawShaderMaterial`}},Nf=class extends pd{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type=`MeshDepthMaterial`,this.depthPacking=Ac,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}},Pf=class extends pd{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type=`MeshDistanceMaterial`,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}};function Ff(e,t){return!e||e.constructor===t?e:typeof t.BYTES_PER_ELEMENT==`number`?new t(e):Array.prototype.slice.call(e)}function If(e){return e!==void 0&&e.inTangents!==void 0&&e.outTangents!==void 0}var Lf=class{constructor(e,t,n,r){this.parameterPositions=e,this._cachedIndex=0,this.resultBuffer=r===void 0?new t.constructor(n):r,this.sampleValues=t,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(e){let t=this.parameterPositions,n=this._cachedIndex,r=t[n],i=t[n-1];validate_interval:{seek:{let a;linear_scan:{forward_scan:if(!(e<r)){for(let a=n+2;;){if(r===void 0){if(e<i)break forward_scan;return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===a)break;if(i=r,r=t[++n],e<r)break seek}a=t.length;break linear_scan}if(!(e>=i)){let o=t[1];e<o&&(n=2,i=o);for(let a=n-2;;){if(i===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===a)break;if(r=i,i=t[--n-1],e>=i)break seek}a=n,n=0;break linear_scan}break validate_interval}for(;n<a;){let r=n+a>>>1;e<t[r]?a=r:n=r+1}if(r=t[n],i=t[n-1],i===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(r===void 0)return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,i,r)}return this.interpolate_(n,i,e,r)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(e){let t=this.resultBuffer,n=this.sampleValues,r=this.valueSize,i=e*r;for(let e=0;e!==r;++e)t[e]=n[i+e];return t}interpolate_(){throw Error(`THREE.Interpolant: Call to abstract method.`)}intervalChanged_(){}},Rf=class extends Lf{constructor(e,t,n,r){super(e,t,n,r),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:Dc,endingEnd:Dc}}intervalChanged_(e,t,n){let r=this.parameterPositions,i=e-2,a=e+1,o=r[i],s=r[a];if(o===void 0)switch(this.getSettings_().endingStart){case Oc:i=e,o=2*t-n;break;case kc:i=r.length-2,o=t+r[i]-r[i+1];break;default:i=e,o=n}if(s===void 0)switch(this.getSettings_().endingEnd){case Oc:a=e,s=2*n-t;break;case kc:a=1,s=n+r[1]-r[0];break;default:a=e-1,s=t}let c=(n-t)*.5,l=this.valueSize;this._weightPrev=c/(t-o),this._weightNext=c/(s-n),this._offsetPrev=i*l,this._offsetNext=a*l}interpolate_(e,t,n,r){let i=this.resultBuffer,a=this.sampleValues,o=this.valueSize,s=e*o,c=s-o,l=this._offsetPrev,u=this._offsetNext,d=this._weightPrev,f=this._weightNext,p=(n-t)/(r-t),m=p*p,h=m*p,g=-d*h+2*d*m-d*p,_=(1+d)*h+(-1.5-2*d)*m+(-.5+d)*p+1,v=(-1-f)*h+(1.5+f)*m+.5*p,y=f*h-f*m;for(let e=0;e!==o;++e)i[e]=g*a[l+e]+_*a[c+e]+v*a[s+e]+y*a[u+e];return i}},zf=class extends Lf{constructor(e,t,n,r){super(e,t,n,r)}interpolate_(e,t,n,r){let i=this.resultBuffer,a=this.sampleValues,o=this.valueSize,s=e*o,c=s-o,l=(n-t)/(r-t),u=1-l;for(let e=0;e!==o;++e)i[e]=a[c+e]*u+a[s+e]*l;return i}},Bf=class extends Lf{constructor(e,t,n,r){super(e,t,n,r)}interpolate_(e){return this.copySampleValue_(e-1)}},Vf=class extends Lf{interpolate_(e,t,n,r){let i=this.resultBuffer,a=this.sampleValues,o=this.valueSize,s=e*o,c=s-o,l=this.inTangents,u=this.outTangents;if(!l||!u){let e=(n-t)/(r-t),l=1-e;for(let t=0;t!==o;++t)i[t]=a[c+t]*l+a[s+t]*e;return i}let d=o*2,f=e-1;for(let p=0;p!==o;++p){let o=a[c+p],m=a[s+p],h=f*d+p*2,g=u[h],_=u[h+1],v=e*d+p*2,y=l[v],b=l[v+1],x=Wf(n,t,g,y,r);i[p]=Hf(x,o,_,b,m)}return i}};function Hf(e,t,n,r,i){let a=1-e;return a*a*a*t+3*a*a*e*n+3*a*e*e*r+e*e*e*i}function Uf(e,t,n,r,i){let a=1-e;return 3*a*a*(n-t)+6*a*e*(r-n)+3*e*e*(i-r)}function Wf(e,t,n,r,i){let a=(e-t)/(i-t);for(let o=0;o<8;o++){let o=Hf(a,t,n,r,i)-e;if(Math.abs(o)<1e-10)break;let s=Uf(a,t,n,r,i);if(Math.abs(s)<1e-10)break;a=Math.max(0,Math.min(1,a-o/s))}return a}var Gf=class{constructor(e,t,n,r){if(e===void 0)throw Error(`THREE.KeyframeTrack: track name is undefined`);if(t===void 0||t.length===0)throw Error(`THREE.KeyframeTrack: no keyframes in track named `+e);this.name=e,this.times=Ff(t,this.TimeBufferType),this.values=Ff(n,this.ValueBufferType),this.setInterpolation(r||this.DefaultInterpolation)}static toJSON(e){let t=e.constructor,n;if(t.toJSON!==this.toJSON)n=t.toJSON(e);else{n={name:e.name,times:Ff(e.times,Array),values:Ff(e.values,Array)};let t=e.getInterpolation();t!==e.DefaultInterpolation&&(n.interpolation=t),If(e.settings)&&(n.settings={inTangents:Ff(e.settings.inTangents,Array),outTangents:Ff(e.settings.outTangents,Array)})}return n.type=e.ValueTypeName,n}InterpolantFactoryMethodDiscrete(e){return new Bf(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodLinear(e){return new zf(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodSmooth(e){return new Rf(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodBezier(e){let t=new Vf(this.times,this.values,this.getValueSize(),e);return this.settings&&(t.inTangents=this.settings.inTangents,t.outTangents=this.settings.outTangents),t}setInterpolation(e){let t;switch(e){case Cc:t=this.InterpolantFactoryMethodDiscrete;break;case wc:t=this.InterpolantFactoryMethodLinear;break;case Tc:t=this.InterpolantFactoryMethodSmooth;break;case Ec:t=this.InterpolantFactoryMethodBezier}if(t===void 0){let t=`unsupported interpolation for `+this.ValueTypeName+` keyframe track named `+this.name;if(this.createInterpolant===void 0){if(e!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw Error(t)}return q(`KeyframeTrack:`,t),this}return this.createInterpolant=t,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return Cc;case this.InterpolantFactoryMethodLinear:return wc;case this.InterpolantFactoryMethodSmooth:return Tc;case this.InterpolantFactoryMethodBezier:return Ec}}getValueSize(){return this.values.length/this.times.length}shift(e){if(e!==0){let t=this.times;for(let n=0,r=t.length;n!==r;++n)t[n]+=e}return this}scale(e){if(e!==1){let t=this.times;for(let n=0,r=t.length;n!==r;++n)t[n]*=e;If(this.settings)&&(Kf(this.settings.inTangents,e),Kf(this.settings.outTangents,e))}return this}trim(e,t){let n=this.times,r=n.length,i=0,a=r-1;for(;i!==r&&n[i]<e;)++i;for(;a!==-1&&n[a]>t;)--a;if(++a,i!==0||a!==r){i>=a&&(a=Math.max(a,1),i=a-1);let e=this.getValueSize();this.times=n.slice(i,a),this.values=this.values.slice(i*e,a*e)}return this}validate(){let e=!0,t=this.getValueSize();t-Math.floor(t)!==0&&(J(`KeyframeTrack: Invalid value size in track.`,this),e=!1);let n=this.times,r=this.values,i=n.length;i===0&&(J(`KeyframeTrack: Track is empty.`,this),e=!1);let a=null;for(let t=0;t!==i;t++){let r=n[t];if(typeof r==`number`&&isNaN(r)){J(`KeyframeTrack: Time is not a valid number.`,this,t,r),e=!1;break}if(a!==null&&a>r){J(`KeyframeTrack: Out of order keys.`,this,t,r,a),e=!1;break}a=r}if(r!==void 0&&zc(r))for(let t=0,n=r.length;t!==n;++t){let n=r[t];if(isNaN(n)){J(`KeyframeTrack: Value is not a valid number.`,this,t,n),e=!1;break}}return e}optimize(){let e=this.times.slice(),t=this.values.slice(),n=this.getValueSize(),r=this.getInterpolation()===Tc,i=e.length-1,a=1;for(let o=1;o<i;++o){let i=!1,s=e[o];if(s!==e[o+1]&&(o!==1||s!==e[0])){if(r)i=!0;else{let e=o*n,r=e-n,a=e+n;for(let o=0;o!==n;++o){let n=t[e+o];if(n!==t[r+o]||n!==t[a+o]){i=!0;break}}}}if(i){if(o!==a){e[a]=e[o];let r=o*n,i=a*n;for(let e=0;e!==n;++e)t[i+e]=t[r+e]}++a}}if(i>0){e[a]=e[i];for(let e=i*n,r=a*n,o=0;o!==n;++o)t[r+o]=t[e+o];++a}return a===e.length?(this.times=e,this.values=t):(this.times=e.slice(0,a),this.values=t.slice(0,a*n)),this}clone(){let e=this.times.slice(),t=this.values.slice(),n=this.constructor,r=new n(this.name,e,t);return r.createInterpolant=this.createInterpolant,If(this.settings)&&(r.settings={inTangents:this.settings.inTangents.slice(),outTangents:this.settings.outTangents.slice()}),r}};function Kf(e,t){for(let n=0,r=e.length;n!==r;n+=2)e[n]*=t}Gf.prototype.ValueTypeName=``,Gf.prototype.TimeBufferType=Float32Array,Gf.prototype.ValueBufferType=Float32Array,Gf.prototype.DefaultInterpolation=wc;var qf=class extends Gf{constructor(e,t,n){super(e,t,n)}};qf.prototype.ValueTypeName=`bool`,qf.prototype.ValueBufferType=Array,qf.prototype.DefaultInterpolation=Cc,qf.prototype.InterpolantFactoryMethodLinear=void 0,qf.prototype.InterpolantFactoryMethodSmooth=void 0;var Jf=class extends Gf{constructor(e,t,n,r){super(e,t,n,r)}};Jf.prototype.ValueTypeName=`color`;var Yf=class extends Gf{constructor(e,t,n,r){super(e,t,n,r)}};Yf.prototype.ValueTypeName=`number`;var Xf=class extends Lf{constructor(e,t,n,r){super(e,t,n,r)}interpolate_(e,t,n,r){let i=this.resultBuffer,a=this.sampleValues,o=this.valueSize,s=(n-t)/(r-t),c=e*o;for(let e=c+o;c!==e;c+=4)il.slerpFlat(i,0,a,c-o,a,c,s);return i}},Zf=class extends Gf{constructor(e,t,n,r){super(e,t,n,r)}InterpolantFactoryMethodLinear(e){return new Xf(this.times,this.values,this.getValueSize(),e)}};Zf.prototype.ValueTypeName=`quaternion`,Zf.prototype.InterpolantFactoryMethodSmooth=void 0;var Qf=class extends Gf{constructor(e,t,n){super(e,t,n)}};Qf.prototype.ValueTypeName=`string`,Qf.prototype.ValueBufferType=Array,Qf.prototype.DefaultInterpolation=Cc,Qf.prototype.InterpolantFactoryMethodLinear=void 0,Qf.prototype.InterpolantFactoryMethodSmooth=void 0;var $f=class extends Gf{constructor(e,t,n,r){super(e,t,n,r)}};$f.prototype.ValueTypeName=`vector`;var ep=new X,tp=new il,np=new X,rp=class extends eu{constructor(){super(),this.isCamera=!0,this.type=`Camera`,this.matrixWorldInverse=new Dl,this.projectionMatrix=new Dl,this.projectionMatrixInverse=new Dl,this.coordinateSystem=Lc,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorld.decompose(ep,tp,np),np.x===1&&np.y===1&&np.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(ep,tp,np.set(1,1,1)).invert()}updateWorldMatrix(e,t,n=!1){super.updateWorldMatrix(e,t,n),this.matrixWorld.decompose(ep,tp,np),np.x===1&&np.y===1&&np.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(ep,tp,np.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}},ip=new X,ap=new Y,op=new Y,sp=class extends rp{constructor(e=50,t=1,n=.1,r=2e3){super(),this.isPerspectiveCamera=!0,this.type=`PerspectiveCamera`,this.fov=e,this.zoom=1,this.near=n,this.far=r,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){let t=.5*this.getFilmHeight()/e;this.fov=Zc*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){let e=Math.tan(Xc*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return Zc*2*Math.atan(Math.tan(Xc*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,n){ip.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(ip.x,ip.y).multiplyScalar(-e/ip.z),ip.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(ip.x,ip.y).multiplyScalar(-e/ip.z)}getViewSize(e,t){return this.getViewBounds(e,ap,op),t.subVectors(op,ap)}setViewOffset(e,t,n,r,i,a){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=r,this.view.width=i,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=this.near,t=e*Math.tan(Xc*.5*this.fov)/this.zoom,n=2*t,r=this.aspect*n,i=-.5*r,a=this.view;if(this.view!==null&&this.view.enabled){let e=a.fullWidth,o=a.fullHeight;i+=a.offsetX*r/e,t-=a.offsetY*n/o,r*=a.width/e,n*=a.height/o}let o=this.filmOffset;o!==0&&(i+=e*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(i,i+r,t,t-n,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}},cp=class extends rp{constructor(e=-1,t=1,n=1,r=-1,i=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type=`OrthographicCamera`,this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=r,this.near=i,this.far=a,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,r,i,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=r,this.view.width=i,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,r=(this.top+this.bottom)/2,i=n-e,a=n+e,o=r+t,s=r-t;if(this.view!==null&&this.view.enabled){let e=(this.right-this.left)/this.view.fullWidth/this.zoom,t=(this.top-this.bottom)/this.view.fullHeight/this.zoom;i+=e*this.view.offsetX,a=i+e*this.view.width,o-=t*this.view.offsetY,s=o-t*this.view.height}this.projectionMatrix.makeOrthographic(i,a,o,s,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}},lp=-90,up=1,dp=class extends eu{constructor(e,t,n){super(),this.type=`CubeCamera`,this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;let r=new sp(lp,up,e,t);r.layers=this.layers,this.add(r);let i=new sp(lp,up,e,t);i.layers=this.layers,this.add(i);let a=new sp(lp,up,e,t);a.layers=this.layers,this.add(a);let o=new sp(lp,up,e,t);o.layers=this.layers,this.add(o);let s=new sp(lp,up,e,t);s.layers=this.layers,this.add(s);let c=new sp(lp,up,e,t);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){let e=this.coordinateSystem,t=this.children.concat(),[n,r,i,a,o,s]=t;for(let e of t)this.remove(e);if(e===2e3)n.up.set(0,1,0),n.lookAt(1,0,0),r.up.set(0,1,0),r.lookAt(-1,0,0),i.up.set(0,0,-1),i.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),s.up.set(0,1,0),s.lookAt(0,0,-1);else if(e===2001)n.up.set(0,-1,0),n.lookAt(-1,0,0),r.up.set(0,-1,0),r.lookAt(1,0,0),i.up.set(0,0,1),i.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),s.up.set(0,-1,0),s.lookAt(0,0,-1);else throw Error(`THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: `+e);for(let e of t)this.add(e),e.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();let{renderTarget:n,activeMipmapLevel:r}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());let[i,a,o,s,c,l]=this.children,u=e.getRenderTarget(),d=e.getActiveCubeFace(),f=e.getActiveMipmapLevel(),p=e.xr.enabled;e.xr.enabled=!1;let m=n.texture.generateMipmaps;n.texture.generateMipmaps=!1;let h=!1;h=e.isWebGLRenderer===!0?e.state.buffers.depth.getReversed():e.reversedDepthBuffer,e.setRenderTarget(n,0,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,i),e.setRenderTarget(n,1,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,a),e.setRenderTarget(n,2,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,o),e.setRenderTarget(n,3,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,s),e.setRenderTarget(n,4,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,c),n.texture.generateMipmaps=m,e.setRenderTarget(n,5,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,l),e.setRenderTarget(u,d,f),e.xr.enabled=p,n.texture.needsPMREMUpdate=!0}},fp=class extends sp{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}},pp=`\\[\\]\\.:\\/`,mp=RegExp(`[\\[\\]\\.:\\/]`,`g`),hp=`[^\\[\\]\\.:\\/]`,gp=`[^`+pp.replace(`\\.`,``)+`]`,_p=`((?:WC+[\\/:])*)`.replace(`WC`,hp),vp=`(WCOD+)?`.replace(`WCOD`,gp),yp=`(?:\\.(WC+)(?:\\[(.+)\\])?)?`.replace(`WC`,hp),bp=`\\.(WC+)(?:\\[(.+)\\])?`.replace(`WC`,hp),xp=RegExp(`^`+_p+vp+yp+bp+`$`),Sp=[`material`,`materials`,`bones`,`map`],Cp=class{constructor(e,t,n){let r=n||wp.parseTrackName(t);this._targetGroup=e,this._bindings=e.subscribe_(t,r)}getValue(e,t){this.bind();let n=this._targetGroup.nCachedObjects_,r=this._bindings[n];r!==void 0&&r.getValue(e,t)}setValue(e,t){let n=this._bindings;for(let r=this._targetGroup.nCachedObjects_,i=n.length;r!==i;++r)n[r].setValue(e,t)}bind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].bind()}unbind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].unbind()}},wp=class e{constructor(t,n,r){this.path=n,this.parsedPath=r||e.parseTrackName(n),this.node=e.findNode(t,this.parsedPath.nodeName),this.rootNode=t,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(t,n,r){return t&&t.isAnimationObjectGroup?new e.Composite(t,n,r):new e(t,n,r)}static sanitizeNodeName(e){return e.replace(/\s/g,`_`).replace(mp,``)}static parseTrackName(e){let t=xp.exec(e);if(t===null)throw Error(`THREE.PropertyBinding: Cannot parse trackName: `+e);let n={nodeName:t[2],objectName:t[3],objectIndex:t[4],propertyName:t[5],propertyIndex:t[6]},r=n.nodeName&&n.nodeName.lastIndexOf(`.`);if(r!==void 0&&r!==-1){let e=n.nodeName.substring(r+1);Sp.indexOf(e)!==-1&&(n.nodeName=n.nodeName.substring(0,r),n.objectName=e)}if(n.propertyName===null||n.propertyName.length===0)throw Error(`THREE.PropertyBinding: can not parse propertyName from trackName: `+e);return n}static findNode(e,t){if(t===void 0||t===``||t===`.`||t===-1||t===e.name||t===e.uuid)return e;if(e.skeleton){let n=e.skeleton.getBoneByName(t);if(n!==void 0)return n}if(e.children){let n=function(e){for(let r=0;r<e.length;r++){let i=e[r];if(i.name===t||i.uuid===t)return i;let a=n(i.children);if(a)return a}return null},r=n(e.children);if(r)return r}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(e,t){e[t]=this.targetObject[this.propertyName]}_getValue_array(e,t){let n=this.resolvedProperty;for(let r=0,i=n.length;r!==i;++r)e[t++]=n[r]}_getValue_arrayElement(e,t){e[t]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(e,t){this.resolvedProperty.toArray(e,t)}_setValue_direct(e,t){this.targetObject[this.propertyName]=e[t]}_setValue_direct_setNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(e,t){let n=this.resolvedProperty;for(let r=0,i=n.length;r!==i;++r)n[r]=e[t++]}_setValue_array_setNeedsUpdate(e,t){let n=this.resolvedProperty;for(let r=0,i=n.length;r!==i;++r)n[r]=e[t++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(e,t){let n=this.resolvedProperty;for(let r=0,i=n.length;r!==i;++r)n[r]=e[t++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(e,t){this.resolvedProperty[this.propertyIndex]=e[t]}_setValue_arrayElement_setNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(e,t){this.resolvedProperty.fromArray(e,t)}_setValue_fromArray_setNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(e,t){this.bind(),this.getValue(e,t)}_setValue_unbound(e,t){this.bind(),this.setValue(e,t)}bind(){let t=this.node,n=this.parsedPath,r=n.objectName,i=n.propertyName,a=n.propertyIndex;if(t||(t=e.findNode(this.rootNode,n.nodeName),this.node=t),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!t){q(`PropertyBinding: No target node found for track: `+this.path+`.`);return}if(r){let e=n.objectIndex;switch(r){case`materials`:if(!t.material){J(`PropertyBinding: Can not bind to material as node does not have a material.`,this);return}if(!t.material.materials){J(`PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.`,this);return}t=t.material.materials;break;case`bones`:if(!t.skeleton){J(`PropertyBinding: Can not bind to bones as node does not have a skeleton.`,this);return}t=t.skeleton.bones;for(let n=0;n<t.length;n++)if(t[n].name===e){e=n;break}break;case`map`:if(`map`in t){t=t.map;break}if(!t.material){J(`PropertyBinding: Can not bind to material as node does not have a material.`,this);return}if(!t.material.map){J(`PropertyBinding: Can not bind to material.map as node.material does not have a map.`,this);return}t=t.material.map;break;default:if(t[r]===void 0){J(`PropertyBinding: Can not bind to objectName of node undefined.`,this);return}t=t[r]}if(e!==void 0){if(t[e]===void 0){J(`PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.`,this,t);return}t=t[e]}}let o=t[i];if(o===void 0){let e=n.nodeName;J(`PropertyBinding: Trying to update property for track: `+e+`.`+i+` but it wasn't found.`,t);return}let s=this.Versioning.None;this.targetObject=t,t.isMaterial===!0?s=this.Versioning.NeedsUpdate:t.isObject3D===!0&&(s=this.Versioning.MatrixWorldNeedsUpdate);let c=this.BindingType.Direct;if(a!==void 0){if(i===`morphTargetInfluences`){if(!t.geometry){J(`PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.`,this);return}if(!t.geometry.morphAttributes){J(`PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.`,this);return}t.morphTargetDictionary[a]!==void 0&&(a=t.morphTargetDictionary[a])}c=this.BindingType.ArrayElement,this.resolvedProperty=o,this.propertyIndex=a}else o.fromArray!==void 0&&o.toArray!==void 0?(c=this.BindingType.HasFromToArray,this.resolvedProperty=o):Array.isArray(o)?(c=this.BindingType.EntireArray,this.resolvedProperty=o):this.propertyName=i;this.getValue=this.GetterByBindingType[c],this.setValue=this.SetterByBindingTypeAndVersioning[c][s]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};wp.Composite=Cp,wp.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3},wp.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2},wp.prototype.GetterByBindingType=[wp.prototype._getValue_direct,wp.prototype._getValue_array,wp.prototype._getValue_arrayElement,wp.prototype._getValue_toArray],wp.prototype.SetterByBindingTypeAndVersioning=[[wp.prototype._setValue_direct,wp.prototype._setValue_direct_setNeedsUpdate,wp.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[wp.prototype._setValue_array,wp.prototype._setValue_array_setNeedsUpdate,wp.prototype._setValue_array_setMatrixWorldNeedsUpdate],[wp.prototype._setValue_arrayElement,wp.prototype._setValue_arrayElement_setNeedsUpdate,wp.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[wp.prototype._setValue_fromArray,wp.prototype._setValue_fromArray_setNeedsUpdate,wp.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]],class e{static{e.prototype.isMatrix2=!0}constructor(e,t,n,r){this.elements=[1,0,0,1],e!==void 0&&this.set(e,t,n,r)}identity(){return this.set(1,0,0,1),this}fromArray(e,t=0){for(let n=0;n<4;n++)this.elements[n]=e[n+t];return this}set(e,t,n,r){let i=this.elements;return i[0]=e,i[2]=t,i[1]=n,i[3]=r,this}};function Tp(e,t,n,r){let i=Ep(r);switch(n){case js:return e*t;case Is:return e*t/i.components*i.byteLength;case Ls:return e*t/i.components*i.byteLength;case Rs:return e*t*2/i.components*i.byteLength;case zs:return e*t*2/i.components*i.byteLength;case Ms:return e*t*3/i.components*i.byteLength;case Ns:return e*t*4/i.components*i.byteLength;case Bs:return e*t*4/i.components*i.byteLength;case Vs:case Hs:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*8;case Us:case Ws:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*16;case Ks:case Js:return Math.max(e,16)*Math.max(t,8)/4;case Gs:case qs:return Math.max(e,8)*Math.max(t,8)/2;case Ys:case Xs:case Qs:case $s:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*8;case Zs:case ec:case tc:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*16;case nc:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*16;case rc:return Math.floor((e+4)/5)*Math.floor((t+3)/4)*16;case ic:return Math.floor((e+4)/5)*Math.floor((t+4)/5)*16;case ac:return Math.floor((e+5)/6)*Math.floor((t+4)/5)*16;case oc:return Math.floor((e+5)/6)*Math.floor((t+5)/6)*16;case sc:return Math.floor((e+7)/8)*Math.floor((t+4)/5)*16;case cc:return Math.floor((e+7)/8)*Math.floor((t+5)/6)*16;case lc:return Math.floor((e+7)/8)*Math.floor((t+7)/8)*16;case uc:return Math.floor((e+9)/10)*Math.floor((t+4)/5)*16;case dc:return Math.floor((e+9)/10)*Math.floor((t+5)/6)*16;case fc:return Math.floor((e+9)/10)*Math.floor((t+7)/8)*16;case pc:return Math.floor((e+9)/10)*Math.floor((t+9)/10)*16;case mc:return Math.floor((e+11)/12)*Math.floor((t+9)/10)*16;case hc:return Math.floor((e+11)/12)*Math.floor((t+11)/12)*16;case gc:case _c:case vc:return Math.ceil(e/4)*Math.ceil(t/4)*16;case yc:case bc:return Math.ceil(e/4)*Math.ceil(t/4)*8;case xc:case Sc:return Math.ceil(e/4)*Math.ceil(t/4)*16}throw Error(`Unable to determine texture byte length for ${n} format.`)}function Ep(e){switch(e){case vs:case ys:return{byteLength:1,components:1};case xs:case bs:case Ts:return{byteLength:2,components:1};case Es:case Ds:return{byteLength:2,components:4};case Cs:case Ss:case ws:return{byteLength:4,components:1};case ks:case As:return{byteLength:4,components:3}}throw Error(`THREE.TextureUtils: Unknown texture type ${e}.`)}typeof __THREE_DEVTOOLS__<`u`&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent(`register`,{detail:{revision:`186`}})),typeof window<`u`&&(window.__THREE__?q(`WARNING: Multiple instances of Three.js being imported.`):window.__THREE__=`186`);function Dp(){let e=null,t=!1,n=null,r=null;function i(t,a){r=e.requestAnimationFrame(i),n(t,a)}return{start:function(){t!==!0&&n!==null&&e!==null&&(r=e.requestAnimationFrame(i),t=!0)},stop:function(){e!==null&&e.cancelAnimationFrame(r),t=!1},setAnimationLoop:function(e){n=e},setContext:function(t){e=t}}}function Op(e){let t=new WeakMap;function n(t,n){let r=t.array,i=t.usage,a=r.byteLength,o=e.createBuffer();e.bindBuffer(n,o),e.bufferData(n,r,i),t.onUploadCallback();let s;if(r instanceof Float32Array)s=e.FLOAT;else if(typeof Float16Array<`u`&&r instanceof Float16Array)s=e.HALF_FLOAT;else if(r instanceof Uint16Array)s=t.isFloat16BufferAttribute?e.HALF_FLOAT:e.UNSIGNED_SHORT;else if(r instanceof Int16Array)s=e.SHORT;else if(r instanceof Uint32Array)s=e.UNSIGNED_INT;else if(r instanceof Int32Array)s=e.INT;else if(r instanceof Int8Array)s=e.BYTE;else if(r instanceof Uint8Array)s=e.UNSIGNED_BYTE;else if(r instanceof Uint8ClampedArray)s=e.UNSIGNED_BYTE;else throw Error(`THREE.WebGLAttributes: Unsupported buffer data format: `+r);return{buffer:o,type:s,bytesPerElement:r.BYTES_PER_ELEMENT,version:t.version,size:a}}function r(t,n,r){let i=n.array,a=n.updateRanges;if(e.bindBuffer(r,t),a.length===0)e.bufferSubData(r,0,i);else{a.sort((e,t)=>e.start-t.start);let t=0;for(let e=1;e<a.length;e++){let n=a[t],r=a[e];r.start<=n.start+n.count+1?n.count=Math.max(n.count,r.start+r.count-n.start):(++t,a[t]=r)}a.length=t+1;for(let t=0,n=a.length;t<n;t++){let n=a[t];e.bufferSubData(r,n.start*i.BYTES_PER_ELEMENT,i,n.start,n.count)}n.clearUpdateRanges()}n.onUploadCallback()}function i(e){return e.isInterleavedBufferAttribute&&(e=e.data),t.get(e)}function a(n){n.isInterleavedBufferAttribute&&(n=n.data);let r=t.get(n);r&&(e.deleteBuffer(r.buffer),t.delete(n))}function o(e,i){if(e.isInterleavedBufferAttribute&&(e=e.data),e.isGLBufferAttribute){let n=t.get(e);(!n||n.version<e.version)&&t.set(e,{buffer:e.buffer,type:e.type,bytesPerElement:e.elementSize,version:e.version});return}let a=t.get(e);if(a===void 0)t.set(e,n(e,i));else if(a.version<e.version){if(a.size!==e.array.byteLength)throw Error(`THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.`);r(a.buffer,e,i),a.version=e.version}}return{get:i,remove:a,update:o}}var Q={alphahash_fragment:`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,alphahash_pars_fragment:`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,alphamap_fragment:`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,alphamap_pars_fragment:`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,alphatest_fragment:`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,alphatest_pars_fragment:`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,aomap_fragment:`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,aomap_pars_fragment:`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,batching_pars_vertex:`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,batching_vertex:`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,begin_vertex:`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,beginnormal_vertex:`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,bsdfs:`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,iridescence_fragment:`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,bumpmap_pars_fragment:`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,clipping_planes_fragment:`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,clipping_planes_pars_fragment:`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,clipping_planes_pars_vertex:`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,clipping_planes_vertex:`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,color_fragment:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,color_pars_fragment:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,color_pars_vertex:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,color_vertex:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,common:`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,cube_uv_reflection_fragment:`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,defaultnormal_vertex:`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,displacementmap_pars_vertex:`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,displacementmap_vertex:`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,emissivemap_fragment:`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,emissivemap_pars_fragment:`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,colorspace_fragment:`gl_FragColor = linearToOutputTexel( gl_FragColor );`,colorspace_pars_fragment:`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,envmap_fragment:`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,envmap_common_pars_fragment:`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,envmap_pars_fragment:`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,envmap_pars_vertex:`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,envmap_physical_pars_fragment:`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_RETROREFLECTION
		vec3 getIBLRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 retroVec = normalize( mix( viewDir, normal, pow4( roughness ) ) );
				retroVec = transformDirectionByInverseViewMatrix( retroVec, viewMatrix );
				vec4 envMapColor = textureCubeUV( envMap, envMapRotation * retroVec, roughness );
				return envMapColor.rgb * envMapIntensity;
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
		#ifdef USE_RETROREFLECTION
			vec3 getIBLAnisotropyRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
				#ifdef ENVMAP_TYPE_CUBE_UV
					vec3 bentNormal = cross( bitangent, viewDir );
					bentNormal = normalize( cross( bentNormal, bitangent ) );
					bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
					return getIBLRetroRadiance( viewDir, bentNormal, roughness );
				#else
					return vec3( 0.0 );
				#endif
			}
		#endif
	#endif
#endif`,envmap_vertex:`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,fog_vertex:`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,fog_pars_vertex:`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,fog_fragment:`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,fog_pars_fragment:`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,gradientmap_pars_fragment:`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,lightmap_pars_fragment:`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,lights_lambert_fragment:`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,lights_lambert_pars_fragment:`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,lights_pars_begin:`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_SUN_LIGHTS > 0
	struct SunLight {
		vec3 direction;
		vec3 color;
	};
	uniform SunLight sunLights[ NUM_SUN_LIGHTS ];
	void getSunLightInfo( const in SunLight sunLight, out IncidentLight light ) {
		light.color = sunLight.color;
		light.direction = sunLight.direction;
		light.visible = true;
	}
#endif
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,lights_toon_fragment:`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,lights_toon_pars_fragment:`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,lights_phong_fragment:`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,lights_phong_pars_fragment:`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,lights_physical_fragment:`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_RETROREFLECTION
	material.retroreflectivity = retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,lights_physical_pars_fragment:`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	vec2 dfg;
	vec3 multiScatteringCompensation;
	#ifdef USE_RETROREFLECTION
		float retroreflectivity;
	#endif
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0Dielectric;
		vec3 iridescenceF0Metallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec2 fab, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec2 fab, const in vec3 specularColor, const in float specularF90, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	vec3 specularBRDF = BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	#ifdef USE_RETROREFLECTION
		vec3 retroViewDir = reflect( - geometryViewDir, geometryNormal );
		vec3 retroSpecularBRDF = BRDF_GGX( directLight.direction, retroViewDir, geometryNormal, material );
		specularBRDF = mix( specularBRDF, retroSpecularBRDF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directSpecular += irradiance * specularBRDF * material.multiScatteringCompensation;
	vec3 halfDir = normalize( directLight.direction + geometryViewDir );
	float dotVH = saturate( dot( geometryViewDir, halfDir ) );
	vec3 F = F_Schlick( material.specularColor, material.specularF90, dotVH );
	#ifdef USE_RETROREFLECTION
		vec3 retroHalfDir = normalize( directLight.direction + retroViewDir );
		float dotRetroVH = saturate( dot( retroViewDir, retroHalfDir ) );
		vec3 retroF = F_Schlick( material.specularColor, material.specularF90, dotRetroVH );
		F = mix( F, retroF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - F );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScattering, multiScattering );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScattering, multiScattering );
	#endif
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - singleScattering - multiScattering );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		sheenSpecularIndirect += irradiance * material.sheenColor * sheenAlbedo * RECIPROCAL_PI;
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( material.dfg, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceF0Metallic, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( material.dfg, material.diffuseColor, material.specularF90, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,lights_fragment_begin:`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		vec3 iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		vec3 iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( iridescenceFresnelDielectric, iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0Dielectric = Schlick_to_F0( iridescenceFresnelDielectric, 1.0, dotNVi );
		material.iridescenceF0Metallic = Schlick_to_F0( iridescenceFresnelMetallic, 1.0, dotNVi );
	}
#endif
#ifdef STANDARD
	float dotNVms = saturate( dot( geometryNormal, geometryViewDir ) );
	material.dfg = texture2D( dfgLUT, vec2( material.roughness, dotNVms ) ).rg;
	#if ( NUM_SUN_LIGHTS > 0 || NUM_DIR_LIGHTS > 0 || NUM_POINT_LIGHTS > 0 || NUM_SPOT_LIGHTS > 0 )
		float EssMs = material.dfg.x + material.dfg.y;
		material.multiScatteringCompensation = 1.0 + material.specularColorBlended * ( 1.0 / EssMs - 1.0 );
	#endif
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SUN_LIGHTS > 0 ) && defined( RE_Direct )
	SunLight sunLight;
	#if defined( USE_SHADOWMAP ) && NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHTS; i ++ ) {
		sunLight = sunLights[ i ];
		getSunLightInfo( sunLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SUN_LIGHT_SHADOWS )
		sunLightShadow = sunLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getSunShadow( sunShadowMap[ i ], sunLightShadow, UNROLLED_LOOP_INDEX ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#ifdef USE_LIGHT_PROBES_GRID
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,lights_fragment_maps:`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		vec3 iblRadiance = getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		vec3 iblRadiance = getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_RETROREFLECTION
		#ifdef USE_ANISOTROPY
			vec3 retroIBLRadiance = getIBLAnisotropyRetroRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
		#else
			vec3 retroIBLRadiance = getIBLRetroRadiance( geometryViewDir, geometryNormal, material.roughness );
		#endif
		iblRadiance = mix( iblRadiance, retroIBLRadiance, saturate( material.retroreflectivity ) );
	#endif
	radiance += iblRadiance;
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,lights_fragment_end:`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,lightprobes_pars_fragment:`#ifdef USE_LIGHT_PROBES_GRID
uniform highp sampler3D probesSH;
uniform vec3 probesMin;
uniform vec3 probesMax;
uniform vec3 probesResolution;
vec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 resMinusOne = res - 1.0;
	vec3 probeSpacing = gridRange / resMinusOne;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );
	uvw = uvw * resMinusOne / res + 0.5 / res;
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,logdepthbuf_fragment:`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,logdepthbuf_pars_fragment:`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,logdepthbuf_pars_vertex:`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,logdepthbuf_vertex:`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,map_fragment:`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,map_pars_fragment:`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,map_particle_fragment:`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,map_particle_pars_fragment:`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,metalnessmap_fragment:`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,metalnessmap_pars_fragment:`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,morphinstance_vertex:`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,morphcolor_vertex:`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,morphnormal_vertex:`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,morphtarget_pars_vertex:`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,morphtarget_vertex:`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,normal_fragment_begin:`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,normal_fragment_maps:`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,normal_pars_fragment:`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,normal_pars_vertex:`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,normal_vertex:`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,normalmap_pars_fragment:`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,clearcoat_normal_fragment_begin:`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,clearcoat_normal_fragment_maps:`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,clearcoat_pars_fragment:`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,iridescence_pars_fragment:`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,opaque_fragment:`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,packing:`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,premultiplied_alpha_fragment:`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,project_vertex:`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,dithering_fragment:`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,dithering_pars_fragment:`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,roughnessmap_fragment:`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,roughnessmap_pars_fragment:`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,shadowmap_pars_fragment:`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		#define SUN_LIGHT_CASCADES 2
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#else
			uniform sampler2D sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#endif
		uniform mat4 sunShadowMatrix[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		uniform vec4 sunShadowCascade[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
		struct SunLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SunLightShadow sunLightShadows[ NUM_SUN_LIGHT_SHADOWS ];
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_SUN_LIGHT_SHADOWS > 0
		float getSunShadow(
			#if defined( SHADOWMAP_TYPE_PCF )
				sampler2DShadow shadowMap,
			#else
				sampler2D shadowMap,
			#endif
			SunLightShadow sunLightShadow,
			int shadowIndex
		) {
			vec4 shadowWorldPosition = vec4( vSunShadowWorldPosition.xyz + vSunShadowWorldNormal * sunLightShadow.shadowNormalBias, 1.0 );
			float viewDepth = vSunShadowWorldPosition.w;
			int cascadeOffset = shadowIndex * SUN_LIGHT_CASCADES;
			float shadow = 1.0;
			for ( int i = SUN_LIGHT_CASCADES - 1; i >= 0; i -- ) {
				vec4 cascade = sunShadowCascade[ cascadeOffset + i ];
				if ( viewDepth >= cascade.x && viewDepth < cascade.y ) {
					float cascadeShadow = getShadow(
						shadowMap,
						sunLightShadow.shadowMapSize,
						sunLightShadow.shadowIntensity,
						sunLightShadow.shadowBias,
						sunLightShadow.shadowRadius,
						sunShadowMatrix[ cascadeOffset + i ] * shadowWorldPosition
					);
					shadow = mix( cascadeShadow, shadow, smoothstep( cascade.z, cascade.y, viewDepth ) );
				}
			}
			return shadow;
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,shadowmap_pars_vertex:`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,shadowmap_vertex:`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_SUN_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_SUN_LIGHT_SHADOWS > 0
		vSunShadowWorldPosition = vec4( worldPosition.xyz, - mvPosition.z );
		vSunShadowWorldNormal = shadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,shadowmask_pars_fragment:`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHT_SHADOWS; i ++ ) {
		sunLight = sunLightShadows[ i ];
		shadow *= receiveShadow ? getSunShadow( sunShadowMap[ i ], sunLight, UNROLLED_LOOP_INDEX ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,skinbase_vertex:`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,skinning_pars_vertex:`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,skinning_vertex:`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,skinnormal_vertex:`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,specularmap_fragment:`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,specularmap_pars_fragment:`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,tonemapping_fragment:`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,tonemapping_pars_fragment:`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,transmission_fragment:`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,transmission_pars_fragment:`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,uv_pars_fragment:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,uv_pars_vertex:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,uv_vertex:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,worldpos_vertex:`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,background_vert:`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,background_frag:`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,backgroundCube_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,backgroundCube_frag:`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,cube_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,cube_frag:`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,depth_vert:`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,depth_frag:`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,distance_vert:`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,distance_frag:`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,equirect_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,equirect_frag:`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,linedashed_vert:`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,linedashed_frag:`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,meshbasic_vert:`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,meshbasic_frag:`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshlambert_vert:`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshlambert_frag:`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshmatcap_vert:`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,meshmatcap_frag:`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshnormal_vert:`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,meshnormal_frag:`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,meshphong_vert:`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshphong_frag:`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshphysical_vert:`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,meshphysical_frag:`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_RETROREFLECTION
	uniform float retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshtoon_vert:`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshtoon_frag:`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,points_vert:`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,points_frag:`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,shadow_vert:`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,shadow_frag:`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,sprite_vert:`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,sprite_frag:`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`},$={common:{diffuse:{value:new cu(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Z},alphaMap:{value:null},alphaMapTransform:{value:new Z},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Z}},envmap:{envMap:{value:null},envMapRotation:{value:new Z},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Z}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Z}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Z},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Z},normalScale:{value:new Y(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Z},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Z}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Z}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Z}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new cu(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},sunLights:{value:[],properties:{direction:{},color:{}}},sunLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},sunShadowMatrix:{value:[]},sunShadowCascade:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new X},probesMax:{value:new X},probesResolution:{value:new X}},points:{diffuse:{value:new cu(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Z},alphaTest:{value:0},uvTransform:{value:new Z}},sprite:{diffuse:{value:new cu(16777215)},opacity:{value:1},center:{value:new Y(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Z},alphaMap:{value:null},alphaMapTransform:{value:new Z},alphaTest:{value:0}}},kp={basic:{uniforms:wf([$.common,$.specularmap,$.envmap,$.aomap,$.lightmap,$.fog]),vertexShader:Q.meshbasic_vert,fragmentShader:Q.meshbasic_frag},lambert:{uniforms:wf([$.common,$.specularmap,$.envmap,$.aomap,$.lightmap,$.emissivemap,$.bumpmap,$.normalmap,$.displacementmap,$.fog,$.lights,{emissive:{value:new cu(0)},envMapIntensity:{value:1}}]),vertexShader:Q.meshlambert_vert,fragmentShader:Q.meshlambert_frag},phong:{uniforms:wf([$.common,$.specularmap,$.envmap,$.aomap,$.lightmap,$.emissivemap,$.bumpmap,$.normalmap,$.displacementmap,$.fog,$.lights,{emissive:{value:new cu(0)},specular:{value:new cu(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:Q.meshphong_vert,fragmentShader:Q.meshphong_frag},standard:{uniforms:wf([$.common,$.envmap,$.aomap,$.lightmap,$.emissivemap,$.bumpmap,$.normalmap,$.displacementmap,$.roughnessmap,$.metalnessmap,$.fog,$.lights,{emissive:{value:new cu(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Q.meshphysical_vert,fragmentShader:Q.meshphysical_frag},toon:{uniforms:wf([$.common,$.aomap,$.lightmap,$.emissivemap,$.bumpmap,$.normalmap,$.displacementmap,$.gradientmap,$.fog,$.lights,{emissive:{value:new cu(0)}}]),vertexShader:Q.meshtoon_vert,fragmentShader:Q.meshtoon_frag},matcap:{uniforms:wf([$.common,$.bumpmap,$.normalmap,$.displacementmap,$.fog,{matcap:{value:null}}]),vertexShader:Q.meshmatcap_vert,fragmentShader:Q.meshmatcap_frag},points:{uniforms:wf([$.points,$.fog]),vertexShader:Q.points_vert,fragmentShader:Q.points_frag},dashed:{uniforms:wf([$.common,$.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Q.linedashed_vert,fragmentShader:Q.linedashed_frag},depth:{uniforms:wf([$.common,$.displacementmap]),vertexShader:Q.depth_vert,fragmentShader:Q.depth_frag},normal:{uniforms:wf([$.common,$.bumpmap,$.normalmap,$.displacementmap,{opacity:{value:1}}]),vertexShader:Q.meshnormal_vert,fragmentShader:Q.meshnormal_frag},sprite:{uniforms:wf([$.sprite,$.fog]),vertexShader:Q.sprite_vert,fragmentShader:Q.sprite_frag},background:{uniforms:{uvTransform:{value:new Z},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Q.background_vert,fragmentShader:Q.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Z}},vertexShader:Q.backgroundCube_vert,fragmentShader:Q.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Q.cube_vert,fragmentShader:Q.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Q.equirect_vert,fragmentShader:Q.equirect_frag},distance:{uniforms:wf([$.common,$.displacementmap,{referencePosition:{value:new X},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Q.distance_vert,fragmentShader:Q.distance_frag},shadow:{uniforms:wf([$.lights,$.fog,{color:{value:new cu(0)},opacity:{value:1}}]),vertexShader:Q.shadow_vert,fragmentShader:Q.shadow_frag}};kp.physical={uniforms:wf([kp.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Z},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Z},clearcoatNormalScale:{value:new Y(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Z},dispersion:{value:0},retroreflectivity:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Z},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Z},sheen:{value:0},sheenColor:{value:new cu(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Z},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Z},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Z},transmissionSamplerSize:{value:new Y},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Z},attenuationDistance:{value:0},attenuationColor:{value:new cu(0)},specularColor:{value:new cu(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Z},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Z},anisotropyVector:{value:new Y},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Z}}]),vertexShader:Q.meshphysical_vert,fragmentShader:Q.meshphysical_frag};var Ap={r:0,b:0,g:0},jp=new Dl,Mp=new Z;Mp.set(-1,0,0,0,1,0,0,0,1);function Np(e,t,n,r,i,a){let o=new cu(0),s=i===!0?0:1,c,l,u=null,d=0,f=null;function p(e){let n=e.isScene===!0?e.background:null;if(n&&n.isTexture){let r=e.backgroundBlurriness>0;n=t.get(n,r)}return n}function m(t){let r=!1,i=p(t);i===null?g(o,s):i&&i.isColor&&(g(i,1),r=!0);let c=e.xr.getEnvironmentBlendMode();c===`additive`?n.buffers.color.setClear(0,0,0,1,a):c===`alpha-blend`&&n.buffers.color.setClear(0,0,0,0,a),(e.autoClear||r)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil))}function h(t,n){let i=p(n);i&&(i.isCubeTexture||i.mapping===306)?(l===void 0&&(l=new qd(new bf(1,1,1),new jf({name:`BackgroundCubeMaterial`,uniforms:Cf(kp.backgroundCube.uniforms),vertexShader:kp.backgroundCube.vertexShader,fragmentShader:kp.backgroundCube.fragmentShader,side:1,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),l.geometry.deleteAttribute(`normal`),l.geometry.deleteAttribute(`uv`),l.onBeforeRender=function(e,t,n){this.matrixWorld.copyPosition(n.matrixWorld)},Object.defineProperty(l.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),r.update(l)),l.material.uniforms.envMap.value=i,l.material.uniforms.backgroundBlurriness.value=n.backgroundBlurriness,l.material.uniforms.backgroundIntensity.value=n.backgroundIntensity,l.material.uniforms.backgroundRotation.value.setFromMatrix4(jp.makeRotationFromEuler(n.backgroundRotation)).transpose(),i.isCubeTexture&&i.isRenderTargetTexture===!1&&l.material.uniforms.backgroundRotation.value.premultiply(Mp),l.material.toneMapped=dl.getTransfer(i.colorSpace)!==Pc,(u!==i||d!==i.version||f!==e.toneMapping)&&(l.material.needsUpdate=!0,u=i,d=i.version,f=e.toneMapping),l.layers.enableAll(),t.unshift(l,l.geometry,l.material,0,0,null)):i&&i.isTexture&&(c===void 0&&(c=new qd(new xf(2,2),new jf({name:`BackgroundMaterial`,uniforms:Cf(kp.background.uniforms),vertexShader:kp.background.vertexShader,fragmentShader:kp.background.fragmentShader,side:0,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),c.geometry.deleteAttribute(`normal`),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),r.update(c)),c.material.uniforms.t2D.value=i,c.material.uniforms.backgroundIntensity.value=n.backgroundIntensity,c.material.toneMapped=dl.getTransfer(i.colorSpace)!==Pc,i.matrixAutoUpdate===!0&&i.updateMatrix(),c.material.uniforms.uvTransform.value.copy(i.matrix),(u!==i||d!==i.version||f!==e.toneMapping)&&(c.material.needsUpdate=!0,u=i,d=i.version,f=e.toneMapping),c.layers.enableAll(),t.unshift(c,c.geometry,c.material,0,0,null))}function g(t,r){t.getRGB(Ap,Df(e)),n.buffers.color.setClear(Ap.r,Ap.g,Ap.b,r,a)}function _(){l!==void 0&&(l.geometry.dispose(),l.material.dispose(),l=void 0),c!==void 0&&(c.geometry.dispose(),c.material.dispose(),c=void 0)}return{getClearColor:function(){return o},setClearColor:function(e,t=1){o.set(e),s=t,g(o,s)},getClearAlpha:function(){return s},setClearAlpha:function(e){s=e,g(o,s)},render:m,addToRenderList:h,dispose:_}}function Pp(e,t){let n=e.getParameter(e.MAX_VERTEX_ATTRIBS),r={},i=f(null),a=i,o=!1;function s(n,r,i,s,c){let u=!1,f=d(n,s,i,r);a!==f&&(a=f,l(a.object)),u=p(n,s,i,c),u&&m(n,s,i,c),c!==null&&t.update(c,e.ELEMENT_ARRAY_BUFFER),(u||o)&&(o=!1,b(n,r,i,s),c!==null&&e.bindBuffer(e.ELEMENT_ARRAY_BUFFER,t.get(c).buffer))}function c(){return e.createVertexArray()}function l(t){return e.bindVertexArray(t)}function u(t){return e.deleteVertexArray(t)}function d(e,t,n,i){let a=i.wireframe===!0,o=r[t.id];o===void 0&&(o={},r[t.id]=o);let s=e.isInstancedMesh===!0?e.id:0,l=o[s];l===void 0&&(l={},o[s]=l);let u=l[n.id];u===void 0&&(u={},l[n.id]=u);let d=u[a];return d===void 0&&(d=f(c()),u[a]=d),d}function f(e){let t=[],r=[],i=[];for(let e=0;e<n;e++)t[e]=0,r[e]=0,i[e]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:t,enabledAttributes:r,attributeDivisors:i,object:e,attributes:{},index:null}}function p(e,t,n,r){let i=a.attributes,o=t.attributes,s=0,c=n.getAttributes();for(let t in c)if(c[t].location>=0){let n=i[t],r=o[t];if(r===void 0&&(t===`instanceMatrix`&&e.instanceMatrix&&(r=e.instanceMatrix),t===`instanceColor`&&e.instanceColor&&(r=e.instanceColor)),n===void 0||n.attribute!==r||r&&n.data!==r.data)return!0;s++}return a.attributesNum!==s||a.index!==r}function m(e,t,n,r){let i={},o=t.attributes,s=0,c=n.getAttributes();for(let t in c)if(c[t].location>=0){let n=o[t];n===void 0&&(t===`instanceMatrix`&&e.instanceMatrix&&(n=e.instanceMatrix),t===`instanceColor`&&e.instanceColor&&(n=e.instanceColor));let r={};r.attribute=n,n&&n.data&&(r.data=n.data),i[t]=r,s++}a.attributes=i,a.attributesNum=s,a.index=r}function h(){let e=a.newAttributes;for(let t=0,n=e.length;t<n;t++)e[t]=0}function g(e){_(e,0)}function _(t,n){let r=a.newAttributes,i=a.enabledAttributes,o=a.attributeDivisors;r[t]=1,i[t]===0&&(e.enableVertexAttribArray(t),i[t]=1),o[t]!==n&&(e.vertexAttribDivisor(t,n),o[t]=n)}function v(){let t=a.newAttributes,n=a.enabledAttributes;for(let r=0,i=n.length;r<i;r++)n[r]!==t[r]&&(e.disableVertexAttribArray(r),n[r]=0)}function y(t,n,r,i,a,o,s){s===!0?e.vertexAttribIPointer(t,n,r,a,o):e.vertexAttribPointer(t,n,r,i,a,o)}function b(n,r,i,a){h();let o=a.attributes,s=i.getAttributes(),c=r.defaultAttributeValues;for(let r in s){let i=s[r];if(i.location>=0){let s=o[r];if(s===void 0&&(r===`instanceMatrix`&&n.instanceMatrix&&(s=n.instanceMatrix),r===`instanceColor`&&n.instanceColor&&(s=n.instanceColor)),s!==void 0){let r=s.normalized,o=s.itemSize,c=t.get(s);if(c===void 0)continue;let l=c.buffer,u=c.type,d=c.bytesPerElement,f=u===e.INT||u===e.UNSIGNED_INT||s.gpuType===1013;if(s.isInterleavedBufferAttribute){let t=s.data,c=t.stride,p=s.offset;if(t.isInstancedInterleavedBuffer){for(let e=0;e<i.locationSize;e++)_(i.location+e,t.meshPerAttribute);n.isInstancedMesh!==!0&&a._maxInstanceCount===void 0&&(a._maxInstanceCount=t.meshPerAttribute*t.count)}else for(let e=0;e<i.locationSize;e++)g(i.location+e);e.bindBuffer(e.ARRAY_BUFFER,l);for(let e=0;e<i.locationSize;e++)y(i.location+e,o/i.locationSize,u,r,c*d,(p+o/i.locationSize*e)*d,f)}else{if(s.isInstancedBufferAttribute){for(let e=0;e<i.locationSize;e++)_(i.location+e,s.meshPerAttribute);n.isInstancedMesh!==!0&&a._maxInstanceCount===void 0&&(a._maxInstanceCount=s.meshPerAttribute*s.count)}else for(let e=0;e<i.locationSize;e++)g(i.location+e);e.bindBuffer(e.ARRAY_BUFFER,l);for(let e=0;e<i.locationSize;e++)y(i.location+e,o/i.locationSize,u,r,o*d,o/i.locationSize*e*d,f)}}else if(c!==void 0){let t=c[r];if(t!==void 0)switch(t.length){case 2:e.vertexAttrib2fv(i.location,t);break;case 3:e.vertexAttrib3fv(i.location,t);break;case 4:e.vertexAttrib4fv(i.location,t);break;default:e.vertexAttrib1fv(i.location,t)}}}}v()}function x(){T();for(let e in r){let t=r[e];for(let e in t){let n=t[e];for(let e in n){let t=n[e];for(let e in t)u(t[e].object),delete t[e];delete n[e]}}delete r[e]}}function S(e){if(r[e.id]===void 0)return;let t=r[e.id];for(let e in t){let n=t[e];for(let e in n){let t=n[e];for(let e in t)u(t[e].object),delete t[e];delete n[e]}}delete r[e.id]}function C(e){for(let t in r){let n=r[t];for(let t in n){let r=n[t];if(r[e.id]===void 0)continue;let i=r[e.id];for(let e in i)u(i[e].object),delete i[e];delete r[e.id]}}}function w(e){for(let t in r){let n=r[t],i=e.isInstancedMesh===!0?e.id:0,a=n[i];if(a!==void 0){for(let e in a){let t=a[e];for(let e in t)u(t[e].object),delete t[e];delete a[e]}delete n[i],Object.keys(n).length===0&&delete r[t]}}}function T(){E(),o=!0,a!==i&&(a=i,l(a.object))}function E(){i.geometry=null,i.program=null,i.wireframe=!1}return{setup:s,reset:T,resetDefaultState:E,dispose:x,releaseStatesOfGeometry:S,releaseStatesOfObject:w,releaseStatesOfProgram:C,initAttributes:h,enableAttribute:g,disableUnusedAttributes:v}}function Fp(e,t,n){let r;function i(e){r=e}function a(t,i){e.drawArrays(r,t,i),n.update(i,r,1)}function o(t,i,a){a!==0&&(e.drawArraysInstanced(r,t,i,a),n.update(i,r,a))}function s(e,i,a){if(a===0)return;t.get(`WEBGL_multi_draw`).multiDrawArraysWEBGL(r,e,0,i,0,a);let o=0;for(let e=0;e<a;e++)o+=i[e];n.update(o,r,1)}this.setMode=i,this.render=a,this.renderInstances=o,this.renderMultiDraw=s}function Ip(e,t,n,r){let i;function a(){if(i!==void 0)return i;if(t.has(`EXT_texture_filter_anisotropic`)===!0){let n=t.get(`EXT_texture_filter_anisotropic`);i=e.getParameter(n.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else i=0;return i}function o(t){return t===1023||r.convert(t)===e.getParameter(e.IMPLEMENTATION_COLOR_READ_FORMAT)}function s(n){let i=n===1016&&(t.has(`EXT_color_buffer_half_float`)||t.has(`EXT_color_buffer_float`));return!(n!==1009&&n!==1015&&!i&&r.convert(n)!==e.getParameter(e.IMPLEMENTATION_COLOR_READ_TYPE))}function c(t){if(t===`highp`){if(e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.HIGH_FLOAT).precision>0&&e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.HIGH_FLOAT).precision>0)return`highp`;t=`mediump`}return t===`mediump`&&e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.MEDIUM_FLOAT).precision>0&&e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.MEDIUM_FLOAT).precision>0?`mediump`:`lowp`}let l=n.precision===void 0?`highp`:n.precision,u=c(l);u!==l&&(q(`WebGLRenderer:`,l,`not supported, using`,u,`instead.`),l=u);let d=n.logarithmicDepthBuffer===!0,f=n.reversedDepthBuffer===!0&&t.has(`EXT_clip_control`);n.reversedDepthBuffer===!0&&f===!1&&q(`WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.`);let p=e.getParameter(e.MAX_TEXTURE_IMAGE_UNITS),m=e.getParameter(e.MAX_VERTEX_TEXTURE_IMAGE_UNITS),h=e.getParameter(e.MAX_TEXTURE_SIZE),g=e.getParameter(e.MAX_CUBE_MAP_TEXTURE_SIZE),_=e.getParameter(e.MAX_VERTEX_ATTRIBS),v=e.getParameter(e.MAX_VERTEX_UNIFORM_VECTORS),y=e.getParameter(e.MAX_VARYING_VECTORS),b=e.getParameter(e.MAX_FRAGMENT_UNIFORM_VECTORS),x=e.getParameter(e.MAX_SAMPLES),S=e.getParameter(e.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:a,getMaxPrecision:c,textureFormatReadable:o,textureTypeReadable:s,precision:l,logarithmicDepthBuffer:d,reversedDepthBuffer:f,maxTextures:p,maxVertexTextures:m,maxTextureSize:h,maxCubemapSize:g,maxAttributes:_,maxVertexUniforms:v,maxVaryings:y,maxFragmentUniforms:b,maxSamples:x,samples:S}}function Lp(e){let t=this,n=null,r=0,i=!1,a=!1,o=new dd,s=new Z,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(e,t){let n=e.length!==0||t||r!==0||i;return i=t,r=e.length,n},this.beginShadows=function(){a=!0,u(null)},this.endShadows=function(){a=!1},this.setGlobalState=function(e,t){n=u(e,t,0)},this.setState=function(t,o,s){let d=t.clippingPlanes,f=t.clipIntersection,p=t.clipShadows,m=e.get(t);if(!i||d===null||d.length===0||a&&!p)a?u(null):l();else{let e=a?0:r,t=e*4,i=m.clippingState||null;c.value=i,i=u(d,o,t,s);for(let e=0;e!==t;++e)i[e]=n[e];m.clippingState=i,this.numIntersection=f?this.numPlanes:0,this.numPlanes+=e}};function l(){c.value!==n&&(c.value=n,c.needsUpdate=r>0),t.numPlanes=r,t.numIntersection=0}function u(e,n,r,i){let a=e===null?0:e.length,l=null;if(a!==0){if(l=c.value,i!==!0||l===null){let t=r+a*4,i=n.matrixWorldInverse;s.getNormalMatrix(i),(l===null||l.length<t)&&(l=new Float32Array(t));for(let t=0,n=r;t!==a;++t,n+=4)o.copy(e[t]).applyMatrix4(i,s),o.normal.toArray(l,n),l[n+3]=o.constant}c.value=l,c.needsUpdate=!0}return t.numPlanes=a,t.numIntersection=0,l}}var Rp=4,zp=6,Bp=20,Vp=256,Hp=new cp,Up=new cu,Wp=null,Gp=0,Kp=0,qp=!1,Jp=new X,Yp=new X,Xp=class{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(e,t=0,n=.1,r=100,i={}){let{size:a=256,position:o=Jp}=i;Wp=this._renderer.getRenderTarget(),Gp=this._renderer.getActiveCubeFace(),Kp=this._renderer.getActiveMipmapLevel(),qp=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(a);let s=this._allocateTargets();return s.depthBuffer=!0,this._sceneToCubeUV(e,n,r,s,o),t>0&&this._blur(s,0,0,t),this._applyPMREM(s),this._cleanup(s),s}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=rm(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=nm(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=2**this._lodMax}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodMeshes.length;e++)this._lodMeshes[e].geometry.dispose()}_cleanup(e){this._renderer.setRenderTarget(Wp,Gp,Kp),this._renderer.xr.enabled=qp,e.scissorTest=!1,$p(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===301||e.mapping===302?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),Wp=this._renderer.getRenderTarget(),Gp=this._renderer.getActiveCubeFace(),Kp=this._renderer.getActiveMipmapLevel(),qp=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;let n=t||this._allocateTargets();return this._textureToCubeUV(e,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){let e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,n={magFilter:hs,minFilter:hs,generateMipmaps:!1,type:Ts,format:Ns,colorSpace:Mc,depthBuffer:!1},r=Qp(e,t,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Qp(e,t,n);let{_lodMax:r}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods}=Zp(r)),this._blurMaterial=tm(r,e,t),this._ggxMaterial=em(r,e,t)}return r}_compileMaterial(e){let t=new qd(new id,e);this._renderer.compile(t,Hp)}_sceneToCubeUV(e,t,n,r,i){let a=new sp(90,1,t,n),o=[1,-1,1,1,1,1],s=[1,1,1,-1,-1,-1],c=this._renderer,l=c.autoClear,u=c.toneMapping;c.getClearColor(Up),c.toneMapping=0,c.autoClear=!1,c.state.buffers.depth.getReversed()&&(c.setRenderTarget(r),c.clearDepth(),c.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new qd(new bf,new Fd({name:`PMREM.Background`,side:1,depthWrite:!1,depthTest:!1})));let d=this._backgroundBox,f=d.material,p=!1,m=e.background;m?m.isColor&&(f.color.copy(m),e.background=null,p=!0):(f.color.copy(Up),p=!0);for(let t=0;t<6;t++){let n=t%3;n===0?(a.up.set(0,o[t],0),a.position.set(i.x,i.y,i.z),a.lookAt(i.x+s[t],i.y,i.z)):n===1?(a.up.set(0,0,o[t]),a.position.set(i.x,i.y,i.z),a.lookAt(i.x,i.y+s[t],i.z)):(a.up.set(0,o[t],0),a.position.set(i.x,i.y,i.z),a.lookAt(i.x,i.y,i.z+s[t]));let l=this._cubeSize;$p(r,n*l,t>2?l:0,l,l),c.setRenderTarget(r),p&&c.render(d,a),c.render(e,a)}c.toneMapping=u,c.autoClear=l,e.background=m}_textureToCubeUV(e,t){let n=this._renderer,r=e.mapping===301||e.mapping===302;r?(this._cubemapMaterial===null&&(this._cubemapMaterial=rm()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=nm());let i=r?this._cubemapMaterial:this._equirectMaterial,a=this._lodMeshes[0];a.material=i;let o=i.uniforms;o.envMap.value=e;let s=this._cubeSize;$p(t,0,0,3*s,2*s),n.setRenderTarget(t),n.render(a,Hp)}_applyPMREM(e){let t=this._renderer,n=t.autoClear;t.autoClear=!1;let r=this._lodMeshes.length;for(let t=1;t<r;t++)this._applyGGXFilter(e,t-1,t);t.autoClear=n}_applyGGXFilter(e,t,n){let r=this._renderer,i=this._pingPongRenderTarget,a=this._ggxMaterial,o=this._lodMeshes[n];o.material=a;let s=a.uniforms,c=n/(this._lodMeshes.length-1),l=t/(this._lodMeshes.length-1),u=Math.sqrt(c*c-l*l)*(c*1.25),{_lodMax:d}=this,f=this._sizeLods[n],p=3*f*(n>d-Rp?n-d+Rp:0),m=4*(this._cubeSize-f);s.envMap.value=e.texture,s.roughness.value=u,s.mipInt.value=d-t,$p(i,p,m,3*f,2*f),r.setRenderTarget(i),r.render(o,Hp),s.envMap.value=i.texture,s.roughness.value=0,s.mipInt.value=d-n,$p(e,p,m,3*f,2*f),r.setRenderTarget(e),r.render(o,Hp)}_blur(e,t,n,r){let i=this._pingPongRenderTarget,a=Math.min(r,Math.PI)/Math.SQRT2;this._blurPass(e,i,t,n,a),this._blurPass(i,e,n,n,a)}_blurPass(e,t,n,r,i){let a=this._renderer,o=this._blurMaterial,s=this._lodMeshes[r];s.material=o;let c=o.uniforms;c.envMap.value=e.texture,c.sigma.value=i,c.mipInt.value=this._lodMax-n;let l=this._sizeLods[r];$p(t,3*l*(r>this._lodMax-Rp?r-this._lodMax+Rp:0),4*(this._cubeSize-l),3*l,2*l),a.setRenderTarget(t),a.render(s,Hp)}};function Zp(e){let t=[],n=[],r=e,i=e-Rp+1+zp;for(let e=0;e<i;e++){let e=2**r;t.push(e);let i=1/(e-2),a=-i,o=1+i,s=[a,a,o,a,o,o,a,a,o,o,a,o],c=new Float32Array(108),l=new Float32Array(108);for(let e=0;e<6;e++){let t=e%3*2/3-1,n=e>2?0:-1,r=[t,n,0,t+2/3,n,0,t+2/3,n+1,0,t,n,0,t+2/3,n+1,0,t,n+1,0];c.set(r,18*e);for(let t=0;t<6;t++){let n=s[t*2]*2-1,r=s[t*2+1]*2-1;e===0?Yp.set(1,r,n):e===1?Yp.set(-n,1,-r):e===2?Yp.set(-n,r,1):e===3?Yp.set(-1,r,-n):e===4?Yp.set(-n,-1,r):Yp.set(n,r,-1),Yp.toArray(l,(e*6+t)*3)}}let u=new id;u.setAttribute(`position`,new Uu(c,3)),u.setAttribute(`outputDirection`,new Uu(l,3)),n.push(new qd(u,null)),r>Rp&&r--}return{lodMeshes:n,sizeLods:t}}function Qp(e,t,n){let r=new wl(e,t,n);return r.texture.mapping=306,r.texture.name=`PMREM.cubeUv`,r.scissorTest=!0,r}function $p(e,t,n,r,i){e.viewport.set(t,n,r,i),e.scissor.set(t,n,r,i)}function em(e,t,n){return new jf({name:`PMREMGGXConvolution`,defines:{GGX_SAMPLES:Vp,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/n,CUBEUV_MAX_MIP:`${e}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:im(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function tm(e,t,n){return new jf({name:`SphericalGaussianBlur`,defines:{SAMPLES:Bp,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/n,CUBEUV_MAX_MIP:`${e}.0`},uniforms:{envMap:{value:null},sigma:{value:0},mipInt:{value:0}},vertexShader:im(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float sigma;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359
			#define GOLDEN_ANGLE 2.39996322973

			void main() {

				if ( sigma == 0.0 ) {

					gl_FragColor = vec4( bilinearCubeUV( envMap, vOutputDirection, mipInt ), 1.0 );
					return;

				}

				vec3 outputDirection = normalize( vOutputDirection );

				vec3 up = abs( outputDirection.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
				vec3 tangent = normalize( cross( up, outputDirection ) );
				vec3 bitangent = cross( outputDirection, tangent );

				// Truncate the kernel at three standard deviations or at the antipode.
				float thetaMax = min( 3.0 * sigma, PI );
				float truncation = 1.0 - exp( - 0.5 * thetaMax * thetaMax / ( sigma * sigma ) );

				vec3 accumColor = vec3( 0.0 );
				float accumWeight = 0.0;

				for ( int i = 0; i < SAMPLES; i ++ ) {

					// Stratified inverse-CDF sampling of the Gaussian, placed on a golden-angle spiral.
					float stratum = ( float( i ) + 0.5 ) / float( SAMPLES );
					float theta = sigma * sqrt( - 2.0 * log( 1.0 - stratum * truncation ) );
					float phi = float( i ) * GOLDEN_ANGLE;

					vec3 offset = cos( phi ) * tangent + sin( phi ) * bitangent;
					vec3 sampleDirection = cos( theta ) * outputDirection + sin( theta ) * offset;

					// Correct the planar sample density to solid angle.
					float weight = sin( theta ) / theta;

					accumColor += weight * bilinearCubeUV( envMap, sampleDirection, mipInt );
					accumWeight += weight;

				}

				gl_FragColor = vec4( accumColor / accumWeight, 1.0 );

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function nm(){return new jf({name:`EquirectangularToCubeUV`,uniforms:{envMap:{value:null}},vertexShader:im(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function rm(){return new jf({name:`CubemapToCubeUV`,uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:im(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function im(){return`

		precision mediump float;
		precision mediump int;

		attribute vec3 outputDirection;

		varying vec3 vOutputDirection;

		void main() {

			vOutputDirection = outputDirection;
			gl_Position = vec4( position, 1.0 );

		}
	`}var am=class extends wl{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;let n={width:e,height:e,depth:1},r=[n,n,n,n,n,n];this.texture=new hf(r),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;let n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},r=new bf(5,5,5),i=new jf({name:`CubemapFromEquirect`,uniforms:Cf(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:1,blending:0});i.uniforms.tEquirect.value=t;let a=new qd(r,i),o=t.minFilter;return t.minFilter===1008&&(t.minFilter=hs),new dp(1,10,this).update(e,a),t.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(e,t=!0,n=!0,r=!0){let i=e.getRenderTarget();for(let i=0;i<6;i++)e.setRenderTarget(this,i),e.clear(t,n,r);e.setRenderTarget(i)}};function om(e){let t=new WeakMap,n=new WeakMap,r=null;function i(e,t=!1){return e==null?null:t?o(e):a(e)}function a(n){if(n&&n.isTexture){let r=n.mapping;if(r===303||r===304){if(t.has(n)){let e=t.get(n).texture;return s(e,n.mapping)}{let r=n.image;if(r&&r.height>0){let i=new am(r.height);return i.fromEquirectangularTexture(e,n),t.set(n,i),n.addEventListener(`dispose`,l),s(i.texture,n.mapping)}return null}}}return n}function o(t){if(t&&t.isTexture){let i=t.mapping,a=i===303||i===304,o=i===301||i===302;if(a||o){let i=n.get(t),s=i===void 0?0:i.texture.pmremVersion;if(t.isRenderTargetTexture&&t.pmremVersion!==s)return r===null&&(r=new Xp(e)),i=a?r.fromEquirectangular(t,i):r.fromCubemap(t,i),i.texture.pmremVersion=t.pmremVersion,n.set(t,i),i.texture;if(i!==void 0)return i.texture;{let s=t.image;return a&&s&&s.height>0||o&&s&&c(s)?(r===null&&(r=new Xp(e)),i=a?r.fromEquirectangular(t):r.fromCubemap(t),i.texture.pmremVersion=t.pmremVersion,n.set(t,i),t.addEventListener(`dispose`,u),i.texture):null}}}return t}function s(e,t){return t===303?e.mapping=301:t===304&&(e.mapping=302),e}function c(e){let t=0;for(let n=0;n<6;n++)e[n]!==void 0&&t++;return t===6}function l(e){let n=e.target;n.removeEventListener(`dispose`,l);let r=t.get(n);r!==void 0&&(t.delete(n),r.dispose())}function u(e){let t=e.target;t.removeEventListener(`dispose`,u);let r=n.get(t);r!==void 0&&(n.delete(t),r.dispose())}function d(){t=new WeakMap,n=new WeakMap,r!==null&&(r.dispose(),r=null)}return{get:i,dispose:d}}function sm(e){let t={};function n(n){if(t[n]!==void 0)return t[n];let r=e.getExtension(n);return t[n]=r,r}return{has:function(e){return n(e)!==null},init:function(){n(`EXT_color_buffer_float`),n(`WEBGL_clip_cull_distance`),n(`OES_texture_float_linear`),n(`EXT_color_buffer_half_float`),n(`WEBGL_multisampled_render_to_texture`),n(`WEBGL_render_shared_exponent`)},get:function(e){let t=n(e);return t===null&&Gc(`WebGLRenderer: `+e+` extension not supported.`),t}}}function cm(e,t,n,r){let i={},a=new WeakMap;function o(e){let s=e.target;s.index!==null&&t.remove(s.index);for(let e in s.attributes)t.remove(s.attributes[e]);s.removeEventListener(`dispose`,o),delete i[s.id];let c=a.get(s);c&&(t.remove(c),a.delete(s)),r.releaseStatesOfGeometry(s),s.isInstancedBufferGeometry===!0&&delete s._maxInstanceCount,n.memory.geometries--}function s(e,t){return i[t.id]===!0?t:(t.addEventListener(`dispose`,o),i[t.id]=!0,n.memory.geometries++,t)}function c(n){let r=n.attributes;for(let n in r)t.update(r[n],e.ARRAY_BUFFER)}function l(e){let n=[],r=e.index,i=e.attributes.position,o=0;if(i===void 0)return;if(r!==null){let e=r.array;o=r.version;for(let t=0,r=e.length;t<r;t+=3){let r=e[t+0],i=e[t+1],a=e[t+2];n.push(r,i,i,a,a,r)}}else{let e=i.array;o=i.version;for(let t=0,r=e.length/3-1;t<r;t+=3){let e=t+0,r=t+1,i=t+2;n.push(e,r,r,i,i,e)}}let s=new(i.count>=65535?Gu:Wu)(n,1);s.version=o;let c=a.get(e);c&&t.remove(c),a.set(e,s)}function u(e){let t=a.get(e);if(t){let n=e.index;n!==null&&t.version<n.version&&l(e)}else l(e);return a.get(e)}return{get:s,update:c,getWireframeAttribute:u}}function lm(e,t,n){let r;function i(e){r=e}let a,o;function s(e){a=e.type,o=e.bytesPerElement}function c(t,i){e.drawElements(r,i,a,t*o),n.update(i,r,1)}function l(t,i,s){s!==0&&(e.drawElementsInstanced(r,i,a,t*o,s),n.update(i,r,s))}function u(e,i,o){if(o===0)return;t.get(`WEBGL_multi_draw`).multiDrawElementsWEBGL(r,i,0,a,e,0,o);let s=0;for(let e=0;e<o;e++)s+=i[e];n.update(s,r,1)}this.setMode=i,this.setIndex=s,this.render=c,this.renderInstances=l,this.renderMultiDraw=u}function um(e){let t={geometries:0,textures:0},n={frame:0,calls:0,triangles:0,points:0,lines:0};function r(t,r,i){switch(n.calls++,r){case e.TRIANGLES:n.triangles+=t/3*i;break;case e.LINES:n.lines+=t/2*i;break;case e.LINE_STRIP:n.lines+=i*(t-1);break;case e.LINE_LOOP:n.lines+=i*t;break;case e.POINTS:n.points+=i*t;break;default:J(`WebGLInfo: Unknown draw mode:`,r)}}function i(){n.calls=0,n.triangles=0,n.points=0,n.lines=0}return{memory:t,render:n,programs:null,autoReset:!0,reset:i,update:r}}function dm(e,t,n){let r=new WeakMap,i=new Sl;function a(a,o,s){let c=a.morphTargetInfluences,l=o.morphAttributes.position||o.morphAttributes.normal||o.morphAttributes.color,u=l===void 0?0:l.length,d=r.get(o);if(d===void 0||d.count!==u){d!==void 0&&d.texture.dispose();let e=o.morphAttributes.position!==void 0,n=o.morphAttributes.normal!==void 0,a=o.morphAttributes.color!==void 0,s=o.morphAttributes.position||[],c=o.morphAttributes.normal||[],l=o.morphAttributes.color||[],f=0;e===!0&&(f=1),n===!0&&(f=2),a===!0&&(f=3);let p=o.attributes.position.count*f,m=1;p>t.maxTextureSize&&(m=Math.ceil(p/t.maxTextureSize),p=t.maxTextureSize);let h=new Float32Array(p*m*4*u),g=new Tl(h,p,m,u);g.type=ws,g.needsUpdate=!0;let _=f*4;for(let t=0;t<u;t++){let r=s[t],o=c[t],u=l[t],d=p*m*4*t;for(let t=0;t<r.count;t++){let s=t*_;e===!0&&(i.fromBufferAttribute(r,t),h[d+s+0]=i.x,h[d+s+1]=i.y,h[d+s+2]=i.z,h[d+s+3]=0),n===!0&&(i.fromBufferAttribute(o,t),h[d+s+4]=i.x,h[d+s+5]=i.y,h[d+s+6]=i.z,h[d+s+7]=0),a===!0&&(i.fromBufferAttribute(u,t),h[d+s+8]=i.x,h[d+s+9]=i.y,h[d+s+10]=i.z,h[d+s+11]=u.itemSize===4?i.w:1)}}d={count:u,texture:g,size:new Y(p,m)},r.set(o,d);function v(){g.dispose(),r.delete(o),o.removeEventListener(`dispose`,v)}o.addEventListener(`dispose`,v)}if(a.isInstancedMesh===!0&&a.morphTexture!==null)s.getUniforms().setValue(e,`morphTexture`,a.morphTexture,n);else{let t=0;for(let e=0;e<c.length;e++)t+=c[e];let n=o.morphTargetsRelative?1:1-t;s.getUniforms().setValue(e,`morphTargetBaseInfluence`,n),s.getUniforms().setValue(e,`morphTargetInfluences`,c)}s.getUniforms().setValue(e,`morphTargetsTexture`,d.texture,n),s.getUniforms().setValue(e,`morphTargetsTextureSize`,d.size)}return{update:a}}function fm(e,t,n,r,i){let a=new WeakMap;function o(r){let o=i.render.frame,s=r.geometry,l=t.get(r,s);if(a.get(l)!==o&&(t.update(l),a.set(l,o)),r.isInstancedMesh&&(r.hasEventListener(`dispose`,c)===!1&&r.addEventListener(`dispose`,c),a.get(r)!==o&&(n.update(r.instanceMatrix,e.ARRAY_BUFFER),r.instanceColor!==null&&n.update(r.instanceColor,e.ARRAY_BUFFER),a.set(r,o))),r.isSkinnedMesh){let e=r.skeleton;a.get(e)!==o&&(e.update(),a.set(e,o))}return l}function s(){a=new WeakMap}function c(e){let t=e.target;t.removeEventListener(`dispose`,c),r.releaseStatesOfObject(t),n.remove(t.instanceMatrix),t.instanceColor!==null&&n.remove(t.instanceColor)}return{update:o,dispose:s}}var pm={1:`LINEAR_TONE_MAPPING`,2:`REINHARD_TONE_MAPPING`,3:`CINEON_TONE_MAPPING`,4:`ACES_FILMIC_TONE_MAPPING`,6:`AGX_TONE_MAPPING`,7:`NEUTRAL_TONE_MAPPING`,5:`CUSTOM_TONE_MAPPING`};function mm(e,t,n,r,i,a){let o=new wl(t,n,{type:e,depthBuffer:i,stencilBuffer:a,samples:r?4:0,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,resolveDepthBuffer:!1,resolveStencilBuffer:!1}),s=null,c=null,l=new id;l.setAttribute(`position`,new Ku([-1,3,0,-1,-1,0,3,-1,0],3)),l.setAttribute(`uv`,new Ku([0,2,0,0,2,0],2));let u=new Mf({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),d=new qd(l,u),f=new cp(-1,1,1,-1,0,1),p=null,m=null,h=!1,g,_=null,v=[],y=!1;this.setSize=function(e,t){o.setSize(e,t),s!==null&&s.setSize(e,t),c!==null&&c.setSize(e,t);for(let n=0;n<v.length;n++){let r=v[n];r.setSize&&r.setSize(e,t)}},this.setEffects=function(e){v=e,y=v.length>0&&v[0].isRenderPass===!0;let t=o.width,n=o.height;v.length>0&&s===null&&(s=new wl(t,n,{type:Ts,depthBuffer:!1,stencilBuffer:!1}),c=new wl(t,n,{type:Ts,depthBuffer:!1,stencilBuffer:!1}));for(let e=0;e<v.length;e++){let r=v[e];r.setSize&&r.setSize(t,n)}},this.begin=function(e,t){if(h||e.toneMapping===0&&v.length===0)return!1;if(_=t,t!==null){let e=t.width,n=t.height;(o.width!==e||o.height!==n)&&this.setSize(e,n)}return y===!1&&e.setRenderTarget(o),g=e.toneMapping,e.toneMapping=0,!0},this.hasRenderPass=function(){return y},this.end=function(e,t){e.toneMapping=g,h=!0;let n=o,r=s;for(let i=0;i<v.length;i++){let a=v[i];a.enabled!==!1&&(a.render(e,r,n,t),a.needsSwap!==!1&&(n=r,r=r===s?c:s))}if(p!==e.outputColorSpace||m!==e.toneMapping){p=e.outputColorSpace,m=e.toneMapping,u.defines={},dl.getTransfer(p)===`srgb`&&(u.defines.SRGB_TRANSFER=``);let t=pm[m];t&&(u.defines[t]=``),u.needsUpdate=!0}u.uniforms.tDiffuse.value=n.texture,e.setRenderTarget(_),e.render(d,f),_=null,h=!1},this.isCompositing=function(){return h},this.dispose=function(){o.dispose(),s!==null&&s.dispose(),c!==null&&c.dispose(),l.dispose(),u.dispose()}}var hm=new xl,gm=new _f(1,1),_m=new Tl,vm=new El,ym=new hf,bm=[],xm=[],Sm=new Float32Array(16),Cm=new Float32Array(9),wm=new Float32Array(4);function Tm(e,t,n){let r=e[0];if(r<=0||r>0)return e;let i=t*n,a=bm[i];if(a===void 0&&(a=new Float32Array(i),bm[i]=a),t!==0){r.toArray(a,0);for(let r=1,i=0;r!==t;++r)i+=n,e[r].toArray(a,i)}return a}function Em(e,t){if(e.length!==t.length)return!1;for(let n=0,r=e.length;n<r;n++)if(e[n]!==t[n])return!1;return!0}function Dm(e,t){for(let n=0,r=t.length;n<r;n++)e[n]=t[n]}function Om(e,t){let n=xm[t];n===void 0&&(n=new Int32Array(t),xm[t]=n);for(let r=0;r!==t;++r)n[r]=e.allocateTextureUnit();return n}function km(e,t){let n=this.cache;n[0]!==t&&(e.uniform1f(this.addr,t),n[0]=t)}function Am(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(e.uniform2f(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(Em(n,t))return;e.uniform2fv(this.addr,t),Dm(n,t)}}function jm(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(e.uniform3f(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else if(t.r!==void 0)(n[0]!==t.r||n[1]!==t.g||n[2]!==t.b)&&(e.uniform3f(this.addr,t.r,t.g,t.b),n[0]=t.r,n[1]=t.g,n[2]=t.b);else{if(Em(n,t))return;e.uniform3fv(this.addr,t),Dm(n,t)}}function Mm(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(e.uniform4f(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(Em(n,t))return;e.uniform4fv(this.addr,t),Dm(n,t)}}function Nm(e,t){let n=this.cache,r=t.elements;if(r===void 0){if(Em(n,t))return;e.uniformMatrix2fv(this.addr,!1,t),Dm(n,t)}else{if(Em(n,r))return;wm.set(r),e.uniformMatrix2fv(this.addr,!1,wm),Dm(n,r)}}function Pm(e,t){let n=this.cache,r=t.elements;if(r===void 0){if(Em(n,t))return;e.uniformMatrix3fv(this.addr,!1,t),Dm(n,t)}else{if(Em(n,r))return;Cm.set(r),e.uniformMatrix3fv(this.addr,!1,Cm),Dm(n,r)}}function Fm(e,t){let n=this.cache,r=t.elements;if(r===void 0){if(Em(n,t))return;e.uniformMatrix4fv(this.addr,!1,t),Dm(n,t)}else{if(Em(n,r))return;Sm.set(r),e.uniformMatrix4fv(this.addr,!1,Sm),Dm(n,r)}}function Im(e,t){let n=this.cache;n[0]!==t&&(e.uniform1i(this.addr,t),n[0]=t)}function Lm(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(e.uniform2i(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(Em(n,t))return;e.uniform2iv(this.addr,t),Dm(n,t)}}function Rm(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(e.uniform3i(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else{if(Em(n,t))return;e.uniform3iv(this.addr,t),Dm(n,t)}}function zm(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(e.uniform4i(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(Em(n,t))return;e.uniform4iv(this.addr,t),Dm(n,t)}}function Bm(e,t){let n=this.cache;n[0]!==t&&(e.uniform1ui(this.addr,t),n[0]=t)}function Vm(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(e.uniform2ui(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(Em(n,t))return;e.uniform2uiv(this.addr,t),Dm(n,t)}}function Hm(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(e.uniform3ui(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else{if(Em(n,t))return;e.uniform3uiv(this.addr,t),Dm(n,t)}}function Um(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(e.uniform4ui(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(Em(n,t))return;e.uniform4uiv(this.addr,t),Dm(n,t)}}function Wm(e,t,n){let r=this.cache,i=n.allocateTextureUnit();r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i);let a;this.type===e.SAMPLER_2D_SHADOW?(gm.compareFunction=n.isReversedDepthBuffer()?518:515,a=gm):a=hm,n.setTexture2D(t||a,i)}function Gm(e,t,n){let r=this.cache,i=n.allocateTextureUnit();r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i),n.setTexture3D(t||vm,i)}function Km(e,t,n){let r=this.cache,i=n.allocateTextureUnit();r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i),n.setTextureCube(t||ym,i)}function qm(e,t,n){let r=this.cache,i=n.allocateTextureUnit();r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i),n.setTexture2DArray(t||_m,i)}function Jm(e){switch(e){case 5126:return km;case 35664:return Am;case 35665:return jm;case 35666:return Mm;case 35674:return Nm;case 35675:return Pm;case 35676:return Fm;case 5124:case 35670:return Im;case 35667:case 35671:return Lm;case 35668:case 35672:return Rm;case 35669:case 35673:return zm;case 5125:return Bm;case 36294:return Vm;case 36295:return Hm;case 36296:return Um;case 35678:case 36198:case 36298:case 36306:case 35682:return Wm;case 35679:case 36299:case 36307:return Gm;case 35680:case 36300:case 36308:case 36293:return Km;case 36289:case 36303:case 36311:case 36292:return qm}}function Ym(e,t){e.uniform1fv(this.addr,t)}function Xm(e,t){let n=Tm(t,this.size,2);e.uniform2fv(this.addr,n)}function Zm(e,t){let n=Tm(t,this.size,3);e.uniform3fv(this.addr,n)}function Qm(e,t){let n=Tm(t,this.size,4);e.uniform4fv(this.addr,n)}function $m(e,t){let n=Tm(t,this.size,4);e.uniformMatrix2fv(this.addr,!1,n)}function eh(e,t){let n=Tm(t,this.size,9);e.uniformMatrix3fv(this.addr,!1,n)}function th(e,t){let n=Tm(t,this.size,16);e.uniformMatrix4fv(this.addr,!1,n)}function nh(e,t){e.uniform1iv(this.addr,t)}function rh(e,t){e.uniform2iv(this.addr,t)}function ih(e,t){e.uniform3iv(this.addr,t)}function ah(e,t){e.uniform4iv(this.addr,t)}function oh(e,t){e.uniform1uiv(this.addr,t)}function sh(e,t){e.uniform2uiv(this.addr,t)}function ch(e,t){e.uniform3uiv(this.addr,t)}function lh(e,t){e.uniform4uiv(this.addr,t)}function uh(e,t,n){let r=this.cache,i=t.length,a=Om(n,i);Em(r,a)||(e.uniform1iv(this.addr,a),Dm(r,a));let o;o=this.type===e.SAMPLER_2D_SHADOW?gm:hm;for(let e=0;e!==i;++e)n.setTexture2D(t[e]||o,a[e])}function dh(e,t,n){let r=this.cache,i=t.length,a=Om(n,i);Em(r,a)||(e.uniform1iv(this.addr,a),Dm(r,a));for(let e=0;e!==i;++e)n.setTexture3D(t[e]||vm,a[e])}function fh(e,t,n){let r=this.cache,i=t.length,a=Om(n,i);Em(r,a)||(e.uniform1iv(this.addr,a),Dm(r,a));for(let e=0;e!==i;++e)n.setTextureCube(t[e]||ym,a[e])}function ph(e,t,n){let r=this.cache,i=t.length,a=Om(n,i);Em(r,a)||(e.uniform1iv(this.addr,a),Dm(r,a));for(let e=0;e!==i;++e)n.setTexture2DArray(t[e]||_m,a[e])}function mh(e){switch(e){case 5126:return Ym;case 35664:return Xm;case 35665:return Zm;case 35666:return Qm;case 35674:return $m;case 35675:return eh;case 35676:return th;case 5124:case 35670:return nh;case 35667:case 35671:return rh;case 35668:case 35672:return ih;case 35669:case 35673:return ah;case 5125:return oh;case 36294:return sh;case 36295:return ch;case 36296:return lh;case 35678:case 36198:case 36298:case 36306:case 35682:return uh;case 35679:case 36299:case 36307:return dh;case 35680:case 36300:case 36308:case 36293:return fh;case 36289:case 36303:case 36311:case 36292:return ph}}var hh=class{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=Jm(t.type)}},gh=class{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=mh(t.type)}},_h=class{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){let r=this.seq;for(let i=0,a=r.length;i!==a;++i){let a=r[i];a.setValue(e,t[a.id],n)}}},vh=/(\w+)(\])?(\[|\.)?/g;function yh(e,t){e.seq.push(t),e.map[t.id]=t}function bh(e,t,n){let r=e.name,i=r.length;for(vh.lastIndex=0;;){let a=vh.exec(r),o=vh.lastIndex,s=a[1],c=a[2]===`]`,l=a[3];if(c&&(s|=0),l===void 0||l===`[`&&o+2===i){yh(n,l===void 0?new hh(s,e,t):new gh(s,e,t));break}{let e=n.map[s];e===void 0&&(e=new _h(s),yh(n,e)),n=e}}}var xh=class{constructor(e,t){this.seq=[],this.map={};let n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let r=0;r<n;++r){let n=e.getActiveUniform(t,r);bh(n,e.getUniformLocation(t,n.name),this)}let r=[],i=[];for(let t of this.seq)t.type===e.SAMPLER_2D_SHADOW||t.type===e.SAMPLER_CUBE_SHADOW||t.type===e.SAMPLER_2D_ARRAY_SHADOW?r.push(t):i.push(t);r.length>0&&(this.seq=r.concat(i))}setValue(e,t,n,r){let i=this.map[t];i!==void 0&&i.setValue(e,n,r)}setOptional(e,t,n){let r=t[n];r!==void 0&&this.setValue(e,n,r)}static upload(e,t,n,r){for(let i=0,a=t.length;i!==a;++i){let a=t[i],o=n[a.id];o.needsUpdate!==!1&&a.setValue(e,o.value,r)}}static seqWithValue(e,t){let n=[];for(let r=0,i=e.length;r!==i;++r){let i=e[r];i.id in t&&n.push(i)}return n}};function Sh(e,t,n){let r=e.createShader(t);return e.shaderSource(r,n),e.compileShader(r),r}var Ch=37297,wh=0;function Th(e,t){let n=e.split(`
`),r=[],i=Math.max(t-6,0),a=Math.min(t+6,n.length);for(let e=i;e<a;e++){let i=e+1;r.push(`${i===t?`>`:` `} ${i}: ${n[e]}`)}return r.join(`
`)}var Eh=new Z;function Dh(e){dl._getMatrix(Eh,dl.workingColorSpace,e);let t=`mat3( ${Eh.elements.map(e=>e.toFixed(4))} )`;switch(dl.getTransfer(e)){case Nc:return[t,`LinearTransferOETF`];case Pc:return[t,`sRGBTransferOETF`];default:return q(`WebGLProgram: Unsupported color space: `,e),[t,`LinearTransferOETF`]}}function Oh(e,t,n){let r=e.getShaderParameter(t,e.COMPILE_STATUS),i=(e.getShaderInfoLog(t)||``).trim();if(r&&i===``)return``;let a=/ERROR: 0:(\d+)/.exec(i);if(a){let r=parseInt(a[1]);return n.toUpperCase()+`

`+i+`

`+Th(e.getShaderSource(t),r)}return i}function kh(e,t){let n=Dh(t);return[`vec4 ${e}( vec4 value ) {`,`	return ${n[1]}( vec4( value.rgb * ${n[0]}, value.a ) );`,`}`].join(`
`)}var Ah={1:`Linear`,2:`Reinhard`,3:`Cineon`,4:`ACESFilmic`,6:`AgX`,7:`Neutral`,5:`Custom`};function jh(e,t){let n=Ah[t];return n===void 0?(q(`WebGLProgram: Unsupported toneMapping:`,t),`vec3 `+e+`( vec3 color ) { return LinearToneMapping( color ); }`):`vec3 `+e+`( vec3 color ) { return `+n+`ToneMapping( color ); }`}var Mh=new X;function Nh(){return dl.getLuminanceCoefficients(Mh),[`float luminance( const in vec3 rgb ) {`,`	const vec3 weights = vec3( ${Mh.x.toFixed(4)}, ${Mh.y.toFixed(4)}, ${Mh.z.toFixed(4)} );`,`	return dot( weights, rgb );`,`}`].join(`
`)}function Ph(e){return[e.extensionClipCullDistance?`#extension GL_ANGLE_clip_cull_distance : require`:``,e.extensionMultiDraw?`#extension GL_ANGLE_multi_draw : require`:``].filter(Lh).join(`
`)}function Fh(e){let t=[];for(let n in e){let r=e[n];r!==!1&&t.push(`#define `+n+` `+r)}return t.join(`
`)}function Ih(e,t){let n={},r=e.getProgramParameter(t,e.ACTIVE_ATTRIBUTES);for(let i=0;i<r;i++){let r=e.getActiveAttrib(t,i),a=r.name,o=1;r.type===e.FLOAT_MAT2&&(o=2),r.type===e.FLOAT_MAT3&&(o=3),r.type===e.FLOAT_MAT4&&(o=4),n[a]={type:r.type,location:e.getAttribLocation(t,a),locationSize:o}}return n}function Lh(e){return e!==``}function Rh(e,t){let n=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return e.replace(/NUM_SUN_LIGHTS/g,t.numSunLights).replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,n).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_SUN_LIGHT_SHADOWS/g,t.numSunLightShadows).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function zh(e,t){return e.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}var Bh=/^[ \t]*#include +<([\w\d./]+)>/gm;function Vh(e){return e.replace(Bh,Uh)}var Hh=new Map;function Uh(e,t){let n=Q[t];if(n===void 0){let e=Hh.get(t);if(e!==void 0)n=Q[e],q(`WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.`,t,e);else throw Error(`THREE.WebGLProgram: Can not resolve #include <`+t+`>`)}return Vh(n)}var Wh=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Gh(e){return e.replace(Wh,Kh)}function Kh(e,t,n,r){let i=``;for(let e=parseInt(t);e<parseInt(n);e++)i+=r.replace(/\[\s*i\s*\]/g,`[ `+e+` ]`).replace(/UNROLLED_LOOP_INDEX/g,e);return i}function qh(e){let t=`precision ${e.precision} float;
	precision ${e.precision} int;
	precision ${e.precision} sampler2D;
	precision ${e.precision} samplerCube;
	precision ${e.precision} sampler3D;
	precision ${e.precision} sampler2DArray;
	precision ${e.precision} sampler2DShadow;
	precision ${e.precision} samplerCubeShadow;
	precision ${e.precision} sampler2DArrayShadow;
	precision ${e.precision} isampler2D;
	precision ${e.precision} isampler3D;
	precision ${e.precision} isamplerCube;
	precision ${e.precision} isampler2DArray;
	precision ${e.precision} usampler2D;
	precision ${e.precision} usampler3D;
	precision ${e.precision} usamplerCube;
	precision ${e.precision} usampler2DArray;
	`;return e.precision===`highp`?t+=`
#define HIGH_PRECISION`:e.precision===`mediump`?t+=`
#define MEDIUM_PRECISION`:e.precision===`lowp`&&(t+=`
#define LOW_PRECISION`),t}var Jh={1:`SHADOWMAP_TYPE_PCF`,3:`SHADOWMAP_TYPE_VSM`};function Yh(e){return Jh[e.shadowMapType]||`SHADOWMAP_TYPE_BASIC`}var Xh={301:`ENVMAP_TYPE_CUBE`,302:`ENVMAP_TYPE_CUBE`,306:`ENVMAP_TYPE_CUBE_UV`};function Zh(e){return e.envMap===!1?`ENVMAP_TYPE_CUBE`:Xh[e.envMapMode]||`ENVMAP_TYPE_CUBE`}var Qh={302:`ENVMAP_MODE_REFRACTION`};function $h(e){return e.envMap===!1?`ENVMAP_MODE_REFLECTION`:Qh[e.envMapMode]||`ENVMAP_MODE_REFLECTION`}var eg={0:`ENVMAP_BLENDING_MULTIPLY`,1:`ENVMAP_BLENDING_MIX`,2:`ENVMAP_BLENDING_ADD`};function tg(e){return e.envMap===!1?`ENVMAP_BLENDING_NONE`:eg[e.combine]||`ENVMAP_BLENDING_NONE`}function ng(e){let t=e.envMapCubeUVHeight;if(t===null)return null;let n=Math.log2(t)-2,r=1/t;return{texelWidth:1/(3*Math.max(2**n,112)),texelHeight:r,maxMip:n}}function rg(e,t,n,r){let i=e.getContext(),a=n.defines,o=n.vertexShader,s=n.fragmentShader,c=Yh(n),l=Zh(n),u=$h(n),d=tg(n),f=ng(n),p=Ph(n),m=Fh(a),h=i.createProgram(),g,_,v=n.glslVersion?`#version `+n.glslVersion+`
`:``;n.isRawShaderMaterial?(g=[`#define SHADER_TYPE `+n.shaderType,`#define SHADER_NAME `+n.shaderName,m].filter(Lh).join(`
`),g.length>0&&(g+=`
`),_=[`#define SHADER_TYPE `+n.shaderType,`#define SHADER_NAME `+n.shaderName,m].filter(Lh).join(`
`),_.length>0&&(_+=`
`)):(g=[qh(n),`#define SHADER_TYPE `+n.shaderType,`#define SHADER_NAME `+n.shaderName,m,n.extensionClipCullDistance?`#define USE_CLIP_DISTANCE`:``,n.batching?`#define USE_BATCHING`:``,n.batchingColor?`#define USE_BATCHING_COLOR`:``,n.instancing?`#define USE_INSTANCING`:``,n.instancingColor?`#define USE_INSTANCING_COLOR`:``,n.instancingMorph?`#define USE_INSTANCING_MORPH`:``,n.useFog&&n.fog?`#define USE_FOG`:``,n.useFog&&n.fogExp2?`#define FOG_EXP2`:``,n.map?`#define USE_MAP`:``,n.envMap?`#define USE_ENVMAP`:``,n.envMap?`#define `+u:``,n.lightMap?`#define USE_LIGHTMAP`:``,n.aoMap?`#define USE_AOMAP`:``,n.bumpMap?`#define USE_BUMPMAP`:``,n.normalMap?`#define USE_NORMALMAP`:``,n.normalMapObjectSpace?`#define USE_NORMALMAP_OBJECTSPACE`:``,n.normalMapTangentSpace?`#define USE_NORMALMAP_TANGENTSPACE`:``,n.displacementMap?`#define USE_DISPLACEMENTMAP`:``,n.emissiveMap?`#define USE_EMISSIVEMAP`:``,n.anisotropy?`#define USE_ANISOTROPY`:``,n.anisotropyMap?`#define USE_ANISOTROPYMAP`:``,n.clearcoatMap?`#define USE_CLEARCOATMAP`:``,n.clearcoatRoughnessMap?`#define USE_CLEARCOAT_ROUGHNESSMAP`:``,n.clearcoatNormalMap?`#define USE_CLEARCOAT_NORMALMAP`:``,n.iridescenceMap?`#define USE_IRIDESCENCEMAP`:``,n.iridescenceThicknessMap?`#define USE_IRIDESCENCE_THICKNESSMAP`:``,n.specularMap?`#define USE_SPECULARMAP`:``,n.specularColorMap?`#define USE_SPECULAR_COLORMAP`:``,n.specularIntensityMap?`#define USE_SPECULAR_INTENSITYMAP`:``,n.roughnessMap?`#define USE_ROUGHNESSMAP`:``,n.metalnessMap?`#define USE_METALNESSMAP`:``,n.alphaMap?`#define USE_ALPHAMAP`:``,n.alphaHash?`#define USE_ALPHAHASH`:``,n.transmission?`#define USE_TRANSMISSION`:``,n.transmissionMap?`#define USE_TRANSMISSIONMAP`:``,n.thicknessMap?`#define USE_THICKNESSMAP`:``,n.sheenColorMap?`#define USE_SHEEN_COLORMAP`:``,n.sheenRoughnessMap?`#define USE_SHEEN_ROUGHNESSMAP`:``,n.mapUv?`#define MAP_UV `+n.mapUv:``,n.alphaMapUv?`#define ALPHAMAP_UV `+n.alphaMapUv:``,n.lightMapUv?`#define LIGHTMAP_UV `+n.lightMapUv:``,n.aoMapUv?`#define AOMAP_UV `+n.aoMapUv:``,n.emissiveMapUv?`#define EMISSIVEMAP_UV `+n.emissiveMapUv:``,n.bumpMapUv?`#define BUMPMAP_UV `+n.bumpMapUv:``,n.normalMapUv?`#define NORMALMAP_UV `+n.normalMapUv:``,n.displacementMapUv?`#define DISPLACEMENTMAP_UV `+n.displacementMapUv:``,n.metalnessMapUv?`#define METALNESSMAP_UV `+n.metalnessMapUv:``,n.roughnessMapUv?`#define ROUGHNESSMAP_UV `+n.roughnessMapUv:``,n.anisotropyMapUv?`#define ANISOTROPYMAP_UV `+n.anisotropyMapUv:``,n.clearcoatMapUv?`#define CLEARCOATMAP_UV `+n.clearcoatMapUv:``,n.clearcoatNormalMapUv?`#define CLEARCOAT_NORMALMAP_UV `+n.clearcoatNormalMapUv:``,n.clearcoatRoughnessMapUv?`#define CLEARCOAT_ROUGHNESSMAP_UV `+n.clearcoatRoughnessMapUv:``,n.iridescenceMapUv?`#define IRIDESCENCEMAP_UV `+n.iridescenceMapUv:``,n.iridescenceThicknessMapUv?`#define IRIDESCENCE_THICKNESSMAP_UV `+n.iridescenceThicknessMapUv:``,n.sheenColorMapUv?`#define SHEEN_COLORMAP_UV `+n.sheenColorMapUv:``,n.sheenRoughnessMapUv?`#define SHEEN_ROUGHNESSMAP_UV `+n.sheenRoughnessMapUv:``,n.specularMapUv?`#define SPECULARMAP_UV `+n.specularMapUv:``,n.specularColorMapUv?`#define SPECULAR_COLORMAP_UV `+n.specularColorMapUv:``,n.specularIntensityMapUv?`#define SPECULAR_INTENSITYMAP_UV `+n.specularIntensityMapUv:``,n.transmissionMapUv?`#define TRANSMISSIONMAP_UV `+n.transmissionMapUv:``,n.thicknessMapUv?`#define THICKNESSMAP_UV `+n.thicknessMapUv:``,n.vertexTangents&&n.flatShading===!1?`#define USE_TANGENT`:``,n.vertexNormals?`#define HAS_NORMAL`:``,n.vertexColors?`#define USE_COLOR`:``,n.vertexAlphas?`#define USE_COLOR_ALPHA`:``,n.vertexUv1s?`#define USE_UV1`:``,n.vertexUv2s?`#define USE_UV2`:``,n.vertexUv3s?`#define USE_UV3`:``,n.pointsUvs?`#define USE_POINTS_UV`:``,n.flatShading?`#define FLAT_SHADED`:``,n.skinning?`#define USE_SKINNING`:``,n.morphTargets?`#define USE_MORPHTARGETS`:``,n.morphNormals&&n.flatShading===!1?`#define USE_MORPHNORMALS`:``,n.morphColors?`#define USE_MORPHCOLORS`:``,n.morphTargetsCount>0?`#define MORPHTARGETS_TEXTURE_STRIDE `+n.morphTextureStride:``,n.morphTargetsCount>0?`#define MORPHTARGETS_COUNT `+n.morphTargetsCount:``,n.doubleSided?`#define DOUBLE_SIDED`:``,n.flipSided?`#define FLIP_SIDED`:``,n.shadowMapEnabled?`#define USE_SHADOWMAP`:``,n.shadowMapEnabled?`#define `+c:``,n.sizeAttenuation?`#define USE_SIZEATTENUATION`:``,n.numLightProbes>0?`#define USE_LIGHT_PROBES`:``,n.logarithmicDepthBuffer?`#define USE_LOGARITHMIC_DEPTH_BUFFER`:``,n.reversedDepthBuffer?`#define USE_REVERSED_DEPTH_BUFFER`:``,`uniform mat4 modelMatrix;`,`uniform mat4 modelViewMatrix;`,`uniform mat4 projectionMatrix;`,`uniform mat4 viewMatrix;`,`uniform mat3 normalMatrix;`,`uniform vec3 cameraPosition;`,`uniform bool isOrthographic;`,`#ifdef USE_INSTANCING`,`	attribute mat4 instanceMatrix;`,`#endif`,`#ifdef USE_INSTANCING_COLOR`,`	attribute vec3 instanceColor;`,`#endif`,`#ifdef USE_INSTANCING_MORPH`,`	uniform sampler2D morphTexture;`,`#endif`,`attribute vec3 position;`,`attribute vec3 normal;`,`attribute vec2 uv;`,`#ifdef USE_UV1`,`	attribute vec2 uv1;`,`#endif`,`#ifdef USE_UV2`,`	attribute vec2 uv2;`,`#endif`,`#ifdef USE_UV3`,`	attribute vec2 uv3;`,`#endif`,`#ifdef USE_TANGENT`,`	attribute vec4 tangent;`,`#endif`,`#if defined( USE_COLOR_ALPHA )`,`	attribute vec4 color;`,`#elif defined( USE_COLOR )`,`	attribute vec3 color;`,`#endif`,`#ifdef USE_SKINNING`,`	attribute vec4 skinIndex;`,`	attribute vec4 skinWeight;`,`#endif`,`
`].filter(Lh).join(`
`),_=[qh(n),`#define SHADER_TYPE `+n.shaderType,`#define SHADER_NAME `+n.shaderName,m,n.useFog&&n.fog?`#define USE_FOG`:``,n.useFog&&n.fogExp2?`#define FOG_EXP2`:``,n.alphaToCoverage?`#define ALPHA_TO_COVERAGE`:``,n.map?`#define USE_MAP`:``,n.matcap?`#define USE_MATCAP`:``,n.envMap?`#define USE_ENVMAP`:``,n.envMap?`#define `+l:``,n.envMap?`#define `+u:``,n.envMap?`#define `+d:``,f?`#define CUBEUV_TEXEL_WIDTH `+f.texelWidth:``,f?`#define CUBEUV_TEXEL_HEIGHT `+f.texelHeight:``,f?`#define CUBEUV_MAX_MIP `+f.maxMip+`.0`:``,n.lightMap?`#define USE_LIGHTMAP`:``,n.aoMap?`#define USE_AOMAP`:``,n.bumpMap?`#define USE_BUMPMAP`:``,n.normalMap?`#define USE_NORMALMAP`:``,n.normalMapObjectSpace?`#define USE_NORMALMAP_OBJECTSPACE`:``,n.normalMapTangentSpace?`#define USE_NORMALMAP_TANGENTSPACE`:``,n.packedNormalMap?`#define USE_PACKED_NORMALMAP`:``,n.emissiveMap?`#define USE_EMISSIVEMAP`:``,n.anisotropy?`#define USE_ANISOTROPY`:``,n.anisotropyMap?`#define USE_ANISOTROPYMAP`:``,n.clearcoat?`#define USE_CLEARCOAT`:``,n.clearcoatMap?`#define USE_CLEARCOATMAP`:``,n.clearcoatRoughnessMap?`#define USE_CLEARCOAT_ROUGHNESSMAP`:``,n.clearcoatNormalMap?`#define USE_CLEARCOAT_NORMALMAP`:``,n.dispersion?`#define USE_DISPERSION`:``,n.retroreflection?`#define USE_RETROREFLECTION`:``,n.iridescence?`#define USE_IRIDESCENCE`:``,n.iridescenceMap?`#define USE_IRIDESCENCEMAP`:``,n.iridescenceThicknessMap?`#define USE_IRIDESCENCE_THICKNESSMAP`:``,n.specularMap?`#define USE_SPECULARMAP`:``,n.specularColorMap?`#define USE_SPECULAR_COLORMAP`:``,n.specularIntensityMap?`#define USE_SPECULAR_INTENSITYMAP`:``,n.roughnessMap?`#define USE_ROUGHNESSMAP`:``,n.metalnessMap?`#define USE_METALNESSMAP`:``,n.alphaMap?`#define USE_ALPHAMAP`:``,n.alphaTest?`#define USE_ALPHATEST`:``,n.alphaHash?`#define USE_ALPHAHASH`:``,n.sheen?`#define USE_SHEEN`:``,n.sheenColorMap?`#define USE_SHEEN_COLORMAP`:``,n.sheenRoughnessMap?`#define USE_SHEEN_ROUGHNESSMAP`:``,n.transmission?`#define USE_TRANSMISSION`:``,n.transmissionMap?`#define USE_TRANSMISSIONMAP`:``,n.thicknessMap?`#define USE_THICKNESSMAP`:``,n.vertexTangents&&n.flatShading===!1?`#define USE_TANGENT`:``,n.vertexColors||n.instancingColor?`#define USE_COLOR`:``,n.vertexAlphas||n.batchingColor?`#define USE_COLOR_ALPHA`:``,n.vertexUv1s?`#define USE_UV1`:``,n.vertexUv2s?`#define USE_UV2`:``,n.vertexUv3s?`#define USE_UV3`:``,n.pointsUvs?`#define USE_POINTS_UV`:``,n.gradientMap?`#define USE_GRADIENTMAP`:``,n.flatShading?`#define FLAT_SHADED`:``,n.doubleSided?`#define DOUBLE_SIDED`:``,n.flipSided?`#define FLIP_SIDED`:``,n.shadowMapEnabled?`#define USE_SHADOWMAP`:``,n.shadowMapEnabled?`#define `+c:``,n.premultipliedAlpha?`#define PREMULTIPLIED_ALPHA`:``,n.numLightProbes>0?`#define USE_LIGHT_PROBES`:``,n.numLightProbeGrids>0?`#define USE_LIGHT_PROBES_GRID`:``,n.decodeVideoTexture?`#define DECODE_VIDEO_TEXTURE`:``,n.decodeVideoTextureEmissive?`#define DECODE_VIDEO_TEXTURE_EMISSIVE`:``,n.logarithmicDepthBuffer?`#define USE_LOGARITHMIC_DEPTH_BUFFER`:``,n.reversedDepthBuffer?`#define USE_REVERSED_DEPTH_BUFFER`:``,`uniform mat4 viewMatrix;`,`uniform vec3 cameraPosition;`,`uniform bool isOrthographic;`,n.toneMapping===0?``:`#define TONE_MAPPING`,n.toneMapping===0?``:Q.tonemapping_pars_fragment,n.toneMapping===0?``:jh(`toneMapping`,n.toneMapping),n.dithering?`#define DITHERING`:``,n.opaque?`#define OPAQUE`:``,Q.colorspace_pars_fragment,kh(`linearToOutputTexel`,n.outputColorSpace),Nh(),n.useDepthPacking?`#define DEPTH_PACKING `+n.depthPacking:``,`
`].filter(Lh).join(`
`)),o=Vh(o),o=Rh(o,n),o=zh(o,n),s=Vh(s),s=Rh(s,n),s=zh(s,n),o=Gh(o),s=Gh(s),n.isRawShaderMaterial!==!0&&(v=`#version 300 es
`,g=[p,`#define attribute in`,`#define varying out`,`#define texture2D texture`].join(`
`)+`
`+g,_=[`#define varying in`,n.glslVersion===`300 es`?``:`layout(location = 0) out highp vec4 pc_fragColor;`,n.glslVersion===`300 es`?``:`#define gl_FragColor pc_fragColor`,`#define gl_FragDepthEXT gl_FragDepth`,`#define texture2D texture`,`#define textureCube texture`,`#define texture2DProj textureProj`,`#define texture2DLodEXT textureLod`,`#define texture2DProjLodEXT textureProjLod`,`#define textureCubeLodEXT textureLod`,`#define texture2DGradEXT textureGrad`,`#define texture2DProjGradEXT textureProjGrad`,`#define textureCubeGradEXT textureGrad`].join(`
`)+`
`+_);let y=v+g+o,b=v+_+s,x=Sh(i,i.VERTEX_SHADER,y),S=Sh(i,i.FRAGMENT_SHADER,b);i.attachShader(h,x),i.attachShader(h,S),n.index0AttributeName===void 0?n.hasPositionAttribute===!0&&i.bindAttribLocation(h,0,`position`):i.bindAttribLocation(h,0,n.index0AttributeName),i.linkProgram(h);function C(t){if(e.debug.checkShaderErrors){let n=i.getProgramInfoLog(h)||``,r=i.getShaderInfoLog(x)||``,a=i.getShaderInfoLog(S)||``,o=n.trim(),s=r.trim(),c=a.trim(),l=!0,u=!0;if(i.getProgramParameter(h,i.LINK_STATUS)===!1){if(l=!1,typeof e.debug.onShaderError==`function`)e.debug.onShaderError(i,h,x,S);else{let e=Oh(i,x,`vertex`),n=Oh(i,S,`fragment`);J(`WebGLProgram: Shader Error `+i.getError()+` - VALIDATE_STATUS `+i.getProgramParameter(h,i.VALIDATE_STATUS)+`

Material Name: `+t.name+`
Material Type: `+t.type+`

Program Info Log: `+o+`
`+e+`
`+n)}}else o===``?(s===``||c===``)&&(u=!1):q(`WebGLProgram: Program Info Log:`,o);u&&(t.diagnostics={runnable:l,programLog:o,vertexShader:{log:s,prefix:g},fragmentShader:{log:c,prefix:_}})}i.deleteShader(x),i.deleteShader(S),w=new xh(i,h),T=Ih(i,h)}let w;this.getUniforms=function(){return w===void 0&&C(this),w};let T;this.getAttributes=function(){return T===void 0&&C(this),T};let E=n.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return E===!1&&(E=i.getProgramParameter(h,Ch)),E},this.destroy=function(){r.releaseStatesOfProgram(this),i.deleteProgram(h),this.program=void 0},this.type=n.shaderType,this.name=n.shaderName,this.id=wh++,this.cacheKey=t,this.usedTimes=1,this.program=h,this.vertexShader=x,this.fragmentShader=S,this}var ig=0,ag=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e,t,n){let r=this._getShaderCacheForMaterial(e);return r.has(t)===!1&&(r.add(t),t.usedTimes++),r.has(n)===!1&&(r.add(n),n.usedTimes++),this}remove(e){let t=this.materialCache.get(e);for(let e of t)e.usedTimes--,e.usedTimes===0&&this.shaderCache.delete(e.code);return this.materialCache.delete(e),this}getVertexShaderStage(e){return this._getShaderStage(e.vertexShader)}getFragmentShaderStage(e){return this._getShaderStage(e.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){let t=this.materialCache,n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){let t=this.shaderCache,n=t.get(e);return n===void 0&&(n=new og(e),t.set(e,n)),n}},og=class{constructor(e){this.id=ig++,this.code=e,this.usedTimes=0}};function sg(e){return e===1030||e===37490||e===36285}function cg(e,t,n,r,i,a){let o=new Rl,s=new ag,c=new Set,l=[],u=new Map,d=r.logarithmicDepthBuffer,f=r.precision,p={MeshDepthMaterial:`depth`,MeshDistanceMaterial:`distance`,MeshNormalMaterial:`normal`,MeshBasicMaterial:`basic`,MeshLambertMaterial:`lambert`,MeshPhongMaterial:`phong`,MeshToonMaterial:`toon`,MeshStandardMaterial:`physical`,MeshPhysicalMaterial:`physical`,MeshMatcapMaterial:`matcap`,LineBasicMaterial:`basic`,LineDashedMaterial:`dashed`,PointsMaterial:`points`,ShadowMaterial:`shadow`,SpriteMaterial:`sprite`};function m(e){return c.add(e),e===0?`uv`:`uv${e}`}function h(i,o,l,u,h,g){let _=u.fog,v=h.geometry,y=i.isMeshStandardMaterial||i.isMeshLambertMaterial||i.isMeshPhongMaterial?u.environment:null,b=i.isMeshStandardMaterial||i.isMeshLambertMaterial&&!i.envMap||i.isMeshPhongMaterial&&!i.envMap,x=t.get(i.envMap||y,b),S=x&&x.mapping===306?x.image.height:null,C=p[i.type];i.precision!==null&&(f=r.getMaxPrecision(i.precision),f!==i.precision&&q(`WebGLProgram.getParameters:`,i.precision,`not supported, using`,f,`instead.`));let w=v.morphAttributes.position||v.morphAttributes.normal||v.morphAttributes.color,T=w===void 0?0:w.length,E=0;v.morphAttributes.position!==void 0&&(E=1),v.morphAttributes.normal!==void 0&&(E=2),v.morphAttributes.color!==void 0&&(E=3);let D,O,k,A;if(C){let e=kp[C];D=e.vertexShader,O=e.fragmentShader}else{D=i.vertexShader,O=i.fragmentShader;let e=s.getVertexShaderStage(i),t=s.getFragmentShaderStage(i);s.update(i,e,t),k=e.id,A=t.id}let j=e.getRenderTarget(),M=e.state.buffers.depth.getReversed(),N=h.isInstancedMesh===!0,P=h.isBatchedMesh===!0,F=!!i.map,I=!!i.matcap,L=!!x,ee=!!i.aoMap,te=!!i.lightMap,ne=!!i.bumpMap&&i.wireframe===!1,R=!!i.normalMap,re=!!i.displacementMap,z=!!i.emissiveMap,B=!!i.metalnessMap,ie=!!i.roughnessMap,ae=i.anisotropy>0,oe=i.clearcoat>0,se=i.dispersion>0,ce=i.retroreflectivity>0,le=i.iridescence>0,ue=i.sheen>0,de=i.transmission>0,fe=ae&&!!i.anisotropyMap,pe=oe&&!!i.clearcoatMap,me=oe&&!!i.clearcoatNormalMap,he=oe&&!!i.clearcoatRoughnessMap,ge=le&&!!i.iridescenceMap,V=le&&!!i.iridescenceThicknessMap,_e=ue&&!!i.sheenColorMap,ve=ue&&!!i.sheenRoughnessMap,ye=!!i.specularMap,H=!!i.specularColorMap,be=!!i.specularIntensityMap,U=de&&!!i.transmissionMap,W=de&&!!i.thicknessMap,xe=!!i.gradientMap,Se=!!i.alphaMap,Ce=i.alphaTest>0,we=!!i.alphaHash,Te=!!i.extensions,Ee=0;i.toneMapped&&(j===null||j.isXRRenderTarget===!0)&&(Ee=e.toneMapping);let De={shaderID:C,shaderType:i.type,shaderName:i.name,vertexShader:D,fragmentShader:O,defines:i.defines,customVertexShaderID:k,customFragmentShaderID:A,isRawShaderMaterial:i.isRawShaderMaterial===!0,glslVersion:i.glslVersion,precision:f,batching:P,batchingColor:P&&h._colorsTexture!==null,instancing:N,instancingColor:N&&h.instanceColor!==null,instancingMorph:N&&h.morphTexture!==null,outputColorSpace:j===null?e.outputColorSpace:j.isXRRenderTarget===!0?j.texture.colorSpace:dl.workingColorSpace,alphaToCoverage:!!i.alphaToCoverage,map:F,matcap:I,envMap:L,envMapMode:L&&x.mapping,envMapCubeUVHeight:S,aoMap:ee,lightMap:te,bumpMap:ne,normalMap:R,displacementMap:re,emissiveMap:z,normalMapObjectSpace:R&&i.normalMapType===1,normalMapTangentSpace:R&&i.normalMapType===0,packedNormalMap:R&&i.normalMapType===0&&sg(i.normalMap.format),metalnessMap:B,roughnessMap:ie,anisotropy:ae,anisotropyMap:fe,clearcoat:oe,clearcoatMap:pe,clearcoatNormalMap:me,clearcoatRoughnessMap:he,dispersion:se,retroreflection:ce,iridescence:le,iridescenceMap:ge,iridescenceThicknessMap:V,sheen:ue,sheenColorMap:_e,sheenRoughnessMap:ve,specularMap:ye,specularColorMap:H,specularIntensityMap:be,transmission:de,transmissionMap:U,thicknessMap:W,gradientMap:xe,opaque:i.transparent===!1&&i.blending===1&&i.alphaToCoverage===!1,alphaMap:Se,alphaTest:Ce,alphaHash:we,combine:i.combine,mapUv:F&&m(i.map.channel),aoMapUv:ee&&m(i.aoMap.channel),lightMapUv:te&&m(i.lightMap.channel),bumpMapUv:ne&&m(i.bumpMap.channel),normalMapUv:R&&m(i.normalMap.channel),displacementMapUv:re&&m(i.displacementMap.channel),emissiveMapUv:z&&m(i.emissiveMap.channel),metalnessMapUv:B&&m(i.metalnessMap.channel),roughnessMapUv:ie&&m(i.roughnessMap.channel),anisotropyMapUv:fe&&m(i.anisotropyMap.channel),clearcoatMapUv:pe&&m(i.clearcoatMap.channel),clearcoatNormalMapUv:me&&m(i.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:he&&m(i.clearcoatRoughnessMap.channel),iridescenceMapUv:ge&&m(i.iridescenceMap.channel),iridescenceThicknessMapUv:V&&m(i.iridescenceThicknessMap.channel),sheenColorMapUv:_e&&m(i.sheenColorMap.channel),sheenRoughnessMapUv:ve&&m(i.sheenRoughnessMap.channel),specularMapUv:ye&&m(i.specularMap.channel),specularColorMapUv:H&&m(i.specularColorMap.channel),specularIntensityMapUv:be&&m(i.specularIntensityMap.channel),transmissionMapUv:U&&m(i.transmissionMap.channel),thicknessMapUv:W&&m(i.thicknessMap.channel),alphaMapUv:Se&&m(i.alphaMap.channel),vertexTangents:!!v.attributes.tangent&&(R||ae),vertexNormals:!!v.attributes.normal,vertexColors:i.vertexColors,vertexAlphas:i.vertexColors===!0&&!!v.attributes.color&&v.attributes.color.itemSize===4,pointsUvs:h.isPoints===!0&&!!v.attributes.uv&&(F||Se),fog:!!_,useFog:i.fog===!0,fogExp2:!!_&&_.isFogExp2,flatShading:i.wireframe===!1&&(i.flatShading===!0||v.attributes.normal===void 0&&R===!1&&(i.isMeshLambertMaterial||i.isMeshPhongMaterial||i.isMeshStandardMaterial||i.isMeshPhysicalMaterial)),sizeAttenuation:i.sizeAttenuation===!0,logarithmicDepthBuffer:d,reversedDepthBuffer:M,skinning:h.isSkinnedMesh===!0,hasPositionAttribute:v.attributes.position!==void 0,morphTargets:v.morphAttributes.position!==void 0,morphNormals:v.morphAttributes.normal!==void 0,morphColors:v.morphAttributes.color!==void 0,morphTargetsCount:T,morphTextureStride:E,numSunLights:o.sun.length,numDirLights:o.directional.length,numPointLights:o.point.length,numSpotLights:o.spot.length,numSpotLightMaps:o.spotLightMap.length,numRectAreaLights:o.rectArea.length,numHemiLights:o.hemi.length,numSunLightShadows:o.sunShadowMap.length,numDirLightShadows:o.directionalShadowMap.length,numPointLightShadows:o.pointShadowMap.length,numSpotLightShadows:o.spotShadowMap.length,numSpotLightShadowsWithMaps:o.numSpotLightShadowsWithMaps,numLightProbes:o.numLightProbes,numLightProbeGrids:g.length,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:i.dithering,shadowMapEnabled:e.shadowMap.enabled&&l.length>0,shadowMapType:e.shadowMap.type,toneMapping:Ee,decodeVideoTexture:F&&i.map.isVideoTexture===!0&&dl.getTransfer(i.map.colorSpace)===`srgb`,decodeVideoTextureEmissive:z&&i.emissiveMap.isVideoTexture===!0&&dl.getTransfer(i.emissiveMap.colorSpace)===`srgb`,premultipliedAlpha:i.premultipliedAlpha,doubleSided:i.side===2,flipSided:i.side===1,useDepthPacking:i.depthPacking>=0,depthPacking:i.depthPacking||0,index0AttributeName:i.index0AttributeName,extensionClipCullDistance:Te&&i.extensions.clipCullDistance===!0&&n.has(`WEBGL_clip_cull_distance`),extensionMultiDraw:(Te&&i.extensions.multiDraw===!0||P)&&n.has(`WEBGL_multi_draw`),rendererExtensionParallelShaderCompile:n.has(`KHR_parallel_shader_compile`),customProgramCacheKey:i.customProgramCacheKey()};return De.vertexUv1s=c.has(1),De.vertexUv2s=c.has(2),De.vertexUv3s=c.has(3),c.clear(),De}function g(t){let n=[];if(t.shaderID?n.push(t.shaderID):(n.push(t.customVertexShaderID),n.push(t.customFragmentShaderID)),t.defines!==void 0)for(let e in t.defines)n.push(e),n.push(t.defines[e]);return t.isRawShaderMaterial===!1&&(_(n,t),v(n,t),n.push(e.outputColorSpace)),n.push(t.customProgramCacheKey),n.join()}function _(e,t){e.push(t.precision),e.push(t.outputColorSpace),e.push(t.envMapMode),e.push(t.envMapCubeUVHeight),e.push(t.mapUv),e.push(t.alphaMapUv),e.push(t.lightMapUv),e.push(t.aoMapUv),e.push(t.bumpMapUv),e.push(t.normalMapUv),e.push(t.displacementMapUv),e.push(t.emissiveMapUv),e.push(t.metalnessMapUv),e.push(t.roughnessMapUv),e.push(t.anisotropyMapUv),e.push(t.clearcoatMapUv),e.push(t.clearcoatNormalMapUv),e.push(t.clearcoatRoughnessMapUv),e.push(t.iridescenceMapUv),e.push(t.iridescenceThicknessMapUv),e.push(t.sheenColorMapUv),e.push(t.sheenRoughnessMapUv),e.push(t.specularMapUv),e.push(t.specularColorMapUv),e.push(t.specularIntensityMapUv),e.push(t.transmissionMapUv),e.push(t.thicknessMapUv),e.push(t.combine),e.push(t.fogExp2),e.push(t.sizeAttenuation),e.push(t.morphTargetsCount),e.push(t.morphAttributeCount),e.push(t.numSunLights),e.push(t.numDirLights),e.push(t.numPointLights),e.push(t.numSpotLights),e.push(t.numSpotLightMaps),e.push(t.numHemiLights),e.push(t.numRectAreaLights),e.push(t.numSunLightShadows),e.push(t.numDirLightShadows),e.push(t.numPointLightShadows),e.push(t.numSpotLightShadows),e.push(t.numSpotLightShadowsWithMaps),e.push(t.numLightProbes),e.push(t.shadowMapType),e.push(t.toneMapping),e.push(t.numClippingPlanes),e.push(t.numClipIntersection),e.push(t.depthPacking)}function v(e,t){o.disableAll(),t.instancing&&o.enable(0),t.instancingColor&&o.enable(1),t.instancingMorph&&o.enable(2),t.matcap&&o.enable(3),t.envMap&&o.enable(4),t.normalMapObjectSpace&&o.enable(5),t.normalMapTangentSpace&&o.enable(6),t.clearcoat&&o.enable(7),t.iridescence&&o.enable(8),t.alphaTest&&o.enable(9),t.vertexColors&&o.enable(10),t.vertexAlphas&&o.enable(11),t.vertexUv1s&&o.enable(12),t.vertexUv2s&&o.enable(13),t.vertexUv3s&&o.enable(14),t.vertexTangents&&o.enable(15),t.anisotropy&&o.enable(16),t.alphaHash&&o.enable(17),t.batching&&o.enable(18),t.dispersion&&o.enable(19),t.retroreflection&&o.enable(24),t.batchingColor&&o.enable(20),t.gradientMap&&o.enable(21),t.packedNormalMap&&o.enable(22),t.vertexNormals&&o.enable(23),e.push(o.mask),o.disableAll(),t.fog&&o.enable(0),t.useFog&&o.enable(1),t.flatShading&&o.enable(2),t.logarithmicDepthBuffer&&o.enable(3),t.reversedDepthBuffer&&o.enable(4),t.skinning&&o.enable(5),t.morphTargets&&o.enable(6),t.morphNormals&&o.enable(7),t.morphColors&&o.enable(8),t.premultipliedAlpha&&o.enable(9),t.shadowMapEnabled&&o.enable(10),t.doubleSided&&o.enable(11),t.flipSided&&o.enable(12),t.useDepthPacking&&o.enable(13),t.dithering&&o.enable(14),t.transmission&&o.enable(15),t.sheen&&o.enable(16),t.opaque&&o.enable(17),t.pointsUvs&&o.enable(18),t.decodeVideoTexture&&o.enable(19),t.decodeVideoTextureEmissive&&o.enable(20),t.alphaToCoverage&&o.enable(21),t.numLightProbeGrids>0&&o.enable(22),t.hasPositionAttribute&&o.enable(23),e.push(o.mask)}function y(e){let t=p[e.type],n;if(t){let e=kp[t];n=Of.clone(e.uniforms)}else n=e.uniforms;return n}function b(t,n){let r=u.get(n);return r===void 0?(r=new rg(e,n,t,i),l.push(r),u.set(n,r)):++r.usedTimes,r}function x(e){if(--e.usedTimes===0){let t=l.indexOf(e);l[t]=l[l.length-1],l.pop(),u.delete(e.cacheKey),e.destroy()}}function S(e){s.remove(e)}function C(){s.dispose()}return{getParameters:h,getProgramCacheKey:g,getUniforms:y,acquireProgram:b,releaseProgram:x,releaseShaderCache:S,programs:l,dispose:C}}function lg(){let e=new WeakMap;function t(t){return e.has(t)}function n(t){let n=e.get(t);return n===void 0&&(n={},e.set(t,n)),n}function r(t){e.delete(t)}function i(t,n,r){e.get(t)[n]=r}function a(){e=new WeakMap}return{has:t,get:n,remove:r,update:i,dispose:a}}function ug(e,t){return e.groupOrder===t.groupOrder?e.renderOrder===t.renderOrder?e.material.id===t.material.id?e.materialVariant===t.materialVariant?e.z===t.z?e.id-t.id:e.z-t.z:e.materialVariant-t.materialVariant:e.material.id-t.material.id:e.renderOrder-t.renderOrder:e.groupOrder-t.groupOrder}function dg(e,t){return e.groupOrder===t.groupOrder?e.renderOrder===t.renderOrder?e.z===t.z?e.id-t.id:t.z-e.z:e.renderOrder-t.renderOrder:e.groupOrder-t.groupOrder}function fg(){let e=[],t=0,n=[],r=[],i=[];function a(){t=0,n.length=0,r.length=0,i.length=0}function o(e){let t=0;return e.isInstancedMesh&&(t+=2),e.isSkinnedMesh&&(t+=1),t}function s(n,r,i,a,s,c){let l=e[t];return l===void 0?(l={id:n.id,object:n,geometry:r,material:i,materialVariant:o(n),groupOrder:a,renderOrder:n.renderOrder,z:s,group:c},e[t]=l):(l.id=n.id,l.object=n,l.geometry=r,l.material=i,l.materialVariant=o(n),l.groupOrder=a,l.renderOrder=n.renderOrder,l.z=s,l.group=c),t++,l}function c(e,t,a,o,c,l,u){u.reversedDepth===!0&&(c=-c);let d=s(e,t,a,o,c,l);a.transmission>0?r.push(d):a.transparent===!0?i.push(d):n.push(d)}function l(e,t,a,o,c,l){let u=s(e,t,a,o,c,l);a.transmission>0?r.unshift(u):a.transparent===!0?i.unshift(u):n.unshift(u)}function u(e,t){n.length>1&&n.sort(e||ug),r.length>1&&r.sort(t||dg),i.length>1&&i.sort(t||dg)}function d(){for(let n=t,r=e.length;n<r;n++){let t=e[n];if(t.id===null)break;t.id=null,t.object=null,t.geometry=null,t.material=null,t.group=null}}return{opaque:n,transmissive:r,transparent:i,init:a,push:c,unshift:l,finish:d,sort:u}}function pg(){let e=new WeakMap;function t(t,n){let r=e.get(t),i;return r===void 0?(i=new fg,e.set(t,[i])):n>=r.length?(i=new fg,r.push(i)):i=r[n],i}function n(){e=new WeakMap}return{get:t,dispose:n}}function mg(){let e={};return{get:function(t){if(e[t.id]!==void 0)return e[t.id];let n;switch(t.type){case`SunLight`:case`DirectionalLight`:n={direction:new X,color:new cu};break;case`SpotLight`:n={position:new X,direction:new X,color:new cu,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case`PointLight`:n={position:new X,color:new cu,distance:0,decay:0};break;case`HemisphereLight`:n={direction:new X,skyColor:new cu,groundColor:new cu};break;case`RectAreaLight`:n={color:new cu,position:new X,halfWidth:new X,halfHeight:new X}}return e[t.id]=n,n}}}function hg(){let e={};return{get:function(t){if(e[t.id]!==void 0)return e[t.id];let n;switch(t.type){case`SunLight`:case`DirectionalLight`:n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Y};break;case`SpotLight`:n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Y};break;case`PointLight`:n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Y,shadowCameraNear:1,shadowCameraFar:1e3}}return e[t.id]=n,n}}}var gg=0;function _g(e,t){return(t.castShadow?2:0)-(e.castShadow?2:0)+ +!!t.map-!!e.map}function vg(e){let t=new mg,n=hg(),r={version:0,hash:{sunLength:-1,directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numSunShadows:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],sun:[],sunShadow:[],sunShadowMap:[],sunShadowMatrix:[],sunShadowCascade:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let e=0;e<9;e++)r.probe.push(new X);let i=new X,a=new Dl,o=new Dl;function s(i){let a=0,o=0,s=0;for(let e=0;e<9;e++)r.probe[e].set(0,0,0);let c=0,l=0,u=0,d=0,f=0,p=0,m=0,h=0,g=0,_=0,v=0,y=0,b=0,x=0;i.sort(_g);for(let e=0,S=i.length;e<S;e++){let S=i[e],C=S.color,w=S.intensity,T=S.distance,E=null;if(S.shadow&&S.shadow.map&&(E=S.shadow.map.texture.format===1030?S.shadow.map.texture:S.shadow.map.depthTexture||S.shadow.map.texture),S.isAmbientLight)a+=C.r*w,o+=C.g*w,s+=C.b*w;else if(S.isLightProbe){for(let e=0;e<9;e++)r.probe[e].addScaledVector(S.sh.coefficients[e],w);x++}else if(S.isSunLight){let e=t.get(S);if(e.color.copy(S.color).multiplyScalar(S.intensity),S.castShadow){let e=S.shadow,t=n.get(S);t.shadowIntensity=e.intensity,t.shadowBias=e.bias,t.shadowNormalBias=e.normalBias,t.shadowRadius=e.radius,t.shadowMapSize.copy(e.mapSize).multiply(e.getFrameExtents()),r.sunShadow[l]=t,r.sunShadowMap[l]=E;let i=e.getViewportCount();for(let t=0;t<i;t++)r.sunShadowMatrix[u+t]=e.getMatrix(t),r.sunShadowCascade[u+t]=e._cascadeData[t];u+=i,l++}r.sun[c]=e,c++}else if(S.isDirectionalLight){let e=t.get(S);if(e.color.copy(S.color).multiplyScalar(S.intensity),S.castShadow){let e=S.shadow,t=n.get(S);t.shadowIntensity=e.intensity,t.shadowBias=e.bias,t.shadowNormalBias=e.normalBias,t.shadowRadius=e.radius,t.shadowMapSize=e.mapSize,r.directionalShadow[d]=t,r.directionalShadowMap[d]=E,r.directionalShadowMatrix[d]=S.shadow.matrix,g++}r.directional[d]=e,d++}else if(S.isSpotLight){let e=t.get(S);e.position.setFromMatrixPosition(S.matrixWorld),e.color.copy(C).multiplyScalar(w),e.distance=T,e.coneCos=Math.cos(S.angle),e.penumbraCos=Math.cos(S.angle*(1-S.penumbra)),e.decay=S.decay,r.spot[p]=e;let i=S.shadow;if(S.map&&(r.spotLightMap[y]=S.map,y++,i.updateMatrices(S),S.castShadow&&b++),r.spotLightMatrix[p]=i.matrix,S.castShadow){let e=n.get(S);e.shadowIntensity=i.intensity,e.shadowBias=i.bias,e.shadowNormalBias=i.normalBias,e.shadowRadius=i.radius,e.shadowMapSize=i.mapSize,r.spotShadow[p]=e,r.spotShadowMap[p]=E,v++}p++}else if(S.isRectAreaLight){let e=t.get(S);e.color.copy(C).multiplyScalar(w),e.halfWidth.set(S.width*.5,0,0),e.halfHeight.set(0,S.height*.5,0),r.rectArea[m]=e,m++}else if(S.isPointLight){let e=t.get(S);if(e.color.copy(S.color).multiplyScalar(S.intensity),e.distance=S.distance,e.decay=S.decay,S.castShadow){let e=S.shadow,t=n.get(S);t.shadowIntensity=e.intensity,t.shadowBias=e.bias,t.shadowNormalBias=e.normalBias,t.shadowRadius=e.radius,t.shadowMapSize=e.mapSize,t.shadowCameraNear=e.camera.near,t.shadowCameraFar=e.camera.far,r.pointShadow[f]=t,r.pointShadowMap[f]=E,r.pointShadowMatrix[f]=S.shadow.matrix,_++}r.point[f]=e,f++}else if(S.isHemisphereLight){let e=t.get(S);e.skyColor.copy(S.color).multiplyScalar(w),e.groundColor.copy(S.groundColor).multiplyScalar(w),r.hemi[h]=e,h++}}m>0&&(e.has(`OES_texture_float_linear`)===!0?(r.rectAreaLTC1=$.LTC_FLOAT_1,r.rectAreaLTC2=$.LTC_FLOAT_2):(r.rectAreaLTC1=$.LTC_HALF_1,r.rectAreaLTC2=$.LTC_HALF_2)),r.ambient[0]=a,r.ambient[1]=o,r.ambient[2]=s;let S=r.hash;(S.sunLength!==c||S.directionalLength!==d||S.pointLength!==f||S.spotLength!==p||S.rectAreaLength!==m||S.hemiLength!==h||S.numSunShadows!==l||S.numDirectionalShadows!==g||S.numPointShadows!==_||S.numSpotShadows!==v||S.numSpotMaps!==y||S.numLightProbes!==x)&&(r.sun.length=c,r.directional.length=d,r.spot.length=p,r.rectArea.length=m,r.point.length=f,r.hemi.length=h,r.sunShadow.length=l,r.sunShadowMap.length=l,r.sunShadowMatrix.length=u,r.sunShadowCascade.length=u,r.directionalShadow.length=g,r.directionalShadowMap.length=g,r.directionalShadowMatrix.length=g,r.pointShadow.length=_,r.pointShadowMap.length=_,r.pointShadowMatrix.length=_,r.spotShadow.length=v,r.spotShadowMap.length=v,r.spotLightMatrix.length=v+y-b,r.spotLightMap.length=y,r.numSpotLightShadowsWithMaps=b,r.numLightProbes=x,S.sunLength=c,S.directionalLength=d,S.pointLength=f,S.spotLength=p,S.rectAreaLength=m,S.hemiLength=h,S.numSunShadows=l,S.numDirectionalShadows=g,S.numPointShadows=_,S.numSpotShadows=v,S.numSpotMaps=y,S.numLightProbes=x,r.version=gg++)}function c(e,t){let n=0,s=0,c=0,l=0,u=0,d=0,f=t.matrixWorldInverse;for(let t=0,p=e.length;t<p;t++){let p=e[t];if(p.isSunLight){let e=r.sun[n];e.direction.setFromMatrixPosition(p.matrixWorld),e.direction.transformDirection(f),n++}else if(p.isDirectionalLight){let e=r.directional[s];e.direction.setFromMatrixPosition(p.matrixWorld),i.setFromMatrixPosition(p.target.matrixWorld),e.direction.sub(i),e.direction.transformDirection(f),s++}else if(p.isSpotLight){let e=r.spot[l];e.position.setFromMatrixPosition(p.matrixWorld),e.position.applyMatrix4(f),e.direction.setFromMatrixPosition(p.matrixWorld),i.setFromMatrixPosition(p.target.matrixWorld),e.direction.sub(i),e.direction.transformDirection(f),l++}else if(p.isRectAreaLight){let e=r.rectArea[u];e.position.setFromMatrixPosition(p.matrixWorld),e.position.applyMatrix4(f),o.identity(),a.copy(p.matrixWorld),a.premultiply(f),o.extractRotation(a),e.halfWidth.set(p.width*.5,0,0),e.halfHeight.set(0,p.height*.5,0),e.halfWidth.applyMatrix4(o),e.halfHeight.applyMatrix4(o),u++}else if(p.isPointLight){let e=r.point[c];e.position.setFromMatrixPosition(p.matrixWorld),e.position.applyMatrix4(f),c++}else if(p.isHemisphereLight){let e=r.hemi[d];e.direction.setFromMatrixPosition(p.matrixWorld),e.direction.transformDirection(f),d++}}}return{setup:s,setupView:c,state:r}}function yg(e){let t=new vg(e),n=[],r=[],i=[];function a(e){d.camera=e,n.length=0,r.length=0,i.length=0}function o(e){n.push(e)}function s(e){r.push(e)}function c(e){i.push(e)}function l(){t.setup(n)}function u(e){t.setupView(n,e)}let d={lightsArray:n,shadowsArray:r,lightProbeGridArray:i,camera:null,lights:t,transmissionRenderTarget:{},textureUnits:0};return{init:a,state:d,setupLights:l,setupLightsView:u,pushLight:o,pushShadow:s,pushLightProbeGrid:c}}function bg(e){let t=new WeakMap;function n(n,r=0){let i=t.get(n),a;return i===void 0?(a=new yg(e),t.set(n,[a])):r>=i.length?(a=new yg(e),i.push(a)):a=i[r],a}function r(){t=new WeakMap}return{get:n,dispose:r}}var xg=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Sg=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,Cg=[new X(1,0,0),new X(-1,0,0),new X(0,1,0),new X(0,-1,0),new X(0,0,1),new X(0,0,-1)],wg=[new X(0,-1,0),new X(0,-1,0),new X(0,0,1),new X(0,0,-1),new X(0,-1,0),new X(0,-1,0)],Tg=new Dl,Eg=new X,Dg=new X;function Og(e,t,n){let r=new ef,i=new Y,a=new Y,o=new Sl,s=new Nf,c=new Pf,l={},u=n.maxTextureSize,d={0:1,1:0,2:2},f=new jf({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Y},radius:{value:4}},vertexShader:xg,fragmentShader:Sg}),p=f.clone();p.defines.HORIZONTAL_PASS=1;let m=new id;m.setAttribute(`position`,new Uu(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let h=new qd(m,f),g=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=1;let _=this.type;this.render=function(t,n,s){if(g.enabled===!1||g.autoUpdate===!1&&g.needsUpdate===!1||t.length===0)return;this.type===2&&(q(`WebGLShadowMap: PCFSoftShadowMap has been removed. Using PCFShadowMap instead.`),this.type=1);let c=e.getRenderTarget(),l=e.getActiveCubeFace(),d=e.getActiveMipmapLevel(),f=e.state;f.setBlending(0),f.buffers.depth.getReversed()===!0?f.buffers.color.setClear(0,0,0,0):f.buffers.color.setClear(1,1,1,1),f.buffers.depth.setTest(!0),f.setScissorTest(!1);let p=_!==this.type;p&&n.traverse(function(e){e.material&&(Array.isArray(e.material)?e.material.forEach(e=>e.needsUpdate=!0):e.material.needsUpdate=!0)});for(let c=0,l=t.length;c<l;c++){let l=t[c],d=l.shadow;if(d===void 0){q(`WebGLShadowMap:`,l,`has no shadow.`);continue}if(d.autoUpdate===!1&&d.needsUpdate===!1)continue;i.copy(d.mapSize);let m=d.getFrameExtents();i.multiply(m),a.copy(d.mapSize),(i.x>u||i.y>u)&&(i.x>u&&(a.x=Math.floor(u/m.x),i.x=a.x*m.x,d.mapSize.x=a.x),i.y>u&&(a.y=Math.floor(u/m.y),i.y=a.y*m.y,d.mapSize.y=a.y));let h=e.state.buffers.depth.getReversed();if(d.camera._reversedDepth=h,d.map===null||p===!0){if(d.map!==null&&(d.map.depthTexture!==null&&(d.map.depthTexture.dispose(),d.map.depthTexture=null),d.map.dispose()),this.type===3){if(l.isPointLight){q(`WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.`);continue}d.map=new wl(i.x,i.y,{format:Rs,type:Ts,minFilter:hs,magFilter:hs,generateMipmaps:!1}),d.map.texture.name=l.name+`.shadowMap`,d.map.depthTexture=new _f(i.x,i.y,ws),d.map.depthTexture.name=l.name+`.shadowMapDepth`,d.map.depthTexture.format=Ps,d.map.depthTexture.compareFunction=null,d.map.depthTexture.minFilter=fs,d.map.depthTexture.magFilter=fs}else l.isPointLight?(d.map=new am(i.x),d.map.depthTexture=new vf(i.x,Cs)):(d.map=new wl(i.x,i.y),d.map.depthTexture=new _f(i.x,i.y,Cs)),d.map.depthTexture.name=l.name+`.shadowMap`,d.map.depthTexture.format=Ps,this.type===1?(d.map.depthTexture.compareFunction=h?518:515,d.map.depthTexture.minFilter=hs,d.map.depthTexture.magFilter=hs):(d.map.depthTexture.compareFunction=null,d.map.depthTexture.minFilter=fs,d.map.depthTexture.magFilter=fs);d.camera.updateProjectionMatrix()}d.map.isWebGLCubeRenderTarget!==!0&&(d.map.width!==i.x||d.map.height!==i.y)&&d.map.setSize(i.x,i.y);let g=d.map.isWebGLCubeRenderTarget?6:d.getViewportCount();l.isPointLight!==!0&&d.updateMatrices(l,s);for(let t=0;t<g;t++){let i=d.getCamera(t);if(l.isPointLight){let e=d.camera,n=d.matrix,r=l.distance||e.far;r!==e.far&&(e.far=r,e.updateProjectionMatrix()),Eg.setFromMatrixPosition(l.matrixWorld),e.position.copy(Eg),Dg.copy(e.position),Dg.add(Cg[t]),e.up.copy(wg[t]),e.lookAt(Dg),e.updateMatrixWorld(),n.makeTranslation(-Eg.x,-Eg.y,-Eg.z),Tg.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),d._frustum.setFromProjectionMatrix(Tg,e.coordinateSystem,e.reversedDepth)}if(d.map.isWebGLCubeRenderTarget)e.setRenderTarget(d.map,t),e.clear();else{t===0&&(e.setRenderTarget(d.map),e.clear());let n=d.getViewport(t);o.set(a.x*n.x,a.y*n.y,a.x*n.z,a.y*n.w),f.viewport(o)}r=d.getFrustum(t),b(n,s,i,l,this.type)}d.isPointLightShadow!==!0&&this.type===3&&v(d,s),d.needsUpdate=!1}_=this.type,g.needsUpdate=!1,e.setRenderTarget(c,l,d)};function v(n,r){let a=t.update(h);f.defines.VSM_SAMPLES!==n.blurSamples&&(f.defines.VSM_SAMPLES=n.blurSamples,p.defines.VSM_SAMPLES=n.blurSamples,f.needsUpdate=!0,p.needsUpdate=!0),n.mapPass===null?n.mapPass=new wl(i.x,i.y,{format:Rs,type:Ts}):(n.mapPass.width!==n.map.width||n.mapPass.height!==n.map.height)&&n.mapPass.setSize(n.map.width,n.map.height),f.uniforms.shadow_pass.value=n.map.depthTexture,f.uniforms.resolution.value.set(n.map.width,n.map.height),f.uniforms.radius.value=n.radius,e.setRenderTarget(n.mapPass),e.clear(),e.renderBufferDirect(r,null,a,f,h,null),p.uniforms.shadow_pass.value=n.mapPass.texture,p.uniforms.resolution.value.set(n.map.width,n.map.height),p.uniforms.radius.value=n.radius,e.setRenderTarget(n.map),e.clear(),e.renderBufferDirect(r,null,a,p,h,null)}function y(t,n,r,i){let a=null,o=r.isPointLight===!0?t.customDistanceMaterial:t.customDepthMaterial;if(o!==void 0)a=o;else if(a=r.isPointLight===!0?c:s,e.localClippingEnabled&&n.clipShadows===!0&&Array.isArray(n.clippingPlanes)&&n.clippingPlanes.length!==0||n.displacementMap&&n.displacementScale!==0||n.alphaMap&&n.alphaTest>0||n.map&&n.alphaTest>0||n.alphaToCoverage===!0){let e=a.uuid,t=n.uuid,r=l[e];r===void 0&&(r={},l[e]=r);let i=r[t];i===void 0&&(i=a.clone(),r[t]=i,n.addEventListener(`dispose`,x)),a=i}if(a.visible=n.visible,a.wireframe=n.wireframe,i===3?a.side=n.shadowSide===null?n.side:n.shadowSide:a.side=n.shadowSide===null?d[n.side]:n.shadowSide,a.alphaMap=n.alphaMap,a.alphaTest=n.alphaToCoverage===!0?.5:n.alphaTest,a.map=n.map,a.clipShadows=n.clipShadows,a.clippingPlanes=n.clippingPlanes,a.clipIntersection=n.clipIntersection,a.displacementMap=n.displacementMap,a.displacementScale=n.displacementScale,a.displacementBias=n.displacementBias,a.wireframeLinewidth=n.wireframeLinewidth,a.linewidth=n.linewidth,r.isPointLight===!0&&a.isMeshDistanceMaterial===!0){let t=e.properties.get(a);t.light=r}return a}function b(n,i,a,o,s){if(n.visible===!1)return;if(n.layers.test(i.layers)&&(n.isMesh||n.isLine||n.isPoints)&&(n.castShadow||n.receiveShadow&&s===3)&&(!n.frustumCulled||n.intersectsFrustum(r))){n.modelViewMatrix.multiplyMatrices(a.matrixWorldInverse,n.matrixWorld);let r=t.update(n),c=n.material;if(Array.isArray(c)){let t=r.groups;for(let l=0,u=t.length;l<u;l++){let u=t[l],d=c[u.materialIndex];if(d&&d.visible){let t=y(n,d,o,s);n.onBeforeShadow(e,n,i,a,r,t,u),e.renderBufferDirect(a,null,r,t,n,u),n.onAfterShadow(e,n,i,a,r,t,u)}}}else if(c.visible){let t=y(n,c,o,s);n.onBeforeShadow(e,n,i,a,r,t,null),e.renderBufferDirect(a,null,r,t,n,null),n.onAfterShadow(e,n,i,a,r,t,null)}}let c=n.children;for(let e=0,t=c.length;e<t;e++)b(c[e],i,a,o,s)}function x(e){e.target.removeEventListener(`dispose`,x);for(let t in l){let n=l[t],r=e.target.uuid;r in n&&(n[r].dispose(),delete n[r])}}}function kg(e,t){function n(){let t=!1,n=new Sl,r=null,i=new Sl(0,0,0,0);return{setMask:function(n){r!==n&&!t&&(e.colorMask(n,n,n,n),r=n)},setLocked:function(e){t=e},setClear:function(t,r,a,o,s){s===!0&&(t*=o,r*=o,a*=o),n.set(t,r,a,o),i.equals(n)===!1&&(e.clearColor(t,r,a,o),i.copy(n))},reset:function(){t=!1,r=null,i.set(-1,0,0,0)}}}function r(){let n=!1,r=!1,i=null,a=null,o=null;return{setReversed:function(e){if(r!==e){let n=t.get(`EXT_clip_control`);e?n.clipControlEXT(n.LOWER_LEFT_EXT,n.ZERO_TO_ONE_EXT):n.clipControlEXT(n.LOWER_LEFT_EXT,n.NEGATIVE_ONE_TO_ONE_EXT),r=e;let i=o;o=null,this.setClear(i)}},getReversed:function(){return r},setTest:function(t){t?B(e.DEPTH_TEST):ie(e.DEPTH_TEST)},setMask:function(t){i!==t&&!n&&(e.depthMask(t),i=t)},setFunc:function(t){if(r&&(t=qc[t]),a!==t){switch(t){case 0:e.depthFunc(e.NEVER);break;case 1:e.depthFunc(e.ALWAYS);break;case 2:e.depthFunc(e.LESS);break;case 3:e.depthFunc(e.LEQUAL);break;case 4:e.depthFunc(e.EQUAL);break;case 5:e.depthFunc(e.GEQUAL);break;case 6:e.depthFunc(e.GREATER);break;case 7:e.depthFunc(e.NOTEQUAL);break;default:e.depthFunc(e.LEQUAL)}a=t}},setLocked:function(e){n=e},setClear:function(t){o!==t&&(o=t,r&&(t=1-t),e.clearDepth(t))},reset:function(){n=!1,i=null,a=null,o=null,r=!1}}}function i(){let t=!1,n=null,r=null,i=null,a=null,o=null,s=null,c=null,l=null;return{setTest:function(n){t||(n?B(e.STENCIL_TEST):ie(e.STENCIL_TEST))},setMask:function(r){n!==r&&!t&&(e.stencilMask(r),n=r)},setFunc:function(t,n,o){(r!==t||i!==n||a!==o)&&(e.stencilFunc(t,n,o),r=t,i=n,a=o)},setOp:function(t,n,r){(o!==t||s!==n||c!==r)&&(e.stencilOp(t,n,r),o=t,s=n,c=r)},setLocked:function(e){t=e},setClear:function(t){l!==t&&(e.clearStencil(t),l=t)},reset:function(){t=!1,n=null,r=null,i=null,a=null,o=null,s=null,c=null,l=null}}}let a=new n,o=new r,s=new i,c=new WeakMap,l=new WeakMap,u={},d={},f={},p=new WeakMap,m=[],h=null,g=!1,_=null,v=null,y=null,b=null,x=null,S=null,C=null,w=new cu(0,0,0),T=0,E=!1,D=null,O=null,k=null,A=null,j=null,M=e.getParameter(e.MAX_COMBINED_TEXTURE_IMAGE_UNITS),N=!1,P=0,F=e.getParameter(e.VERSION);F.indexOf(`WebGL`)===-1?F.indexOf(`OpenGL ES`)!==-1&&(P=parseFloat(/^OpenGL ES (\d)/.exec(F)[1]),N=P>=2):(P=parseFloat(/^WebGL (\d)/.exec(F)[1]),N=P>=1);let I=null,L={},ee=e.getParameter(e.SCISSOR_BOX),te=e.getParameter(e.VIEWPORT),ne=new Sl().fromArray(ee),R=new Sl().fromArray(te);function re(t,n,r,i){let a=new Uint8Array(4),o=e.createTexture();e.bindTexture(t,o),e.texParameteri(t,e.TEXTURE_MIN_FILTER,e.NEAREST),e.texParameteri(t,e.TEXTURE_MAG_FILTER,e.NEAREST);for(let o=0;o<r;o++)t===e.TEXTURE_3D||t===e.TEXTURE_2D_ARRAY?e.texImage3D(n,0,e.RGBA,1,1,i,0,e.RGBA,e.UNSIGNED_BYTE,a):e.texImage2D(n+o,0,e.RGBA,1,1,0,e.RGBA,e.UNSIGNED_BYTE,a);return o}let z={};z[e.TEXTURE_2D]=re(e.TEXTURE_2D,e.TEXTURE_2D,1),z[e.TEXTURE_CUBE_MAP]=re(e.TEXTURE_CUBE_MAP,e.TEXTURE_CUBE_MAP_POSITIVE_X,6),z[e.TEXTURE_2D_ARRAY]=re(e.TEXTURE_2D_ARRAY,e.TEXTURE_2D_ARRAY,1,1),z[e.TEXTURE_3D]=re(e.TEXTURE_3D,e.TEXTURE_3D,1,1),a.setClear(0,0,0,1),o.setClear(1),s.setClear(0),B(e.DEPTH_TEST),o.setFunc(3),fe(!1),pe(1),B(e.CULL_FACE),ue(0);function B(t){u[t]!==!0&&(e.enable(t),u[t]=!0)}function ie(t){u[t]!==!1&&(e.disable(t),u[t]=!1)}function ae(t,n){return f[t]!==n&&(e.bindFramebuffer(t,n),f[t]=n,t===e.DRAW_FRAMEBUFFER&&(f[e.FRAMEBUFFER]=n),t===e.FRAMEBUFFER&&(f[e.DRAW_FRAMEBUFFER]=n),!0)}function oe(t,n){let r=m,i=!1;if(t){r=p.get(n),r===void 0&&(r=[],p.set(n,r));let a=t.textures;if(r.length!==a.length||r[0]!==e.COLOR_ATTACHMENT0){for(let t=0,n=a.length;t<n;t++)r[t]=e.COLOR_ATTACHMENT0+t;r.length=a.length,i=!0}}else r[0]!==e.BACK&&(r[0]=e.BACK,i=!0);i&&e.drawBuffers(r)}function se(t){return h!==t&&(e.useProgram(t),h=t,!0)}let ce={100:e.FUNC_ADD,101:e.FUNC_SUBTRACT,102:e.FUNC_REVERSE_SUBTRACT};ce[103]=e.MIN,ce[104]=e.MAX;let le={200:e.ZERO,201:e.ONE,202:e.SRC_COLOR,204:e.SRC_ALPHA,210:e.SRC_ALPHA_SATURATE,208:e.DST_COLOR,206:e.DST_ALPHA,203:e.ONE_MINUS_SRC_COLOR,205:e.ONE_MINUS_SRC_ALPHA,209:e.ONE_MINUS_DST_COLOR,207:e.ONE_MINUS_DST_ALPHA,211:e.CONSTANT_COLOR,212:e.ONE_MINUS_CONSTANT_COLOR,213:e.CONSTANT_ALPHA,214:e.ONE_MINUS_CONSTANT_ALPHA};function ue(t,n,r,i,a,o,s,c,l,u){if(t===0){g===!0&&(ie(e.BLEND),g=!1);return}if(g===!1&&(B(e.BLEND),g=!0),t!==5){if(t!==_||u!==E){if((v!==100||x!==100)&&(e.blendEquation(e.FUNC_ADD),v=100,x=100),u)switch(t){case 1:e.blendFuncSeparate(e.ONE,e.ONE_MINUS_SRC_ALPHA,e.ONE,e.ONE_MINUS_SRC_ALPHA);break;case 2:e.blendFunc(e.ONE,e.ONE);break;case 3:e.blendFuncSeparate(e.ZERO,e.ONE_MINUS_SRC_COLOR,e.ZERO,e.ONE);break;case 4:e.blendFuncSeparate(e.DST_COLOR,e.ONE_MINUS_SRC_ALPHA,e.ZERO,e.ONE);break;default:J(`WebGLState: Invalid blending: `,t)}else switch(t){case 1:e.blendFuncSeparate(e.SRC_ALPHA,e.ONE_MINUS_SRC_ALPHA,e.ONE,e.ONE_MINUS_SRC_ALPHA);break;case 2:e.blendFuncSeparate(e.SRC_ALPHA,e.ONE,e.ONE,e.ONE);break;case 3:J(`WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true`);break;case 4:J(`WebGLState: MultiplyBlending requires material.premultipliedAlpha = true`);break;default:J(`WebGLState: Invalid blending: `,t)}y=null,b=null,S=null,C=null,w.set(0,0,0),T=0,_=t,E=u}return}a||=n,o||=r,s||=i,(n!==v||a!==x)&&(e.blendEquationSeparate(ce[n],ce[a]),v=n,x=a),(r!==y||i!==b||o!==S||s!==C)&&(e.blendFuncSeparate(le[r],le[i],le[o],le[s]),y=r,b=i,S=o,C=s),(c.equals(w)===!1||l!==T)&&(e.blendColor(c.r,c.g,c.b,l),w.copy(c),T=l),_=t,E=!1}function de(t,n){t.side===2?ie(e.CULL_FACE):B(e.CULL_FACE);let r=t.side===1;n&&(r=!r),fe(r),t.blending===1&&t.transparent===!1?ue(0):ue(t.blending,t.blendEquation,t.blendSrc,t.blendDst,t.blendEquationAlpha,t.blendSrcAlpha,t.blendDstAlpha,t.blendColor,t.blendAlpha,t.premultipliedAlpha),o.setFunc(t.depthFunc),o.setTest(t.depthTest),o.setMask(t.depthWrite),a.setMask(t.colorWrite);let i=t.stencilWrite;s.setTest(i),i&&(s.setMask(t.stencilWriteMask),s.setFunc(t.stencilFunc,t.stencilRef,t.stencilFuncMask),s.setOp(t.stencilFail,t.stencilZFail,t.stencilZPass)),he(t.polygonOffset,t.polygonOffsetFactor,t.polygonOffsetUnits),t.alphaToCoverage===!0?B(e.SAMPLE_ALPHA_TO_COVERAGE):ie(e.SAMPLE_ALPHA_TO_COVERAGE)}function fe(t){D!==t&&(t?e.frontFace(e.CW):e.frontFace(e.CCW),D=t)}function pe(t){t===0?ie(e.CULL_FACE):(B(e.CULL_FACE),t!==O&&(t===1?e.cullFace(e.BACK):t===2?e.cullFace(e.FRONT):e.cullFace(e.FRONT_AND_BACK))),O=t}function me(t){t!==k&&(N&&e.lineWidth(t),k=t)}function he(t,n,r){t?(B(e.POLYGON_OFFSET_FILL),(A!==n||j!==r)&&(A=n,j=r,o.getReversed()&&(n=-n),e.polygonOffset(n,r))):ie(e.POLYGON_OFFSET_FILL)}function ge(t){t?B(e.SCISSOR_TEST):ie(e.SCISSOR_TEST)}function V(t){t===void 0&&(t=e.TEXTURE0+M-1),I!==t&&(e.activeTexture(t),I=t)}function _e(t,n,r){r===void 0&&(r=I===null?e.TEXTURE0+M-1:I);let i=L[r];i===void 0&&(i={type:void 0,texture:void 0},L[r]=i),(i.type!==t||i.texture!==n)&&(I!==r&&(e.activeTexture(r),I=r),e.bindTexture(t,n||z[t]),i.type=t,i.texture=n)}function ve(){let t=L[I];t!==void 0&&t.type!==void 0&&(e.bindTexture(t.type,null),t.type=void 0,t.texture=void 0)}function ye(){try{e.compressedTexImage2D(...arguments)}catch(e){J(`WebGLState:`,e)}}function H(){try{e.compressedTexImage3D(...arguments)}catch(e){J(`WebGLState:`,e)}}function be(){try{e.texSubImage2D(...arguments)}catch(e){J(`WebGLState:`,e)}}function U(){try{e.texSubImage3D(...arguments)}catch(e){J(`WebGLState:`,e)}}function W(){try{e.compressedTexSubImage2D(...arguments)}catch(e){J(`WebGLState:`,e)}}function xe(){try{e.compressedTexSubImage3D(...arguments)}catch(e){J(`WebGLState:`,e)}}function Se(){try{e.texStorage2D(...arguments)}catch(e){J(`WebGLState:`,e)}}function Ce(){try{e.texStorage3D(...arguments)}catch(e){J(`WebGLState:`,e)}}function we(){try{e.texImage2D(...arguments)}catch(e){J(`WebGLState:`,e)}}function Te(){try{e.texImage3D(...arguments)}catch(e){J(`WebGLState:`,e)}}function Ee(t){return d[t]===void 0?e.getParameter(t):d[t]}function De(t,n){d[t]!==n&&(e.pixelStorei(t,n),d[t]=n)}function Oe(t){ne.equals(t)===!1&&(e.scissor(t.x,t.y,t.z,t.w),ne.copy(t))}function ke(t){R.equals(t)===!1&&(e.viewport(t.x,t.y,t.z,t.w),R.copy(t))}function Ae(t,n){let r=l.get(n);r===void 0&&(r=new WeakMap,l.set(n,r));let i=r.get(t);i===void 0&&(i=e.getUniformBlockIndex(n,t.name),r.set(t,i))}function je(t,n){let r=l.get(n).get(t);c.get(n)!==r&&(e.uniformBlockBinding(n,r,t.__bindingPointIndex),c.set(n,r))}function Me(){e.disable(e.BLEND),e.disable(e.CULL_FACE),e.disable(e.DEPTH_TEST),e.disable(e.POLYGON_OFFSET_FILL),e.disable(e.SCISSOR_TEST),e.disable(e.STENCIL_TEST),e.disable(e.SAMPLE_ALPHA_TO_COVERAGE),e.blendEquation(e.FUNC_ADD),e.blendFunc(e.ONE,e.ZERO),e.blendFuncSeparate(e.ONE,e.ZERO,e.ONE,e.ZERO),e.blendColor(0,0,0,0),e.colorMask(!0,!0,!0,!0),e.clearColor(0,0,0,0),e.depthMask(!0),e.depthFunc(e.LESS),o.setReversed(!1),e.clearDepth(1),e.stencilMask(4294967295),e.stencilFunc(e.ALWAYS,0,4294967295),e.stencilOp(e.KEEP,e.KEEP,e.KEEP),e.clearStencil(0),e.cullFace(e.BACK),e.frontFace(e.CCW),e.polygonOffset(0,0),e.activeTexture(e.TEXTURE0),e.bindFramebuffer(e.FRAMEBUFFER,null),e.bindFramebuffer(e.DRAW_FRAMEBUFFER,null),e.bindFramebuffer(e.READ_FRAMEBUFFER,null),e.useProgram(null),e.lineWidth(1),e.scissor(0,0,e.canvas.width,e.canvas.height),e.viewport(0,0,e.canvas.width,e.canvas.height),e.pixelStorei(e.PACK_ALIGNMENT,4),e.pixelStorei(e.UNPACK_ALIGNMENT,4),e.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,!1),e.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),e.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,e.BROWSER_DEFAULT_WEBGL),e.pixelStorei(e.PACK_ROW_LENGTH,0),e.pixelStorei(e.PACK_SKIP_PIXELS,0),e.pixelStorei(e.PACK_SKIP_ROWS,0),e.pixelStorei(e.UNPACK_ROW_LENGTH,0),e.pixelStorei(e.UNPACK_IMAGE_HEIGHT,0),e.pixelStorei(e.UNPACK_SKIP_PIXELS,0),e.pixelStorei(e.UNPACK_SKIP_ROWS,0),e.pixelStorei(e.UNPACK_SKIP_IMAGES,0),u={},d={},I=null,L={},f={},p=new WeakMap,m=[],h=null,g=!1,_=null,v=null,y=null,b=null,x=null,S=null,C=null,w=new cu(0,0,0),T=0,E=!1,D=null,O=null,k=null,A=null,j=null,ne.set(0,0,e.canvas.width,e.canvas.height),R.set(0,0,e.canvas.width,e.canvas.height),a.reset(),o.reset(),s.reset()}return{buffers:{color:a,depth:o,stencil:s},enable:B,disable:ie,bindFramebuffer:ae,drawBuffers:oe,useProgram:se,setBlending:ue,setMaterial:de,setFlipSided:fe,setCullFace:pe,setLineWidth:me,setPolygonOffset:he,setScissorTest:ge,activeTexture:V,bindTexture:_e,unbindTexture:ve,compressedTexImage2D:ye,compressedTexImage3D:H,texImage2D:we,texImage3D:Te,pixelStorei:De,getParameter:Ee,updateUBOMapping:Ae,uniformBlockBinding:je,texStorage2D:Se,texStorage3D:Ce,texSubImage2D:be,texSubImage3D:U,compressedTexSubImage2D:W,compressedTexSubImage3D:xe,scissor:Oe,viewport:ke,reset:Me}}function Ag(e,t,n,r,i,a,o){let s=t.has(`WEBGL_multisampled_render_to_texture`)?t.get(`WEBGL_multisampled_render_to_texture`):null,c=typeof navigator>`u`?!1:/OculusBrowser/g.test(navigator.userAgent),l=new Y,u=new WeakMap,d=new Set,f,p=new WeakMap,m=!1;try{m=typeof OffscreenCanvas<`u`&&new OffscreenCanvas(1,1).getContext(`2d`)!==null}catch{}function h(e,t){return m?new OffscreenCanvas(e,t):Bc(`canvas`)}function g(e,t,n){let r=1,i=ye(e);if((i.width>n||i.height>n)&&(r=n/Math.max(i.width,i.height)),r<1){if(typeof HTMLImageElement<`u`&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<`u`&&e instanceof HTMLCanvasElement||typeof ImageBitmap<`u`&&e instanceof ImageBitmap||typeof VideoFrame<`u`&&e instanceof VideoFrame){let n=Math.floor(r*i.width),a=Math.floor(r*i.height);f===void 0&&(f=h(n,a));let o=t?h(n,a):f;return o.width=n,o.height=a,o.getContext(`2d`).drawImage(e,0,0,n,a),q(`WebGLRenderer: Texture has been resized from (`+i.width+`x`+i.height+`) to (`+n+`x`+a+`).`),o}return`data`in e&&q(`WebGLRenderer: Image in DataTexture is too big (`+i.width+`x`+i.height+`).`),e}return e}function _(e){return e.generateMipmaps}function v(t){e.generateMipmap(t)}function y(t){return t.isWebGLCubeRenderTarget?e.TEXTURE_CUBE_MAP:t.isWebGL3DRenderTarget?e.TEXTURE_3D:t.isWebGLArrayRenderTarget||t.isCompressedArrayTexture?e.TEXTURE_2D_ARRAY:e.TEXTURE_2D}function b(n,r,i,a,o,s=!1){if(n!==null){if(e[n]!==void 0)return e[n];q(`WebGLRenderer: Attempt to use non-existing WebGL internal format '`+n+`'`)}let c;a&&(c=t.get(`EXT_texture_norm16`),c||q(`WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension`));let l=r;if(r===e.RED&&(i===e.FLOAT&&(l=e.R32F),i===e.HALF_FLOAT&&(l=e.R16F),i===e.UNSIGNED_BYTE&&(l=e.R8),i===e.UNSIGNED_SHORT&&c&&(l=c.R16_EXT),i===e.SHORT&&c&&(l=c.R16_SNORM_EXT)),r===e.RED_INTEGER&&(i===e.UNSIGNED_BYTE&&(l=e.R8UI),i===e.UNSIGNED_SHORT&&(l=e.R16UI),i===e.UNSIGNED_INT&&(l=e.R32UI),i===e.BYTE&&(l=e.R8I),i===e.SHORT&&(l=e.R16I),i===e.INT&&(l=e.R32I)),r===e.RG&&(i===e.FLOAT&&(l=e.RG32F),i===e.HALF_FLOAT&&(l=e.RG16F),i===e.UNSIGNED_BYTE&&(l=e.RG8),i===e.UNSIGNED_SHORT&&c&&(l=c.RG16_EXT),i===e.SHORT&&c&&(l=c.RG16_SNORM_EXT)),r===e.RG_INTEGER&&(i===e.UNSIGNED_BYTE&&(l=e.RG8UI),i===e.UNSIGNED_SHORT&&(l=e.RG16UI),i===e.UNSIGNED_INT&&(l=e.RG32UI),i===e.BYTE&&(l=e.RG8I),i===e.SHORT&&(l=e.RG16I),i===e.INT&&(l=e.RG32I)),r===e.RGB_INTEGER&&(i===e.UNSIGNED_BYTE&&(l=e.RGB8UI),i===e.UNSIGNED_SHORT&&(l=e.RGB16UI),i===e.UNSIGNED_INT&&(l=e.RGB32UI),i===e.BYTE&&(l=e.RGB8I),i===e.SHORT&&(l=e.RGB16I),i===e.INT&&(l=e.RGB32I)),r===e.RGBA_INTEGER&&(i===e.UNSIGNED_BYTE&&(l=e.RGBA8UI),i===e.UNSIGNED_SHORT&&(l=e.RGBA16UI),i===e.UNSIGNED_INT&&(l=e.RGBA32UI),i===e.BYTE&&(l=e.RGBA8I),i===e.SHORT&&(l=e.RGBA16I),i===e.INT&&(l=e.RGBA32I)),r===e.RGB&&(i===e.UNSIGNED_SHORT&&c&&(l=c.RGB16_EXT),i===e.SHORT&&c&&(l=c.RGB16_SNORM_EXT),i===e.UNSIGNED_INT_5_9_9_9_REV&&(l=e.RGB9_E5),i===e.UNSIGNED_INT_10F_11F_11F_REV&&(l=e.R11F_G11F_B10F)),r===e.RGBA){let t=s?Nc:dl.getTransfer(o);i===e.FLOAT&&(l=e.RGBA32F),i===e.HALF_FLOAT&&(l=e.RGBA16F),i===e.UNSIGNED_BYTE&&(l=t===`srgb`?e.SRGB8_ALPHA8:e.RGBA8),i===e.UNSIGNED_SHORT&&c&&(l=c.RGBA16_EXT),i===e.SHORT&&c&&(l=c.RGBA16_SNORM_EXT),i===e.UNSIGNED_SHORT_4_4_4_4&&(l=e.RGBA4),i===e.UNSIGNED_SHORT_5_5_5_1&&(l=e.RGB5_A1)}return(l===e.R16F||l===e.R32F||l===e.RG16F||l===e.RG32F||l===e.RGBA16F||l===e.RGBA32F)&&t.get(`EXT_color_buffer_float`),l}function x(t,n){let r;return t?n===null||n===1014||n===1020?r=e.DEPTH24_STENCIL8:n===1015?r=e.DEPTH32F_STENCIL8:n===1012&&(r=e.DEPTH24_STENCIL8,q(`DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.`)):n===null||n===1014||n===1020?r=e.DEPTH_COMPONENT24:n===1015?r=e.DEPTH_COMPONENT32F:n===1012&&(r=e.DEPTH_COMPONENT16),r}function S(e,t){return _(e)===!0||e.isFramebufferTexture&&e.minFilter!==1003&&e.minFilter!==1006?Math.log2(Math.max(t.width,t.height))+1:e.mipmaps!==void 0&&e.mipmaps.length>0?e.mipmaps.length:e.isCompressedTexture&&Array.isArray(e.image)?t.mipmaps.length:1}function C(e){let t=e.target;t.removeEventListener(`dispose`,C),T(t),t.isVideoTexture&&u.delete(t),t.isHTMLTexture&&d.delete(t)}function w(e){let t=e.target;t.removeEventListener(`dispose`,w),D(t)}function T(e){let t=r.get(e);if(t.__webglInit===void 0)return;let n=e.source,i=p.get(n);if(i){let r=i[t.__cacheKey];r.usedTimes--,r.usedTimes===0&&E(e),Object.keys(i).length===0&&p.delete(n)}r.remove(e)}function E(t){let n=r.get(t);e.deleteTexture(n.__webglTexture);let i=t.source,a=p.get(i);delete a[n.__cacheKey],o.memory.textures--}function D(t){let n=r.get(t);if(t.depthTexture&&(t.depthTexture.dispose(),r.remove(t.depthTexture)),t.isWebGLCubeRenderTarget)for(let t=0;t<6;t++){if(Array.isArray(n.__webglFramebuffer[t]))for(let r=0;r<n.__webglFramebuffer[t].length;r++)e.deleteFramebuffer(n.__webglFramebuffer[t][r]);else e.deleteFramebuffer(n.__webglFramebuffer[t]);n.__webglDepthbuffer&&e.deleteRenderbuffer(n.__webglDepthbuffer[t])}else{if(Array.isArray(n.__webglFramebuffer))for(let t=0;t<n.__webglFramebuffer.length;t++)e.deleteFramebuffer(n.__webglFramebuffer[t]);else e.deleteFramebuffer(n.__webglFramebuffer);if(n.__webglDepthbuffer&&e.deleteRenderbuffer(n.__webglDepthbuffer),n.__webglMultisampledFramebuffer&&e.deleteFramebuffer(n.__webglMultisampledFramebuffer),n.__webglColorRenderbuffer)for(let t=0;t<n.__webglColorRenderbuffer.length;t++)n.__webglColorRenderbuffer[t]&&e.deleteRenderbuffer(n.__webglColorRenderbuffer[t]);n.__webglDepthRenderbuffer&&e.deleteRenderbuffer(n.__webglDepthRenderbuffer)}let i=t.textures;for(let t=0,n=i.length;t<n;t++){let n=r.get(i[t]);n.__webglTexture&&(e.deleteTexture(n.__webglTexture),o.memory.textures--),r.remove(i[t])}r.remove(t)}let O=0;function k(){O=0}function A(){return O}function j(e){O=e}function M(){let e=O;return e>=i.maxTextures&&q(`WebGLTextures: Trying to use `+(e+1)+` texture units while this GPU supports only `+i.maxTextures),O+=1,e}function N(e){let t=[];return t.push(e.wrapS),t.push(e.wrapT),t.push(e.wrapR||0),t.push(e.magFilter),t.push(e.minFilter),t.push(e.anisotropy),t.push(e.internalFormat),t.push(e.format),t.push(e.type),t.push(e.generateMipmaps),t.push(e.premultiplyAlpha),t.push(e.flipY),t.push(e.unpackAlignment),t.push(e.colorSpace),t.join()}function P(t,i){let a=r.get(t);if(t.isVideoTexture&&_e(t),t.isRenderTargetTexture===!1&&t.isExternalTexture!==!0&&t.version>0&&a.__version!==t.version){let e=t.image;if(e===null)q(`WebGLRenderer: Texture marked for update but no image data found.`);else if(e.complete===!1)q(`WebGLRenderer: Texture marked for update but image is incomplete`);else{ie(a,t,i);return}}else t.isExternalTexture&&(a.__webglTexture=t.sourceTexture?t.sourceTexture:null);n.bindTexture(e.TEXTURE_2D,a.__webglTexture,e.TEXTURE0+i)}function F(t,i){let a=r.get(t);if(t.isRenderTargetTexture===!1&&t.version>0&&a.__version!==t.version){ie(a,t,i);return}t.isExternalTexture&&(a.__webglTexture=t.sourceTexture?t.sourceTexture:null),n.bindTexture(e.TEXTURE_2D_ARRAY,a.__webglTexture,e.TEXTURE0+i)}function I(t,i){let a=r.get(t);if(t.isRenderTargetTexture===!1&&t.version>0&&a.__version!==t.version){ie(a,t,i);return}n.bindTexture(e.TEXTURE_3D,a.__webglTexture,e.TEXTURE0+i)}function L(t,i){let a=r.get(t);if(t.isCubeDepthTexture!==!0&&t.version>0&&a.__version!==t.version){ae(a,t,i);return}n.bindTexture(e.TEXTURE_CUBE_MAP,a.__webglTexture,e.TEXTURE0+i)}let ee={[ls]:e.REPEAT,[us]:e.CLAMP_TO_EDGE,[ds]:e.MIRRORED_REPEAT},te={[fs]:e.NEAREST,[ps]:e.NEAREST_MIPMAP_NEAREST,[ms]:e.NEAREST_MIPMAP_LINEAR,[hs]:e.LINEAR,[gs]:e.LINEAR_MIPMAP_NEAREST,[_s]:e.LINEAR_MIPMAP_LINEAR},ne={512:e.NEVER,519:e.ALWAYS,513:e.LESS,515:e.LEQUAL,514:e.EQUAL,518:e.GEQUAL,516:e.GREATER,517:e.NOTEQUAL};function R(n,a){if(a.type===1015&&t.has(`OES_texture_float_linear`)===!1&&(a.magFilter===1006||a.magFilter===1007||a.magFilter===1005||a.magFilter===1008||a.minFilter===1006||a.minFilter===1007||a.minFilter===1005||a.minFilter===1008)&&q(`WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device.`),e.texParameteri(n,e.TEXTURE_WRAP_S,ee[a.wrapS]),e.texParameteri(n,e.TEXTURE_WRAP_T,ee[a.wrapT]),(n===e.TEXTURE_3D||n===e.TEXTURE_2D_ARRAY)&&e.texParameteri(n,e.TEXTURE_WRAP_R,ee[a.wrapR]),e.texParameteri(n,e.TEXTURE_MAG_FILTER,te[a.magFilter]),e.texParameteri(n,e.TEXTURE_MIN_FILTER,te[a.minFilter]),a.compareFunction&&(e.texParameteri(n,e.TEXTURE_COMPARE_MODE,e.COMPARE_REF_TO_TEXTURE),e.texParameteri(n,e.TEXTURE_COMPARE_FUNC,ne[a.compareFunction])),t.has(`EXT_texture_filter_anisotropic`)===!0){if(a.magFilter===1003||a.minFilter!==1005&&a.minFilter!==1008||a.type===1015&&t.has(`OES_texture_float_linear`)===!1)return;if(a.anisotropy>1||r.get(a).__currentAnisotropy){let o=t.get(`EXT_texture_filter_anisotropic`);e.texParameterf(n,o.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(a.anisotropy,i.getMaxAnisotropy())),r.get(a).__currentAnisotropy=a.anisotropy}}}function re(t,n){let r=!1;t.__webglInit===void 0&&(t.__webglInit=!0,n.addEventListener(`dispose`,C));let i=n.source,a=p.get(i);a===void 0&&(a={},p.set(i,a));let s=N(n);if(s!==t.__cacheKey){a[s]===void 0&&(a[s]={texture:e.createTexture(),usedTimes:0},o.memory.textures++,r=!0),a[s].usedTimes++;let i=a[t.__cacheKey];i!==void 0&&(a[t.__cacheKey].usedTimes--,i.usedTimes===0&&E(n)),t.__cacheKey=s,t.__webglTexture=a[s].texture}return r}function z(e,t,n){return Math.floor(Math.floor(e/n)/t)}function B(t,r,i,a){let o=t.updateRanges;if(o.length===0)n.texSubImage2D(e.TEXTURE_2D,0,0,0,r.width,r.height,i,a,r.data);else{o.sort((e,t)=>e.start-t.start);let s=0;for(let e=1;e<o.length;e++){let t=o[s],n=o[e],i=t.start+t.count,a=z(n.start,r.width,4),c=z(t.start,r.width,4);n.start<=i+1&&a===c&&z(n.start+n.count-1,r.width,4)===a?t.count=Math.max(t.count,n.start+n.count-t.start):(++s,o[s]=n)}o.length=s+1;let c=n.getParameter(e.UNPACK_ROW_LENGTH),l=n.getParameter(e.UNPACK_SKIP_PIXELS),u=n.getParameter(e.UNPACK_SKIP_ROWS);n.pixelStorei(e.UNPACK_ROW_LENGTH,r.width);for(let t=0,s=o.length;t<s;t++){let s=o[t],c=Math.floor(s.start/4),l=Math.ceil(s.count/4),u=c%r.width,d=Math.floor(c/r.width),f=l;n.pixelStorei(e.UNPACK_SKIP_PIXELS,u),n.pixelStorei(e.UNPACK_SKIP_ROWS,d),n.texSubImage2D(e.TEXTURE_2D,0,u,d,f,1,i,a,r.data)}t.clearUpdateRanges(),n.pixelStorei(e.UNPACK_ROW_LENGTH,c),n.pixelStorei(e.UNPACK_SKIP_PIXELS,l),n.pixelStorei(e.UNPACK_SKIP_ROWS,u)}}function ie(t,o,s){let c=e.TEXTURE_2D;(o.isDataArrayTexture||o.isCompressedArrayTexture)&&(c=e.TEXTURE_2D_ARRAY),o.isData3DTexture&&(c=e.TEXTURE_3D);let l=re(t,o),u=o.source;n.bindTexture(c,t.__webglTexture,e.TEXTURE0+s);let f=r.get(u);if(u.version!==f.__version||l===!0){if(n.activeTexture(e.TEXTURE0+s),!(typeof ImageBitmap<`u`&&o.image instanceof ImageBitmap)){let t=dl.getPrimaries(dl.workingColorSpace),r=o.colorSpace===``?null:dl.getPrimaries(o.colorSpace),i=o.colorSpace===``||t===r?e.NONE:e.BROWSER_DEFAULT_WEBGL;n.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,o.flipY),n.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,o.premultiplyAlpha),n.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,i)}n.pixelStorei(e.UNPACK_ALIGNMENT,o.unpackAlignment);let t=g(o.image,!1,i.maxTextureSize);t=ve(o,t);let r=a.convert(o.format,o.colorSpace),p=a.convert(o.type),m=b(o.internalFormat,r,p,o.normalized,o.colorSpace,o.isVideoTexture);R(c,o);let h,y=o.mipmaps,C=o.isVideoTexture!==!0,w=f.__version===void 0||l===!0,T=u.dataReady,E=S(o,t);if(o.isDepthTexture)m=x(o.format===Fs,o.type),w&&(C?n.texStorage2D(e.TEXTURE_2D,1,m,t.width,t.height):n.texImage2D(e.TEXTURE_2D,0,m,t.width,t.height,0,r,p,null));else if(o.isDataTexture){if(y.length>0){C&&w&&n.texStorage2D(e.TEXTURE_2D,E,m,y[0].width,y[0].height);for(let t=0,i=y.length;t<i;t++)h=y[t],C?T&&n.texSubImage2D(e.TEXTURE_2D,t,0,0,h.width,h.height,r,p,h.data):n.texImage2D(e.TEXTURE_2D,t,m,h.width,h.height,0,r,p,h.data);o.generateMipmaps=!1}else C?(w&&n.texStorage2D(e.TEXTURE_2D,E,m,t.width,t.height),T&&B(o,t,r,p)):n.texImage2D(e.TEXTURE_2D,0,m,t.width,t.height,0,r,p,t.data)}else if(o.isCompressedTexture){if(o.isCompressedArrayTexture){C&&w&&n.texStorage3D(e.TEXTURE_2D_ARRAY,E,m,y[0].width,y[0].height,t.depth);for(let i=0,a=y.length;i<a;i++)if(h=y[i],o.format!==1023){if(r!==null){if(C){if(T){if(o.layerUpdates.size>0){let t=Tp(h.width,h.height,o.format,o.type);for(let a of o.layerUpdates){let o=h.data.subarray(a*t/h.data.BYTES_PER_ELEMENT,(a+1)*t/h.data.BYTES_PER_ELEMENT);n.compressedTexSubImage3D(e.TEXTURE_2D_ARRAY,i,0,0,a,h.width,h.height,1,r,o)}}else n.compressedTexSubImage3D(e.TEXTURE_2D_ARRAY,i,0,0,0,h.width,h.height,t.depth,r,h.data)}}else n.compressedTexImage3D(e.TEXTURE_2D_ARRAY,i,m,h.width,h.height,t.depth,0,h.data,0,0)}else q(`WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()`)}else C?T&&n.texSubImage3D(e.TEXTURE_2D_ARRAY,i,0,0,0,h.width,h.height,t.depth,r,p,h.data):n.texImage3D(e.TEXTURE_2D_ARRAY,i,m,h.width,h.height,t.depth,0,r,p,h.data);o.layerUpdates.size>0&&o.clearLayerUpdates()}else{C&&w&&n.texStorage2D(e.TEXTURE_2D,E,m,y[0].width,y[0].height);for(let t=0,i=y.length;t<i;t++)h=y[t],o.format===1023?C?T&&n.texSubImage2D(e.TEXTURE_2D,t,0,0,h.width,h.height,r,p,h.data):n.texImage2D(e.TEXTURE_2D,t,m,h.width,h.height,0,r,p,h.data):r===null?q(`WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()`):C?T&&n.compressedTexSubImage2D(e.TEXTURE_2D,t,0,0,h.width,h.height,r,h.data):n.compressedTexImage2D(e.TEXTURE_2D,t,m,h.width,h.height,0,h.data)}}else if(o.isDataArrayTexture){if(C){if(w&&n.texStorage3D(e.TEXTURE_2D_ARRAY,E,m,t.width,t.height,t.depth),T){if(o.layerUpdates.size>0){let i=Tp(t.width,t.height,o.format,o.type);for(let a of o.layerUpdates){let o=t.data.subarray(a*i/t.data.BYTES_PER_ELEMENT,(a+1)*i/t.data.BYTES_PER_ELEMENT);n.texSubImage3D(e.TEXTURE_2D_ARRAY,0,0,0,a,t.width,t.height,1,r,p,o)}o.clearLayerUpdates()}else n.texSubImage3D(e.TEXTURE_2D_ARRAY,0,0,0,0,t.width,t.height,t.depth,r,p,t.data)}}else n.texImage3D(e.TEXTURE_2D_ARRAY,0,m,t.width,t.height,t.depth,0,r,p,t.data)}else if(o.isData3DTexture)C?(w&&n.texStorage3D(e.TEXTURE_3D,E,m,t.width,t.height,t.depth),T&&n.texSubImage3D(e.TEXTURE_3D,0,0,0,0,t.width,t.height,t.depth,r,p,t.data)):n.texImage3D(e.TEXTURE_3D,0,m,t.width,t.height,t.depth,0,r,p,t.data);else if(o.isFramebufferTexture){if(w){if(C)n.texStorage2D(e.TEXTURE_2D,E,m,t.width,t.height);else{let i=t.width,a=t.height;for(let t=0;t<E;t++)n.texImage2D(e.TEXTURE_2D,t,m,i,a,0,r,p,null),i>>=1,a>>=1}}}else if(o.isHTMLTexture){if(`texElementImage2D`in e){let n=e.canvas;if(n.hasAttribute(`layoutsubtree`)||n.setAttribute(`layoutsubtree`,`true`),t.parentNode!==n){n.appendChild(t),d.add(o),n.onpaint=e=>{let t=e.changedElements;for(let e of d)t.includes(e.image)&&(e.needsUpdate=!0)},n.requestPaint();return}if(e.texElementImage2D.length===3)e.texElementImage2D(e.TEXTURE_2D,e.RGBA8,t);else{let n=e.RGBA,r=e.RGBA,i=e.UNSIGNED_BYTE;e.texElementImage2D(e.TEXTURE_2D,0,n,r,i,t)}e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MIN_FILTER,e.LINEAR),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_S,e.CLAMP_TO_EDGE),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_T,e.CLAMP_TO_EDGE)}}else if(y.length>0){if(C&&w){let t=ye(y[0]);n.texStorage2D(e.TEXTURE_2D,E,m,t.width,t.height)}for(let t=0,i=y.length;t<i;t++)h=y[t],C?T&&n.texSubImage2D(e.TEXTURE_2D,t,0,0,r,p,h):n.texImage2D(e.TEXTURE_2D,t,m,r,p,h);o.generateMipmaps=!1}else if(C){if(w){let r=ye(t);n.texStorage2D(e.TEXTURE_2D,E,m,r.width,r.height)}T&&n.texSubImage2D(e.TEXTURE_2D,0,0,0,r,p,t)}else n.texImage2D(e.TEXTURE_2D,0,m,r,p,t);_(o)&&v(c),f.__version=u.version,o.onUpdate&&o.onUpdate(o)}t.__version=o.version}function ae(t,o,s){if(o.image.length!==6)return;let c=re(t,o),l=o.source;n.bindTexture(e.TEXTURE_CUBE_MAP,t.__webglTexture,e.TEXTURE0+s);let u=r.get(l);if(l.version!==u.__version||c===!0){n.activeTexture(e.TEXTURE0+s);let t=dl.getPrimaries(dl.workingColorSpace),r=o.colorSpace===``?null:dl.getPrimaries(o.colorSpace),d=o.colorSpace===``||t===r?e.NONE:e.BROWSER_DEFAULT_WEBGL;n.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,o.flipY),n.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,o.premultiplyAlpha),n.pixelStorei(e.UNPACK_ALIGNMENT,o.unpackAlignment),n.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,d);let f=o.isCompressedTexture||o.image[0].isCompressedTexture,p=o.image[0]&&o.image[0].isDataTexture,m=[];for(let e=0;e<6;e++)!f&&!p?m[e]=g(o.image[e],!0,i.maxCubemapSize):m[e]=p?o.image[e].image:o.image[e],m[e]=ve(o,m[e]);let h=m[0],y=a.convert(o.format,o.colorSpace),x=a.convert(o.type),C=b(o.internalFormat,y,x,o.normalized,o.colorSpace),w=o.isVideoTexture!==!0,T=u.__version===void 0||c===!0,E=l.dataReady,D=S(o,h);R(e.TEXTURE_CUBE_MAP,o);let O;if(f){w&&T&&n.texStorage2D(e.TEXTURE_CUBE_MAP,D,C,h.width,h.height);for(let t=0;t<6;t++){O=m[t].mipmaps;for(let r=0;r<O.length;r++){let i=O[r];o.format===1023?w?E&&n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r,0,0,i.width,i.height,y,x,i.data):n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r,C,i.width,i.height,0,y,x,i.data):y===null?q(`WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()`):w?E&&n.compressedTexSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r,0,0,i.width,i.height,y,i.data):n.compressedTexImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r,C,i.width,i.height,0,i.data)}}}else{if(O=o.mipmaps,w&&T){O.length>0&&D++;let t=ye(m[0]);n.texStorage2D(e.TEXTURE_CUBE_MAP,D,C,t.width,t.height)}for(let t=0;t<6;t++)if(p){w?E&&n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,0,0,0,m[t].width,m[t].height,y,x,m[t].data):n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,0,C,m[t].width,m[t].height,0,y,x,m[t].data);for(let r=0;r<O.length;r++){let i=O[r].image[t].image;w?E&&n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r+1,0,0,i.width,i.height,y,x,i.data):n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r+1,C,i.width,i.height,0,y,x,i.data)}}else{w?E&&n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,0,0,0,y,x,m[t]):n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,0,C,y,x,m[t]);for(let r=0;r<O.length;r++){let i=O[r];w?E&&n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r+1,0,0,y,x,i.image[t]):n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r+1,C,y,x,i.image[t])}}}_(o)&&v(e.TEXTURE_CUBE_MAP),u.__version=l.version,o.onUpdate&&o.onUpdate(o)}t.__version=o.version}function oe(t,i,o,c,l,u){let d=a.convert(o.format,o.colorSpace),f=a.convert(o.type),p=b(o.internalFormat,d,f,o.normalized,o.colorSpace),m=r.get(i),h=r.get(o);if(h.__renderTarget=i,!m.__hasExternalTextures){let t=Math.max(1,i.width>>u),r=Math.max(1,i.height>>u);l===e.TEXTURE_3D||l===e.TEXTURE_2D_ARRAY?n.texImage3D(l,u,p,t,r,i.depth,0,d,f,null):n.texImage2D(l,u,p,t,r,0,d,f,null)}n.bindFramebuffer(e.FRAMEBUFFER,t),V(i)?s.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,c,l,h.__webglTexture,0,ge(i)):(l===e.TEXTURE_2D||l>=e.TEXTURE_CUBE_MAP_POSITIVE_X&&l<=e.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&e.framebufferTexture2D(e.FRAMEBUFFER,c,l,h.__webglTexture,u),n.bindFramebuffer(e.FRAMEBUFFER,null)}function se(t,n,r){if(e.bindRenderbuffer(e.RENDERBUFFER,t),n.depthBuffer){let i=n.depthTexture,a=i&&i.isDepthTexture?i.type:null,o=x(n.stencilBuffer,a),c=n.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT;V(n)?s.renderbufferStorageMultisampleEXT(e.RENDERBUFFER,ge(n),o,n.width,n.height):r?e.renderbufferStorageMultisample(e.RENDERBUFFER,ge(n),o,n.width,n.height):e.renderbufferStorage(e.RENDERBUFFER,o,n.width,n.height),e.framebufferRenderbuffer(e.FRAMEBUFFER,c,e.RENDERBUFFER,t)}else{let t=n.textures;for(let i=0;i<t.length;i++){let o=t[i],c=a.convert(o.format,o.colorSpace),l=a.convert(o.type),u=b(o.internalFormat,c,l,o.normalized,o.colorSpace);V(n)?s.renderbufferStorageMultisampleEXT(e.RENDERBUFFER,ge(n),u,n.width,n.height):r?e.renderbufferStorageMultisample(e.RENDERBUFFER,ge(n),u,n.width,n.height):e.renderbufferStorage(e.RENDERBUFFER,u,n.width,n.height)}}e.bindRenderbuffer(e.RENDERBUFFER,null)}function ce(t,i,o){let c=i.isWebGLCubeRenderTarget===!0;if(n.bindFramebuffer(e.FRAMEBUFFER,t),!(i.depthTexture&&i.depthTexture.isDepthTexture))throw Error(`THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.`);let l=r.get(i.depthTexture);if(l.__renderTarget=i,(!l.__webglTexture||i.depthTexture.image.width!==i.width||i.depthTexture.image.height!==i.height)&&(i.depthTexture.image.width=i.width,i.depthTexture.image.height=i.height,i.depthTexture.needsUpdate=!0),c){if(l.__webglInit===void 0&&(l.__webglInit=!0,i.depthTexture.addEventListener(`dispose`,C)),l.__webglTexture===void 0){l.__webglTexture=e.createTexture(),n.bindTexture(e.TEXTURE_CUBE_MAP,l.__webglTexture),R(e.TEXTURE_CUBE_MAP,i.depthTexture);let t=a.convert(i.depthTexture.format),r=a.convert(i.depthTexture.type),o;i.depthTexture.format===1026?o=e.DEPTH_COMPONENT24:i.depthTexture.format===1027&&(o=e.DEPTH24_STENCIL8);for(let n=0;n<6;n++)e.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+n,0,o,i.width,i.height,0,t,r,null)}}else P(i.depthTexture,0);let u=l.__webglTexture,d=ge(i),f=c?e.TEXTURE_CUBE_MAP_POSITIVE_X+o:e.TEXTURE_2D,p=i.depthTexture.format===1027?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT;if(i.depthTexture.format===1026)V(i)?s.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,p,f,u,0,d):e.framebufferTexture2D(e.FRAMEBUFFER,p,f,u,0);else if(i.depthTexture.format===1027)V(i)?s.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,p,f,u,0,d):e.framebufferTexture2D(e.FRAMEBUFFER,p,f,u,0);else throw Error(`THREE.WebGLTextures: Unknown depthTexture format.`)}function le(t){let i=r.get(t),a=t.isWebGLCubeRenderTarget===!0;if(i.__boundDepthTexture!==t.depthTexture){let e=t.depthTexture;if(i.__depthDisposeCallback&&i.__depthDisposeCallback(),e){let t=()=>{delete i.__boundDepthTexture,delete i.__depthDisposeCallback,e.removeEventListener(`dispose`,t)};e.addEventListener(`dispose`,t),i.__depthDisposeCallback=t}i.__boundDepthTexture=e}if(t.depthTexture&&!i.__autoAllocateDepthBuffer){if(a)for(let e=0;e<6;e++)ce(i.__webglFramebuffer[e],t,e);else{let e=t.texture.mipmaps;e&&e.length>0?ce(i.__webglFramebuffer[0],t,0):ce(i.__webglFramebuffer,t,0)}}else if(a){i.__webglDepthbuffer=[];for(let r=0;r<6;r++)if(n.bindFramebuffer(e.FRAMEBUFFER,i.__webglFramebuffer[r]),i.__webglDepthbuffer[r]===void 0)i.__webglDepthbuffer[r]=e.createRenderbuffer(),se(i.__webglDepthbuffer[r],t,!1);else{let n=t.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,a=i.__webglDepthbuffer[r];e.bindRenderbuffer(e.RENDERBUFFER,a),e.framebufferRenderbuffer(e.FRAMEBUFFER,n,e.RENDERBUFFER,a)}}else{let r=t.texture.mipmaps;if(r&&r.length>0?n.bindFramebuffer(e.FRAMEBUFFER,i.__webglFramebuffer[0]):n.bindFramebuffer(e.FRAMEBUFFER,i.__webglFramebuffer),i.__webglDepthbuffer===void 0)i.__webglDepthbuffer=e.createRenderbuffer(),se(i.__webglDepthbuffer,t,!1);else{let n=t.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,r=i.__webglDepthbuffer;e.bindRenderbuffer(e.RENDERBUFFER,r),e.framebufferRenderbuffer(e.FRAMEBUFFER,n,e.RENDERBUFFER,r)}}n.bindFramebuffer(e.FRAMEBUFFER,null)}function ue(t,n,i){let a=r.get(t);n!==void 0&&oe(a.__webglFramebuffer,t,t.texture,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,0),i!==void 0&&le(t)}function de(t){let i=t.texture,s=r.get(t),c=r.get(i);t.addEventListener(`dispose`,w);let l=t.textures,u=t.isWebGLCubeRenderTarget===!0,d=l.length>1;if(d||(c.__webglTexture===void 0&&(c.__webglTexture=e.createTexture()),c.__version=i.version,o.memory.textures++),u){s.__webglFramebuffer=[];for(let t=0;t<6;t++)if(i.mipmaps&&i.mipmaps.length>0){s.__webglFramebuffer[t]=[];for(let n=0;n<i.mipmaps.length;n++)s.__webglFramebuffer[t][n]=e.createFramebuffer()}else s.__webglFramebuffer[t]=e.createFramebuffer()}else{if(i.mipmaps&&i.mipmaps.length>0){s.__webglFramebuffer=[];for(let t=0;t<i.mipmaps.length;t++)s.__webglFramebuffer[t]=e.createFramebuffer()}else s.__webglFramebuffer=e.createFramebuffer();if(d)for(let t=0,n=l.length;t<n;t++){let n=r.get(l[t]);n.__webglTexture===void 0&&(n.__webglTexture=e.createTexture(),o.memory.textures++)}if(t.samples>0&&V(t)===!1){s.__webglMultisampledFramebuffer=e.createFramebuffer(),s.__webglColorRenderbuffer=[],n.bindFramebuffer(e.FRAMEBUFFER,s.__webglMultisampledFramebuffer);for(let n=0;n<l.length;n++){let r=l[n];s.__webglColorRenderbuffer[n]=e.createRenderbuffer(),e.bindRenderbuffer(e.RENDERBUFFER,s.__webglColorRenderbuffer[n]);let i=a.convert(r.format,r.colorSpace),o=a.convert(r.type),c=b(r.internalFormat,i,o,r.normalized,r.colorSpace,t.isXRRenderTarget===!0),u=ge(t);e.renderbufferStorageMultisample(e.RENDERBUFFER,u,c,t.width,t.height),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+n,e.RENDERBUFFER,s.__webglColorRenderbuffer[n])}e.bindRenderbuffer(e.RENDERBUFFER,null),t.depthBuffer&&(s.__webglDepthRenderbuffer=e.createRenderbuffer(),se(s.__webglDepthRenderbuffer,t,!0)),n.bindFramebuffer(e.FRAMEBUFFER,null)}}if(u){n.bindTexture(e.TEXTURE_CUBE_MAP,c.__webglTexture),R(e.TEXTURE_CUBE_MAP,i);for(let n=0;n<6;n++)if(i.mipmaps&&i.mipmaps.length>0)for(let r=0;r<i.mipmaps.length;r++)oe(s.__webglFramebuffer[n][r],t,i,e.COLOR_ATTACHMENT0,e.TEXTURE_CUBE_MAP_POSITIVE_X+n,r);else oe(s.__webglFramebuffer[n],t,i,e.COLOR_ATTACHMENT0,e.TEXTURE_CUBE_MAP_POSITIVE_X+n,0);_(i)&&v(e.TEXTURE_CUBE_MAP),n.unbindTexture()}else if(d){for(let i=0,a=l.length;i<a;i++){let a=l[i],o=r.get(a),c=e.TEXTURE_2D;(t.isWebGL3DRenderTarget||t.isWebGLArrayRenderTarget)&&(c=t.isWebGL3DRenderTarget?e.TEXTURE_3D:e.TEXTURE_2D_ARRAY),n.bindTexture(c,o.__webglTexture),R(c,a),oe(s.__webglFramebuffer,t,a,e.COLOR_ATTACHMENT0+i,c,0),_(a)&&v(c)}n.unbindTexture()}else{let r=e.TEXTURE_2D;if((t.isWebGL3DRenderTarget||t.isWebGLArrayRenderTarget)&&(r=t.isWebGL3DRenderTarget?e.TEXTURE_3D:e.TEXTURE_2D_ARRAY),n.bindTexture(r,c.__webglTexture),R(r,i),i.mipmaps&&i.mipmaps.length>0)for(let n=0;n<i.mipmaps.length;n++)oe(s.__webglFramebuffer[n],t,i,e.COLOR_ATTACHMENT0,r,n);else oe(s.__webglFramebuffer,t,i,e.COLOR_ATTACHMENT0,r,0);_(i)&&v(r),n.unbindTexture()}t.depthBuffer&&le(t)}function fe(e){let t=e.textures;for(let i=0,a=t.length;i<a;i++){let a=t[i];if(_(a)){let t=y(e),i=r.get(a).__webglTexture;n.bindTexture(t,i),v(t),n.unbindTexture()}}}let pe=[],me=[];function he(t){if(t.samples>0){if(V(t)===!1){let i=t.textures,a=t.width,o=t.height,s=e.COLOR_BUFFER_BIT,l=t.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,u=r.get(t),d=i.length>1;if(d)for(let t=0;t<i.length;t++)n.bindFramebuffer(e.FRAMEBUFFER,u.__webglMultisampledFramebuffer),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+t,e.RENDERBUFFER,null),n.bindFramebuffer(e.FRAMEBUFFER,u.__webglFramebuffer),e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0+t,e.TEXTURE_2D,null,0);n.bindFramebuffer(e.READ_FRAMEBUFFER,u.__webglMultisampledFramebuffer);let f=t.texture.mipmaps;f&&f.length>0?n.bindFramebuffer(e.DRAW_FRAMEBUFFER,u.__webglFramebuffer[0]):n.bindFramebuffer(e.DRAW_FRAMEBUFFER,u.__webglFramebuffer);for(let n=0;n<i.length;n++){if(t.resolveDepthBuffer&&(t.depthBuffer&&(s|=e.DEPTH_BUFFER_BIT),t.stencilBuffer&&t.resolveStencilBuffer&&(s|=e.STENCIL_BUFFER_BIT)),d){e.framebufferRenderbuffer(e.READ_FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.RENDERBUFFER,u.__webglColorRenderbuffer[n]);let t=r.get(i[n]).__webglTexture;e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,t,0)}e.blitFramebuffer(0,0,a,o,0,0,a,o,s,e.NEAREST),c===!0&&(pe.length=0,me.length=0,pe.push(e.COLOR_ATTACHMENT0+n),t.depthBuffer&&t.storeMultisampledDepthBuffer===!1&&(pe.push(l),me.push(l),e.invalidateFramebuffer(e.DRAW_FRAMEBUFFER,me)),e.invalidateFramebuffer(e.READ_FRAMEBUFFER,pe))}if(n.bindFramebuffer(e.READ_FRAMEBUFFER,null),n.bindFramebuffer(e.DRAW_FRAMEBUFFER,null),d)for(let t=0;t<i.length;t++){n.bindFramebuffer(e.FRAMEBUFFER,u.__webglMultisampledFramebuffer),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+t,e.RENDERBUFFER,u.__webglColorRenderbuffer[t]);let a=r.get(i[t]).__webglTexture;n.bindFramebuffer(e.FRAMEBUFFER,u.__webglFramebuffer),e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0+t,e.TEXTURE_2D,a,0)}n.bindFramebuffer(e.DRAW_FRAMEBUFFER,u.__webglMultisampledFramebuffer)}else if(t.depthBuffer&&t.storeMultisampledDepthBuffer===!1&&c){let n=t.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT;e.invalidateFramebuffer(e.DRAW_FRAMEBUFFER,[n])}}}function ge(e){return Math.min(i.maxSamples,e.samples)}function V(e){let n=r.get(e);return e.samples>0&&t.has(`WEBGL_multisampled_render_to_texture`)===!0&&n.__useRenderToTexture!==!1}function _e(e){let t=o.render.frame;u.get(e)!==t&&(u.set(e,t),e.update())}function ve(e,t){let n=e.colorSpace,r=e.format,i=e.type;return e.isCompressedTexture===!0||e.isVideoTexture===!0||n!==`srgb-linear`&&n!==``&&(dl.getTransfer(n)===`srgb`?(r!==1023||i!==1009)&&q(`WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType.`):J(`WebGLTextures: Unsupported texture color space:`,n)),t}function ye(e){return typeof HTMLImageElement<`u`&&e instanceof HTMLImageElement?(l.width=e.naturalWidth||e.width,l.height=e.naturalHeight||e.height):typeof VideoFrame<`u`&&e instanceof VideoFrame?(l.width=e.displayWidth,l.height=e.displayHeight):(l.width=e.width,l.height=e.height),l}this.allocateTextureUnit=M,this.resetTextureUnits=k,this.getTextureUnits=A,this.setTextureUnits=j,this.setTexture2D=P,this.setTexture2DArray=F,this.setTexture3D=I,this.setTextureCube=L,this.rebindTextures=ue,this.setupRenderTarget=de,this.updateRenderTargetMipmap=fe,this.updateMultisampleRenderTarget=he,this.setupDepthRenderbuffer=le,this.setupFrameBufferTexture=oe,this.useMultisampledRTT=V,this.isReversedDepthBuffer=function(){return n.buffers.depth.getReversed()}}function jg(e,t){function n(n,r=``){let i,a=dl.getTransfer(r);if(n===1009)return e.UNSIGNED_BYTE;if(n===1017)return e.UNSIGNED_SHORT_4_4_4_4;if(n===1018)return e.UNSIGNED_SHORT_5_5_5_1;if(n===35902)return e.UNSIGNED_INT_5_9_9_9_REV;if(n===35899)return e.UNSIGNED_INT_10F_11F_11F_REV;if(n===1010)return e.BYTE;if(n===1011)return e.SHORT;if(n===1012)return e.UNSIGNED_SHORT;if(n===1013)return e.INT;if(n===1014)return e.UNSIGNED_INT;if(n===1015)return e.FLOAT;if(n===1016)return e.HALF_FLOAT;if(n===1021)return e.ALPHA;if(n===1022)return e.RGB;if(n===1023)return e.RGBA;if(n===1026)return e.DEPTH_COMPONENT;if(n===1027)return e.DEPTH_STENCIL;if(n===1028)return e.RED;if(n===1029)return e.RED_INTEGER;if(n===1030)return e.RG;if(n===1031)return e.RG_INTEGER;if(n===1033)return e.RGBA_INTEGER;if(n===33776||n===33777||n===33778||n===33779){if(a===`srgb`){if(i=t.get(`WEBGL_compressed_texture_s3tc_srgb`),i!==null){if(n===33776)return i.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===33777)return i.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===33778)return i.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===33779)return i.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null}else if(i=t.get(`WEBGL_compressed_texture_s3tc`),i!==null){if(n===33776)return i.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===33777)return i.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===33778)return i.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===33779)return i.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null}if(n===35840||n===35841||n===35842||n===35843){if(i=t.get(`WEBGL_compressed_texture_pvrtc`),i!==null){if(n===35840)return i.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===35841)return i.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===35842)return i.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===35843)return i.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null}if(n===36196||n===37492||n===37496||n===37488||n===37489||n===37490||n===37491){if(i=t.get(`WEBGL_compressed_texture_etc`),i!==null){if(n===36196||n===37492)return a===`srgb`?i.COMPRESSED_SRGB8_ETC2:i.COMPRESSED_RGB8_ETC2;if(n===37496)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:i.COMPRESSED_RGBA8_ETC2_EAC;if(n===37488)return i.COMPRESSED_R11_EAC;if(n===37489)return i.COMPRESSED_SIGNED_R11_EAC;if(n===37490)return i.COMPRESSED_RG11_EAC;if(n===37491)return i.COMPRESSED_SIGNED_RG11_EAC}else return null}if(n===37808||n===37809||n===37810||n===37811||n===37812||n===37813||n===37814||n===37815||n===37816||n===37817||n===37818||n===37819||n===37820||n===37821){if(i=t.get(`WEBGL_compressed_texture_astc`),i!==null){if(n===37808)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:i.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===37809)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:i.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===37810)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:i.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===37811)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:i.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===37812)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:i.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===37813)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:i.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===37814)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:i.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===37815)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:i.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===37816)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:i.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===37817)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:i.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===37818)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:i.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===37819)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:i.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===37820)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:i.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===37821)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:i.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null}if(n===36492||n===36494||n===36495){if(i=t.get(`EXT_texture_compression_bptc`),i!==null){if(n===36492)return a===`srgb`?i.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:i.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===36494)return i.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===36495)return i.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null}if(n===36283||n===36284||n===36285||n===36286){if(i=t.get(`EXT_texture_compression_rgtc`),i!==null){if(n===36283)return i.COMPRESSED_RED_RGTC1_EXT;if(n===36284)return i.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===36285)return i.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===36286)return i.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null}return n===1020?e.UNSIGNED_INT_24_8:e[n]===void 0?null:e[n]}return{convert:n}}var Mg=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,Ng=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`,Pg=class{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t){if(this.texture===null){let n=new yf(e.texture);(e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=n}}getMesh(e){if(this.texture!==null&&this.mesh===null){let t=e.cameras[0].viewport,n=new jf({vertexShader:Mg,fragmentShader:Ng,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new qd(new xf(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}},Fg=class extends Jc{constructor(e,t){super();let n=this,r=null,i=1,a=null,o=`local-floor`,s=1,c=null,l=null,u=null,d=null,f=null,p=null,m=typeof XRWebGLBinding<`u`,h=new Pg,g={},_=t.getContextAttributes(),v=null,y=null,b=[],x=[],S=new Y,C=null,w=null,T=new sp;T.viewport=new Sl;let E=new sp;E.viewport=new Sl;let D=[T,E],O=new fp,k=null,A=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(e){let t=b[e];return t===void 0&&(t=new ru,b[e]=t),t.getTargetRaySpace()},this.getControllerGrip=function(e){let t=b[e];return t===void 0&&(t=new ru,b[e]=t),t.getGripSpace()},this.getHand=function(e){let t=b[e];return t===void 0&&(t=new ru,b[e]=t),t.getHandSpace()};function j(e){let t=x.indexOf(e.inputSource);if(t===-1)return;let n=b[t];n!==void 0&&(n.update(e.inputSource,e.frame,c||a),n.dispatchEvent({type:e.type,data:e.inputSource}))}function M(){r.removeEventListener(`select`,j),r.removeEventListener(`selectstart`,j),r.removeEventListener(`selectend`,j),r.removeEventListener(`squeeze`,j),r.removeEventListener(`squeezestart`,j),r.removeEventListener(`squeezeend`,j),r.removeEventListener(`end`,M),r.removeEventListener(`inputsourceschange`,N);for(let e=0;e<b.length;e++){let t=x[e];t!==null&&(x[e]=null,b[e].disconnect(t))}k=null,A=null,h.reset();for(let e in g)delete g[e];if(e.setRenderTarget(v),f=null,d=null,u=null,r=null,y=null,R.stop(),n.isPresenting=!1,e.setPixelRatio(C),e.setSize(S.width,S.height,!1),w!==null){let e=w.camera;e.fov=w.fov,e.zoom=w.zoom,e.updateProjectionMatrix(),w=null}n.dispatchEvent({type:`sessionend`})}this.setFramebufferScaleFactor=function(e){i=e,n.isPresenting===!0&&q(`WebXRManager: Cannot change framebuffer scale while presenting.`)},this.setReferenceSpaceType=function(e){o=e,n.isPresenting===!0&&q(`WebXRManager: Cannot change reference space type while presenting.`)},this.getReferenceSpace=function(){return c||a},this.setReferenceSpace=function(e){c=e},this.getBaseLayer=function(){return d===null?f:d},this.getBinding=function(){return u===null&&m&&(u=new XRWebGLBinding(r,t)),u},this.getFrame=function(){return p},this.getSession=function(){return r},this.setSession=async function(l){if(r=l,r!==null){if(v=e.getRenderTarget(),r.addEventListener(`select`,j),r.addEventListener(`selectstart`,j),r.addEventListener(`selectend`,j),r.addEventListener(`squeeze`,j),r.addEventListener(`squeezestart`,j),r.addEventListener(`squeezeend`,j),r.addEventListener(`end`,M),r.addEventListener(`inputsourceschange`,N),_.xrCompatible!==!0&&await t.makeXRCompatible(),C=e.getPixelRatio(),e.getSize(S),m&&`createProjectionLayer`in XRWebGLBinding.prototype){let n=null,a=null,o=null;_.depth&&(o=_.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,n=_.stencil?Fs:Ps,a=_.stencil?Os:Cs);let s={colorFormat:t.RGBA8,depthFormat:o,scaleFactor:i};u=this.getBinding(),d=u.createProjectionLayer(s),r.updateRenderState({layers:[d]}),e.setPixelRatio(1),e.setSize(d.textureWidth,d.textureHeight,!1),y=new wl(d.textureWidth,d.textureHeight,{format:Ns,type:vs,depthTexture:new _f(d.textureWidth,d.textureHeight,a,void 0,void 0,void 0,void 0,void 0,void 0,n),stencilBuffer:_.stencil,colorSpace:e.outputColorSpace,samples:_.antialias?4:0,resolveDepthBuffer:d.ignoreDepthValues===!1,resolveStencilBuffer:d.ignoreDepthValues===!1,storeMultisampledDepthBuffer:d.ignoreDepthValues===!1,storeMultisampledStencilBuffer:d.ignoreDepthValues===!1})}else{let n={antialias:_.antialias,alpha:!0,depth:_.depth,stencil:_.stencil,framebufferScaleFactor:i};f=new XRWebGLLayer(r,t,n),r.updateRenderState({baseLayer:f}),e.setPixelRatio(1),e.setSize(f.framebufferWidth,f.framebufferHeight,!1),y=new wl(f.framebufferWidth,f.framebufferHeight,{format:Ns,type:vs,colorSpace:e.outputColorSpace,stencilBuffer:_.stencil,resolveDepthBuffer:f.ignoreDepthValues===!1,resolveStencilBuffer:f.ignoreDepthValues===!1,storeMultisampledDepthBuffer:f.ignoreDepthValues===!1,storeMultisampledStencilBuffer:f.ignoreDepthValues===!1})}y.isXRRenderTarget=!0,this.setFoveation(s),c=null,a=await r.requestReferenceSpace(o),R.setContext(r),R.start(),n.isPresenting=!0,n.dispatchEvent({type:`sessionstart`})}},this.getEnvironmentBlendMode=function(){if(r!==null)return r.environmentBlendMode},this.getDepthTexture=function(){return h.getDepthTexture()};function N(e){for(let t=0;t<e.removed.length;t++){let n=e.removed[t],r=x.indexOf(n);r>=0&&(x[r]=null,b[r].disconnect(n))}for(let t=0;t<e.added.length;t++){let n=e.added[t],r=x.indexOf(n);if(r===-1){for(let e=0;e<b.length;e++)if(e>=x.length){x.push(n),r=e;break}else if(x[e]===null){x[e]=n,r=e;break}if(r===-1)break}let i=b[r];i&&i.connect(n)}}let P=new X,F=new X;function I(e,t,n){P.setFromMatrixPosition(t.matrixWorld),F.setFromMatrixPosition(n.matrixWorld);let r=P.distanceTo(F),i=t.projectionMatrix.elements,a=n.projectionMatrix.elements,o=i[14]/(i[10]-1),s=i[14]/(i[10]+1),c=(i[9]+1)/i[5],l=(i[9]-1)/i[5],u=(i[8]-1)/i[0],d=(a[8]+1)/a[0],f=o*u,p=o*d,m=r/(-u+d),h=m*-u;if(t.matrixWorld.decompose(e.position,e.quaternion,e.scale),e.translateX(h),e.translateZ(m),e.matrixWorld.compose(e.position,e.quaternion,e.scale),e.matrixWorldInverse.copy(e.matrixWorld).invert(),i[10]===-1)e.projectionMatrix.copy(t.projectionMatrix),e.projectionMatrixInverse.copy(t.projectionMatrixInverse);else{let t=o+m,n=s+m,i=f-h,a=p+(r-h),u=c*s/n*t,d=l*s/n*t;e.projectionMatrix.makePerspective(i,a,u,d,t,n),e.projectionMatrixInverse.copy(e.projectionMatrix).invert()}}function L(e,t){t===null?e.matrixWorld.copy(e.matrix):e.matrixWorld.multiplyMatrices(t.matrixWorld,e.matrix),e.matrixWorldInverse.copy(e.matrixWorld).invert()}this.updateCamera=function(e){if(r===null)return;let t=e.near,n=e.far;h.texture!==null&&(h.depthNear>0&&(t=h.depthNear),h.depthFar>0&&(n=h.depthFar)),O.near=E.near=T.near=t,O.far=E.far=T.far=n,(k!==O.near||A!==O.far)&&(r.updateRenderState({depthNear:O.near,depthFar:O.far}),k=O.near,A=O.far),O.layers.mask=e.layers.mask|6,T.layers.mask=O.layers.mask&-5,E.layers.mask=O.layers.mask&-3;let i=e.parent,a=O.cameras;L(O,i);for(let e=0;e<a.length;e++)L(a[e],i);a.length===2?I(O,T,E):O.projectionMatrix.copy(T.projectionMatrix),w===null&&e.isPerspectiveCamera&&(w={camera:e,fov:e.fov,zoom:e.zoom}),ee(e,O,i)};function ee(e,t,n){n===null?e.matrix.copy(t.matrixWorld):(e.matrix.copy(n.matrixWorld),e.matrix.invert(),e.matrix.multiply(t.matrixWorld)),e.matrix.decompose(e.position,e.quaternion,e.scale),e.updateMatrixWorld(!0),e.projectionMatrix.copy(t.projectionMatrix),e.projectionMatrixInverse.copy(t.projectionMatrixInverse),e.isPerspectiveCamera&&(e.fov=Zc*2*Math.atan(1/e.projectionMatrix.elements[5]),e.zoom=1)}this.getCamera=function(){return O},this.getFoveation=function(){if(d!==null||f!==null)return s},this.setFoveation=function(e){s=e,d!==null&&(d.fixedFoveation=e),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=e)},this.hasDepthSensing=function(){return h.texture!==null},this.getDepthSensingMesh=function(){return h.getMesh(O)},this.getCameraTexture=function(e){return g[e]};let te=null;function ne(t,i){if(l=i.getViewerPose(c||a),p=i,l!==null){let t=l.views;f!==null&&(e.setRenderTargetFramebuffer(y,f.framebuffer),e.setRenderTarget(y));let i=!1;t.length!==O.cameras.length&&(O.cameras.length=0,i=!0);for(let n=0;n<t.length;n++){let r=t[n],a=null;if(f!==null)a=f.getViewport(r);else{let t=u.getViewSubImage(d,r);a=t.viewport,n===0&&(e.setRenderTargetTextures(y,t.colorTexture,t.depthStencilTexture),e.setRenderTarget(y))}let o=D[n];o===void 0&&(o=new sp,o.layers.enable(n),o.viewport=new Sl,D[n]=o),o.matrix.fromArray(r.transform.matrix),o.matrix.decompose(o.position,o.quaternion,o.scale),o.projectionMatrix.fromArray(r.projectionMatrix),o.projectionMatrixInverse.copy(o.projectionMatrix).invert(),o.viewport.set(a.x,a.y,a.width,a.height),n===0&&(O.matrix.copy(o.matrix),O.matrix.decompose(O.position,O.quaternion,O.scale)),i===!0&&O.cameras.push(o)}let a=r.enabledFeatures;if(a&&a.includes(`depth-sensing`)&&r.depthUsage==`gpu-optimized`&&m){u=n.getBinding();let e=u.getDepthInformation(t[0]);e&&e.isValid&&e.texture&&h.init(e,r.renderState)}if(a&&a.includes(`camera-access`)&&m){e.state.unbindTexture(),u=n.getBinding();for(let e=0;e<t.length;e++){let n=t[e].camera;if(n){let e=g[n];e||(e=new yf,g[n]=e);let t=u.getCameraImage(n);e.sourceTexture=t}}}}for(let e=0;e<b.length;e++){let t=x[e],n=b[e];t!==null&&n!==void 0&&n.update(t,i,c||a)}te&&te(t,i),i.detectedPlanes&&n.dispatchEvent({type:`planesdetected`,data:i}),p=null}let R=new Dp;R.setAnimationLoop(ne),this.setAnimationLoop=function(e){te=e},this.dispose=function(){}}},Ig=new Dl,Lg=new Z;Lg.set(-1,0,0,0,1,0,0,0,1);function Rg(e,t){function n(e,t){e.matrixAutoUpdate===!0&&e.updateMatrix(),t.value.copy(e.matrix)}function r(t,n){n.color.getRGB(t.fogColor.value,Df(e)),n.isFog?(t.fogNear.value=n.near,t.fogFar.value=n.far):n.isFogExp2&&(t.fogDensity.value=n.density)}function i(e,t,n,r,i){t.isNodeMaterial?t.uniformsNeedUpdate=!1:t.isMeshBasicMaterial?a(e,t):t.isMeshLambertMaterial?(a(e,t),t.envMap&&(e.envMapIntensity.value=t.envMapIntensity)):t.isMeshToonMaterial?(a(e,t),d(e,t)):t.isMeshPhongMaterial?(a(e,t),u(e,t),t.envMap&&(e.envMapIntensity.value=t.envMapIntensity)):t.isMeshStandardMaterial?(a(e,t),f(e,t),t.isMeshPhysicalMaterial&&p(e,t,i)):t.isMeshMatcapMaterial?(a(e,t),m(e,t)):t.isMeshDepthMaterial?a(e,t):t.isMeshDistanceMaterial?(a(e,t),h(e,t)):t.isMeshNormalMaterial?a(e,t):t.isLineBasicMaterial?(o(e,t),t.isLineDashedMaterial&&s(e,t)):t.isPointsMaterial?c(e,t,n,r):t.isSpriteMaterial?l(e,t):t.isShadowMaterial?(e.color.value.copy(t.color),e.opacity.value=t.opacity):t.isShaderMaterial&&(t.uniformsNeedUpdate=!1)}function a(e,r){e.opacity.value=r.opacity,r.color&&e.diffuse.value.copy(r.color),r.emissive&&e.emissive.value.copy(r.emissive).multiplyScalar(r.emissiveIntensity),r.map&&(e.map.value=r.map,n(r.map,e.mapTransform)),r.alphaMap&&(e.alphaMap.value=r.alphaMap,n(r.alphaMap,e.alphaMapTransform)),r.bumpMap&&(e.bumpMap.value=r.bumpMap,n(r.bumpMap,e.bumpMapTransform),e.bumpScale.value=r.bumpScale,r.side===1&&(e.bumpScale.value*=-1)),r.normalMap&&(e.normalMap.value=r.normalMap,n(r.normalMap,e.normalMapTransform),e.normalScale.value.copy(r.normalScale),r.side===1&&e.normalScale.value.negate()),r.displacementMap&&(e.displacementMap.value=r.displacementMap,n(r.displacementMap,e.displacementMapTransform),e.displacementScale.value=r.displacementScale,e.displacementBias.value=r.displacementBias),r.emissiveMap&&(e.emissiveMap.value=r.emissiveMap,n(r.emissiveMap,e.emissiveMapTransform)),r.specularMap&&(e.specularMap.value=r.specularMap,n(r.specularMap,e.specularMapTransform)),r.alphaTest>0&&(e.alphaTest.value=r.alphaTest);let i=t.get(r),a=i.envMap,o=i.envMapRotation;a&&(e.envMap.value=a,e.envMapRotation.value.setFromMatrix4(Ig.makeRotationFromEuler(o)).transpose(),a.isCubeTexture&&a.isRenderTargetTexture===!1&&e.envMapRotation.value.premultiply(Lg),e.reflectivity.value=r.reflectivity,e.ior.value=r.ior,e.refractionRatio.value=r.refractionRatio),r.lightMap&&(e.lightMap.value=r.lightMap,e.lightMapIntensity.value=r.lightMapIntensity,n(r.lightMap,e.lightMapTransform)),r.aoMap&&(e.aoMap.value=r.aoMap,e.aoMapIntensity.value=r.aoMapIntensity,n(r.aoMap,e.aoMapTransform))}function o(e,t){e.diffuse.value.copy(t.color),e.opacity.value=t.opacity,t.map&&(e.map.value=t.map,n(t.map,e.mapTransform))}function s(e,t){e.dashSize.value=t.dashSize,e.totalSize.value=t.dashSize+t.gapSize,e.scale.value=t.scale}function c(e,t,r,i){e.diffuse.value.copy(t.color),e.opacity.value=t.opacity,e.size.value=t.size*r,e.scale.value=i*.5,t.map&&(e.map.value=t.map,n(t.map,e.uvTransform)),t.alphaMap&&(e.alphaMap.value=t.alphaMap,n(t.alphaMap,e.alphaMapTransform)),t.alphaTest>0&&(e.alphaTest.value=t.alphaTest)}function l(e,t){e.diffuse.value.copy(t.color),e.opacity.value=t.opacity,e.rotation.value=t.rotation,t.map&&(e.map.value=t.map,n(t.map,e.mapTransform)),t.alphaMap&&(e.alphaMap.value=t.alphaMap,n(t.alphaMap,e.alphaMapTransform)),t.alphaTest>0&&(e.alphaTest.value=t.alphaTest)}function u(e,t){e.specular.value.copy(t.specular),e.shininess.value=Math.max(t.shininess,1e-4)}function d(e,t){t.gradientMap&&(e.gradientMap.value=t.gradientMap)}function f(e,t){e.metalness.value=t.metalness,t.metalnessMap&&(e.metalnessMap.value=t.metalnessMap,n(t.metalnessMap,e.metalnessMapTransform)),e.roughness.value=t.roughness,t.roughnessMap&&(e.roughnessMap.value=t.roughnessMap,n(t.roughnessMap,e.roughnessMapTransform)),t.envMap&&(e.envMapIntensity.value=t.envMapIntensity)}function p(e,t,r){e.ior.value=t.ior,t.sheen>0&&(e.sheenColor.value.copy(t.sheenColor).multiplyScalar(t.sheen),e.sheenRoughness.value=t.sheenRoughness,t.sheenColorMap&&(e.sheenColorMap.value=t.sheenColorMap,n(t.sheenColorMap,e.sheenColorMapTransform)),t.sheenRoughnessMap&&(e.sheenRoughnessMap.value=t.sheenRoughnessMap,n(t.sheenRoughnessMap,e.sheenRoughnessMapTransform))),t.clearcoat>0&&(e.clearcoat.value=t.clearcoat,e.clearcoatRoughness.value=t.clearcoatRoughness,t.clearcoatMap&&(e.clearcoatMap.value=t.clearcoatMap,n(t.clearcoatMap,e.clearcoatMapTransform)),t.clearcoatRoughnessMap&&(e.clearcoatRoughnessMap.value=t.clearcoatRoughnessMap,n(t.clearcoatRoughnessMap,e.clearcoatRoughnessMapTransform)),t.clearcoatNormalMap&&(e.clearcoatNormalMap.value=t.clearcoatNormalMap,n(t.clearcoatNormalMap,e.clearcoatNormalMapTransform),e.clearcoatNormalScale.value.copy(t.clearcoatNormalScale),t.side===1&&e.clearcoatNormalScale.value.negate())),t.dispersion>0&&(e.dispersion.value=t.dispersion),t.retroreflectivity>0&&(e.retroreflectivity.value=t.retroreflectivity),t.iridescence>0&&(e.iridescence.value=t.iridescence,e.iridescenceIOR.value=t.iridescenceIOR,e.iridescenceThicknessMinimum.value=t.iridescenceThicknessRange[0],e.iridescenceThicknessMaximum.value=t.iridescenceThicknessRange[1],t.iridescenceMap&&(e.iridescenceMap.value=t.iridescenceMap,n(t.iridescenceMap,e.iridescenceMapTransform)),t.iridescenceThicknessMap&&(e.iridescenceThicknessMap.value=t.iridescenceThicknessMap,n(t.iridescenceThicknessMap,e.iridescenceThicknessMapTransform))),t.transmission>0&&(e.transmission.value=t.transmission,e.transmissionSamplerMap.value=r.texture,e.transmissionSamplerSize.value.set(r.width,r.height),t.transmissionMap&&(e.transmissionMap.value=t.transmissionMap,n(t.transmissionMap,e.transmissionMapTransform)),e.thickness.value=t.thickness,t.thicknessMap&&(e.thicknessMap.value=t.thicknessMap,n(t.thicknessMap,e.thicknessMapTransform)),e.attenuationDistance.value=t.attenuationDistance,e.attenuationColor.value.copy(t.attenuationColor)),t.anisotropy>0&&(e.anisotropyVector.value.set(t.anisotropy*Math.cos(t.anisotropyRotation),t.anisotropy*Math.sin(t.anisotropyRotation)),t.anisotropyMap&&(e.anisotropyMap.value=t.anisotropyMap,n(t.anisotropyMap,e.anisotropyMapTransform))),e.specularIntensity.value=t.specularIntensity,e.specularColor.value.copy(t.specularColor),t.specularColorMap&&(e.specularColorMap.value=t.specularColorMap,n(t.specularColorMap,e.specularColorMapTransform)),t.specularIntensityMap&&(e.specularIntensityMap.value=t.specularIntensityMap,n(t.specularIntensityMap,e.specularIntensityMapTransform))}function m(e,t){t.matcap&&(e.matcap.value=t.matcap)}function h(e,n){let r=t.get(n).light;e.referencePosition.value.setFromMatrixPosition(r.matrixWorld),e.nearDistance.value=r.shadow.camera.near,e.farDistance.value=r.shadow.camera.far}return{refreshFogUniforms:r,refreshMaterialUniforms:i}}function zg(e,t,n,r){let i={},a={},o=[],s=e.getParameter(e.MAX_UNIFORM_BUFFER_BINDINGS);function c(e,t){let n=t.program;r.uniformBlockBinding(e,n)}function l(e,n){let o=i[e.id];o===void 0&&(g(e),o=u(e),i[e.id]=o,e.addEventListener(`dispose`,v));let s=n.program;r.updateUBOMapping(e,s);let c=t.render.frame;a[e.id]!==c&&(f(e),a[e.id]=c)}function u(t){let n=d();t.__bindingPointIndex=n;let r=e.createBuffer(),i=t.__size,a=t.usage;return e.bindBuffer(e.UNIFORM_BUFFER,r),e.bufferData(e.UNIFORM_BUFFER,i,a),e.bindBuffer(e.UNIFORM_BUFFER,null),e.bindBufferBase(e.UNIFORM_BUFFER,n,r),r}function d(){for(let e=0;e<s;e++)if(o.indexOf(e)===-1)return o.push(e),e;return J(`WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached.`),0}function f(t){let n=i[t.id],r=t.uniforms,a=t.__cache;e.bindBuffer(e.UNIFORM_BUFFER,n);for(let e=0,t=r.length;e<t;e++){let t=r[e];if(Array.isArray(t))for(let n=0,r=t.length;n<r;n++)p(t[n],e,n,a);else p(t,e,0,a)}e.bindBuffer(e.UNIFORM_BUFFER,null)}function p(t,n,r,i){if(h(t,n,r,i)===!0){let n=t.__offset,r=t.value;if(Array.isArray(r)){let e=0;for(let n=0;n<r.length;n++){let i=r[n],a=_(i);m(i,t.__data,e),typeof i!=`number`&&typeof i!=`boolean`&&!i.isMatrix3&&!ArrayBuffer.isView(i)&&(e+=a.storage/Float32Array.BYTES_PER_ELEMENT)}}else m(r,t.__data,0);e.bufferSubData(e.UNIFORM_BUFFER,n,t.__data)}}function m(e,t,n){typeof e==`number`||typeof e==`boolean`?t[0]=e:e.isMatrix3?(t[0]=e.elements[0],t[1]=e.elements[1],t[2]=e.elements[2],t[3]=0,t[4]=e.elements[3],t[5]=e.elements[4],t[6]=e.elements[5],t[7]=0,t[8]=e.elements[6],t[9]=e.elements[7],t[10]=e.elements[8],t[11]=0):ArrayBuffer.isView(e)?t.set(new e.constructor(e.buffer,e.byteOffset,t.length)):e.toArray(t,n)}function h(e,t,n,r){let i=e.value,a=t+`_`+n;if(r[a]===void 0)return r[a]=typeof i==`number`||typeof i==`boolean`?i:ArrayBuffer.isView(i)?i.slice():i.clone(),!0;{let e=r[a];if(typeof i==`number`||typeof i==`boolean`){if(e!==i)return r[a]=i,!0}else if(ArrayBuffer.isView(i))return!0;else if(e.equals(i)===!1)return e.copy(i),!0}return!1}function g(e){let t=e.uniforms,n=0;for(let e=0,r=t.length;e<r;e++){let r=Array.isArray(t[e])?t[e]:[t[e]];for(let e=0,t=r.length;e<t;e++){let t=r[e],i=Array.isArray(t.value)?t.value:[t.value];for(let e=0,r=i.length;e<r;e++){let r=i[e],a=_(r),o=n%16,s=o%a.boundary,c=o+s;n+=s,c!==0&&16-c<a.storage&&(n+=16-c),t.__data=new Float32Array(a.storage/Float32Array.BYTES_PER_ELEMENT),t.__offset=n,n+=a.storage}}}let r=n%16;return r>0&&(n+=16-r),e.__size=n,e.__cache={},this}function _(e){let t={boundary:0,storage:0};return typeof e==`number`||typeof e==`boolean`?(t.boundary=4,t.storage=4):e.isVector2?(t.boundary=8,t.storage=8):e.isVector3||e.isColor?(t.boundary=16,t.storage=12):e.isVector4?(t.boundary=16,t.storage=16):e.isMatrix3?(t.boundary=48,t.storage=48):e.isMatrix4?(t.boundary=64,t.storage=64):e.isTexture?q(`WebGLRenderer: Texture samplers can not be part of an uniforms group.`):ArrayBuffer.isView(e)?(t.boundary=16,t.storage=e.byteLength):q(`WebGLRenderer: Unsupported uniform value type.`,e),t}function v(t){let n=t.target;n.removeEventListener(`dispose`,v);let r=o.indexOf(n.__bindingPointIndex);o.splice(r,1),e.deleteBuffer(i[n.id]),delete i[n.id],delete a[n.id]}function y(){for(let t in i)e.deleteBuffer(i[t]);o=[],i={},a={}}return{bind:c,update:l,dispose:y}}var Bg=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]),Vg=null;function Hg(){return Vg===null&&(Vg=new Xd(Bg,16,16,Rs,Ts),Vg.name=`DFG_LUT`,Vg.minFilter=hs,Vg.magFilter=hs,Vg.wrapS=us,Vg.wrapT=us,Vg.generateMipmaps=!1,Vg.needsUpdate=!0),Vg}var Ug=class{constructor(e={}){let{canvas:t=Vc(),context:n=null,depth:r=!0,stencil:i=!1,alpha:a=!1,antialias:o=!1,premultipliedAlpha:s=!0,preserveDrawingBuffer:c=!1,powerPreference:l=`default`,failIfMajorPerformanceCaveat:u=!1,reversedDepthBuffer:d=!1,outputBufferType:f=vs}=e;this.isWebGLRenderer=!0;let p;if(n!==null){if(typeof WebGLRenderingContext<`u`&&n instanceof WebGLRenderingContext)throw Error(`THREE.WebGLRenderer: WebGL 1 is not supported since r163.`);p=n.getContextAttributes().alpha}else p=a;let m=f,h=new Set([Bs,zs,Ls]),g=new Set([vs,Cs,xs,Os,Es,Ds]),_=new Uint32Array(4),v=new Int32Array(4),y=new X,b=null,x=null,S=[],C=[],w=null;this.domElement=t,this.debug={checkShaderErrors:!0,diagnostics:{keywords:!1},onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=0,this.toneMappingExposure=1,this.transmissionResolutionScale=1;let T=this,E=!1,D=null,O=null,k=null,A=null;this._outputColorSpace=jc;let j=0,M=0,N=null,P=-1,F=null,I=new Sl,L=new Sl,ee=null,te=new cu(0),ne=0,R=t.width,re=t.height,z=1,B=null,ie=null,ae=new Sl(0,0,R,re),oe=new Sl(0,0,R,re),se=!1,ce=new ef,le=!1,ue=!1,de=new Dl,fe=new X,pe=new Sl,me={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0},he=!1;function ge(){return N===null?z:1}let V=n;function _e(e,n){return t.getContext(e,n)}let ve,ye,H,be,U,W,xe,Se,Ce,we,Te,Ee,De,Oe,ke,Ae,je,Me,Ne,Pe,G,Fe,Ie;try{let e={alpha:!0,depth:r,stencil:i,antialias:o,premultipliedAlpha:s,preserveDrawingBuffer:c,powerPreference:l,failIfMajorPerformanceCaveat:u};if(`setAttribute`in t&&t.setAttribute(`data-engine`,`three.js r186`),t.addEventListener(`webglcontextlost`,ze,!1),t.addEventListener(`webglcontextrestored`,Be,!1),t.addEventListener(`webglcontextcreationerror`,Ve,!1),V===null){let t=`webgl2`;if(V=_e(t,e),V===null)throw _e(t)?Error(`THREE.WebGLRenderer: Error creating WebGL context with your selected attributes.`):Error(`THREE.WebGLRenderer: Error creating WebGL context.`)}Le()}catch(e){throw t.removeEventListener(`webglcontextlost`,ze,!1),t.removeEventListener(`webglcontextrestored`,Be,!1),t.removeEventListener(`webglcontextcreationerror`,Ve,!1),J(`WebGLRenderer: `+e.message),e}function Le(){ve=new sm(V),ve.init(),G=new jg(V,ve),ye=new Ip(V,ve,e,G),H=new kg(V,ve),ye.reversedDepthBuffer&&d&&H.buffers.depth.setReversed(!0),O=V.createFramebuffer(),k=V.createFramebuffer(),A=V.createFramebuffer(),be=new um(V),U=new lg,W=new Ag(V,ve,H,U,ye,G,be),xe=new om(T),Se=new Op(V),Fe=new Pp(V,Se),Ce=new cm(V,Se,be,Fe),we=new fm(V,Ce,Se,Fe,be),Me=new dm(V,ye,W),ke=new Lp(U),Te=new cg(T,xe,ve,ye,Fe,ke),Ee=new Rg(T,U),De=new pg,Oe=new bg(ve),je=new Np(T,xe,H,we,p,s),Ae=new Og(T,we,ye),Ie=new zg(V,be,ye,H),Ne=new Fp(V,ve,be),Pe=new lm(V,ve,be),be.programs=Te.programs,T.capabilities=ye,T.extensions=ve,T.properties=U,T.renderLists=De,T.shadowMap=Ae,T.state=H,T.info=be}m!==1009&&(w=new mm(m,t.width,t.height,o,r,i));let Re=new Fg(T,V);this.xr=Re,this.getContext=function(){return V},this.getContextAttributes=function(){return V.getContextAttributes()},this.forceContextLoss=function(){let e=ve.get(`WEBGL_lose_context`);e&&e.loseContext()},this.forceContextRestore=function(){let e=ve.get(`WEBGL_lose_context`);e&&e.restoreContext()},this.getPixelRatio=function(){return z},this.setPixelRatio=function(e){e!==void 0&&(z=e,this.setSize(R,re,!1))},this.getSize=function(e){return e.set(R,re)},this.setSize=function(e,n,r=!0){if(Re.isPresenting){q(`WebGLRenderer: Can't change size while VR device is presenting.`);return}R=e,re=n,t.width=Math.floor(e*z),t.height=Math.floor(n*z),r===!0&&(t.style.width=e+`px`,t.style.height=n+`px`),w!==null&&w.setSize(t.width,t.height),this.setViewport(0,0,e,n)},this.getDrawingBufferSize=function(e){return e.set(R*z,re*z).floor()},this.setDrawingBufferSize=function(e,n,r){R=e,re=n,z=r,t.width=Math.floor(e*r),t.height=Math.floor(n*r),this.setViewport(0,0,e,n)},this.setEffects=function(e){if(m===1009){J(`WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.`);return}if(e){for(let t=0;t<e.length;t++)if(e[t].isOutputPass===!0){q(`WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.`);break}}w.setEffects(e||[])},this.getCurrentViewport=function(e){return e.copy(I)},this.getViewport=function(e){return e.copy(ae)},this.setViewport=function(e,t,n,r){e.isVector4?ae.set(e.x,e.y,e.z,e.w):ae.set(e,t,n,r),H.viewport(I.copy(ae).multiplyScalar(z).round())},this.getScissor=function(e){return e.copy(oe)},this.setScissor=function(e,t,n,r){e.isVector4?oe.set(e.x,e.y,e.z,e.w):oe.set(e,t,n,r),H.scissor(L.copy(oe).multiplyScalar(z).round())},this.getScissorTest=function(){return se},this.setScissorTest=function(e){H.setScissorTest(se=e)},this.setOpaqueSort=function(e){B=e},this.setTransparentSort=function(e){ie=e},this.getClearColor=function(e){return e.copy(je.getClearColor())},this.setClearColor=function(){je.setClearColor(...arguments)},this.getClearAlpha=function(){return je.getClearAlpha()},this.setClearAlpha=function(){je.setClearAlpha(...arguments)},this.clear=function(e=!0,t=!0,n=!0){let r=0;if(e){let e=!1;if(N!==null){let t=N.texture.format;e=h.has(t)}if(e){let e=N.texture.type,t=g.has(e),n=je.getClearColor(),r=je.getClearAlpha(),i=n.r,a=n.g,o=n.b;t?(_[0]=i,_[1]=a,_[2]=o,_[3]=r,V.clearBufferuiv(V.COLOR,0,_)):(v[0]=i,v[1]=a,v[2]=o,v[3]=r,V.clearBufferiv(V.COLOR,0,v))}else r|=V.COLOR_BUFFER_BIT}t&&(r|=V.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),n&&(r|=V.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),r!==0&&V.clear(r)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(e){e.setRenderer(this),D=e},this.dispose=function(){t.removeEventListener(`webglcontextlost`,ze,!1),t.removeEventListener(`webglcontextrestored`,Be,!1),t.removeEventListener(`webglcontextcreationerror`,Ve,!1),je.dispose(),De.dispose(),Oe.dispose(),U.dispose(),xe.dispose(),we.dispose(),Fe.dispose(),Ie.dispose(),Te.dispose(),Re.dispose(),Re.removeEventListener(`sessionstart`,Je),Re.removeEventListener(`sessionend`,Ye),Xe.stop()};function ze(e){e.preventDefault(),Uc(`WebGLRenderer: Context Lost.`),E=!0}function Be(){Uc(`WebGLRenderer: Context Restored.`),E=!1;let e=be.autoReset,t=Ae.enabled,n=Ae.autoUpdate,r=Ae.needsUpdate,i=Ae.type;Le(),be.autoReset=e,Ae.enabled=t,Ae.autoUpdate=n,Ae.needsUpdate=r,Ae.type=i}function Ve(e){J(`WebGLRenderer: A WebGL context could not be created. Reason: `,e.statusMessage)}function He(e){let t=e.target;t.removeEventListener(`dispose`,He),Ue(t)}function Ue(e){We(e),U.remove(e)}function We(e){let t=U.get(e).programs;t!==void 0&&(t.forEach(function(e){Te.releaseProgram(e)}),e.isShaderMaterial&&Te.releaseShaderCache(e))}this.renderBufferDirect=function(e,t,n,r,i,a){t===null&&(t=me);let o=i.isMesh&&i.matrixWorld.determinantAffine()<0,s=ot(e,t,n,r,i);H.setMaterial(r,o);let c=n.index,l=1;if(r.wireframe===!0){if(c=Ce.getWireframeAttribute(n),c===void 0)return;l=2}let u=n.drawRange,d=n.attributes.position,f=u.start*l,p=(u.start+u.count)*l;a!==null&&(f=Math.max(f,a.start*l),p=Math.min(p,(a.start+a.count)*l)),c===null?d!=null&&(f=Math.max(f,0),p=Math.min(p,d.count)):(f=Math.max(f,0),p=Math.min(p,c.count));let m=p-f;if(m<0||m===1/0)return;Fe.setup(i,r,s,n,c);let h,g=Ne;if(c!==null&&(h=Se.get(c),g=Pe,g.setIndex(h)),i.isMesh)r.wireframe===!0?(H.setLineWidth(r.wireframeLinewidth*ge()),g.setMode(V.LINES)):g.setMode(V.TRIANGLES);else if(i.isLine){let e=r.linewidth;e===void 0&&(e=1),H.setLineWidth(e*ge()),i.isLineSegments?g.setMode(V.LINES):i.isLineLoop?g.setMode(V.LINE_LOOP):g.setMode(V.LINE_STRIP)}else i.isPoints?g.setMode(V.POINTS):i.isSprite&&g.setMode(V.TRIANGLES);if(i.isBatchedMesh){if(ve.get(`WEBGL_multi_draw`))g.renderMultiDraw(i._multiDrawStarts,i._multiDrawCounts,i._multiDrawCount);else{let e=i._multiDrawStarts,t=i._multiDrawCounts,n=i._multiDrawCount,a=c?Se.get(c).bytesPerElement:1,o=U.get(r).currentProgram.getUniforms();for(let r=0;r<n;r++)o.setValue(V,`_gl_DrawID`,r),g.render(e[r]/a,t[r])}}else if(i.isInstancedMesh)g.renderInstances(f,m,i.count);else if(n.isInstancedBufferGeometry){let e=n._maxInstanceCount===void 0?1/0:n._maxInstanceCount,t=Math.min(n.instanceCount,e);g.renderInstances(f,m,t)}else g.render(f,m)};function Ge(e,t,n,r){D!==null&&e.isNodeMaterial&&D.setObject(r,e),le===!0&&ke.setState(e,n,!1),e.transparent===!0&&e.side===2&&e.forceSinglePass===!1?(e.side=1,e.needsUpdate=!0,nt(e,t,r),e.side=0,e.needsUpdate=!0,nt(e,t,r),e.side=2):nt(e,t,r)}this.compile=function(e,t,n=null){n===null&&(n=e),D!==null&&D.renderStart(e,t,n),x=Oe.get(n),x.init(t),C.push(x),n.traverseVisible(function(e){e.isLight&&e.layers.test(t.layers)&&(x.pushLight(e),e.castShadow&&x.pushShadow(e))}),e!==n&&e.traverseVisible(function(e){e.isLight&&e.layers.test(t.layers)&&(x.pushLight(e),e.castShadow&&x.pushShadow(e))}),x.setupLights(),D!==null&&D.updateLights(x.state.lightsArray),ue=this.localClippingEnabled,le=ke.init(this.clippingPlanes,ue),le===!0&&ke.setGlobalState(this.clippingPlanes,t),D!==null&&Ae.render(x.state.shadowsArray,n,t);let r=new Set;return e.traverse(function(e){if(!(e.isMesh||e.isPoints||e.isLine||e.isSprite))return;let i=e.material;if(i){if(Array.isArray(i))for(let a=0;a<i.length;a++){let o=i[a];Ge(o,n,t,e),r.add(o)}else Ge(i,n,t,e),r.add(i)}}),x=C.pop(),D!==null&&D.renderEnd(),r},this.compileAsync=function(e,t,n=null){let r=this.compile(e,t,n);return new Promise(t=>{function n(){if(r.forEach(function(e){let t=U.get(e).currentProgram;(t===void 0||t.isReady())&&r.delete(e)}),r.size===0){t(e);return}setTimeout(n,10)}ve.get(`KHR_parallel_shader_compile`)===null?setTimeout(n,10):n()})};let Ke=null;function qe(e){Ke&&Ke(e)}function Je(){Xe.stop()}function Ye(){Xe.start()}let Xe=new Dp;Xe.setAnimationLoop(qe),typeof self<`u`&&Xe.setContext(self),this.setAnimationLoop=function(e){Ke=e,Re.setAnimationLoop(e),e===null?Xe.stop():Xe.start()},Re.addEventListener(`sessionstart`,Je),Re.addEventListener(`sessionend`,Ye),this.render=function(e,t){if(t!==void 0&&t.isCamera!==!0){J(`WebGLRenderer.render: camera is not an instance of THREE.Camera.`);return}if(E===!0)return;D!==null&&D.renderStart(e,t);let n=Re.enabled===!0&&Re.isPresenting===!0,r=w!==null&&(N===null||n)&&w.begin(T,N);if(e.matrixWorldAutoUpdate===!0&&e.updateMatrixWorld(),t.parent===null&&t.matrixWorldAutoUpdate===!0&&t.updateMatrixWorld(),Re.enabled===!0&&Re.isPresenting===!0&&(w===null||w.isCompositing()===!1)&&(Re.cameraAutoUpdate===!0&&Re.updateCamera(t),t=Re.getCamera()),e.isScene===!0&&e.onBeforeRender(T,e,t,N),x=Oe.get(e,C.length),x.init(t),x.state.textureUnits=W.getTextureUnits(),C.push(x),de.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),ce.setFromProjectionMatrix(de,Lc,t.reversedDepth),ue=this.localClippingEnabled,le=ke.init(this.clippingPlanes,ue),b=De.get(e,S.length),b.init(),S.push(b),Re.enabled===!0&&Re.isPresenting===!0){let e=T.xr.getDepthSensingMesh();e!==null&&Ze(e,t,-1/0,T.sortObjects)}Ze(e,t,0,T.sortObjects),b.finish(),D!==null&&D.updateLights(x.state.lightsArray),T.sortObjects===!0&&b.sort(B,ie),he=Re.enabled===!1||Re.isPresenting===!1||Re.hasDepthSensing()===!1,he&&je.addToRenderList(b,e),this.info.render.frame++,this.info.autoReset===!0&&this.info.reset(),le===!0&&ke.beginShadows();let i=x.state.shadowsArray;if(Ae.render(i,e,t),le===!0&&ke.endShadows(),(r&&w.hasRenderPass())===!1){let n=b.opaque,r=b.transmissive;if(x.setupLights(),t.isArrayCamera){let i=t.cameras;if(r.length>0)for(let t=0,a=i.length;t<a;t++){let a=i[t];$e(n,r,e,a)}he&&je.render(e);for(let t=0,n=i.length;t<n;t++){let n=i[t];Qe(b,e,n,n.viewport)}}else r.length>0&&$e(n,r,e,t),he&&je.render(e),Qe(b,e,t)}N!==null&&M===0&&(W.updateMultisampleRenderTarget(N),W.updateRenderTargetMipmap(N)),r&&w.end(T),e.isScene===!0&&e.onAfterRender(T,e,t),Fe.resetDefaultState(),P=-1,F=null,C.pop(),C.length>0?(x=C[C.length-1],W.setTextureUnits(x.state.textureUnits),le===!0&&ke.setGlobalState(T.clippingPlanes,x.state.camera)):x=null,S.pop(),b=S.length>0?S[S.length-1]:null,D!==null&&D.renderEnd()};function Ze(e,t,n,r){if(e.visible===!1)return;if(e.layers.test(t.layers)){if(e.isGroup)n=e.renderOrder;else if(e.isLOD)e.autoUpdate===!0&&e.update(t);else if(e.isLightProbeGrid)x.pushLightProbeGrid(e);else if(e.isLight)x.pushLight(e),e.castShadow&&x.pushShadow(e);else if(e.isSprite){if(!e.frustumCulled||e.intersectsFrustum(ce)){r&&pe.setFromMatrixPosition(e.matrixWorld).applyMatrix4(de);let i=we.update(e),a=e.material;a.visible&&b.push(e,i,a,n,pe.z,null,t)}}else if((e.isMesh||e.isLine||e.isPoints)&&(!e.frustumCulled||e.intersectsFrustum(ce))){let i=we.update(e),a=e.material;if(r&&(e.boundingSphere===void 0?(i.boundingSphere===null&&i.computeBoundingSphere(),pe.copy(i.boundingSphere.center)):(e.boundingSphere===null&&e.computeBoundingSphere(),pe.copy(e.boundingSphere.center)),pe.applyMatrix4(e.matrixWorld).applyMatrix4(de)),Array.isArray(a)){let r=i.groups;for(let o=0,s=r.length;o<s;o++){let s=r[o],c=a[s.materialIndex];c&&c.visible&&b.push(e,i,c,n,pe.z,s,t)}}else a.visible&&b.push(e,i,a,n,pe.z,null,t)}}let i=e.children;for(let e=0,a=i.length;e<a;e++)Ze(i[e],t,n,r)}function Qe(e,t,n,r){let{opaque:i,transmissive:a,transparent:o}=e;x.setupLightsView(n),le===!0&&ke.setGlobalState(T.clippingPlanes,n),r&&H.viewport(I.copy(r)),i.length>0&&et(i,t,n),a.length>0&&et(a,t,n),o.length>0&&et(o,t,n),H.buffers.depth.setTest(!0),H.buffers.depth.setMask(!0),H.buffers.color.setMask(!0),H.setPolygonOffset(!1)}function $e(e,t,n,r){if((n.isScene===!0?n.overrideMaterial:null)!==null)return;if(x.state.transmissionRenderTarget[r.id]===void 0){let e=ve.has(`EXT_color_buffer_half_float`)||ve.has(`EXT_color_buffer_float`);x.state.transmissionRenderTarget[r.id]=new wl(1,1,{generateMipmaps:!0,type:e?Ts:vs,minFilter:_s,samples:Math.max(4,ye.samples),stencilBuffer:i,resolveDepthBuffer:!1,resolveStencilBuffer:!1,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,colorSpace:dl.workingColorSpace})}let a=x.state.transmissionRenderTarget[r.id],o=r.viewport||I;a.setSize(o.z*T.transmissionResolutionScale,o.w*T.transmissionResolutionScale);let s=T.getRenderTarget(),c=T.getActiveCubeFace(),l=T.getActiveMipmapLevel();T.setRenderTarget(a),T.getClearColor(te),ne=T.getClearAlpha(),ne<1&&T.setClearColor(16777215,.5),T.clear(),he&&je.render(n);let u=T.toneMapping;T.toneMapping=0;let d=r.viewport;if(r.viewport!==void 0&&(r.viewport=void 0),x.setupLightsView(r),le===!0&&ke.setGlobalState(T.clippingPlanes,r),et(e,n,r),W.updateMultisampleRenderTarget(a),W.updateRenderTargetMipmap(a),ve.has(`WEBGL_multisampled_render_to_texture`)===!1){let e=!1;for(let i=0,a=t.length;i<a;i++){let{object:a,geometry:o,material:s,group:c}=t[i];if(s.side===2&&a.layers.test(r.layers)){let t=s.side;s.side=1,s.needsUpdate=!0,tt(a,n,r,o,s,c),s.side=t,s.needsUpdate=!0,e=!0}}e===!0&&(W.updateMultisampleRenderTarget(a),W.updateRenderTargetMipmap(a))}T.setRenderTarget(s,c,l),T.setClearColor(te,ne),d!==void 0&&(r.viewport=d),T.toneMapping=u}function et(e,t,n){let r=t.isScene===!0?t.overrideMaterial:null;for(let i=0,a=e.length;i<a;i++){let a=e[i],{object:o,geometry:s,group:c}=a,l=a.material;l.allowOverride===!0&&r!==null&&(l=r),o.layers.test(n.layers)&&tt(o,t,n,s,l,c)}}function tt(e,t,n,r,i,a){D!==null&&i.isNodeMaterial&&D.setObject(e,i),e.onBeforeRender(T,t,n,r,i,a),e.modelViewMatrix.multiplyMatrices(n.matrixWorldInverse,e.matrixWorld),e.normalMatrix.getNormalMatrix(e.modelViewMatrix),i.onBeforeRender(T,t,n,r,e,a),i.transparent===!0&&i.side===2&&i.forceSinglePass===!1?(i.side=1,i.needsUpdate=!0,T.renderBufferDirect(n,t,r,i,e,a),i.side=0,i.needsUpdate=!0,T.renderBufferDirect(n,t,r,i,e,a),i.side=2):T.renderBufferDirect(n,t,r,i,e,a),e.onAfterRender(T,t,n,r,i,a)}function nt(e,t,n){t.isScene!==!0&&(t=me);let r=U.get(e),i=x.state.lights,a=x.state.shadowsArray,o=i.state.version,s=Te.getParameters(e,i.state,a,t,n,x.state.lightProbeGridArray),c=Te.getProgramCacheKey(s),l=r.programs;r.environment=e.isMeshStandardMaterial||e.isMeshLambertMaterial||e.isMeshPhongMaterial?t.environment:null,r.fog=t.fog;let u=e.isMeshStandardMaterial||e.isMeshLambertMaterial&&!e.envMap||e.isMeshPhongMaterial&&!e.envMap;r.envMap=xe.get(e.envMap||r.environment,u),r.envMapRotation=r.environment!==null&&e.envMap===null?t.environmentRotation:e.envMapRotation,l===void 0&&(e.addEventListener(`dispose`,He),l=new Map,r.programs=l);let d=l.get(c);if(d!==void 0){if(r.currentProgram===d&&r.lightsStateVersion===o)return it(e,s),d}else s.uniforms=Te.getUniforms(e),D!==null&&e.isNodeMaterial&&D.build(e,n,s),e.onBeforeCompile(s,T),d=Te.acquireProgram(s,c),l.set(c,d),r.uniforms=s.uniforms;let f=r.uniforms;return(!e.isShaderMaterial&&!e.isRawShaderMaterial||e.clipping===!0)&&(f.clippingPlanes=ke.uniform),it(e,s),r.needsLights=ct(e),r.lightsStateVersion=o,r.needsLights&&(f.ambientLightColor.value=i.state.ambient,f.lightProbe.value=i.state.probe,f.sunLights.value=i.state.sun,f.sunLightShadows.value=i.state.sunShadow,f.directionalLights.value=i.state.directional,f.directionalLightShadows.value=i.state.directionalShadow,f.spotLights.value=i.state.spot,f.spotLightShadows.value=i.state.spotShadow,f.rectAreaLights.value=i.state.rectArea,f.ltc_1.value=i.state.rectAreaLTC1,f.ltc_2.value=i.state.rectAreaLTC2,f.pointLights.value=i.state.point,f.pointLightShadows.value=i.state.pointShadow,f.hemisphereLights.value=i.state.hemi,f.sunShadowMatrix.value=i.state.sunShadowMatrix,f.sunShadowCascade.value=i.state.sunShadowCascade,f.directionalShadowMatrix.value=i.state.directionalShadowMatrix,f.spotLightMatrix.value=i.state.spotLightMatrix,f.spotLightMap.value=i.state.spotLightMap,f.pointShadowMatrix.value=i.state.pointShadowMatrix),r.lightProbeGrid=x.state.lightProbeGridArray.length>0,r.currentProgram=d,r.uniformsList=null,d}function rt(e){if(e.uniformsList===null){let t=e.currentProgram.getUniforms();e.uniformsList=xh.seqWithValue(t.seq,e.uniforms)}return e.uniformsList}function it(e,t){let n=U.get(e);n.outputColorSpace=t.outputColorSpace,n.batching=t.batching,n.batchingColor=t.batchingColor,n.instancing=t.instancing,n.instancingColor=t.instancingColor,n.instancingMorph=t.instancingMorph,n.skinning=t.skinning,n.morphTargets=t.morphTargets,n.morphNormals=t.morphNormals,n.morphColors=t.morphColors,n.morphTargetsCount=t.morphTargetsCount,n.numClippingPlanes=t.numClippingPlanes,n.numIntersection=t.numClipIntersection,n.vertexAlphas=t.vertexAlphas,n.vertexTangents=t.vertexTangents,n.toneMapping=t.toneMapping}function at(e,t){if(e.length===0)return null;if(e.length===1)return e[0].texture===null?null:e[0];y.setFromMatrixPosition(t.matrixWorld);for(let t=0,n=e.length;t<n;t++){let n=e[t];if(n.texture!==null&&n.boundingBox.containsPoint(y))return n}return null}function ot(e,t,n,r,i){t.isScene!==!0&&(t=me),W.resetTextureUnits();let a=t.fog,o=r.isMeshStandardMaterial||r.isMeshLambertMaterial||r.isMeshPhongMaterial?t.environment:null,s=N===null?T.outputColorSpace:N.isXRRenderTarget===!0?N.texture.colorSpace:dl.workingColorSpace,c=r.isMeshStandardMaterial||r.isMeshLambertMaterial&&!r.envMap||r.isMeshPhongMaterial&&!r.envMap,l=xe.get(r.envMap||o,c),u=r.vertexColors===!0&&!!n.attributes.color&&n.attributes.color.itemSize===4,d=!!n.attributes.tangent&&(!!r.normalMap||r.anisotropy>0),f=!!n.morphAttributes.position,p=!!n.morphAttributes.normal,m=!!n.morphAttributes.color,h=0;r.toneMapped&&(N===null||N.isXRRenderTarget===!0)&&(h=T.toneMapping);let g=n.morphAttributes.position||n.morphAttributes.normal||n.morphAttributes.color,_=g===void 0?0:g.length,v=U.get(r),y=x.state.lights;if(le===!0&&(ue===!0||e!==F)){let t=e===F&&r.id===P;ke.setState(r,e,t)}let b=!1;r.version===v.__version?v.needsLights&&v.lightsStateVersion!==y.state.version?b=!0:v.outputColorSpace===s?i.isBatchedMesh&&v.batching===!1||!i.isBatchedMesh&&v.batching===!0||i.isBatchedMesh&&v.batchingColor===!0&&i._colorsTexture===null||i.isBatchedMesh&&v.batchingColor===!1&&i._colorsTexture!==null||i.isInstancedMesh&&v.instancing===!1||!i.isInstancedMesh&&v.instancing===!0||i.isSkinnedMesh&&v.skinning===!1||!i.isSkinnedMesh&&v.skinning===!0||i.isInstancedMesh&&v.instancingColor===!0&&i.instanceColor===null||i.isInstancedMesh&&v.instancingColor===!1&&i.instanceColor!==null||i.isInstancedMesh&&v.instancingMorph===!0&&i.morphTexture===null||i.isInstancedMesh&&v.instancingMorph===!1&&i.morphTexture!==null?b=!0:v.envMap===l?r.fog===!0&&v.fog!==a||v.numClippingPlanes!==void 0&&(v.numClippingPlanes!==ke.numPlanes||v.numIntersection!==ke.numIntersection)?b=!0:v.vertexAlphas===u&&v.vertexTangents===d&&v.morphTargets===f&&v.morphNormals===p&&v.morphColors===m&&v.toneMapping===h&&v.morphTargetsCount===_?!!v.lightProbeGrid!=x.state.lightProbeGridArray.length>0&&(b=!0):b=!0:b=!0:b=!0:(b=!0,v.__version=r.version);let S=v.currentProgram;b===!0&&(S=nt(r,t,i),D&&r.isNodeMaterial&&D.onUpdateProgram(r,S,v));let C=!1,w=!1,E=!1,O=S.getUniforms(),k=v.uniforms;if(H.useProgram(S.program)&&(C=!0,w=!0,E=!0),r.id!==P&&(P=r.id,w=!0),v.needsLights){let e=at(x.state.lightProbeGridArray,i);v.lightProbeGrid!==e&&(v.lightProbeGrid=e,w=!0)}if(C||F!==e){H.buffers.depth.getReversed()&&e.reversedDepth!==!0&&(e._reversedDepth=!0,e.updateProjectionMatrix()),O.setValue(V,`projectionMatrix`,e.projectionMatrix),O.setValue(V,`viewMatrix`,e.matrixWorldInverse);let t=O.map.cameraPosition;t!==void 0&&t.setValue(V,fe.setFromMatrixPosition(e.matrixWorld)),ye.logarithmicDepthBuffer&&O.setValue(V,`logDepthBufFC`,2/(Math.log(e.far+1)/Math.LN2)),(r.isMeshPhongMaterial||r.isMeshToonMaterial||r.isMeshLambertMaterial||r.isMeshBasicMaterial||r.isMeshStandardMaterial||r.isShaderMaterial)&&O.setValue(V,`isOrthographic`,e.isOrthographicCamera===!0),F!==e&&(F=e,w=!0,E=!0)}if(v.needsLights&&(y.state.sunShadowMap.length>0&&O.setValue(V,`sunShadowMap`,y.state.sunShadowMap,W),y.state.directionalShadowMap.length>0&&O.setValue(V,`directionalShadowMap`,y.state.directionalShadowMap,W),y.state.spotShadowMap.length>0&&O.setValue(V,`spotShadowMap`,y.state.spotShadowMap,W),y.state.pointShadowMap.length>0&&O.setValue(V,`pointShadowMap`,y.state.pointShadowMap,W)),i.isSkinnedMesh){O.setOptional(V,i,`bindMatrix`),O.setOptional(V,i,`bindMatrixInverse`);let e=i.skeleton;e&&(e.boneTexture===null&&e.computeBoneTexture(),O.setValue(V,`boneTexture`,e.boneTexture,W))}i.isBatchedMesh&&(O.setOptional(V,i,`batchingTexture`),O.setValue(V,`batchingTexture`,i._matricesTexture,W),O.setOptional(V,i,`batchingIdTexture`),O.setValue(V,`batchingIdTexture`,i._indirectTexture,W),O.setOptional(V,i,`batchingColorTexture`),i._colorsTexture!==null&&O.setValue(V,`batchingColorTexture`,i._colorsTexture,W));let A=n.morphAttributes;if((A.position!==void 0||A.normal!==void 0||A.color!==void 0)&&Me.update(i,n,S),(w||v.receiveShadow!==i.receiveShadow)&&(v.receiveShadow=i.receiveShadow,O.setValue(V,`receiveShadow`,i.receiveShadow)),(r.isMeshStandardMaterial||r.isMeshLambertMaterial||r.isMeshPhongMaterial)&&r.envMap===null&&t.environment!==null&&(k.envMapIntensity.value=t.environmentIntensity),k.dfgLUT!==void 0&&(k.dfgLUT.value=Hg()),w){if(O.setValue(V,`toneMappingExposure`,T.toneMappingExposure),v.needsLights&&st(k,E),a&&r.fog===!0&&Ee.refreshFogUniforms(k,a),Ee.refreshMaterialUniforms(k,r,z,re,x.state.transmissionRenderTarget[e.id]),v.needsLights&&v.lightProbeGrid){let e=v.lightProbeGrid;k.probesSH.value=e.texture,k.probesMin.value.copy(e.boundingBox.min),k.probesMax.value.copy(e.boundingBox.max),k.probesResolution.value.copy(e.resolution)}xh.upload(V,rt(v),k,W)}if(r.isShaderMaterial&&r.uniformsNeedUpdate===!0&&(xh.upload(V,rt(v),k,W),r.uniformsNeedUpdate=!1),r.isSpriteMaterial&&O.setValue(V,`center`,i.center),O.setValue(V,`modelViewMatrix`,i.modelViewMatrix),O.setValue(V,`normalMatrix`,i.normalMatrix),O.setValue(V,`modelMatrix`,i.matrixWorld),r.uniformsGroups!==void 0){let e=r.uniformsGroups;for(let t=0,n=e.length;t<n;t++){let n=e[t];Ie.update(n,S),Ie.bind(n,S)}}return S}function st(e,t){e.ambientLightColor.needsUpdate=t,e.lightProbe.needsUpdate=t,e.sunLights.needsUpdate=t,e.sunLightShadows.needsUpdate=t,e.directionalLights.needsUpdate=t,e.directionalLightShadows.needsUpdate=t,e.pointLights.needsUpdate=t,e.pointLightShadows.needsUpdate=t,e.spotLights.needsUpdate=t,e.spotLightShadows.needsUpdate=t,e.rectAreaLights.needsUpdate=t,e.hemisphereLights.needsUpdate=t}function ct(e){return e.isMeshLambertMaterial||e.isMeshToonMaterial||e.isMeshPhongMaterial||e.isMeshStandardMaterial||e.isShadowMaterial||e.isShaderMaterial&&e.lights===!0}this.getActiveCubeFace=function(){return j},this.getActiveMipmapLevel=function(){return M},this.getRenderTarget=function(){return N},this.setRenderTargetTextures=function(e,t,n){let r=U.get(e);r.__autoAllocateDepthBuffer=e.resolveDepthBuffer===!1,r.__autoAllocateDepthBuffer===!1&&(r.__useRenderToTexture=!1),U.get(e.texture).__webglTexture=t,U.get(e.depthTexture).__webglTexture=r.__autoAllocateDepthBuffer?void 0:n,r.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(e,t){let n=U.get(e);n.__webglFramebuffer=t,n.__useDefaultFramebuffer=t===void 0},this.setRenderTarget=function(e,t=0,n=0){N=e,j=t,M=n;let r=null,i=!1,a=!1;if(e){let o=U.get(e);if(o.__useDefaultFramebuffer!==void 0){H.bindFramebuffer(V.FRAMEBUFFER,o.__webglFramebuffer),I.copy(e.viewport),L.copy(e.scissor),ee=e.scissorTest,H.viewport(I),H.scissor(L),H.setScissorTest(ee),P=-1;return}if(o.__webglFramebuffer===void 0)W.setupRenderTarget(e);else if(o.__hasExternalTextures)W.rebindTextures(e,U.get(e.texture).__webglTexture,U.get(e.depthTexture).__webglTexture);else if(e.depthBuffer){let t=e.depthTexture;if(o.__boundDepthTexture!==t){if(t!==null&&U.has(t)&&(e.width!==t.image.width||e.height!==t.image.height))throw Error(`THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.`);W.setupDepthRenderbuffer(e)}}let s=e.texture;(s.isData3DTexture||s.isDataArrayTexture||s.isCompressedArrayTexture)&&(a=!0);let c=U.get(e).__webglFramebuffer;e.isWebGLCubeRenderTarget?(r=Array.isArray(c[t])?c[t][n]:c[t],i=!0):r=e.samples>0&&W.useMultisampledRTT(e)===!1?U.get(e).__webglMultisampledFramebuffer:Array.isArray(c)?c[n]:c,I.copy(e.viewport),L.copy(e.scissor),ee=e.scissorTest}else I.copy(ae).multiplyScalar(z).floor(),L.copy(oe).multiplyScalar(z).floor(),ee=se;if(n!==0&&(r=O),H.bindFramebuffer(V.FRAMEBUFFER,r)&&H.drawBuffers(e,r),H.viewport(I),H.scissor(L),H.setScissorTest(ee),i){let r=U.get(e.texture);V.framebufferTexture2D(V.FRAMEBUFFER,V.COLOR_ATTACHMENT0,V.TEXTURE_CUBE_MAP_POSITIVE_X+t,r.__webglTexture,n)}else if(a){let r=t;for(let t=0;t<e.textures.length;t++){let i=U.get(e.textures[t]);V.framebufferTextureLayer(V.FRAMEBUFFER,V.COLOR_ATTACHMENT0+t,i.__webglTexture,n,r)}}else if(e!==null&&n!==0){let t=U.get(e.texture);V.framebufferTexture2D(V.FRAMEBUFFER,V.COLOR_ATTACHMENT0,V.TEXTURE_2D,t.__webglTexture,n)}P=-1};function lt(e){let t=U.get(e);return(t.__readFormat!==e.format||t.__readType!==e.type)&&(t.__readFormat=e.format,t.__readType=e.type,t.__formatReadable=ye.textureFormatReadable(e.format),t.__typeReadable=ye.textureTypeReadable(e.type)),t}this.readRenderTargetPixels=function(e,t,n,r,i,a,o,s=0){if(!(e&&e.isWebGLRenderTarget)){J(`WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.`);return}let c=U.get(e).__webglFramebuffer;if(e.isWebGLCubeRenderTarget&&o!==void 0&&(c=c[o]),c){H.bindFramebuffer(V.FRAMEBUFFER,c);try{let o=e.textures[s],c=o.format,l=o.type;e.textures.length>1&&V.readBuffer(V.COLOR_ATTACHMENT0+s);let u=lt(o);if(u.__formatReadable===!1){J(`WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.`);return}if(u.__typeReadable===!1){J(`WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.`);return}t>=0&&t<=e.width-r&&n>=0&&n<=e.height-i&&V.readPixels(t,n,r,i,G.convert(c),G.convert(l),a)}finally{let e=N===null?null:U.get(N).__webglFramebuffer;H.bindFramebuffer(V.FRAMEBUFFER,e)}}},this.readRenderTargetPixelsAsync=async function(e,t,n,r,i,a,o,s=0){if(!(e&&e.isWebGLRenderTarget))throw Error(`THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.`);let c=U.get(e).__webglFramebuffer;if(e.isWebGLCubeRenderTarget&&o!==void 0&&(c=c[o]),c){if(t>=0&&t<=e.width-r&&n>=0&&n<=e.height-i){H.bindFramebuffer(V.FRAMEBUFFER,c);let o=e.textures[s],l=o.format,u=o.type;e.textures.length>1&&V.readBuffer(V.COLOR_ATTACHMENT0+s);let d=lt(o);if(d.__formatReadable===!1)throw Error(`THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.`);if(d.__typeReadable===!1)throw Error(`THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.`);let f=V.createBuffer();V.bindBuffer(V.PIXEL_PACK_BUFFER,f),V.bufferData(V.PIXEL_PACK_BUFFER,a.byteLength,V.STREAM_READ),V.readPixels(t,n,r,i,G.convert(l),G.convert(u),0),V.bindBuffer(V.PIXEL_PACK_BUFFER,null);let p=N===null?null:U.get(N).__webglFramebuffer;H.bindFramebuffer(V.FRAMEBUFFER,p);let m=V.fenceSync(V.SYNC_GPU_COMMANDS_COMPLETE,0);return V.flush(),await Kc(V,m,4),V.bindBuffer(V.PIXEL_PACK_BUFFER,f),V.getBufferSubData(V.PIXEL_PACK_BUFFER,0,a),V.bindBuffer(V.PIXEL_PACK_BUFFER,null),V.deleteBuffer(f),V.deleteSync(m),a}throw Error(`THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.`)}},this.copyFramebufferToTexture=function(e,t=null,n=0){let r=2**-n,i=Math.floor(e.image.width*r),a=Math.floor(e.image.height*r),o=t===null?0:t.x,s=t===null?0:t.y;W.setTexture2D(e,0),V.copyTexSubImage2D(V.TEXTURE_2D,n,0,0,o,s,i,a),H.unbindTexture()},this.copyTextureToTexture=function(e,t,n=null,r=null,i=0,a=0){let o,s,c,l,u,d,f,p,m,h=e.isCompressedTexture?e.mipmaps[a]:e.image;if(n!==null)o=n.max.x-n.min.x,s=n.max.y-n.min.y,c=n.isBox3?n.max.z-n.min.z:1,l=n.min.x,u=n.min.y,d=n.isBox3?n.min.z:0;else{let t=2**-i;o=Math.floor(h.width*t),s=Math.floor(h.height*t),c=e.isDataArrayTexture?h.depth:e.isData3DTexture?Math.floor(h.depth*t):1,l=0,u=0,d=0}r===null?(f=0,p=0,m=0):(f=r.x,p=r.y,m=r.z);let g=G.convert(t.format),_=G.convert(t.type),v;t.isData3DTexture?(W.setTexture3D(t,0),v=V.TEXTURE_3D):t.isDataArrayTexture||t.isCompressedArrayTexture?(W.setTexture2DArray(t,0),v=V.TEXTURE_2D_ARRAY):(W.setTexture2D(t,0),v=V.TEXTURE_2D),H.activeTexture(V.TEXTURE0),H.pixelStorei(V.UNPACK_FLIP_Y_WEBGL,t.flipY),H.pixelStorei(V.UNPACK_PREMULTIPLY_ALPHA_WEBGL,t.premultiplyAlpha),H.pixelStorei(V.UNPACK_ALIGNMENT,t.unpackAlignment);let y=H.getParameter(V.UNPACK_ROW_LENGTH),b=H.getParameter(V.UNPACK_IMAGE_HEIGHT),x=H.getParameter(V.UNPACK_SKIP_PIXELS),S=H.getParameter(V.UNPACK_SKIP_ROWS),C=H.getParameter(V.UNPACK_SKIP_IMAGES);H.pixelStorei(V.UNPACK_ROW_LENGTH,h.width),H.pixelStorei(V.UNPACK_IMAGE_HEIGHT,h.height),H.pixelStorei(V.UNPACK_SKIP_PIXELS,l),H.pixelStorei(V.UNPACK_SKIP_ROWS,u),H.pixelStorei(V.UNPACK_SKIP_IMAGES,d);let w=e.isDataArrayTexture||e.isData3DTexture,T=t.isDataArrayTexture||t.isData3DTexture;if(e.isDepthTexture){let n=U.get(e),r=U.get(t),h=U.get(n.__renderTarget),g=U.get(r.__renderTarget);H.bindFramebuffer(V.READ_FRAMEBUFFER,h.__webglFramebuffer),H.bindFramebuffer(V.DRAW_FRAMEBUFFER,g.__webglFramebuffer);for(let n=0;n<c;n++)w&&(V.framebufferTextureLayer(V.READ_FRAMEBUFFER,V.COLOR_ATTACHMENT0,U.get(e).__webglTexture,i,d+n),V.framebufferTextureLayer(V.DRAW_FRAMEBUFFER,V.COLOR_ATTACHMENT0,U.get(t).__webglTexture,a,m+n)),V.blitFramebuffer(l,u,o,s,f,p,o,s,V.DEPTH_BUFFER_BIT,V.NEAREST);H.bindFramebuffer(V.READ_FRAMEBUFFER,null),H.bindFramebuffer(V.DRAW_FRAMEBUFFER,null)}else if(i!==0||e.isRenderTargetTexture||U.has(e)){let n=U.get(e),r=U.get(t);H.bindFramebuffer(V.READ_FRAMEBUFFER,k),H.bindFramebuffer(V.DRAW_FRAMEBUFFER,A);for(let e=0;e<c;e++)w?V.framebufferTextureLayer(V.READ_FRAMEBUFFER,V.COLOR_ATTACHMENT0,n.__webglTexture,i,d+e):V.framebufferTexture2D(V.READ_FRAMEBUFFER,V.COLOR_ATTACHMENT0,V.TEXTURE_2D,n.__webglTexture,i),T?V.framebufferTextureLayer(V.DRAW_FRAMEBUFFER,V.COLOR_ATTACHMENT0,r.__webglTexture,a,m+e):V.framebufferTexture2D(V.DRAW_FRAMEBUFFER,V.COLOR_ATTACHMENT0,V.TEXTURE_2D,r.__webglTexture,a),i===0?T?V.copyTexSubImage3D(v,a,f,p,m+e,l,u,o,s):V.copyTexSubImage2D(v,a,f,p,l,u,o,s):V.blitFramebuffer(l,u,o,s,f,p,o,s,V.COLOR_BUFFER_BIT,V.NEAREST);H.bindFramebuffer(V.READ_FRAMEBUFFER,null),H.bindFramebuffer(V.DRAW_FRAMEBUFFER,null)}else T?e.isDataTexture||e.isData3DTexture?V.texSubImage3D(v,a,f,p,m,o,s,c,g,_,h.data):t.isCompressedArrayTexture?V.compressedTexSubImage3D(v,a,f,p,m,o,s,c,g,h.data):V.texSubImage3D(v,a,f,p,m,o,s,c,g,_,h):e.isDataTexture?V.texSubImage2D(V.TEXTURE_2D,a,f,p,o,s,g,_,h.data):e.isCompressedTexture?V.compressedTexSubImage2D(V.TEXTURE_2D,a,f,p,h.width,h.height,g,h.data):V.texSubImage2D(V.TEXTURE_2D,a,f,p,o,s,g,_,h);H.pixelStorei(V.UNPACK_ROW_LENGTH,y),H.pixelStorei(V.UNPACK_IMAGE_HEIGHT,b),H.pixelStorei(V.UNPACK_SKIP_PIXELS,x),H.pixelStorei(V.UNPACK_SKIP_ROWS,S),H.pixelStorei(V.UNPACK_SKIP_IMAGES,C),a===0&&t.generateMipmaps&&V.generateMipmap(v),H.unbindTexture()},this.initRenderTarget=function(e){U.get(e).__webglFramebuffer===void 0&&W.setupRenderTarget(e)},this.initTexture=function(e){e.isCubeTexture?W.setTextureCube(e,0):e.isData3DTexture?W.setTexture3D(e,0):e.isDataArrayTexture||e.isCompressedArrayTexture?W.setTexture2DArray(e,0):W.setTexture2D(e,0),H.unbindTexture()},this.resetState=function(){j=0,M=0,N=null,H.reset(),Fe.reset()},typeof __THREE_DEVTOOLS__<`u`&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent(`observe`,{detail:this}))}get coordinateSystem(){return Lc}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;let t=this.getContext();t.drawingBufferColorSpace=dl._getDrawingBufferColorSpace(e),t.unpackColorSpace=dl._getUnpackColorSpace()}},Wg=e=>1-(1-e)**4,Gg=1100;function Kg(e){return getComputedStyle(document.documentElement).getPropertyValue(e).trim()}function qg(){let e=document.documentElement.getAttribute(`data-theme`);return e===`night`||e===`dark`?!0:e===`day`||e===`light`?!1:window.matchMedia(`(prefers-color-scheme: dark)`).matches}function Jg(){let e=qg(),t={ink1:`--color-ink-1`,ink2:`--color-ink-2`,ink3:`--color-ink-3`,accent:`--color-accent-base`,soft:`--color-accent-soft`,fire:`--color-lamp-fire`,prime:`--color-lamp-prime`,inhibit:`--color-lamp-inhibit`,cost:`--color-cost`,line:`--color-ink-3`},n={};for(let e of Object.keys(t)){let r=Kg(t[e]);n[e]=new cu(r&&r.startsWith(`#`)?r:`#8b8e9c`)}return{dark:e,role:n,hue:t=>new cu().setHSL(t/360,e?.55:.5,e?.68:.42),css:e=>`#${n[e].getHexString()}`}}function Yg(){let e=document.createElement(`canvas`);e.width=e.height=64;let t=e.getContext(`2d`);if(t){let e=t.createRadialGradient(32,32,0,32,32,32);e.addColorStop(0,`rgba(255,255,255,1)`),e.addColorStop(.25,`rgba(255,255,255,0.45)`),e.addColorStop(1,`rgba(255,255,255,0)`),t.fillStyle=e,t.fillRect(0,0,64,64)}return new gf(e)}function Xg(){try{let e=document.createElement(`canvas`);return!!(e.getContext(`webgl2`)??e.getContext(`webgl`))}catch{return!1}}var Zg=class{canvas;layer;palette;pal;renderer;scene=new uu;camera=new sp(40,1,.1,400);tex=Yg();dots=new Map;links=new Map;labels=new Map;camFrom={target:[0,0,0],yaw:0,pitch:.5,dist:20};camTo=this.camFrom;camCur=this.camFrom;user={yaw:0,pitch:0,zoom:1};t0=0;dur=0;raf=0;dragging=null;last=null;reduced=window.matchMedia(`(prefers-reduced-motion: reduce)`).matches;cleanup=[];tmp=new X;onRetheme=null;inset=0;constructor(e,t){this.canvas=e,this.layer=t,this.renderer=new Ug({canvas:e,antialias:!0,alpha:!0}),this.renderer.setPixelRatio(Math.min(2,window.devicePixelRatio||1)),this.pal=Jg(),this.palette=()=>this.pal;let n=(e,t,n,r)=>{e.addEventListener(t,n,r),this.cleanup.push(()=>e.removeEventListener(t,n,r))};n(e,`pointerdown`,t=>{this.dragging={x:t.clientX,y:t.clientY,yaw:this.user.yaw,pitch:this.user.pitch,touch:t.pointerType===`touch`},e.setPointerCapture(t.pointerId)}),n(e,`pointermove`,e=>{let t=this.dragging;t&&(this.user.yaw=t.yaw-(e.clientX-t.x)*.006,t.touch||(this.user.pitch=Math.max(-.5,Math.min(.7,t.pitch+(e.clientY-t.y)*.004))),this.kick())});let r=()=>this.dragging=null;n(e,`pointerup`,r),n(e,`pointercancel`,r),n(e,`wheel`,e=>{e.preventDefault(),this.user.zoom=Math.max(.55,Math.min(1.7,this.user.zoom*(1+e.deltaY*.001))),this.kick()},{passive:!1}),n(e,`dblclick`,()=>this.resetView());let i=new ResizeObserver(()=>this.kick());i.observe(e),this.cleanup.push(()=>i.disconnect());let a=window.matchMedia(`(prefers-color-scheme: dark)`),o=()=>this.retheme();a.addEventListener(`change`,o),this.cleanup.push(()=>a.removeEventListener(`change`,o));let s=new MutationObserver(o);s.observe(document.documentElement,{attributes:!0,attributeFilter:[`data-theme`]}),this.cleanup.push(()=>s.disconnect())}onTheme(e){this.onRetheme=e}setInset(e){Math.abs(e-this.inset)<1||(this.inset=e,this.kick())}resetView(){this.user={yaw:0,pitch:0,zoom:1},this.kick()}dot(e,t=.17){let n=new qd(new Sf(t,20,14),new Fd({color:16777215,transparent:!0,opacity:0})),r=new Od(new md({map:this.tex,transparent:!0,depthWrite:!1,blending:this.pal.dark?2:1,opacity:0}));n.visible=r.visible=!1,this.scene.add(n,r),this.dots.set(e,{id:e,mesh:n,glow:r,size:t,cur:null,from:null,to:null})}link(e,t,n=`line`){let r=new id;r.setAttribute(`position`,new Uu(new Float32Array(Math.max(1,t.length)*6),3));let i=new tf({color:this.pal.role[n],transparent:!0,opacity:0,depthWrite:!1}),a=new mf(r,i);a.visible=!1,this.scene.add(a),this.links.set(e,{pairs:t,geo:r,mat:i,obj:a,role:n,op:0,from:0,to:0})}label(e,t,n,r={}){let i=document.createElement(`div`);return i.className=`how-label ${r.cls??``}`,i.innerHTML=t,i.style.opacity=`0`,this.layer.appendChild(i),this.labels.set(e,{id:e,el:i,anchor:n,dx:r.dx??0,dy:r.dy??0,center:r.center??!1,on:!1}),i}clear(){for(let e of this.dots.values())this.scene.remove(e.mesh,e.glow),e.mesh.geometry.dispose(),e.mesh.material.dispose(),e.glow.material.dispose();for(let e of this.links.values())this.scene.remove(e.obj),e.geo.dispose(),e.mat.dispose();for(let e of this.labels.values())e.el.remove();this.dots.clear(),this.links.clear(),this.labels.clear(),this.last=null,this.resetView()}look(e){let t=e.color,n=typeof t==`string`?this.pal.role[t].clone():t instanceof cu?t.clone():this.pal.hue(t.hue);return{pos:new X(...e.pos),color:n,alpha:e.alpha??1,scale:e.scale??1,glow:e.glow??.18}}to(e,t=!1){this.last=e;for(let t of this.dots.values()){let n=e.dots[t.id],r=n?this.look(n):t.cur?{...t.cur,pos:t.cur.pos.clone(),color:t.cur.color.clone(),alpha:0,glow:0}:null;r&&(t.cur||={...r,pos:r.pos.clone(),color:r.color.clone(),alpha:0,glow:0},t.from={...t.cur,pos:t.cur.pos.clone(),color:t.cur.color.clone()},t.to=r)}for(let[t,n]of this.links)n.from=n.op,n.to=e.links?.[t]??0;let n=new Set(e.labels??[]);for(let e of this.labels.values())e.on=n.has(e.id);this.camFrom={...this.camCur,target:[...this.camCur.target]},this.camTo=e.cam,this.t0=performance.now(),this.dur=t||this.reduced?0:Gg,this.kick()}retheme(){this.pal=Jg();let e=this.pal.dark?2:1;for(let t of this.dots.values())t.glow.material.blending=e,t.glow.material.needsUpdate=!0;for(let e of this.links.values())e.mat.color.copy(this.pal.role[e.role]);this.last&&this.to(this.last,!0),this.onRetheme?.()}kick(){this.raf||=requestAnimationFrame(e=>this.frame(e))}endPos(e){return typeof e==`string`?this.dots.get(e)?.mesh.position??this.tmp.set(0,0,0):new X(...e)}frame(e){this.raf=0;let t=this.canvas.clientWidth,n=this.canvas.clientHeight;if(!t||!n)return;let r=this.renderer.getPixelRatio();(this.canvas.width!==Math.floor(t*r)||this.canvas.height!==Math.floor(n*r))&&(this.renderer.setSize(t,n,!1),this.camera.aspect=t/n,this.camera.updateProjectionMatrix());let i=this.dur?Wg(Math.min(1,(e-this.t0)/this.dur)):1,a=(e,t)=>e+(t-e)*i,o=this.pal.dark?1:.5;for(let e of this.dots.values()){if(!e.from||!e.to||!e.cur)continue;let t=e.cur;t.pos.lerpVectors(e.from.pos,e.to.pos,i),t.color.copy(e.from.color).lerp(e.to.color,i),t.alpha=a(e.from.alpha,e.to.alpha),t.scale=a(e.from.scale,e.to.scale),t.glow=a(e.from.glow,e.to.glow);let n=t.alpha>.01;e.mesh.visible=n,e.glow.visible=n&&t.glow>.01,e.mesh.position.copy(t.pos),e.mesh.scale.setScalar(t.scale),e.mesh.material.color.copy(t.color),e.mesh.material.opacity=t.alpha,e.glow.position.copy(t.pos),e.glow.scale.setScalar(e.size*7.6*t.scale),e.glow.material.color.copy(t.color),e.glow.material.opacity=t.glow*o}for(let e of this.links.values()){if(e.op=a(e.from,e.to),e.mat.opacity=e.op,e.obj.visible=e.op>.005,!e.obj.visible)continue;let t=e.geo.attributes.position.array;e.pairs.forEach(([e,n],r)=>{let i=this.endPos(e);t[r*6]=i.x,t[r*6+1]=i.y,t[r*6+2]=i.z;let a=this.endPos(n);t[r*6+3]=a.x,t[r*6+4]=a.y,t[r*6+5]=a.z}),e.geo.attributes.position.needsUpdate=!0}let s=this.camFrom,c=this.camTo,l={target:[a(s.target[0],c.target[0]),a(s.target[1],c.target[1]),a(s.target[2],c.target[2])],yaw:a(s.yaw,c.yaw),pitch:a(s.pitch,c.pitch),dist:a(s.dist,c.dist)};this.camCur=l;let u=l.yaw+this.user.yaw,d=l.pitch+this.user.pitch,f=this.inset>0&&this.inset<t*.6?Math.min(1.3,t/(t-this.inset)):1,p=l.dist*this.user.zoom*(t<640?1.6:f);this.camera.position.set(l.target[0]+p*Math.cos(d)*Math.sin(u),l.target[1]+p*Math.sin(d),l.target[2]+p*Math.cos(d)*Math.cos(u)),this.camera.lookAt(...l.target),this.inset>0&&this.inset<t*.6?this.camera.setViewOffset(t,n,-this.inset/2,0,t,n):this.camera.clearViewOffset(),this.renderer.render(this.scene,this.camera);for(let e of this.labels.values()){let r=this.tmp.copy(this.endPos(e.anchor)).project(this.camera),i=e.on&&r.z<1;if(e.el.style.opacity=i?`1`:`0`,i){let i=(r.x*.5+.5)*t+e.dx,a=(-r.y*.5+.5)*n+e.dy;e.el.style.transform=`translate(${i}px, ${a}px)${e.center?` translateX(-50%)`:``}`}}(i<1||this.dragging)&&this.kick()}dispose(){cancelAnimationFrame(this.raf),this.clear();for(let e of this.cleanup)e();this.tex.dispose(),this.renderer.dispose()}},Qg=e({default:()=>t_}),$g=5200,e_=`adage.how.detail`;function t_({graph:e}){let[t,n]=je(),r=ts(t.ch),i=$o[r],a=(0,s.useRef)(null),o=(0,s.useRef)(null),c=(0,s.useRef)(null),l=(0,s.useRef)(null),[u,d]=(0,s.useState)(null),[f]=(0,s.useState)(()=>Xg()),[p,m]=(0,s.useState)(null),[h,g]=(0,s.useState)(!1),[_,v]=(0,s.useState)(0),y=i.usesRepo&&!!e?.routes.length,[b,x]=(0,s.useState)(!0),S=y&&b,[C,w]=(0,s.useState)(()=>{try{return localStorage.getItem(e_)===`open`}catch{return!1}}),T=(0,s.useCallback)(e=>{w(e);try{localStorage.setItem(e_,e?`open`:`closed`)}catch{}},[]);(0,s.useEffect)(()=>{if(!f||!a.current||!o.current)return;let e;try{e=new Zg(a.current,o.current)}catch{return}return e.onTheme(()=>v(e=>e+1)),d(e),()=>e.dispose()},[f]),(0,s.useEffect)(()=>{let e=l.current;if(!u||!e)return;let t=()=>u.setInset(getComputedStyle(e).position===`absolute`?e.offsetLeft+e.offsetWidth:0),n=new ResizeObserver(t);return n.observe(e),t(),()=>n.disconnect()},[u]);let E=S?e?.generation:null;(0,s.useEffect)(()=>{let t=u??n_;t.clear(),m(i.build(t,{graph:e,repo:S}))},[u,i,S,E]);let D=p?.steps??[],O=Math.min(Math.max(0,t.step),Math.max(0,D.length-1)),k=D[O];(0,s.useEffect)(()=>{u&&k&&u.to(k.state)},[u,k]),(0,s.useEffect)(()=>{let e=c.current;if(!e||!k?.figure)return;let t=Math.min(2,window.devicePixelRatio||1),n=e.clientWidth,r=e.clientHeight;e.width=n*t,e.height=r*t;let i=e.getContext(`2d`);i&&(i.setTransform(t,0,0,t,0,0),i.clearRect(0,0,n,r),k.figure(i,n,r,u?.palette()??Jg()))},[k,u,_,C]);let A=(0,s.useCallback)((e,t,r=!1)=>{let i=$o[(e+$o.length)%$o.length];n({ch:i.id,step:Math.max(0,t)},r)},[n]),j=(0,s.useCallback)(()=>{O<D.length-1?A(r,O+1):r<$o.length-1?A(r+1,0):g(!1)},[O,D.length,r,A]),M=(0,s.useCallback)(()=>{O>0?A(r,O-1):r>0&&A(r-1,999)},[O,r,A]);(0,s.useEffect)(()=>{t.step>=999&&D.length&&n({step:D.length-1})},[t.step,D.length,n]),(0,s.useEffect)(()=>{if(!h)return;let e=window.setTimeout(j,$g);return()=>window.clearTimeout(e)},[h,j,O,r]),(0,s.useEffect)(()=>{let e=e=>{let t=e.detail;t===`next`&&(g(!1),j()),t===`prev`&&(g(!1),M()),t===`toggle`&&g(e=>!e)};return window.addEventListener(`adage-how`,e),()=>window.removeEventListener(`adage-how`,e)},[j,M]);let N=(0,s.useMemo)(()=>{let e=u?.palette()??Jg();return(p?.legend??[]).map(t=>({label:t.label,color:t.role===`hue`?`#${e.hue(t.hue??0).getHexString()}`:e.css(t.role)}))},[p,u,_]);return(0,G.jsxs)(`main`,{className:`grid min-h-0 grow grid-cols-1 overflow-y-auto lg:grid-cols-[260px_minmax(0,1fr)] lg:overflow-hidden`,"aria-labelledby":`how-title`,children:[(0,G.jsxs)(`nav`,{"aria-label":`Chapters`,className:`border-b border-line p-4 lg:overflow-y-auto lg:border-r lg:border-b-0`,children:[(0,G.jsx)(`h1`,{id:`how-title`,className:`m-0 mb-3 font-mono text-[11px] font-medium tracking-[0.14em] text-ink-3 uppercase`,children:`How it works · traces to reflexes`}),(0,G.jsxs)(`label`,{className:`flex items-center gap-2 lg:hidden`,children:[(0,G.jsx)(`span`,{className:`sr-only`,children:`Chapter`}),(0,G.jsx)(`select`,{value:i.id,onChange:e=>(g(!1),A($o.findIndex(t=>t.id===e.target.value),0,!0)),className:`h-9 w-full rounded-lg border border-line-strong bg-raised px-2 text-sm text-ink-1`,children:$o.map((e,t)=>(0,G.jsxs)(`option`,{value:e.id,children:[String(t+1).padStart(2,`0`),` `,e.title]},e.id))})]}),(0,G.jsx)(`ol`,{className:`m-0 hidden list-none gap-0.5 p-0 lg:grid`,children:$o.map((e,t)=>(0,G.jsx)(`li`,{children:(0,G.jsxs)(`button`,{type:`button`,onClick:()=>(g(!1),A(t,0,!0)),"aria-current":t===r?`step`:void 0,className:Ke(`grid w-full grid-cols-[22px_1fr] gap-x-2 rounded-lg px-2.5 py-2 text-left`,t===r?`bg-raised text-ink-1 shadow-[inset_0_0_0_1px_var(--color-line-strong)]`:`text-ink-2 hover:bg-raised hover:text-ink-1`),children:[(0,G.jsx)(`span`,{className:`pt-0.5 font-mono text-xs text-ink-3 tabular-nums`,children:String(t+1).padStart(2,`0`)}),(0,G.jsx)(`span`,{className:`text-sm font-semibold`,children:e.title}),(0,G.jsx)(`span`,{className:Ke(`col-start-2 font-mono text-[11px]`,e.kind===`flag`?`text-prime`:`text-ink-3`),children:e.kind===`flag`?e.status:e.technical})]})},e.id))}),(0,G.jsx)(`p`,{className:`mt-4 mb-0 hidden max-w-[32ch] text-[13px] text-ink-3 lg:block`,children:`Every chapter describes Adage as it ships: the graph engine is the only learner, and it is on by default.`})]}),(0,G.jsxs)(`section`,{"aria-label":`${i.title}: step ${O+1} of ${D.length}`,className:`relative flex min-h-[560px] flex-col lg:min-h-0`,children:[(0,G.jsxs)(`div`,{className:`relative flex grow flex-col overflow-hidden bg-[radial-gradient(120%_90%_at_70%_20%,color-mix(in_oklab,var(--color-accent-base)_9%,transparent),transparent_60%)] sm:min-h-[380px]`,children:[(0,G.jsxs)(`div`,{className:`relative h-[360px] flex-none sm:absolute sm:inset-0 sm:h-auto`,children:[f?(0,G.jsxs)(G.Fragment,{children:[(0,G.jsx)(`canvas`,{ref:a,className:`absolute inset-0 block h-full w-full cursor-grab touch-pan-y active:cursor-grabbing`,"aria-hidden":`true`}),(0,G.jsx)(`div`,{ref:o,className:`pointer-events-none absolute inset-0 overflow-hidden`,"aria-hidden":`true`})]}):(0,G.jsx)(`p`,{className:`absolute inset-0 m-0 grid place-items-center p-8 text-center text-sm text-ink-3`,children:`This view draws in 3D with WebGL, which this browser has turned off. Every step still reads below.`}),(0,G.jsxs)(`div`,{className:`absolute top-3 right-3 flex flex-col items-end gap-2 sm:top-4 sm:right-4`,children:[(0,G.jsx)(Qe,{label:`Whose traces`,size:`sm`,value:S?`repo`:`sample`,onChange:e=>x(e===`repo`),options:[{value:`sample`,label:`Sample traces`},{value:`repo`,label:`This repository`,title:y?`Replay this chapter with this repository's reflexes`:`This chapter shows sample traces; the map does not read raw traces`}]}),!y&&(0,G.jsx)(`span`,{className:`font-mono text-[11px] text-ink-3`,children:i.usesRepo?`no reflexes here yet`:`sample traces in this chapter`}),N.length>0&&(0,G.jsx)(`ul`,{className:`m-0 hidden list-none gap-1 rounded-lg border border-line bg-[color-mix(in_oklab,var(--color-bg-panel)_80%,transparent)] p-2.5 font-mono text-[11px] text-ink-2 sm:grid`,"aria-label":`Legend`,children:N.map(e=>(0,G.jsxs)(`li`,{children:[(0,G.jsx)(`span`,{className:`mr-1.5 inline-block size-2 rounded-full`,style:{background:e.color}}),e.label]},e.label))})]})]}),(0,G.jsx)(`div`,{ref:l,className:`sm:absolute sm:top-4 sm:left-4 sm:w-[min(420px,calc(100%-32px))]`,children:(0,G.jsx)(r_,{chapter:r,step:O,total:D.length,built:p,figRef:c,more:C,setMore:T})})]}),(0,G.jsx)(i_,{steps:D.map(e=>e.title),step:O,playing:h,onStep:e=>(g(!1),A(r,e)),onPrev:()=>(g(!1),M()),onNext:()=>(g(!1),j()),onPlay:()=>g(e=>!e)})]})]})}var n_={dot(){},link(){},label(){return document.createElement(`div`)},clear(){},to(){},palette:()=>Jg()};function r_({chapter:e,step:t,total:n,built:r,figRef:i,more:a,setMore:o}){let c=$o[e],l=r?.steps[t],{setTip:u,node:d}=bt(),[f,p]=(0,s.useMemo)(()=>{let e=new Set;return[cs(l?.plain??``,e),cs(l?.body??``,e)]},[l]);return(0,G.jsxs)(`div`,{"aria-live":`polite`,className:`m-3 grid gap-2 rounded-xl border border-line-strong bg-[color-mix(in_oklab,var(--color-bg-panel)_84%,transparent)] p-4 backdrop-blur-md sm:m-0`,children:[(0,G.jsxs)(`div`,{className:`flex flex-wrap gap-x-2.5 gap-y-1 font-mono text-[11px] tracking-[0.1em] text-ink-3 uppercase`,children:[(0,G.jsxs)(`span`,{children:[String(e+1).padStart(2,`0`),` `,c.title]}),(0,G.jsxs)(`span`,{children:[`· step `,t+1,` of `,n]}),(0,G.jsxs)(`span`,{className:c.kind===`flag`?`text-prime`:void 0,children:[`· `,r?.source??``]})]}),(0,G.jsx)(`h2`,{className:`display m-0 text-[22px] leading-[1.15] font-semibold text-balance`,children:l?.title}),(0,G.jsx)(`p`,{className:`m-0 text-[15px] leading-normal text-ink-1`,children:(0,G.jsx)(xt,{parts:f,onTip:u})}),a&&(0,G.jsxs)(`div`,{id:`how-more`,className:`grid gap-2 border-t border-dashed border-line-strong pt-2`,children:[(0,G.jsx)(`p`,{className:`m-0 text-sm text-ink-2`,children:(0,G.jsx)(xt,{parts:p,onTip:u})}),l?.figure&&(0,G.jsx)(`canvas`,{ref:i,className:`block h-24 w-full`,role:`img`,"aria-label":`Figure: ${l.title}`}),(0,G.jsx)(`div`,{className:`flex flex-wrap gap-1.5`,children:l?.chips.map(e=>(0,G.jsxs)(`span`,{className:`rounded-md border border-line bg-raised px-1.5 py-0.5 font-mono text-[11.5px] text-ink-1 tabular-nums`,children:[rs(e)&&(0,G.jsxs)(`span`,{className:e.ok?`text-fire`:`text-inhibit`,children:[rs(e),` `]}),ns(e)]},e.text))})]}),(0,G.jsx)(`div`,{children:(0,G.jsxs)(`button`,{type:`button`,"aria-expanded":a,"aria-controls":`how-more`,onClick:()=>o(!a),className:`inline-flex items-center gap-1.5 rounded-full border border-line-strong bg-raised px-3 py-1 text-[13px] font-semibold text-ink-1 hover:border-accent`,children:[a?`Less detail`:`More detail`,(0,G.jsx)(`svg`,{viewBox:`0 0 12 12`,"aria-hidden":`true`,className:Ke(`size-3 fill-none stroke-current stroke-[1.6]`,a&&`rotate-180`),children:(0,G.jsx)(`path`,{d:`M2.5 4.5 6 8l3.5-3.5`,strokeLinecap:`round`,strokeLinejoin:`round`})})]})}),d]})}function i_(e){let t=`grid size-9 flex-none place-items-center rounded-lg border border-line-strong bg-raised hover:border-accent`;return(0,G.jsxs)(`div`,{className:`flex items-center gap-2.5 border-t border-line bg-panel px-3 py-2`,children:[(0,G.jsx)(`button`,{type:`button`,className:t,onClick:e.onPrev,"aria-label":`Previous step`,children:(0,G.jsx)(`svg`,{viewBox:`0 0 16 16`,className:`size-3.5 fill-ink-1`,"aria-hidden":`true`,children:(0,G.jsx)(`path`,{d:`M11 2 4 8l7 6z`})})}),(0,G.jsx)(`button`,{type:`button`,className:t,onClick:e.onPlay,"aria-label":e.playing?`Pause`:`Play`,children:(0,G.jsx)(`svg`,{viewBox:`0 0 16 16`,className:`size-3.5 fill-ink-1`,"aria-hidden":`true`,children:e.playing?(0,G.jsx)(`path`,{d:`M3 2h4v12H3zM9 2h4v12H9z`}):(0,G.jsx)(`path`,{d:`M4 2l10 6-10 6z`})})}),(0,G.jsx)(`button`,{type:`button`,className:t,onClick:e.onNext,"aria-label":`Next step`,children:(0,G.jsx)(`svg`,{viewBox:`0 0 16 16`,className:`size-3.5 fill-ink-1`,"aria-hidden":`true`,children:(0,G.jsx)(`path`,{d:`M5 2l7 6-7 6z`})})}),(0,G.jsx)(`ol`,{className:`m-0 flex min-w-0 grow list-none p-0`,"aria-label":`Steps`,children:e.steps.map((t,n)=>(0,G.jsx)(`li`,{className:`min-w-0 flex-1`,children:(0,G.jsx)(`button`,{type:`button`,onClick:()=>e.onStep(n),"aria-label":`Step ${n+1}: ${t}`,"aria-current":n===e.step?`step`:void 0,title:`${n+1} · ${t}`,className:`group relative h-9 w-full`,children:(0,G.jsx)(`span`,{className:Ke(`absolute inset-x-0.5 top-1/2 -translate-y-1/2 rounded-sm transition-colors`,n===e.step?`h-[5px] bg-accent`:n<e.step?`h-[3px] bg-[color-mix(in_oklab,var(--color-accent-base)_55%,transparent)]`:`h-[3px] bg-line-strong`)})})},t))}),(0,G.jsxs)(`span`,{className:`flex-none text-right font-mono text-xs whitespace-nowrap text-ink-2 tabular-nums`,children:[e.step+1,` / `,e.steps.length]})]})}export{b as $,xe as A,fe as B,Be as C,ze as D,Re as E,be as F,m as G,me as H,he as I,M as J,C as K,de as L,Me as M,_e as N,Ve as O,U as P,S as Q,ye as R,Ie as S,Ue as T,L as U,ue as V,I as W,E as X,T as Y,j as Z,at as _,f as _t,_t as a,F as at,Le as b,o as bt,Ze as c,se as ct,Ye as d,P as dt,x as et,lt as f,te as ft,ft as g,d as gt,rt as h,u as ht,ht as i,ie as it,je as j,Pe as k,Xe as l,w as lt,Je as m,N as mt,vt as n,y as nt,mt as o,oe as ot,Qe as p,R as pt,A as q,gt as r,B as rt,ot as s,re as st,Qg as t,k as tt,ct as u,_ as ut,Ke as v,p as vt,He as w,Ge as x,i as xt,dt as y,l as yt,ve as z};